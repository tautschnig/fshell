/*******************************************************************\

Module: Main Module 

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <fstream>
#include <memory>

#include <config.h>

#include <goto-programs/read_goto_binary.h>
#include <goto-programs/goto_function_pointers.h>
#include <goto-programs/loop_numbers.h>

#include "parseoptions.h"
#include "cover.h"
#include "version.h"
#include "show_goals.h"

/*******************************************************************\

Function: cover_parseoptionst::set_verbosity

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

cover_parseoptionst::cover_parseoptionst(int argc, const char **argv):
  parseoptions_baset(COVER_OPTIONS, argc, argv),
  language_uit("COVER " COVER_VERSION, cmdline)
{
}

/*******************************************************************\

Function: cover_parseoptionst::set_verbosity

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_parseoptionst::set_verbosity(message_clientt &message_client)
{
  int v=8;
  
  if(cmdline.isset("verbosity"))
  {
    v=atoi(cmdline.getval("verbosity"));
    if(v<0)
      v=0;
    else if(v>9)
      v=9;
  }
  
  message_client.set_verbosity(v);
}

/*******************************************************************\

Function: cover_parseoptionst::get_command_line_options

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_parseoptionst::get_command_line_options(optionst &options)
{
  if(config.set(cmdline))
  {
    usage_error();
    exit(1);
  }

  if(cmdline.isset("arrays-uf-always"))
    options.set_option("arrays-uf", "always");
  else if(cmdline.isset("arrays-uf-never"))
    options.set_option("arrays-uf", "never");
  else
    options.set_option("arrays-uf", "auto");

  if(cmdline.isset("refine"))
    options.set_option("refine", true);

  if(cmdline.isset("boolector"))
    options.set_option("boolector", true);

  if(cmdline.isset("cvc"))
    options.set_option("cvc", true);

  if(cmdline.isset("smt"))
    options.set_option("smt1", true);

  if(cmdline.isset("smt2"))
    options.set_option("smt2", true);

  if(cmdline.isset("yices"))
    options.set_option("yices", true);

  if(cmdline.isset("z3"))
    options.set_option("z3", true);

  if(cmdline.isset("outfile"))
    options.set_option("outfile", cmdline.getval("outfile"));
    
  if(cmdline.isset("unwind"))
    options.set_option("unwind", cmdline.getval("unwind"));
}

/*******************************************************************\

Function: cover_parseoptionst::doit

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int cover_parseoptionst::doit()
{
  if(cmdline.isset("version"))
  {
    std::cout << COVER_VERSION << std::endl;
    return 0;
  }

  register_languages();

  goto_functionst goto_functions;
  covert cover(context, goto_functions, ui_message_handler);

  //
  // command line options
  //

  get_command_line_options(cover.options);

  set_verbosity(cover);
  set_verbosity(*this);

  if(get_goto_program(goto_functions))
    return 6;

  if(cmdline.isset("show-goals"))
  {
    const namespacet ns(context);
    show_goals(ns, get_ui(), goto_functions);
    return 0;
  }

  // do actual TCG
  return cover();
}

/*******************************************************************\

Function: cover_parseoptionst::get_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/
  
bool cover_parseoptionst::get_goto_program(
  goto_functionst &goto_functions)
{
  if(cmdline.args.size()==0)
  {
    error("Please provide a program for TCG");
    return true;
  }

  status("Reading GOTO program from file");

  try
  {
    const std::string file=cmdline.args.front();
  
    ::read_goto_binary(
      file, context, goto_functions, get_message_handler());

    namespacet ns(context);

    status("Function Pointer Removal");
    remove_function_pointers(goto_functions);

    // recalculate numbers, etc.
    goto_functions.update();

    // add loop ids
    goto_functions.compute_loop_numbers();

    // show it?
    if(cmdline.isset("show-goto-functions"))
    {
      goto_functions.output(ns, std::cout);
      return true;
    }
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  catch(std::bad_alloc)
  {
    error("Out of memory");
    return true;
  }
  
  return false;
}

/*******************************************************************\

Function: cover_parseoptionst::help

  Inputs:

 Outputs:

 Purpose: display command line help

\*******************************************************************/

void cover_parseoptionst::help()
{
  std::cout <<
    "\n"
    "* *           COVER " COVER_VERSION " - Copyright (C) 2009-2010           * *\n"
    "* *                     Daniel Kroening                     * *\n"
    "* *       University of Oxford, Computing Laboratory        * *\n"
    "* *                 kroening@kroening.com                   * *\n"
    "\n"
    "Usage:                       Purpose:\n"
    "\n"
    " cover [-?] [-h] [--help]     show help\n"
    " cover file                   goto-binary file name\n"
    "\n"
    "Additonal options:\n"
    " --criterion ID               set coverage criterion\n"
    " --function name              set main function name\n"
    " --show-goals                 only show test goals\n"
    " --goal id                    only do specific test goal\n"
    " --smt                        output subgoals in SMT syntax (experimental)\n"
    " --boolector                  use Boolector (experimental)\n"
    " --cvc                        use CVC3 (experimental)\n"
    " --yices                      use Yices (experimental)\n"
    " --z3                         use Z3 (experimental)\n"
    " --refine                     use refinement procedure (experimental)\n"
    " --outfile Filename           output subgoals to given file\n"
    " --show-goto-functions        show goto program\n"
    " --arrays-uf-never            never turn arrays into uninterpreted functions\n"
    " --arrays-uf-always           always turn arrays into uninterpreted functions\n"
    " --interpreter                do concrete execution\n"
    " --version                    show current COVER version and exit\n"
    " --xml-ui                     use XML-formatted output\n"
    "\n";
}
