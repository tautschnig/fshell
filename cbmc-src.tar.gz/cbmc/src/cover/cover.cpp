/*******************************************************************\

Module: Test Case Generation

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "cover.h"

/*******************************************************************\

Function: covert::collect_targets

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void covert::collect_targets()
{
}

/*******************************************************************\

Function: covert::cover_attempt

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void covert::cover_attempt(unsigned depth)
{
  str << "Depth: " << depth;
  status();
}

/*******************************************************************\

Function: covert::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

int covert::operator()()
{
  try
  {
    collect_targets();

    unsigned depth=0;
    covered=unreachable=0;
    total=targets.size();

    while(!targets.empty())
    {
      depth++;

      cover_attempt(depth);
    }
    
    str << total << " targets, " << covered << " covered, "
        << unreachable << " unreachable";
    status();

    result("DONE");
  }

  catch(const char *e)
  {
    error(e);
    return 1;
  }

  catch(const std::string e)
  {
    error(e);
    return 1;
  }
  
  catch(int)
  {
    return 1;
  }
  
  return 0;
}
