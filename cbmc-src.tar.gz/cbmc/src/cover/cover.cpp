/*******************************************************************\

Module: Test Case Generation

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "cover.h"
#include "cover_bmc.h"
#include "goal.h"

/*******************************************************************\

Function: covert::collect_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void covert::collect_goals()
{
  covered=unsatisfiable=0;
    
  // find the coverage goals there are
  
  forall_goto_functions(f_it, goto_functions)
  {
    forall_goto_program_instructions(i_it, f_it->second.body)
      if(is_goal(i_it))
      {
        coverage_goals.push_back(coverage_goalt());
        coverage_goals.back().pc=i_it;
      }
  }
  
  str << "Found " << coverage_goals.size() << " goal(s)";
  status();
}

/*******************************************************************\

Function: covert::cover_attempt

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void covert::cover_attempt(unsigned unwind)
{
  str << "Number of unwindings: " << unwind;
  status();
  
  cover_bmct cover_bmc(context, get_message_handler());
  cover_bmc.options=options;
  cover_bmc.set_verbosity(get_verbosity());
  cover_bmc.options.set_option("assertions", true);
  cover_bmc.options.set_option("assumptions", true);
  cover_bmc.options.set_option("simplify", true);
  cover_bmc.options.set_option("substitution", true);
  
  cover_bmc(goto_functions, unwind, coverage_goals);
}

/*******************************************************************\

Function: covert::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

int covert::operator()()
{
  try
  {
    collect_goals();
    
    if(coverage_goals.size()==0)
      return 0;

    unsigned unwind=options.get_int_option("unwind");

    cover_attempt(unwind);
    
    /*
    str << "Final result: "
        << coverage_goals.size() << " goals, " << covered << " covered, "
        << unsatisfiable << " unsatisfiable";
    status();
    */
  }

  catch(const char *e)
  {
    error(e);
    return 1;
  }

  catch(const std::string e)
  {
    error(e);
    return 1;
  }
  
  catch(int)
  {
    return 1;
  }
  
  return 0;
}
