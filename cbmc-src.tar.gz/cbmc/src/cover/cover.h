/*******************************************************************\

Module: Test Case Generation for ANSI-C

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_COVER_H
#define CPROVER_COVER_H

#include <message_stream.h>
#include <context.h>
#include <options.h>

#include <langapi/language_ui.h>
#include <goto-programs/goto_functions.h>

class covert:public message_streamt
{
public:
  covert(
    const contextt &_context,
    const goto_functionst &goto_functions,
    message_handlert &_message_handler):
    message_streamt(_message_handler),
    context(_context),
    goto_functions(goto_functions),
    ui(ui_message_handlert::PLAIN)
  {
  }
 
  optionst options;
  
  virtual int operator()();
  virtual ~covert() { }

  void set_ui(language_uit::uit _ui) { ui=_ui; }
  
protected:
  const contextt &context;
  const goto_functionst &goto_functions;
 
  // use gui format
  language_uit::uit ui;
  
  // targets
  void collect_targets();

  // target statistics
  unsigned covered, unsatisfiable;

  void cover_attempt(unsigned unwind);
  
  class coverage_targett
  {
  public:
    goto_programt::const_targett pc;
  };
  
  typedef std::vector<coverage_targett> coverage_targetst;
  coverage_targetst coverage_targets;
};

#endif
