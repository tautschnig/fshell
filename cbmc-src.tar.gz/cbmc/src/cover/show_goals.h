/*******************************************************************\

Module: Show goals

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_GOTO_PROGRAMS_SHOW_GOALS_H
#define CPROVER_GOTO_PROGRAMS_SHOW_GOALS_H

#include <ui_message.h>
#include <namespace.h>

#include <goto-programs/goto_functions.h>

void show_goals(
  const namespacet &ns,
  ui_message_handlert::uit ui,
  const goto_functionst &goto_functions);

#endif
