/*******************************************************************\

Module: Goals

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "goal.h"

// defined in ../goto-symex/builtin_functions.cpp
irep_idt get_string_argument(const exprt &src);

/*******************************************************************\

Function: is_goal

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool is_goal(
  const goto_programt::const_targett &pc)
{
  if(!pc->is_other()) return false;
  
  if(pc->code.get_statement()!="output") return false;
  
  if(pc->code.operands().size()!=2) return false;
  
  if(get_string_argument(pc->code.op0())!="cover") return false;
  
  return true;
}
