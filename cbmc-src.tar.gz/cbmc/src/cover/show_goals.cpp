/*******************************************************************\

Module: Show Goals

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <xml.h>
#include <i2string.h>
#include <xml_irep.h>

#include <langapi/language_util.h>

#include "show_goals.h"
#include "goal.h"

// defined in ../goto-symex/builtin_functions.cpp
irep_idt get_string_argument(const exprt &src);

/*******************************************************************\

Function: show_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void show_goals(
  const namespacet &ns,
  const irep_idt &identifier,
  ui_message_handlert::uit ui,
  const goto_programt &goto_program,
  std::map<irep_idt, unsigned> &goal_counter)
{
  for(goto_programt::instructionst::const_iterator
      it=goto_program.instructions.begin();
      it!=goto_program.instructions.end();
      it++)
  {
    if(!is_goal(it))
      continue;
      
    const locationt &location=it->location;
    const irep_idt &function=location.get_function();
      
    unsigned &count=goal_counter[function];
    
    count++;

    std::string goal_name=
      function==""?i2string(count):
      id2string(function)+"."+i2string(count);
    
    switch(ui)
    {
    case ui_message_handlert::XML_UI:
      {
        xmlt xml("goal");
        xml.new_element("name").data=goal_name;
        
        xmlt &l=xml.new_element();
        convert(it->location, l);
        l.name="location";
        
        l.new_element("line").data=id2string(location.get_line());
        l.new_element("file").data=id2string(location.get_file());
        l.new_element("function").data=id2string(location.get_function());
        
        xml.new_element("expression").data=
          xmlt::escape(from_expr(ns, identifier, it->code.op1()));
          
        std::cout << xml << std::endl;
      }
      break;
      
    case ui_message_handlert::PLAIN:
      std::cout << "Goal " << goal_name << ":" << std::endl;

      std::cout << "  " << it->location << std::endl
                << "  " << from_expr(ns, identifier, it->code.op1())
                << std::endl
                << std::endl;
      break;

    default:
      assert(false);
    }
  }
}

/*******************************************************************\

Function: show_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void show_goals(
  const namespacet &ns,
  ui_message_handlert::uit ui,
  const goto_functionst &goto_functions)
{
  std::map<irep_idt, unsigned> count;

  for(goto_functionst::function_mapt::const_iterator
      it=goto_functions.function_map.begin();
      it!=goto_functions.function_map.end();
      it++)
    if(!it->second.is_inlined())
      show_goals(ns, it->first, ui, it->second.body, count);
}
