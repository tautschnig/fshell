/*******************************************************************\

Module: Test-Vector Generation with Bounded Model Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_COVER_BMC_H
#define CPROVER_COVER_BMC_H

#include <list>
#include <map>

#include <hash_cont.h>
#include <options.h>

#include <solvers/prop/prop.h>
#include <solvers/prop/prop_conv.h>
#include <solvers/sat/cnf.h>
#include <solvers/sat/satcheck.h>
#include <solvers/smt1/smt1_dec.h>
#include <solvers/smt2/smt2_dec.h>
#include <langapi/language_ui.h>
#include <goto-symex/symex_target_equation.h>

#include <cbmc/symex_bmc.h>

class cover_bmct:public messaget
{
public:
  cover_bmct(
    const contextt &_context,
    message_handlert &_message_handler):
    messaget(_message_handler),
    ns(_context, new_context),
    equation(ns),
    symex(ns, new_context, equation)
  {
  }
 
  ~cover_bmct() { }

  optionst options;

  void operator()(
    const goto_functionst &goto_functions, unsigned depth);

protected:
  contextt new_context;
  namespacet ns;
  symex_target_equationt equation;
  symex_bmct symex;
 
  decision_proceduret::resultt
    run_decision_procedure(prop_convt &prop_conv);
    
  void decide();
  void show_trace(prop_convt &prop_conv);
};

#endif
