int main()
{
  int x, y;

  x=3;

  __CPROVER_input("i1", x, y, .5);
  __CPROVER_output("o1", x, y, .3);
  __CPROVER_cover("o1");
  printf("Muh: %05d xxx\n", x);
}

