/*******************************************************************\

Module: Test-Vector Genertation with Bounded Model Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <arith_tools.h>
#include <ieee_float.h>

#include "mogentes_xml.h"

/*******************************************************************\

Function: mogentes_test_case_xml

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void mogentes_test_case_xml(
  const namespacet &ns,
  const goto_tracet &src,
  xmlt &dest)
{
  dest=xmlt("AbstractTestCase");
  
  dest.set_attribute("root", 0);
  
  unsigned counter=0;

  for(goto_tracet::stepst::const_iterator 
      s_it=src.steps.begin();  
      s_it!=src.steps.end();
      s_it++)
    if(s_it->is_input())
    {
      counter++;
      xmlt &transition=dest.new_element("Transition");
      
      transition.set_attribute(
        "event",
        xmlt::escape_attribute("in_"+id2string(s_it->io_id)));
        
      transition.set_attribute("source", counter-1);
      transition.set_attribute("target", counter);

      for(goto_trace_stept::io_argst::const_iterator
          io_it=s_it->io_args.begin();
          io_it!=s_it->io_args.end();
          io_it++)
      {
        xmlt &argument=transition.new_element();

        const exprt &expr=*io_it;
        const typet &type=expr.type();
        
        if(type.id()=="unsignedbv" ||
           type.id()=="signedbv")
        {
          mp_integer value;
          to_integer(expr, value);
          argument.name="IntArgument";
          argument.data=integer2string(value);
        }
        else if(type.id()=="bool")
        {
          argument.name="IntArgument";
          argument.data=expr.is_true()?"1":"0";
        }
        else if(type.id()=="floatbv")
        {
          argument.name="RealArgument";
          argument.data=xmlt::escape(ieee_floatt(expr).to_ansi_c_string());
        }
        else
        {
          argument.name="OtherArgument";
          argument.data=xmlt::escape(from_expr(ns, "", expr));
        }
      }
    }
}
