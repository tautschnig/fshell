/*******************************************************************\

Module: Goals

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_GOAL_H
#define CPROVER_GOAL_H

#include <goto-programs/goto_program.h>
  
class coverage_goalt
{
  public:
    goto_programt::const_targett pc;
};

typedef std::vector<coverage_goalt> coverage_goalst;

bool is_goal(const goto_programt::const_targett &pc);

#endif
