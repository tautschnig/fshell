/*******************************************************************\

Module: Test-Vector Generation with Bounded Model Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_MOGENTES_XML_H
#define CPROVER_MOGENTES_XML_H

#include <util/xml.h>
#include <goto-symex/goto_trace.h>

void mogentes_test_case_xml(
  const namespacet &ns,
  const goto_tracet &src,
  xmlt &dest);

#endif
