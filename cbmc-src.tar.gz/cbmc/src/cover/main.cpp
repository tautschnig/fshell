/*******************************************************************\

Module: Main Module 

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

/*

  COVER
  Automatic Test Case Generation
  Copyright (C) 2009 Daniel Kroening <kroening@kroening.com>

*/

#include "parseoptions.h"

/*******************************************************************\

Function: main

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

int main(int argc, const char **argv)
{
  cover_parseoptionst parseoptions(argc, argv);
  return parseoptions.main();
}
