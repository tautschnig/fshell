/*******************************************************************\

Module: Test-Vector Genertation with Bounded Model Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <sstream>
#include <fstream>

#include <i2string.h>
#include <location.h>
#include <time_stopping.h>
#include <message_stream.h>

#include <langapi/mode.h>
#include <langapi/languages.h>
#include <langapi/language_util.h>

#include <ansi-c/ansi_c_language.h>

#include <goto-symex/goto_trace.h>
#include <goto-symex/build_goto_trace.h>
#include <goto-symex/slice.h>
#include <goto-symex/slice_by_trace.h>
#include <goto-symex/xml_goto_trace.h>

#include <solvers/sat/satcheck.h>

#include <solvers/flattening/bv_pointers.h>

#include "cover_bmc.h"

/*******************************************************************\

Function: cover_bmct::run_decision_procedure

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

decision_proceduret::resultt
cover_bmct::run_decision_procedure(prop_convt &prop_conv)
{
  status("Passing problem to "+prop_conv.decision_procedure_text());

  prop_conv.set_message_handler(get_message_handler());
  prop_conv.set_verbosity(get_verbosity());

  // stop the time
  fine_timet sat_start=current_time();

  equation.convert(prop_conv);

  status("Running "+prop_conv.decision_procedure_text());

  decision_proceduret::resultt dec_result=prop_conv.dec_solve();
  // output runtime

  {
    std::ostringstream str;
    fine_timet sat_stop=current_time();

    str << "Runtime decision procedure: ";
    output_time(sat_stop-sat_start, str);
    str << "s";
    status(str.str());
  }

  return dec_result;
}

/*******************************************************************\

Function: cover_bmct::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::operator()(
  const goto_functionst &goto_functions,
  unsigned unwind)
{
  symex.set_message_handler(get_message_handler());
  symex.set_verbosity(get_verbosity());
  symex.options=options;
  
  status("Starting Bounded Model Checking");

  symex.last_location.make_nil();
  symex.max_unwind=unwind;

  try
  {
    symex(goto_functions);
  }

  catch(std::string &error_str)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return;
  }

  catch(const char *error_str)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return;
  }

  catch(std::bad_alloc)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.error("Out of memory");
    return;
  }

  statistics("size of program expression: "+
             i2string(equation.SSA_steps.size())+
             " assignments");

  try
  {
    if(options.get_option("slice-by-trace")!="")
    {
      symex_slice_by_tracet symex_slice_by_trace(ns);

      symex_slice_by_trace.slice_by_trace
	(options.get_option("slice-by-trace"), equation);
    }

    if(options.get_bool_option("slice-formula"))
    {
      slice(equation);
      print(8, "slicing removed "+
        i2string(equation.count_ignored_SSA_steps())+" assignments");
    }
    else
    {
      simple_slice(equation);
      print(8, "simple slicing removed "+
        i2string(equation.count_ignored_SSA_steps())+" assignments");
    }

    {
      std::string msg;
      msg="Generated "+i2string(symex.total_claims)+
          " VCC(s), "+i2string(symex.remaining_claims)+
          " remaining after simplification";
      print(8, msg);
    }

    if(symex.remaining_claims==0)
    {
      //report_success();
      return;
    }

    decide();
  }

  catch(std::string &error_str)
  {
    error(error_str);
    return;
  }

  catch(const char *error_str)
  {
    error(error_str);
    return;
  }

  catch(std::bad_alloc)
  {
    error("Out of memory");
    return;
  }
}

/*******************************************************************\

Function: cover_bmct::decide

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::decide()
{
  satcheckt satcheck;
  satcheck.set_message_handler(get_message_handler());
  satcheck.set_verbosity(get_verbosity());
  
  bv_pointerst bv_pointers(ns, satcheck);
  
  if(options.get_option("arrays-uf")=="never")
    bv_pointers.unbounded_array=bv_pointerst::U_NONE;
  else if(options.get_option("arrays-uf")=="always")
    bv_pointers.unbounded_array=bv_pointerst::U_ALL;

  switch(run_decision_procedure(bv_pointers))
  {
  case decision_proceduret::D_UNSATISFIABLE:
    break;

  case decision_proceduret::D_SATISFIABLE:
    show_trace(bv_pointers);
    break;

  default:
    error("decision procedure failed");
  }
}

/*******************************************************************\

Function: cover_bmct::show_trace

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::show_trace(prop_convt &prop_conv)
{
  goto_tracet goto_trace;
  build_goto_trace(equation, prop_conv, goto_trace);
  
  std::string result="Input vector:";

  for(goto_tracet::stepst::const_iterator 
      s_it=goto_trace.steps.begin();  
      s_it!=goto_trace.steps.end();
      s_it++)
    if(s_it->is_input())
    {
      if(s_it->io_args.size()==1)
        result+=" "+id2string(s_it->io_id)+"="+
                from_expr(ns, "", s_it->io_args.front());
    }
    
  status(result);
  
  std::string outfile_name=options.get_option("outfile");
  if(outfile_name!="")
  {
    std::ofstream outfile(outfile_name.c_str());
  
    xmlt tv("test-vector");

    for(goto_tracet::stepst::const_iterator 
        s_it=goto_trace.steps.begin();  
        s_it!=goto_trace.steps.end();
        s_it++)
      if(s_it->is_input())
        if(s_it->io_args.size()==1)
        {
          xmlt &input=tv.new_element("input");
          input.new_element("id").data=xmlt::escape(id2string(s_it->io_id));
          input.new_element("value").data=xmlt::escape(from_expr(ns, "", s_it->io_args.front()));
        }
        
    outfile << tv;
  }
}
