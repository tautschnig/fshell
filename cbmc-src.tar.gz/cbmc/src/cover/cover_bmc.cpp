/*******************************************************************\

Module: Test-Vector Genertation with Bounded Model Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <sstream>
#include <fstream>

#include <i2string.h>
#include <location.h>
#include <time_stopping.h>
#include <message_stream.h>

#include <langapi/mode.h>
#include <langapi/languages.h>
#include <langapi/language_util.h>

#include <ansi-c/ansi_c_language.h>

#include <goto-symex/goto_trace.h>
#include <goto-symex/build_goto_trace.h>
#include <goto-symex/slice.h>
#include <goto-symex/slice_by_trace.h>
#include <goto-symex/xml_goto_trace.h>

#include <solvers/sat/satcheck.h>
#include <solvers/sat/cnf_clause_list.h>

#include <solvers/flattening/bv_pointers.h>

#include "cover_bmc.h"
#include "mogentes_xml.h"

/*******************************************************************\

Function: cover_bmct::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::operator()(
  const goto_functionst &goto_functions,
  unsigned unwind,
  const coverage_goalst &goals)
{
  coverage_goals = &goals;

  symex.set_message_handler(get_message_handler());
  symex.set_verbosity(get_verbosity());
  symex.options=options;
  
  status("Starting Bounded Model Checking");

  symex.last_location.make_nil();
  symex.max_unwind=unwind;

  try
  {
    symex(goto_functions);
  }

  catch(std::string &error_str)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return;
  }

  catch(const char *error_str)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return;
  }

  catch(std::bad_alloc)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.error("Out of memory");
    return;
  }

  statistics("size of program expression: "+
             i2string(equation.SSA_steps.size())+
             " assignments");

  try
  {
    if(options.get_bool_option("slice-formula"))
    {
      slice(equation);
      print(8, "slicing removed "+
        i2string(equation.count_ignored_SSA_steps())+" assignments");
    }
    else
    {
      simple_slice(equation);
      print(8, "simple slicing removed "+
        i2string(equation.count_ignored_SSA_steps())+" assignments");
    }

    #if 0
    {
      std::string msg;
      msg="Generated "+i2string(symex.total_claims)+
          " VCC(s), "+i2string(symex.remaining_claims)+
          " remaining after simplification";
      print(8, msg);
    }
    #endif

    run_decision_procedure();
  }

  catch(std::string &error_str)
  {
    error(error_str);
    return;
  }

  catch(const char *error_str)
  {
    error(error_str);
    return;
  }

  catch(std::bad_alloc)
  {
    error("Out of memory");
    return;
  }
}

/*******************************************************************\

Function: cover_bmct::run_decision_procedure

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::run_decision_procedure()
{
  cnf_clause_list_assignmentt cnf;
  cnf.set_message_handler(get_message_handler());
  cnf.set_verbosity(get_verbosity());
  
  bv_pointerst bv_pointers(ns, cnf);
  
  if(options.get_option("arrays-uf")=="never")
    bv_pointers.unbounded_array=bv_pointerst::U_NONE;
  else if(options.get_option("arrays-uf")=="always")
    bv_pointers.unbounded_array=bv_pointerst::U_ALL;
    
  prop_convt &prop_conv=bv_pointers;

  status("Passing problem to "+prop_conv.decision_procedure_text());

  prop_conv.set_message_handler(get_message_handler());
  prop_conv.set_verbosity(get_verbosity());

  // stop the time
  fine_timet sat_start=current_time();

  equation.convert(prop_conv);

  status("Running "+prop_conv.decision_procedure_text());
  
  iterative_constraint_strengthening(bv_pointers, cnf);

  {
    // output runtime
    std::ostringstream str;
    fine_timet sat_stop=current_time();

    str << "Runtime decision procedure: ";
    output_time(sat_stop-sat_start, str);
    str << "s";
    status(str.str());
  }
}

/*******************************************************************\

Function: cover_bmct::translate_test_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::translate_test_goals(cnf_clause_list_assignmentt & cnf, test_goal_literalst & dest)
{
#if 0
  typedef ::std::set< ::goto_programt::const_targett > coverage_goal_sett;
  coverage_goal_sett goals_as_set;
  for (coverage_goalst::const_iterator iter(coverage_goals->begin());
      iter != coverage_goals->end(); ++iter)
    goals_as_set.insert(iter->pc);
#endif

	// build a map from GOTO instructions to guard literals by walking the
	// equation
  typedef ::std::map< ::goto_programt::const_targett, 
            ::std::set< ::literalt > > pc_to_guardst;
  pc_to_guardst pc_to_guards;

	for (::symex_target_equationt::SSA_stepst::const_iterator iter( 
				equation.SSA_steps.begin() ); iter != equation.SSA_steps.end(); ++iter)
	{
		if (!is_goal(iter->source.pc)) continue;
		/*::goto_programt tmp;
		tmp.output_instruction(this->ns, "", ::std::cerr, iter->source.pc);
		iter->output(this->ns, ::std::cerr);*/
		pc_to_guards[ iter->source.pc ].insert(iter->guard_literal);
	}

  for (coverage_goalst::const_iterator iter(coverage_goals->begin());
      iter != coverage_goals->end(); ++iter)
  {
    ::bvt set;
    pc_to_guardst::const_iterator entry(pc_to_guards.find(iter->pc));
    // test goal need not exist, i.e., it may have been found unreachable after
    // constant propagation, slicing, etc.
    if (pc_to_guards.end() == entry) continue;

    for (::std::set< ::literalt >::const_iterator l_iter(entry->second.begin());
        l_iter != entry->second.end(); ++l_iter)
    {
      // unreachable
      if (l_iter->is_false() || l_iter->var_no() == ::literalt::unused_var_no()) continue;
      // we will always take this edge, a trivial goal
      if (l_iter->is_true()) {
        set.clear();
        // just make sure we have a single entry in there to get at
        // least one test case
        // ::std::cerr << "Adding true guard " << l_iter->var_no() << ::std::endl;
        set.push_back(*l_iter);
        break;
      }
      // ::std::cerr << "Adding guard " << l_iter->var_no() << ::std::endl;
      set.push_back(*l_iter);
    }
    
    if (!set.empty()) {
      // ::std::cerr << "Adding subgoal composed of " << set.size() << " guards" << ::std::endl;
      ::literalt const tg(cnf.lor(set));
      // ::std::cerr << "Subgoal " << tg.var_no() << " for ctx " << c_iter->first->location << ::std::endl;
      dest.insert(tg);
      /*for (Evaluate_Path_Monitor::test_goal_states_t::const_iterator s_iter(
        states.begin()); s_iter != states.end(); ++s_iter)
        m_state_context_tg_map[ *s_iter ].insert(::std::make_pair(c_iter->first, tg));
        */
    }
	}
}

/*******************************************************************\

Function: cover_bmct::iterative_constraint_strengthening

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::iterative_constraint_strengthening(boolbvt const& bv, cnf_clause_list_assignmentt & cnf)
{
  test_goal_literalst goal_set;
  translate_test_goals(cnf, goal_set);

	::std::map< ::literalt, ::literalt > aux_var_map;
	::bvt goal_cl;
	for (test_goal_literalst::const_iterator iter(goal_set.begin()); iter != goal_set.end(); ++iter) {
		::literalt s(cnf.new_variable());
		aux_var_map.insert(::std::make_pair(*iter, s));
		goal_cl.push_back(cnf.land(*iter, s));
	}
	cnf.lcnf(goal_cl);

	::satcheck_minisatt minisat;
	minisat.set_message_handler(cnf.get_message_handler());
	minisat.set_verbosity(cnf.get_verbosity());
	
	cnf.copy_to(minisat);

	status("Possibly feasible test goals: " + i2string(aux_var_map.size()));
  
  unsigned iteration=1;
  ::propt::resultt dec_result;
	::bvt goals_done;
  
	while (!aux_var_map.empty())
  {
    status("Iteration "+i2string(iteration++));
  
		minisat.set_assumptions(goals_done);
    dec_result=minisat.prop_solve();
		if (::propt::P_UNSATISFIABLE == dec_result) break;
    else if (::propt::P_SATISFIABLE != dec_result) {
      error("decision procedure failed");
      break;
    }

		cnf.copy_assignment_from(minisat);
    show_trace(bv);
  
		// keep all test cases
		// tcs.push_back(::cnf_clause_list_assignmentt());
		// tcs.back().set_no_variables(cnf.no_variables());
		// tcs.back().copy_assignment_from(minisat);

		// deactivate test goals
		unsigned const size1(aux_var_map.size());
		for (::std::map< ::literalt, ::literalt >::iterator iter(aux_var_map.begin());
				iter != aux_var_map.end();) {
			assert(minisat.l_get(iter->first).is_known());
			if (minisat.l_get(iter->first).is_false()) {
				++iter;
				continue;
			}
			// test goal is done
			// ::std::cerr << "Goal " << iter->first.var_no() << " sat" << ::std::endl;
			goals_done.push_back(::neg(iter->second));
			aux_var_map.erase(iter++);
		}

		status("Covers " + i2string(size1 - aux_var_map.size()) + " test goals");
	}
	
  // ::std::cerr << "#Test cases: " << tcs.size() << ::std::endl;
  status("Infeasible test goals: " + i2string(aux_var_map.size()));
}

/*******************************************************************\

Function: cover_bmct::show_trace

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void cover_bmct::show_trace(prop_convt const&prop_conv)
{
  goto_tracet goto_trace;
  build_goto_trace(equation, prop_conv, goto_trace);
  
  std::string result="Input vector:";

  for(goto_tracet::stepst::const_iterator 
      s_it=goto_trace.steps.begin();  
      s_it!=goto_trace.steps.end();
      s_it++)
    if(s_it->is_input())
    {
      if(s_it->io_args.size()==1)
        result+=" "+id2string(s_it->io_id)+"="+
                from_expr(ns, "", s_it->io_args.front());
    }
    
  status(result);
  
  std::string outfile_name=options.get_option("outfile");
  if(outfile_name!="")
  {
    std::ofstream outfile(outfile_name.c_str());
  
    xmlt tc;
    mogentes_test_case_xml(ns, goto_trace, tc);

    outfile << tc;
  }
}
