/*******************************************************************\

Module: Command Line Parsing

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_COVER_PARSEOPTIONS_H
#define CPROVER_COVER_PARSEOPTIONS_H

#include <ui_message.h>
#include <parseoptions.h>
#include <options.h>

#include <langapi/language_ui.h>
#include <goto-programs/goto_functions.h>

#define COVER_OPTIONS \
  "(function):(no-simplify)" \
  "(debug-level):(no-substitution)(no-simplify-if)" \
  "(outfile):D:I:(depth):(xml-ui)" \
  "(cvc)(smt)(smt2)(boolector)(yices)(z3)" \
  "(dimacs)(16)(32)(64)(little-endian)(big-endian)(refine)" \
  "(show-goto-functions)(show-symbol-table)(show-targets)(target):" \
  "(cover-label):(verbosity):(version)(criterion):" \
  "(arrays-uf-always)(arrays-uf-never)"

class cover_parseoptionst:
  public parseoptions_baset,
  public language_uit
{
public:
  virtual int doit();
  virtual void help();

  cover_parseoptionst(int argc, const char **argv);

protected:
  virtual void register_languages();

  virtual void get_command_line_options(optionst &options);

  bool get_goto_program(goto_functionst &goto_functions);

  void set_verbosity(message_clientt &message_client);
};

#endif
