int main(int argc, char * argv[]) {
  __CPROVER_input("argc", 5);
  if (argc > 5) {
  __CPROVER_cover("bla");
  } else {
  __CPROVER_cover("bla2");
  }

  __CPROVER_cover("bla3");
  return 0;
}

