/*******************************************************************\

Module: Set Claims

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <i2string.h>
#include <hash_cont.h>

#include "set_goals.h"

/*******************************************************************\

Function: set_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void set_goals(
  goto_programt &goto_program,
  std::map<irep_idt, unsigned> &goal_counters,
  hash_set_cont<std::string, string_hash> &goal_set)
{
  for(goto_programt::instructionst::iterator
      it=goto_program.instructions.begin();
      it!=goto_program.instructions.end();
      it++)
  {
    if(!it->is_assert()) continue;
    
    irep_idt function=it->location.get_function();
    unsigned &count=goal_counters[function];
    
    count++;
    
    std::string goal_name=
      function==""?i2string(count):
      id2string(function)+"."+i2string(count);
    
    hash_set_cont<std::string, string_hash>::iterator
      c_it=goal_set.find(goal_name);
      
    if(c_it==goal_set.end())
      it->type=SKIP;
    else
      goal_set.erase(c_it);
  }
}

/*******************************************************************\

Function: set_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void set_goals(
  goto_programt &goto_program,
  const std::list<std::string> &goals)
{
  hash_set_cont<std::string, string_hash> goal_set;
  std::map<irep_idt, unsigned> goal_counters;
  
  for(std::list<std::string>::const_iterator
      it=goals.begin();
      it!=goals.end();
      it++)
    goal_set.insert(*it);

  set_goals(goto_program, goal_counters, goal_set);
  
  if(!goal_set.empty())
    throw "goal "+(*goal_set.begin())+" not found";
}

/*******************************************************************\

Function: set_goals

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void set_goals(
  goto_functionst &goto_functions,
  const std::list<std::string> &goals)
{
  hash_set_cont<std::string, string_hash> goal_set;
  std::map<irep_idt, unsigned> goal_counters;

  for(std::list<std::string>::const_iterator
      it=goals.begin();
      it!=goals.end();
      it++)
    goal_set.insert(*it);

  for(goto_functionst::function_mapt::iterator
      it=goto_functions.function_map.begin();
      it!=goto_functions.function_map.end();
      it++)
    if(!it->second.is_inlined())
      set_goals(it->second.body, goal_counters, goal_set);

  if(!goal_set.empty())
    throw "goal "+(*goal_set.begin())+" not found";
}
