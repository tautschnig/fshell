/*******************************************************************\

Module: Set goals

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_GOTO_PROGRAMS_SET_GOALS_H
#define CPROVER_GOTO_PROGRAMS_SET_GOALS_H

#include <goto-programs/goto_functions.h>

void set_goal(
  goto_functionst &goto_functions,
  const std::list<std::string> &goals);

#endif
