/*******************************************************************\

Module: Simplify CFG class

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef SIMPLIFY_CFG_CLASS_H
#define SIMPLIFY_CFG_CLASS_H

#include <replace_expr.h>
#include <find_expr.h>

#include <std_code.h>

class simplify_cfgt 
{
public:
  simplify_cfgt(
    const inv_generatort& _inv, 
    const namespacet& _ns) 
    : inv(_inv), ns(_ns) { }

  void simplify_cfg(CFGt& c);
  void simplify_cfg_node(CFG_nodet& n);

protected:
  const inv_generatort& inv;
  const namespacet& ns;

  void get_replace_map_from_inv(
    const exprt& inv, 
    replace_mapt& repl_map);

  void simplify_indices_only(const replace_mapt& repl_map, exprt& e);

  bool is_constant(const exprt& e);
  
  const exprt& get_assigned_symbol(const exprt& lhs);

  void get_used_symbols(const exprt& lhs, expr_sett& used_symbols);
};

#endif
