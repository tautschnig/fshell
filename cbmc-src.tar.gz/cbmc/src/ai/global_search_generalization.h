/*******************************************************************\

Module: Proof generalization using search on the whole program

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef GLOBAL_SEARCH_GENERALIZATION_H
#define GLOBAL_SEARCH_GENERALIZATION_H

#include "proof_generalization.h"

#include "abstr_env.h"
#include "domains/interval_var_domain.h"

class global_search_generalizationt : public proof_generalizationt
{
public:
  global_search_generalizationt(
    abstr_fwd_analysist& _analysis,
    abstr_env_domaint& _env_domain,
    interval_var_domaint& _var_domain,
    abstr_elementt& _initial)
    : proof_generalizationt(_analysis),
      env_domain(_env_domain),
      var_domain(_var_domain),
      initial(_initial)
  { }
  
  virtual void generalize();

  virtual ~global_search_generalizationt() { }

protected:
  abstr_env_domaint& env_domain;
  interval_var_domaint& var_domain;
  abstr_elementt& initial;
};

#endif 
