
#include "abstr_domain_mem.h"
#include <iostream>


class test_datat 
{
public:
  static int counter;
  test_datat() { counter++; }
  test_datat(const test_datat&) { counter++; }
  test_datat& operator=(const test_datat&) { counter ++; return *this; }
  ~test_datat() { counter--; }

  int x;
};

int test_datat::counter = 0;

class abstr_domain_memtestt : public abstr_domain_memt<test_datat>
{
public:
  virtual abstr_elementt top() { return new_elem(new test_datat); }
  virtual abstr_elementt bot()  { return new_elem(new test_datat); }

  virtual bool is_top(const abstr_elementt& e) { return true; }

  virtual bool is_bot(const abstr_elementt& e) { return true; }

  const test_datat& get_td(const abstr_elementt& e)
  { return read(e); }

  test_datat& get_td(abstr_elementt& e)
  { return write(e); }

  virtual bool leq(const abstr_elementt& a, const abstr_elementt& b) 
  { return true; }
  
  virtual void
    meet_inplace(test_datat& a, const test_datat& e) 
  {  }

  virtual void
    join_inplace(test_datat& a, const test_datat& e) 
  {  }

  virtual void
    widen_inplace(test_datat& a, const test_datat& e, 
                  const test_datat& threshold) 
  { }

  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      test_datat& a, 
      const exprt& lhs, 
      const exprt& rhs) 
  { }

  //return result of applying test for c expression
  virtual void apply_test_inplace(
      test_datat& a, 
      const exprt& e,
      bool result) 
  { }

  virtual std::string to_string(const abstr_elementt& a) 
  { return ""; }

  virtual exprt to_expr(const abstr_elementt& a) 
  { return exprt(); }

  //get initial element, before program starts
  virtual abstr_elementt get_initial() { return top(); }

  //virtual destructor
  virtual ~abstr_domain_memtestt() { }

};

void test(abstr_domain_memtestt& m)
{
  abstr_elementt a = m.top();
  abstr_elementt b = m.bot();
  std::cout << test_datat::counter << std::endl;
  a.join(b);
  std::cout << test_datat::counter << std::endl;
  abstr_elementt c = a;
  std::cout << test_datat::counter << std::endl;
  c.meet(b);
  std::cout << test_datat::counter << std::endl;
  c = b;
  std::cout << test_datat::counter << std::endl;
  c.meet(a);
  std::cout << test_datat::counter << std::endl;
}

void test2(abstr_domain_memtestt& m)
{
  abstr_elementt a = m.top();
  m.get_td(a).x = 4;

  abstr_elementt b(a);
  m.get_td(b).x = 2;

  assert(m.get_td(a).x == 4);
}

int main(void)
{
  std::cout <<
  "===========================================" << std::endl <<
  "== UNIT TEST: abstr_domain_mem_test " << std::endl <<
  "===========================================" << std::endl;
  try{
  assert(test_datat::counter == 0);
  abstr_domain_memtestt m; 
  test(m);
  test2(m);
  assert(test_datat::counter == 0);
  } catch(const char* c)
  {
    std::cout << c << std::endl;
    assert(0);
  }
  std::cout <<
  "======================= UNIT TEST SUCCESSFUL " << std::endl;

  return 0;
}
