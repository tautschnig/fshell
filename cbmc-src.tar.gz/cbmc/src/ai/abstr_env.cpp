#include "abstr_env.h"

#include <negate_expr.h>

#include <sstream>
#include <memory>

/*******************************************************************\

Function: var_mapt::to_string
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string var_mapt::to_string() 
{
  if(is_bot())
    return "Bot";
  else if(empty())
    return "Top";

  std::stringstream ss;
  var_mapt::iterator it = begin();
  ss << "{ "  << it->first.get_identifier() << 
        " = " << it->second.to_string();

  for(++it; it != end(); ++it)
    if(!it->second.is_top())
      ss << ", " << it->first.get_identifier() 
         << " = " << it->second.to_string();

  ss << " }";
  return ss.str();
 
}

/*******************************************************************\

Function: abstr_env_domaint::meet_inplace
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::meet_inplace(var_mapt& v1, const var_mapt& v2)
{
  if(v1.is_bot()|| v2.is_bot())
  {
    v1.set_bot();
    return;
  }

  for(var_mapt::const_iterator v2_it = v2.begin(); v2_it != v2.end(); v2_it++)
  {

    var_mapt::iterator v1_it = v1.find(v2_it->first);

    if(v1_it == v1.end())
    {
      v1.insert(*v2_it);
    } else {
      v1_it->second.meet(v2_it->second);

      if(v1_it->second.is_bot())
      {
        v1.set_bot();
        return;
      }
    }

  }

}

/*******************************************************************\

Function: abstr_env_domaint::join_inplace
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::join_inplace(var_mapt& v1, const var_mapt& v2)
{ 
  if(v2.is_bot()) {
    return;
  } else if(v1.is_bot()) {
    v1 = v2;
    return;
  }  
  
  var_mapt result = var_mapt::top();

  for(var_mapt::const_iterator v2_it = v2.begin(); v2_it != v2.end(); v2_it++)
  {
    var_mapt::iterator v1_it = v1.find(v2_it->first);

    if(v1_it != v1.end())
    {
      std::pair<const symbol_exprt, var_elementt> 
        p(v2_it->first, v2_it->second);
      p.second.join(v1_it->second);
      if(!p.second.is_top())
        result.insert(p);
    }
  }

  result.swap(v1);

}

/*******************************************************************\

Function: abstr_env_domaint::widen_inplace
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::widen_inplace(
    var_mapt& v1, 
    const var_mapt& v2, 
    const var_mapt& threshold)
{
  if(v2.is_bot())
    return;

  if(v1.is_bot())
  {
    v1 = v2;
    return;
  }

  var_mapt result = var_mapt::top();
  for(var_mapt::const_iterator v2_it = v2.begin(); v2_it != v2.end(); v2_it++)
  {
    var_mapt::iterator v1_it = v1.find(v2_it->first);

    var_mapt::const_iterator thresh_it = threshold.find(v2_it->first);
    
    var_elementt var_thresh = (thresh_it != threshold.end()) ? 
                                  thresh_it->second :
                                  var_domain.top(v2_it->first.type());

    if(v1_it->second.geq(v2_it->second))
    { //if element is unchanged, do not widen
      result.insert(*v1_it);
    }
    else if(v1_it != v1.end())
    {
      var_mapt::iterator inserted = result.insert(*v1_it).first;
      inserted->second.widen(
            v2_it->second, 
            var_thresh);
    }
  
  }

  result.swap(v1);
}

/*******************************************************************\

Function: abstr_env_domaint::apply_assign_inplace
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::apply_assign_inplace(
    var_mapt& a, 
    const exprt& lhs, 
    const exprt& rhs)
{
  apply_assign_inplace(a, lhs, rhs, a); //src == dest
}

/*******************************************************************\

Function: abstr_env_domaint::apply_assign_inplace
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::apply_assign_inplace(
    const var_mapt& src, 
    const exprt& lhs, 
    const exprt& rhs,
    var_mapt& dest)
{
  if(!var_domain.supports_type(lhs.type()))
    return;

  if(lhs.id() != ID_symbol)
    return;
  
  const symbol_exprt& sym = to_symbol_expr(lhs);

  var_elementt val = fwd_interpret(rhs, src, NULL);
  set_variable_value(dest, sym, val);
}

/*******************************************************************\

Function: apply_parallel_assign_inplace
 
  Inputs:

 Outputs:

 Purpose: Perform a parallel assignment lhs[i] := rhs[i] (0 <= i <= size)

\*******************************************************************/

void abstr_env_domaint::apply_parallel_assign_inplace(
    var_mapt& a, 
    const std::vector<exprt>& lhs_vec, 
    const std::vector<exprt>& rhs_vec)
{
  assert(lhs_vec.size() == rhs_vec.size());
  assert(lhs_vec.size() != 0);
  
  var_mapt& result = a;
  
  std::vector<exprt>::const_iterator lhs_it, rhs_it;

  for(lhs_it = lhs_vec.begin(), rhs_it = rhs_vec.begin(); 
      lhs_it != lhs_vec.end(); 
      lhs_it++, rhs_it++)
  {
    apply_assign_inplace(result, *lhs_it, *rhs_it, a);
  }
}

/*******************************************************************\

Function: abstr_env_domaint::apply_test_inplace
  
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_env_domaint::apply_test_inplace(
    var_mapt& a, 
    const exprt& e,
    bool result)
{
  fwd_mapt fwd_cache;
  var_mapt bwd_interpretation = bwd_interpret_bool(e,a, result, fwd_cache);
  meet_inplace(a, bwd_interpretation);
}

/*******************************************************************\

Function: abstr_env_domaint::fwd_interpret
 
  Inputs:

 Outputs:

 Purpose: Returns the abstract forward interpretation 
          of "e" under "context" 

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::fwd_interpret(
  const exprt& e, 
  const var_mapt& context,
  fwd_mapt* cache)
{  

  if(context.is_bot())
    return var_domain.bot(e.type());

  if(cache != NULL)
  { //check cache
    fwd_mapt::const_iterator find_it = cache->find(e);
    if(find_it != cache->end())
      return find_it->second;
  }
  var_elementt result = fwd_interpret_nocache(e, context, cache);
  
  if(cache != NULL)
  {
    std::pair<exprt, var_elementt> p(e, result);
    cache->insert(p);
  }

  return result;
}

/*******************************************************************\

Function: abstr_env_domaint::fwd_interpret_nocache
 
  Inputs:

 Outputs:

 Purpose: Forward interpretation, don't check cache

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::fwd_interpret_nocache(
  const exprt& e, 
  const var_mapt& context,
  fwd_mapt* cache)
{  
  var_elementt result = var_domain.top(e.type());

  const irep_idt& id = e.id();

  if(id == ID_symbol && var_domain.supports_type(e.type()))
    return fwd_interpret_symbol(e, context);
  else if(id == ID_if) 
    return fwd_interpret_if(e, context, cache);
  else if(id == ID_implies)
    return fwd_interpret_implies(e, context, cache);
  else {
    //interpret with the variable domain
    abstr_elementst elems;
    elems.reserve(e.operands().size());

    forall_operands(it, e)
      elems.push_back(fwd_interpret(*it, context, cache));

    return var_domain.fwd_interpret(e, elems);
  }
}


/*******************************************************************\

Function: abstr_env_domaint::fwd_interpret_symbol
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::fwd_interpret_symbol(
  const exprt& e, 
  const var_mapt& context)
{
  return get_variable_value(context, to_symbol_expr(e));
}

/*******************************************************************\

Function: abstr_env_domaint::fwd_interpret_if
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::fwd_interpret_if(
  const exprt& e, 
  const var_mapt& context,
  fwd_mapt* cache)
{
  assert(e.operands().size() == 3 && e.op0().type().id() == ID_bool);

  const exprt& c = e.op0(); 
    
  var_mapt control_true; 
  var_mapt control_false;

  if(cache != NULL)
  {
    control_true = bwd_interpret_bool(c, context, true, *cache);
    control_false= bwd_interpret_bool(c, context, false, *cache);
  } else
  {
    fwd_mapt tmp_cache;
    control_true = bwd_interpret_bool(c, context, true, tmp_cache);
    control_false= bwd_interpret_bool(c, context, false, tmp_cache);
  }

  var_elementt fwd_a = fwd_interpret(e.op1(), control_true, cache);
  var_elementt fwd_b = fwd_interpret(e.op2(), control_false, cache);

  fwd_a.join(fwd_b);
  return fwd_a;
}

/*******************************************************************\

Function: abstr_env_domaint::fwd_interpret_implies
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::fwd_interpret_implies(
  const exprt& e, 
  const var_mapt& context, 
  fwd_mapt* cache)
{
  assert(e.operands().size() == 2);

  exprt or_expr(ID_or, typet(ID_bool));
  or_expr.copy_to_operands(e.op0());
  or_expr.copy_to_operands(e.op1());

  or_expr.op0().make_not();

  return fwd_interpret(or_expr, context, cache);
}

/*******************************************************************\

Function: abstr_env_domaint::set_variable_value
 
  Inputs:

 Outputs:

 Purpose: Set abstract value of symbol in var_map

\*******************************************************************/

void abstr_env_domaint::set_variable_value(
    var_mapt& var_map,
    const symbol_exprt& s, 
    const var_elementt& val)
{
  if(var_map.is_bot())
    return;

  if(val.is_bot())
  {
    var_map.set_bot();
    return;
  }

  var_mapt::iterator it = var_map.find(s);

  if(it == var_map.end())
    var_map.insert(std::pair<const symbol_exprt, var_elementt>(s,val));
  else 
    it->second = val;
}
/*******************************************************************\

Function: abstr_env_domaint::get_variable_value
 
  Inputs:

 Outputs:

 Purpose: Get abstract value of symbol in var_map

\*******************************************************************/

abstr_env_domaint::var_elementt abstr_env_domaint::get_variable_value(
      const var_mapt& m,
      const symbol_exprt& s)
{
  if(m.is_bot())
    return var_domain.bot(s.type());

  var_mapt::const_iterator it = m.find(s);
  if(it == m.end())
    return var_domain.top(s.type());
  else
    return it->second;
}
/*******************************************************************\

Function: abstr_env_domaint::top()
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

abstr_elementt abstr_env_domaint::top()
{
  return new_elem(new var_mapt);
}
/*******************************************************************\

Function: abstr_env_domaint::bot()
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

abstr_elementt abstr_env_domaint::bot()
{
  var_mapt* v = new var_mapt();
  v->set_bot();
  return new_elem(v);
}

/*******************************************************************\

Function: abstr_env_domaint::is_top
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_env_domaint::is_top(const abstr_elementt& e)
{
  if(read(e).is_bot())
    return false;

  const var_mapt& v = read(e);
  for(var_mapt::const_iterator it = v.begin(); it != v.end(); it++)
  {
    if(!it->second.is_top())
      return false;
  }

  return true;
}

/*******************************************************************\

Function: abstr_env_domaint::is_bot
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_env_domaint::is_bot(const abstr_elementt& e)
{
  return read(e).is_bot();
}

/*******************************************************************\

Function: abstr_env_domaint::leq
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_env_domaint::leq(const abstr_elementt& a1, const abstr_elementt& a2)
{
  const var_mapt& v1 = read(a1);
  const var_mapt& v2 = read(a2);

  if(v1.is_bot()) return true;
  else if(v2.is_bot()) return false;

  for(var_mapt::const_iterator it2 = v2.begin(); it2 != v2.end(); it2++)
  {
    if(it2->second.is_top()) 
      continue;

    var_mapt::const_iterator it1 = v1.find(it2->first);

    if(it1 == v1.end())
      return false;
    else if(!(it1->second.leq(it2->second)))
      return false;

  }

  return true;
}

/*******************************************************************\

Function: abstr_env_domaint::to_string
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string abstr_env_domaint::to_string(const abstr_elementt& a)
{
  if(a.is_top())
    return "Top";
  else if(a.is_bot())
    return "Bot";

  const var_mapt& v = read(a);

  std::stringstream ss;
  var_mapt::const_iterator it = v.begin();
  ss << "{ " << var_domain.to_string(it->second, it->first); 

  for(++it; it != v.end(); ++it)
    if(!it->second.is_top())
      ss << ", " << var_domain.to_string(it->second, it->first);

  ss << " }";
  return ss.str();
}

/*******************************************************************\

Function: abstr_env_domaint::to_expr
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt abstr_env_domaint::to_expr(const abstr_elementt& a)
{
  exprt e(ID_and, typet(ID_bool));
  
  if(a.is_top())
  {
    return true_exprt();
  }
  else if(a.is_bot())
  {
    return false_exprt();
  }
 
  const var_mapt& v = read(a);
  for(var_mapt::const_iterator it = v.begin(); it != v.end(); it++)
  {
    exprt val_expr = var_domain.to_expr(it->second, it->first);

    if(!val_expr.is_true())
      e.move_to_operands(val_expr);
  }
  
  
  if(e.operands().size() == 0)
    e.make_true();
  else if(e.operands().size() == 1)
  { 
    exprt tmp = e.op0();
    e.swap(tmp);
  }
  
  return e;
}


exprt abstr_env_domaint::to_expr(
    const abstr_elementt& a, 
    const std::vector<symbol_exprt>& symbols)
{
  exprt e(ID_and, typet(ID_bool));

  if(a.is_top())
  {
    e.make_true();
    return e;
  }
  else if(a.is_bot())
  {
    e.make_false();
    return e;
  }

  const var_mapt& v = read(a);

  for(std::vector<symbol_exprt>::const_iterator it = symbols.begin(); 
      it != symbols.end(); it++)
  {
    var_mapt::const_iterator find_it = v.find(*it);

    if(find_it != v.end())
    {
      exprt val_expr = var_domain.to_expr(find_it->second, find_it->first);
      if(!val_expr.is_true())
        e.move_to_operands(val_expr);
    }
  }
  
  if(e.operands().size() == 0)
    e.make_true();
  else if(e.operands().size() == 1)
  {
    exprt tmp = e.op0();
    e.swap(tmp);
  }

  return e;
}


/*******************************************************************\

Function: abstr_env_domaint::from_abstr_assignments

  Inputs: 

 Outputs:

 Purpose: Generates an abstract element from a set of abstract assignments.
          Later assignments overwrite earlier ones to the same variable.
          If any value in the vals list is bottom, a bottom element is returned.

\*******************************************************************/

abstr_env_domaint::env_elementt abstr_env_domaint::from_abstr_assignments(
    const std::vector<symbol_exprt>& symbols,
    const var_elementst& vals)
{
  std::auto_ptr<var_mapt> r =
    std::auto_ptr<var_mapt>(new var_mapt());
  
  assert(symbols.size() == vals.size());
  var_elementst::const_iterator it2 = vals.begin();
  for(std::vector<symbol_exprt>::const_iterator it = symbols.begin();
      it != symbols.end(); it++, it2++)
  {
    //assert that the variable value comes from the right domain
    assert(&(it2->get_domain()) == &var_domain);

    if(it2->is_bot())
    {
      r->set_bot();
      break;
    }
    
    std::pair<const symbol_exprt, abstr_elementt> new_entry(*it, *it2);

    r->insert(new_entry);
  }
  
  return new_elem(r.release());
}

void abstr_env_domaint::to_abstr_assignments(
    const env_elementt& e,
    std::vector<symbol_exprt>& symbols,
    var_elementst& v)
{
  if(e.is_bot() || e.is_top()) //don't do anything
    return;

  const var_mapt& map = read(e);
  for(var_mapt::const_iterator it = map.begin(); it != map.end(); it++)
  {
    //add non-top values to assignment
    if(!it->second.is_top())
    {
      symbols.push_back(it->first);
      v.push_back(it->second);
    }
  }
}


abstr_env_domaint::var_elementt abstr_env_domaint::get_abstr_val(
    const env_elementt& e, 
    const symbol_exprt& s) const
{
  const var_mapt& v = read(e);
  var_mapt::const_iterator find_it = v.find(s);

  if(find_it == v.end())
    return var_domain.top();
  else
    return find_it->second;
}


/*******************************************************************\

Function: abstr_env_domaint::begin

  Inputs: 

 Outputs:

 Purpose: 

\*******************************************************************/

abstr_env_domaint::const_iterator abstr_env_domaint::begin(abstr_elementt& e)
{
  var_mapt m = read(e);
  if(m.is_bot())
    return m.end();
  else
    return m.begin();
}

/*******************************************************************\

Function: abstr_env_domaint::end

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

abstr_env_domaint::const_iterator abstr_env_domaint::end(abstr_elementt& e)
{
  return read(e).end();
}


/*******************************************************************\

Function: abstr_env_domaint::set_abstr_val

  Inputs: 

 Outputs:

 Purpose: Set value of symbol in abstract element

\*******************************************************************/

void abstr_env_domaint::set_abstr_val(
    env_elementt& e,
    const symbol_exprt& s,
    const var_elementt& v)
{
  var_mapt& map = write(e);
  set_variable_value(map, s, v);
}

void abstr_env_domaint::get_used_symbols(
  const abstr_elementt& elem, hash_set_cont<exprt, irep_hash>& symbols) const
{
  if(elem.is_bot() || elem.is_top())
    return;

  const var_mapt& m = read(elem);

  for(var_mapt::const_iterator it = m.begin(); it != m.end(); it++)
    if(!it->second.is_top()) 
      symbols.insert(it->first);
}
