/*******************************************************************\

Module: Points to information for a CFG f. pointers potentially 
        pointing to stack variables. 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef POINTS_TO_INFO_H
#define POINTS_TO_INFO_H

#include <expr.h>
#include <goto-programs/control_flow_graph.h>
#include <pointer-analysis/value_set_analysis.h>

#include <set>

class points_to_infot
{
public: 
  points_to_infot(const CFGt& _cfg) : cfg(_cfg) 
  { } 

  //return the set of stack symbols that e could point to at node n
  virtual void points_to(
      const CFG_nodet& n, 
      const exprt& e,
      std::set<exprt>& points_to_set) const = 0;

protected:
  const CFGt& cfg;
};

class value_set_points_to_infot : public points_to_infot
{
public:

  //supplied map should map every cfg node to a target
  value_set_points_to_infot(
      const CFGt& cfg,
      const goto_functionst& goto_functions,
      const irep_idt& function_name,
      const namespacet& ns);

  virtual void points_to(
      const CFG_nodet& n, 
      const exprt& e,
      std::set<exprt>& points_to_set) const;

protected:
  typedef std::map<const CFG_nodet*, goto_programt::const_targett>
    node_target_mapt;

  mutable value_set_analysist pointer_analysis; //mutable because of lazy eval
  goto_functionst goto_functions; //copy because it will be changed 
  const irep_idt& function_name;

  node_target_mapt node_target_map;
};

//only uses type information
class simple_points_to_infot : public points_to_infot
{
public:
  simple_points_to_infot(
    const CFGt& cfg, 
    const namespacet& _ns,
    const std::set<symbol_exprt> symbols) :
    points_to_infot(cfg), ns(_ns)
  { collect_types(symbols); }

  virtual void points_to(
      const CFG_nodet& n, 
      const exprt& e,
      std::set<exprt>& points_to_set) const;

protected:
  void collect_types(const std::set<symbol_exprt>& symbols);
  void collect_type(const exprt& sym);
    
  typedef hash_map_cont<typet, std::set<exprt>, irep_hash> type_mapt;
  type_mapt type_map;
  
  const std::set<exprt> empty_set;
  const namespacet& ns;
};


#endif
