#include <float_median.h>
#include <iostream>
#include <cmath>
#include <cstdlib>
#define PINF (1.0f/0.0f)
#define NINF (-1.0f/0.0f)

float random_float()
{
  union
  {
    float f;
    unsigned i;
  } u;

  unsigned r = ((unsigned) random()) % 20;

  switch(r)
  {
    case 0:
      return PINF;
    case 1:
      return NINF;
    case 2:
      return PINF+NINF;
    case 3:
      return 0.0f;
    case 4:
      return -0.0f;
    case 5:
      //subnormal number
      u.i=std::rand();
      u.i=(u.i<<16)^std::rand();
      u.i &= 2155872255u;//mask out exponent
      return u.f;
    default: 
      u.i=std::rand();
      u.i=(u.i<<16)^std::rand();
      return u.f;
  }
}

int main(void)
{
  unsigned error = 0;
  srand(0);
  
  float fail1 = -0.999999821f;
  float fail2 = 0.0f;

  float fail3 = -5.6E-45f;

  ieee_floatt if1, if2, if3;
  if1.from_float(fail1);
  if2.from_float(fail2);

  if3.from_float(fail3);

  mp_integer b1 = if1.spec.bias();
  mp_integer b2 = if2.spec.bias();
  ieee_float_median(if1, if2);

  for(int i = 0; i < 500000; i++)
  {
    float f1 = random_float();
    float f2 = random_float();

    if((i & 32767) == 0)
      std::cerr << "tested " << i << " float medians (" 
                << error << " errors)" << std::endl;

    ieee_floatt i1, i2;
    i1.from_float(f1);
    i2.from_float(f2);

    if(i1.is_NaN() || i2.is_NaN())
      continue;
    
    ieee_floatt med = ieee_float_median(i1, i2);
    if(!(i1 <= med && med <= i2) && !(i2 <= med && med <= i1))
    {
      std::cout << i << " wrong: med(" 
                << i1 << ", " << i2 
                << ") returns " << med << std::endl;
      error++;
    }

    ieee_floatt avg = ieee_float_average(i1, i2);
    if(!(i1 <= avg && avg <= i2) && !(i2 <= avg && avg <= i1))
    {
      std::cout << i << " wrong: avg(" 
                << i1 << ", " << i2 
                << ") returns " << avg << std::endl;
      error++;
    }

  } 

  if(error)
  { 
    std::cerr << "ERROR" << std::endl; 
    return 1;
  }

  return 0;
}
