/*******************************************************************\

Module: Abstract superclass for widening strategies

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef WIDENING_STRATEGYT_H
#define WIDENING_STRATEGYT_H

#include "iteration_schedule.h"

class widening_strategyt
{
public:
  widening_strategyt(iteration_schedulet& _schedule)
    : schedule(_schedule) { }
  
  virtual bool apply_widening() = 0;
  
protected:
  const iteration_schedulet& schedule;
};


class simple_widening_strategyt : public widening_strategyt
{
public:
  typedef widening_strategyt SUB;

  simple_widening_strategyt(iteration_schedulet& schedule,  
                            unsigned n) :
    SUB(schedule), iterations_to_widening(n) { }

  virtual bool apply_widening();

  void set_iterations_to_widening(unsigned w)
  { iterations_to_widening = w; }

  unsigned get_iterations_to_widening()
  { return iterations_to_widening; }

protected:
  unsigned iterations_to_widening;
};

#endif//WIDENING_STRATEGYT_H
