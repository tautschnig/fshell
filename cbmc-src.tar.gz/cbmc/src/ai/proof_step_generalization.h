/*******************************************************************\

Module: Proof generalization, statement by statement

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef PROOF_STEP_GENERALIZATION_H
#define PROOF_STEP_GENERALIZATION_H

#include "abstr_fwd_analysis.h"
#include "proof_generalization.h"

#include <vector>
#include <set>

//#define PROOF_GEN_DEBUGINFO 1

class proof_step_generalizationt : public proof_generalizationt
{
public:
  typedef std::vector<abstr_elementt> abstr_elementst;
  typedef std::set<irep_idt> id_sett;

public:
  proof_step_generalizationt(
      abstr_fwd_analysist& _analysis, 
      const namespacet& _ns);

  virtual ~proof_step_generalizationt() { }
  
  virtual void generalize();
  
  //locally generalize elem at node
  virtual void generalize_step(
    const CFG_nodet&, 
    abstr_elementt& elem,
    const id_sett& do_not_generalize) = 0; 

  //locally repair broken proof step
  virtual void repair_step(
    const CFG_nodet&, 
    abstr_elementt& broken_pre,
    const abstr_elementt& proof,
    const id_sett& must_include) = 0; 

  void ignore_symbols(const id_sett& id)
  { do_not_touch = id; }

protected:
  const CFGt& cfg;
  abstr_elementst& proof;
  abstr_elementst new_proof;
  const namespacet& ns;
  id_sett do_not_touch;

protected:
  virtual bool has_symbol(const exprt& e, const id_sett& s);

  virtual bool valid_triple(
      const CFG_nodet& n,
      const CFG_nodet& n2,
      const abstr_elementt& pre, 
      const abstr_elementt& post);

  virtual bool valid_pre(
      const CFG_nodet& n, 
      const abstr_elementt& pre,
      abstr_elementst& proof);

  virtual abstr_elementt& get_invariant(abstr_elementst& p, const CFG_nodet& n)
  { return p[n.id]; }

  virtual abstr_elementt& set_invariant(abstr_elementst& p, const CFG_nodet& n, abstr_elementt& e)
  { return p[n.id] = e; }
  
};

#endif
