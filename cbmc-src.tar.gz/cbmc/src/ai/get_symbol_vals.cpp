/*******************************************************************\

Module: Extract conjunction of equalities from SAT assignment

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "get_symbol_vals.h"

exprt get_symbol_vals(const boolbvt& p, const expr_sett& s)
{
  exprt result(ID_and, typet(ID_bool));
  for(expr_sett::const_iterator it = s.begin();
      it != s.end(); it++)
  {
    const exprt& e = *it;

    exprt val = p.get(e);
    assert(val.is_not_nil());

    exprt eq(ID_equal,typet(ID_bool));
    eq.copy_to_operands(*it);
    eq.move_to_operands(val);

    result.move_to_operands(eq);
  }
  
  if(result.operands().size() == 0)
    result.make_true();
  else if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  return result;
}

exprt get_symbol_vals(const boolbvt& p, const symbol_sett& s)
{
  exprt result(ID_and, typet(ID_bool));
  for(symbol_sett::const_iterator it = s.begin();
      it != s.end(); it++)
  {
    const exprt& e = *it;

    exprt val = p.get(e);
    assert(val.is_not_nil());

    exprt eq(ID_equal,typet(ID_bool));
    eq.copy_to_operands(*it);
    eq.move_to_operands(val);

    result.move_to_operands(eq);
  }
  
  if(result.operands().size() == 0)
    result.make_true();
  else if(result.operands().size() == 1)
  { 
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  return result;
}
