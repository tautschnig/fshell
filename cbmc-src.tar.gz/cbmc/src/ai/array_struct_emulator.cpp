/*******************************************************************\

Module: Transformation between expression over arrays or structs 
        and auxiliary representing single primitive values

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "array_struct_emulator.h"

#include <expand_array_struct.h>

#include <arith_tools.h>
#include <std_types.h>

#include <sstream>

/*******************************************************************\

Function: array_struct_emulatort::emulate
 
  Inputs:

 Outputs:

 Purpose: emulate all emulatable symbols in a list

\*******************************************************************/

void array_struct_emulatort::emulate(std::vector<exprt>& l)
{
  for(std::vector<exprt>::iterator it = l.begin(); it != l.end(); ++it)
  {
    if(it->id() == ID_index || it->id() == ID_member) 
    {
      exprt emulated = emulate(*it);
      it->swap(emulated);
    }
  }
}



/*******************************************************************\

Function: array_struct_emulatort::replace_symbols_by_orig

  Inputs: 

 Outputs: 

 Purpose: Replace all symbols expressions in input expression that 
          correspond to array index or struct expressions by their original
          expressions

\*******************************************************************/

void array_struct_emulatort::replace_symbols_by_orig(exprt& e)
{
  if(e.id() == ID_symbol)
  {
    exprt replaced; 
    if( get_orig_from_symbol(to_symbol_expr(e), replaced) )
      e.swap(replaced);
  }

  Forall_operands(it, e)
    replace_symbols_by_orig(*it);
}

/*******************************************************************\

Function: array_struct_emulatort::replace_by_symbols

  Inputs: 

 Outputs: 

 Purpose: Replace supported expressions by their corresponding symbols

\*******************************************************************/

void array_struct_emulatort::replace_by_symbols(exprt& e)
{
  if(e.id() == ID_index || e.id() == ID_member)
  {
    if(supported(e) && has_constant_indices(e))
    {
      exprt emulated = emulate(e);
      e.swap(emulated);
    }
  } 

  Forall_operands(it, e)
    replace_by_symbols(*it);
}


/*******************************************************************\

Function: array_struct_emulatort::get_orig_from_symbol

  Inputs: 

 Outputs: Returns false, if symbol is not an emulated symbol

 Purpose: Get expression that is emulated by this symbol

\*******************************************************************/

bool array_struct_emulatort::get_orig_from_symbol(
    const symbol_exprt& e, 
    exprt& i)
{
  exprt orig = e.find_expr(ID_original_expr);

  if(orig.is_nil())
    return false;
  
  i = orig;
  return true;
}



/*******************************************************************\

Function: array_struct_emulatort::emulate

  Inputs: Index expression with constant indices, or member access

 Outputs: 

 Purpose: Return symbol corresponding to index or member expr
          or other expression in case of array literal

\*******************************************************************/

exprt array_struct_emulatort::emulate(
   const exprt& e)
{
  //check cache
  expr2symbolt::const_iterator it = expr2symbol.find(e);

  if(it != expr2symbol.end()) 
    return it->second; //found in cache
  else
  {
    //not found in cache
    std::vector<mp_integer> index_stack;
    std::vector<irep_idt> member_stack;
    std::vector<bool> is_index_stack;

    /*************************************************************************/
    /* Iterate the structure of expression until a non-index, non-member     */
    /* expression is found, save all iterated index and member exprs on stack*/
    /*************************************************************************/
    exprt e_it = e;
    while(e_it.id() == ID_index || e_it.id() == ID_member) //get all indices
    {
      if(e_it.id() == ID_index)
      {
        index_exprt& e_it_index = to_index_expr(e_it);
        assert(e_it_index.index().is_constant());
        assert( 
            to_array_type(e_it_index.array().type()) . size().is_constant() 
            );

        mp_integer index;
        bool failed = to_integer(e_it.op1(), index);
        assert(!failed);

        index_stack.push_back(index);
        is_index_stack.push_back(true);
        
        exprt tmp = e_it.op0();
        e_it.swap(tmp);

      } else {
        assert(e_it.id() == ID_member);
        member_exprt& e_it_member = to_member_expr(e_it);
        member_stack.push_back(e_it_member.get_component_name());
        is_index_stack.push_back(false);

        exprt tmp = e_it.op0();
        e_it.swap(tmp);
      }
    }

    /*************************************************************************/
    /* Create a symbol, or resolve literal                                   */
    /*************************************************************************/

    if(e_it.id() == ID_symbol) //index expression over symbol
    {  
      /***********************************************************************/
      /* Create a symbol                                                     */
      /***********************************************************************/

      //create a new symbol for the whole index expression
      assert(e_it.type().id() == ID_array || e_it.type().id() == ID_struct);

      std::stringstream ss;

      ss << to_symbol_expr(e_it).get_identifier().as_string();

      assert(is_index_stack.size() >= 1);

      //create name for new symbol
      while(is_index_stack.size() > 0)
      {
        if(is_index_stack.back())
        {
          assert(index_stack.back().is_long());
          ss << "[" << index_stack.back().to_long() << "]";
          index_stack.pop_back();
        } else {
          ss << "." << member_stack.back();
          member_stack.pop_back();
        }

        is_index_stack.pop_back();
      }
      assert(!member_stack.size() && !index_stack.size());

      symbol_exprt result(ss.str(), e.type());
      result.set(ID_original_expr, e);
      //put into cache 
      expr2symbol[e] = result;

      return result;

    } else if(e_it.id() == ID_array || e_it.id() == ID_struct) { 
      /***********************************************************************/
      /* Resolve a literal                                                   */
      /***********************************************************************/

      while(is_index_stack.size() > 0)
      {
        if(is_index_stack.back())
        {
          assert(index_stack.back().is_long());
          assert(e_it.id() == ID_array);

          long index = index_stack.back().to_long();

          assert(index >= 0);
          assert(e_it.operands().size() > (unsigned long) index);
          
          exprt tmp = e_it.operands()[index];
          e_it.swap(tmp);

          index_stack.pop_back();
        } else {
          //find the right operand
          const struct_typet& t = to_struct_type(e_it.type());
          unsigned nr = t.component_number(member_stack.back());

          assert(nr >= 0);
          assert(e_it.operands().size() > (unsigned long) nr);
          exprt tmp = e_it.operands()[nr];
          e_it.swap(tmp);

          member_stack.pop_back();
        }

        is_index_stack.pop_back();
      }


      assert(e_it.id() != ID_index);

      return e_it;
    } 

    return e;
  }
} 

/*******************************************************************\

Function: array_struct_emulatort::nr_assignables

  Inputs: array type

 Outputs: The size of "primitive" assignable objects in the 
          array/struct

 Purpose: Determine the overall number of assignable expressions 

\*******************************************************************/

long array_struct_emulatort::nr_assignables(const typet& t)
{
  if(t.id() == ID_array)
  {
    const array_typet &arr_t = to_array_type(t);
    if( ! arr_t.size().is_constant() ) 
      return -1;

    mp_integer sz;
    bool failed = to_integer(arr_t.size(), sz);
    assert(!failed);
    assert(sz.is_long());

    long size = sz.to_long();

    return size * nr_assignables(to_array_type(arr_t.subtype()));

  } else if(t.id() == ID_struct) {
    long size = 0;
    const struct_typet& struct_t = to_struct_type(t);
    for(struct_typet::componentst::const_iterator it = struct_t.components().begin();
        it != struct_t.components().end(); it++)
    {
      const struct_typet::componentt& c = *it;
      size += nr_assignables(c.type());
    }

    return size;
  } 
  else return 1; 
}

/*******************************************************************\

Function: array_struct_emulatort::supported

  Inputs: 

 Outputs: True if this type can be emulated

 Purpose: 

\*******************************************************************/

bool array_struct_emulatort::supported(const typet& t)
{
  if(t.id() == ID_array)
  {
    const array_typet& arr_t = to_array_type(t);
    if(arr_t.size().id() != ID_constant)
      return false;

    mp_integer sz;
    bool failed = to_integer(arr_t.size(), sz);
    assert(!failed);
    assert(sz.is_long());

    long size = sz.to_long();

    return size > 0 && size <= max_dim_size &&
           supported(arr_t.subtype()) ;

  } else if(t.id() == ID_struct) {

    const struct_typet& struct_t = to_struct_type(t);
    for(struct_typet::componentst::const_iterator it = struct_t.components().begin();
        it != struct_t.components().end(); it++)
    {
      if(!supported(it->type()))
        return false;
    }

    return true;

  } else
    return true;
 }

/*******************************************************************\

Function: array_struct_emulatort::supported

  Inputs: if as_pointer=true, we also support indexing expressions
          over large arrays, in case the index is zero.
          This allows handling of statements of the form 
          &(a[0]), where a is a large array

 Outputs: True if the expression can be emulated

 Purpose: 

\*******************************************************************/

bool array_struct_emulatort::supported(const exprt& e, bool as_pointer)
{ 
  if(e.id() == ID_index)
  {
    const index_exprt& ie = to_index_expr(e);
    bool size_ok = true;

    const exprt& array_size = to_array_type(ie.array().type()).size();

    if(array_size.is_constant())
    {
      mp_integer sz;
      bool failed = to_integer(array_size, sz);
      assert(!failed);
      if(sz > max_dim_size)
        size_ok = false; //array too large
    } else 
    {
      size_ok = false; //array has non-constant size
    }

    if(!size_ok && !(as_pointer && ie.index().is_zero()) )
      return false;

    return supported(ie.array());
  } else if(e.id() == ID_member)
  {
    return supported(e.op0());
  } else if(e.id() == ID_symbol || e.id() == ID_struct || e.id() == ID_array) 
    return true;
  else return false;
}

/*******************************************************************\

Function: array_struct_emulatort::get_all_assignables

  Inputs: array expression of constant size or struct

 Outputs: All exprs corresponding to assignable values (members, indices)

 Purpose: 

\*******************************************************************/

void array_struct_emulatort::get_all_assignables(
    const exprt& e, 
    std::vector<exprt>& indices)
{
  expand_array_struct(e, indices);
}

/*******************************************************************\

Function: array_struct_emulatort::has_constant_indices

  Inputs: 

 Outputs: Returns true if all indices are constants

 Purpose: 

\*******************************************************************/

bool array_struct_emulatort::has_constant_indices(const exprt& e)
{
  if(e.id() == ID_index)
  {
    const index_exprt& ie = to_index_expr(e);
    if(!ie.index().is_constant())
      return false;
    else return has_constant_indices(ie.array());
  } 
  else if(e.id() == ID_member)
    return has_constant_indices(e.op0());   
  else return true;
}
