/*******************************************************************\

Module: Proof generalization using search on the whole program

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "global_search_generalization.h"

#include "bounds_search.h"

#include <time.h>

void global_search_generalizationt::generalize()
{
  //abstr_vect& proof = analysis.get_abstr_vec();
    
  bounds_searcht bs(initial, env_domain, var_domain);

  unsigned counter = 0;
  bool valid = true;
  
  clock_t start, finish;
  
  start = clock();

  //std::cout << "\n\ngeneralizing" << std::endl;
  
  while(bs.has_next())
  {
    counter++;
    //abstr_vect old_proof(proof);

    bs.next(valid); //changes initial element
    
    //std::cout << "trying " << initial.to_string() << std::endl;
    analysis.reset(); //reset analysis
    analysis.propagate(analysis.get_cfg().get_initial());

    valid = !analysis.has_violated_assertions();
    //std::cout << (valid ? "valid" : "failed") << std::endl;

    //if(!valid)
    //  old_proof.swap(proof); 
  }
  finish = clock();
  double time = double(finish - start) / CLOCKS_PER_SEC;
  std::cout << "Global generalization: " << counter 
            << " steps, " << time << "s (" << (time / counter) << "s/step)" 
            << std::endl;
}
