/*******************************************************************\

Module: Iteration schedule for fixpoint computation

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ITERATION_SCHEDULE_H
#define ITERATION_SCHEDULE_H

#include <goto-programs/loops.h>
#include <hash_cont.h>

#include <stack>
#include <queue>

class iteration_schedulet
{
public:
  iteration_schedulet(const CFGt& _cfg, const loop_infot& _loop_info)
    : cfg(_cfg), loop_info(_loop_info) { }
  virtual ~iteration_schedulet() { }

  //reset and enqueue start node
  virtual void reset() 
  { reset(cfg.get_initial()); }

  virtual void reset(const CFG_nodet& n) = 0;

  //returns true if iteration is not done
  virtual bool empty() const = 0 ;

  //return the next node that is to be processed
  virtual const CFG_nodet& top() const = 0;

  //remove node from stack and record changes
  virtual void pop(bool value_changed) = 0;

  //true iff the next node is a loop header
  virtual bool is_loop_header() const = 0;

  //returns loop depth of next node
  virtual unsigned loop_depth() const = 0;

  //returns nr of iterations spent at specified loop depth
  virtual unsigned iterations_in_loop(unsigned d) const = 0;

  //returns nr of iterations at deepest loop depth
  virtual unsigned iterations_in_loop() const = 0;

protected:
  const CFGt& cfg;
  const loop_infot& loop_info;
};


struct CFG_node_greatert : 
  public std::binary_function<CFG_nodet*, CFG_nodet*, bool>
{
  bool operator() (const CFG_nodet* &n1, const CFG_nodet* &n2)
  { return n1->id > n2->id; }
};

class fwd_iteration_schedulet : public iteration_schedulet
{
public:
  typedef iteration_schedulet sub;

  virtual ~fwd_iteration_schedulet() { }
  fwd_iteration_schedulet(const CFGt&, const loop_infot&);

  virtual void reset(const CFG_nodet& n);
  
  virtual bool empty() const;
  virtual const CFG_nodet& top() const;
  virtual void pop(bool value_changed);

  virtual bool is_loop_header() const;
  virtual unsigned loop_depth() const;
  virtual unsigned iterations_in_loop(unsigned d) const;
  virtual unsigned iterations_in_loop() const;

protected:
  void clear_all_empty();
  //enqueue successor at the right loop_frame
  void enqueue_successor(const CFG_nodet&);

  typedef 
    std::priority_queue<
      const CFG_nodet*, 
      std::vector<const CFG_nodet*>,
      CFG_node_greatert>
    node_queuet;

  //loop frame
  struct loop_framet {
    const loop_infot::loopt* loop;
    node_queuet node_queue;
    unsigned iterations;

    loop_framet(const loop_infot::loopt* _loop)
      : loop(_loop), iterations(0) { }
  };

  typedef std::vector<loop_framet> node_stackt;

  typedef hash_set_cont<int> id_sett; 

  id_sett on_stack;
  node_stackt node_stack;
  
};


#endif

