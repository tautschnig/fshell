/*******************************************************************\

Module: Abstract DPLL using search, clause learning, backtracking

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_DPLL_SEARCH_H
#define ABSTR_DPLL_SEARCH_H

#include "abstr_dpll.h"
#include "itv_invar_bmc.h"

#include "domains/itv.h"

#include <numbering.h>
#include <context.h>

class abstr_dpll_searcht : public abstr_dpllt
{
public:
  enum clause_statet { CONFLICT = 0, UNKNOWN = 1, SATISFIED = 2, UNIT = 3};

  typedef abstr_dpllt sub;

  abstr_dpll_searcht(
      const CFGt& cfg, 
      const loop_infot& _loop_info,
      interval_array_domaint& dom,
      unsigned widening_limit,
      const namespacet& ns, 
      const optionst& _options)
    : sub(cfg,_loop_info, dom, widening_limit, ns, _options)
      { }

protected:
  typedef std::vector<itvt> valuest;
  typedef std::vector<int> var_stackt;
  typedef std::vector<itvt> val_stackt;
  typedef std::vector<val_stackt> val_stackst;
  typedef std::vector<unsigned> control_stackt;
  typedef std::vector<std::vector<unsigned> > dlevelst;
  typedef std::vector<std::vector<int> > reasonst;
  typedef hash_numbering<symbol_exprt, irep_hash> sym_expr_numberingt;
  typedef std::pair<int, itvt> literalt;
  typedef std::vector<literalt> clauset;
  typedef std::vector<literalt> cubet;
  typedef std::vector<clauset> clausest;
  typedef std::vector<unsigned> clause_indicest;
  typedef std::vector<clause_indicest> clauses_indicest;

  std::auto_ptr<itv_invar_bmct> bmc;
   
  valuest values;
  clausest clauses;
  var_stackt var_trail;//decision variables stack
  val_stackt val_trail;//decision value stack, ordered chronologically
  var_stackt reason_trail;

  val_stackst var_val_trail;//decision values per variables stack
  std::vector<int> last_backtrack;

  control_stackt control_trail;

  int backtracks;

  unsigned bcp_queue_top;
  
  //positive and negative occurrence list
  clauses_indicest pos_occ, neg_occ;

  sym_expr_numberingt numbering;

  unsigned dlevel;
  dlevelst dlevels;
  reasonst reasons; 

  int conflicting_clause;

  bool found_bmc_counterexample;
  //return decision, or bottom if none are left
  virtual bool decide(abstr_elementt& elem);

  //returns false when a conflict is detected
  virtual bool deduce();

  //initialize analysis
  virtual void init(abstr_elementt& initial_elem);

  //returns false if no further backtrack possible
  virtual bool learn_and_backtrack(abstr_elementt& elem);

  virtual bool conflict_or_proof();

  enum proof_typet { PROPOSITIONAL, ABSINT, BMC };
  proof_typet last_proof;

  virtual void generalize_proof(abstr_elementt& elem);

  void compress_clause(clauset& c1);

  clauset& add_clause(const clauset& cl);
  
  //returns false when a conflict is detected
  bool propagate(int trail_index);
  clause_statet unit_rule(int clause_index);

  //get clause from proof
  void get_conflict_clause(clauset& cl, int& blevel);

  //resolve at c1[p] into c1, return new start of clause
  void resolve_into(
    clauset& c1,
    int p,
    const clauset& c2);

  //get reason from generalized abstr. int. proof
  void get_ai_reason(cubet& c);

  //get reason from bmc
  void get_bmc_reason(cubet& c);

  //return earliest decision level at which the literal is contradicted
  unsigned get_earliest_contradiction(const literalt& l);

  //takes a cube returns a clause representing the negation
  void negate(const literalt& l, clauset& r);

  void resolve_with_antecedents(clauset& c, int& blevel);
  
  //return the phase of a literal
  bool lit_phase(const literalt& l);

  //assign a value
  void assign(int var, const itvt& value, int reason = -1);

  //undo assignments on stack until lvl 
  void cancel_until(unsigned lvl);

  //undo one level of assignments on stack
  void cancel_once();


  void flip(itvt& decision, const itvt& context);

  void check_consistency();

  void init_bmc();

  bool prove_with_bmc();


  bool use_bmc(); 

  std::string to_string(const clauset& cl);

  std::string to_string(const literalt& l);
  
  void dump_trail(const clauset& added_clause, unsigned blevel);

  //range in percent (approximation) of decision variables
  void get_scores(std::vector<double>& s, bool relative);

  double get_avg_score(bool relative);

  double get_ratio(const itvt& i1, const itvt& i2);
  
  void get_var_ranges(cubet& c);

  void find_uip(
    clauset& result, 
    unsigned dl,
    int& blevel);

  literalt lit_from_trail(int index);

  int first_contradiction_on_trail(
    const literalt& l, 
    int trail_start, 
    int trail_end);

  void get_bmc_thresh();
  
  valuest initial_values; 
  
  //threshold when to call bmc
  double bmc_thresh;
  //threshold of how much to backtrack before bmcing
  double bmc_bt_thresh;
  bool rel_bmc;

  //choose a variable and value to decide on, return false, if no such variable
  bool decision_heuristic(int& v, itvt& itv);

  /******* decision heuristics *******/
  enum dec_heurt { RANGE, RANGE_REL, BERKMIN };
  dec_heurt dec_heur;

  bool dec_heur_largest_range(int& v, itvt& itv, bool relative);
  bool dec_heur_berkmin(int& v, itvt& itv);
  
  bool just_backtracked;

};

#endif
