/*******************************************************************\

Module: Proof growing analysis

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef PROOF_GROWING_ANALYSIS_H
#define PROOF_GROWING_ANALYSIS_H

#include "abstr_dpll.h"
#include "domains/interval_array_domain.h"

#include <solvers/sat/satcheck_minisat2.h>
#include <solvers/flattening/boolbv.h>

#include <options.h>

class proof_growing_analysist : public abstr_dpllt
{
public:
  typedef abstr_dpllt sub;

  proof_growing_analysist(
      const CFGt& cfg, 
      const loop_infot& _loop_info,
      interval_array_domaint& dom,
      unsigned widening_limit,
      const namespacet& ns, 
      const optionst& options)
    : sub(cfg, _loop_info, dom, widening_limit, ns, options),
      boolbv(ns, solver)
  {

  }

  virtual ~proof_growing_analysist() { };

  //return decision, or bottom if none are left
  virtual bool decide(abstr_elementt& elem);

  //returns false when a conflict is detected
  virtual bool deduce() { return true; }

  virtual void init(abstr_elementt& elem);

  //returns false if no further backtrack possible
  virtual bool learn_and_backtrack(abstr_elementt& elem);

  virtual void generalize_proof(abstr_elementt& elem);

protected:

  satcheck_minisat_simpt solver;
  boolbvt boolbv;

protected:
  void convert_symbols(const symbol_sett& s, boolbvt& bv);
};
#endif
