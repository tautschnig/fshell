/*******************************************************************\

Module: Interface to apron as a constraint solver. This class just
  routes calls to apron_wrapper, which directly communicates with the 
  apron library. This was done to eliminate dependencies to apron.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef APRON_INTERFACE_APRON_CONSTRAINT_SOLVER_H
#define APRON_INTERFACE_APRON_CONSTRAINT_SOLVER_H

#include "apron_domain_type.h"

#include <decision_procedure.h>


#include <vector>


class apron_constraint_solvert : public decision_proceduret 
{
public:
  typedef decision_proceduret SUB;

  apron_constraint_solvert(const namespacet& ns, apron_domain_typet dt);

  virtual ~apron_constraint_solvert();

  //not supported
  virtual exprt get(const exprt &expr) const;

  virtual void print_assignment(std::ostream &out) const;

  //add constraints to the solver
  virtual void set_to(const exprt &expr, bool value);

  virtual resultt dec_solve();

  virtual bool in_core(const exprt &expr);

  virtual std::string decision_procedure_text() const;

protected:
  apron_domain_typet domain_type;
  
  //use pointer to keep apron and library distinct 
  void *apron_wrapper;
};

#endif
