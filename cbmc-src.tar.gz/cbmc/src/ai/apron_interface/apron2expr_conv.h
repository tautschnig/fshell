/*******************************************************************\

Module: Conversion from apron internal types to CPROVER expressions

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef APRON2EXPR_CONV_H
#define APRON2EXPR_CONV_H

#include <std_expr.h>
#include <namespace.h>

#include <apronxx.hh>

class apron2expr_convt 
{
public:
  //context is need to get the correct type of expressions
  apron2expr_convt(const contextt& ctx, apron::manager& _man) :
    context(ctx), ns(ctx), man(_man) { } 
  
  virtual ~apron2expr_convt() { } 

  //return a expression corresponding to the constraint
  virtual exprt convert(const apron::abstract1&);

  virtual exprt convert(const apron::tcons1&);

  virtual exprt convert(const apron::texpr1::const_iterator&);

  //translate apron type into cprover type
  virtual typet translate_type(const ap_texpr_rtype_t& r_type); 

  //change types to make overflows impossible
  virtual void make_overflow_safe(exprt&);

protected:
  const contextt& context;
  namespacet ns;
  apron::manager& man;

  virtual exprt convert_variable(const apron::texpr1::const_iterator&);
  virtual exprt convert_constant(const apron::texpr1::const_iterator&);
  virtual exprt convert_operator(const apron::texpr1::const_iterator&);

  virtual void create_bin_expr(
      const irep_idt& op, 
      exprt& lhs,
      exprt& rhs, 
      exprt& dest);


  //return safe result type for op so that no overflow can occur
  virtual typet get_safe_result_type(
      const irep_idt& op, 
      const typet& t1, 
      const typet& t2);

  virtual const typet& get_maxtype(
      const typet& t1, 
      const typet& t2);

  virtual void remove_apron_idioms(exprt& expr);
};

//returns an expression with unbounded types
exprt apron2expr(const apron::abstract1& a, 
                 const contextt& ctx, 
                 apron::manager& man);


#endif
