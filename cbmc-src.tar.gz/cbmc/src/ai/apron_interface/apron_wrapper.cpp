#include "apron_wrapper.h"

#include "expr2apron_conv.h"

#include <expr2var.h>
#include <std_expr.h>


apron_wrappert::apron_wrappert(const namespacet& ns, apron_domain_typet dt) :
  SUB(ns), domain_type(dt), apron_man(NULL)
{
  switch(dt)
  {
    case BOX:
      apron_man = new box_manager;
    case OCT:
      apron_man = new oct_manager;
      break;
    case POLKA:
      apron_man = new polka_manager(false);
      break;
    case POLKA_STRICT:
      apron_man = new polka_manager(true);
      break;
    case PPL: 
    case PPL_STRICT:
      throw "PPL not supported";
      break;
  }
}

apron_wrappert::~apron_wrappert()
{ if(apron_man != NULL) delete apron_man; }


//add variables to apron environment
void apron_wrappert::get_var_names(const exprt& e, 
                              var_namest& float_vars,
                              var_namest& int_vars)
{
  if(e.id() == "symbol")
  {
    //determine whether float or int and add to list
    symbol_exprt s = to_symbol_expr(e);
    
    std::string ident = s.get_identifier().as_string();

    if(e.type().id() == "floatbv") 
    {
      float_vars.insert(ident);
    } else if(e.type().id() == "signedbv")
    {
      int_vars.insert(ident);
    } else
    {
      throw "unsupported symbol type encountered: " + e.type().id().as_string();
    }

  } else
  {
    //recursive call
    forall_operands(it,e)
      get_var_names(*it, float_vars, int_vars);
  }
}

void apron_wrappert::set_to(const exprt &expr, bool value)
{
  assert(expr.type().id() == "bool");

  constraints.push_back((value ?  expr : negate(expr)));
}

exprt apron_wrappert::negate(const exprt& e)
{
  exprt result = e;
  
  if(result.id() == "=") 
    result.id("notequal");
  if(result.id() == "notequal") 
    result.id("=");
  else if(result.id() == "ieee_float_equal")
    result.id("ieee_float_notequal");
  else if(result.id() == "ieee_float_notequal")
    result.id("ieee_float_equal");
  else if(result.id() == "<")
    result.id(">=");
  else if(result.id() == "<=")
    result.id(">");
  else if(result.id() == ">")
    result.id("<=");
  else if(result.id() == ">=")
    result.id("<");
  else  
    throw "unknown bool expression: " + e.id_string();

  return result;
}

decision_proceduret::resultt apron_wrappert::dec_solve()
{
  
  var_namest float_names, int_names;

  //fetch all variables
  for(constraintst::const_iterator it = constraints.begin();
      it != constraints.end(); it++)
    get_var_names(*it, float_names, int_names);

  
  //copy variables to list
  std::vector<var> float_vars, int_vars;

  for(var_namest::const_iterator it = float_names.begin(); 
      it != float_names.end(); it++)
    float_vars.push_back(var(*it));

  for(var_namest::const_iterator it = int_names.begin(); 
      it != int_names.end(); it++)
    int_vars.push_back(var(*it));

  //initialize environment with variables
  env = environment(int_vars, float_vars);

  abstract1 a(*apron_man, env, top());
  //translate constraints
  std::vector<tcons1> translated_constraints;
  expr2apron_convt converter(env);

  for(constraintst::const_iterator it = constraints.begin();
      it != constraints.end(); it++)
  {
    translated_constraints.push_back(converter.convert_ineq_expr(*it));
    std::cout << "translated " << translated_constraints.back() << std::endl;
  }

  tcons1_array ta(translated_constraints);

  a.meet(*apron_man, ta);
  
  std::cout << a << std::endl;
 
  if(a.is_bottom(*apron_man))
    return D_UNSATISFIABLE;
  else 
    return D_ERROR;
}
