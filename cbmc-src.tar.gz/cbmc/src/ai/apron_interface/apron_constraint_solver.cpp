#include "apron_constraint_solver.h"
#include "apron_wrapper.h"

#define APRON_WRAPPER ((apron_wrappert*) apron_wrapper)

apron_constraint_solvert::
apron_constraint_solvert(const namespacet& ns, apron_domain_typet dt)
  : SUB(ns), domain_type(dt), apron_wrapper(new apron_wrappert(ns, dt))
{ };

apron_constraint_solvert::
~apron_constraint_solvert()
{
  delete APRON_WRAPPER;
}

//add constraints to the solver
void apron_constraint_solvert::set_to(const exprt &expr, bool value)
{
  APRON_WRAPPER->set_to(expr, value);
}

exprt apron_constraint_solvert::get(const exprt &expr) const
{
  throw "\"get\" not supported";
}

bool apron_constraint_solvert::in_core(const exprt &expr) 
{
  throw "\"in_core\" not supported";
}

std::string apron_constraint_solvert::decision_procedure_text() const
{
  return APRON_WRAPPER->decision_procedure_text();
}

void apron_constraint_solvert::print_assignment(std::ostream &out) const
{
  return APRON_WRAPPER->print_assignment(out);
}

decision_proceduret::resultt
apron_constraint_solvert::dec_solve()
{
  return APRON_WRAPPER->dec_solve();
}
