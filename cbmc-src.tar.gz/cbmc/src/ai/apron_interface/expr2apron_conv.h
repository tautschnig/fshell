/*******************************************************************\

Module: Converter from expressions to apron internal types.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef EXPR2APRON_CONV_H
#define EXPR2APRON_CONV_H

#include <apronxx.hh>

#include <std_expr.h>

class expr2apron_convt 
{
public:
  expr2apron_convt(const apron::environment& e) : env(e) { }

  virtual ~expr2apron_convt() { }

  /***** convert boolean or arithmetic expressions *****/
  virtual apron::tcons1 convert_ineq_expr(const exprt& e);

  virtual apron::texpr1 convert_arith_expr(const exprt& e);
  
  /****************** [-infty,+infty] ******************/
  apron::texpr1 get_top_interval();

  static bool has_supported_type(const exprt& e);

protected:
  /************* auxiliary methods *******************/
  virtual apron::texpr1 convert_constant(const exprt& e);

  virtual apron::texpr1 convert_symbol(const exprt& e);

  virtual apron::texpr1 convert_typecast(const exprt& e);

  virtual apron::texpr1 convert_unary_minus(const exprt& e);

  virtual apron::texpr1 convert_add(const exprt& e);

  virtual apron::texpr1 convert_sub(const exprt& e);

  virtual apron::texpr1 convert_mul(const exprt& e);

  virtual apron::texpr1 convert_div(const exprt& e);

  virtual apron::texpr1 convert_mod(const exprt& e);

  virtual apron::tcons1 convert_bool_constant(const exprt& e);

  virtual ap_texpr_rtype_t get_r_type(const exprt& e);

  virtual exprt translate_bool_typecast(const exprt& e);

  const apron::environment& env;


};


apron::tcons1 expr2apron_ineq(const apron::environment&, const exprt&);
apron::texpr1 expr2apron_arith(const apron::environment&, const exprt&);

#endif
