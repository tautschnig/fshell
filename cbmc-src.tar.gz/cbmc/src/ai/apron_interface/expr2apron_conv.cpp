#include "expr2apron_conv.h"

#include "expr2var.h"

#include <negate_expr.h>

#include <std_types.h>
#include <std_expr.h>
 

using namespace apron;


tcons1 expr2apron_ineq(const environment& env, const exprt& e)
{
  expr2apron_convt conv(env);
  return conv.convert_ineq_expr(e);
}

texpr1 expr2apron_arith(const environment& env, const exprt& e)
{
  expr2apron_convt conv(env);
  return conv.convert_arith_expr(e);
}


texpr1 expr2apron_convt::convert_arith_expr(const exprt& e)
{
  //unsupported expressions are overapproximated
  if(!has_supported_type(e))
    return get_top_interval();

  if(e.id() == ID_symbol)
    return convert_symbol(e);
  if(e.is_constant())
    return convert_constant(e);

  if(e.id() == ID_unary_minus) 
    return convert_unary_minus(e);

  if(e.id() == ID_typecast)
    return convert_typecast(e);

  if(e.id() == ID_plus) 
    return convert_add(e);
  else if(e.id() == ID_minus) 
    return convert_sub(e);
  else if(e.id() == ID_mult) 
    return convert_mul(e);
  else if(e.id() == ID_div) 
    return convert_div(e);
  else if(e.id() == ID_mod) 
    return convert_mod(e);
  else 
    //overapproximate unknown 
    return get_top_interval();
}

texpr1 expr2apron_convt::convert_unary_minus(const exprt& e)
{
  assert(e.operands().size() == 1);
  return -convert_arith_expr(e.op0());
}

texpr1 expr2apron_convt::convert_typecast(const exprt& e)
{
  assert(e.operands().size() == 1);
  ap_texpr_rtype_t rtype = get_r_type(e);
  return unary(AP_TEXPR_CAST, convert_arith_expr(e.op0()), rtype);
}

bool expr2apron_convt::has_supported_type(const exprt& e)
{
  const bitvector_typet& t = to_bitvector_type(e.type());

  return (t.id() == ID_signedbv && t.get_width() == 32) ||
         (t.id() == ID_floatbv && 
                (t.get_width() == 32 || t.get_width() == 64));

}


texpr1 expr2apron_convt::convert_constant(const exprt& e)
{
  const bitvector_typet& t = to_bitvector_type(e.type());

  unsigned width = t.get_width();

  if(t.id() == "floatbv")
  {
    if(width == 32)
      return texpr1(env, parse_float(e));
    else if(width == 64)
      return texpr1(env, parse_double(e));
  } else if(t.id() == "signedbv")
  {
    if(width == 32)
      return texpr1(env, parse_int(e));
  } 

  //unsupported expressions translated as top intervals
  return get_top_interval();
}

texpr1 expr2apron_convt::get_top_interval()
{
  return texpr1(env, coeff(top()));
}

texpr1 expr2apron_convt::convert_symbol(const exprt& e)
{
  symbol_exprt s = to_symbol_expr(e);
  if(!has_supported_type(s))
    return get_top_interval();
  else
    return texpr1(env, var(s.get_identifier().as_string()));
}

texpr1 expr2apron_convt::convert_add(const exprt& e)
{ 
  return add(convert_arith_expr(e.op0()), convert_arith_expr(e.op1()),
             get_r_type(e));
}

texpr1 expr2apron_convt::convert_sub(const exprt& e)
{ 
  return sub(convert_arith_expr(e.op0()), convert_arith_expr(e.op1()),
             get_r_type(e));
}

texpr1 expr2apron_convt::convert_mul(const exprt& e)
{ 
  return mul(convert_arith_expr(e.op0()), convert_arith_expr(e.op1()),
             get_r_type(e));
}

texpr1 expr2apron_convt::convert_div(const exprt& e)
{ 
  return div(convert_arith_expr(e.op0()), convert_arith_expr(e.op1()),
             get_r_type(e));
}

texpr1 expr2apron_convt::convert_mod(const exprt& e)
{ 
  return mod(convert_arith_expr(e.op0()), convert_arith_expr(e.op1()),
             get_r_type(e));
}

tcons1 expr2apron_convt::convert_bool_constant(const exprt& e)
{
  int z = 0;
  texpr1 zero(env, z);

  if(e.is_true())
    return zero == zero;
  else 
  {
    assert(e.is_false());
    return zero != zero;
  }
}

//reformulate "(bool) x" as "x != 0" 
exprt expr2apron_convt::translate_bool_typecast(const exprt& e)
{
  exprt helper(e.type().id() == ID_floatbv ? 
      ID_ieee_float_notequal : ID_notequal,
      e.type());

  constant_exprt zero(e.op0().type());
  zero.set_value("0");

  helper.copy_to_operands(e.op0());
  helper.copy_to_operands(zero);

  return helper;
}

tcons1 expr2apron_convt::convert_ineq_expr(const exprt& e)
{
  assert(e.type().id() == "bool");

  //std::cout << "converting " << e << std::endl;

  if(e.is_constant())
    return convert_bool_constant(e);

  if(e.id() == ID_typecast)
  {
    return convert_ineq_expr(translate_bool_typecast(e));
  } else if(e.id() == ID_not)
  {
    assert(e.operands().size() == 1);
      
    exprt negated;
    
    if(e.op0().id() == ID_typecast)
      negated = translate_bool_typecast(e.op0()); 
    else
      negated = e.op0();

    if(!negate_expr(negated))
      throw "could not negate expression";
    
    return convert_ineq_expr(negated);
  }

  if(e.operands().size() != 2)
    throw "unsupported boolean expression: " + e.to_string();

  assert(e.op0().type().id() == e.op1().type().id());

  if(e.id() == ID_equal || e.id() == ID_ieee_float_equal)
    return convert_arith_expr(e.op0()) == convert_arith_expr(e.op1());
  else if(e.id() == ID_notequal || e.id() == ID_ieee_float_notequal)
    return convert_arith_expr(e.op0()) != convert_arith_expr(e.op1());
  else if(e.id() == ID_gt)
    return convert_arith_expr(e.op0()) > convert_arith_expr(e.op1());
  else if(e.id() == ID_lt)
    return convert_arith_expr(e.op0()) < convert_arith_expr(e.op1());
  else if(e.id() == ID_ge)
    return convert_arith_expr(e.op0()) >= convert_arith_expr(e.op1());
  else if(e.id() == ID_le)
    return convert_arith_expr(e.op0()) <= convert_arith_expr(e.op1());
  else    
    throw "unsupported boolean expression: \n" + e.to_string();
}

ap_texpr_rtype_t expr2apron_convt::get_r_type(const exprt& e)
{
  const irep_idt& t = e.type().id();
  unsigned width = to_bitvector_type(e.type()).get_width();
  if(width != 32 && width != 64)
    throw "unexpected bitwidth in expr: \n" + e.pretty(1);

  if(t == "signedbv") 
  {
    if(width == 64)
      throw "64 bit integers not supported";

    return AP_RTYPE_INT;
  }
  else if(t == "floatbv")
    return width == 32 ? AP_RTYPE_SINGLE : AP_RTYPE_DOUBLE;
  else 
    throw "unexpected expression \n" + e.pretty(1);
}



