#include "apron_domain_type.h"

std::string apron_domain_type_to_string(apron_domain_typet t)
{
  switch(t)
  {
    case BOX:
      return "Box";
    case OCT:
      return "Octagon";
    case POLKA:
      return "Polyhedra (polka)";
    case POLKA_STRICT:
      return "Polyhedra strict (polka)";
    case PPL:
      return "Polyhedra (PPL)";
    case PPL_STRICT:
      return "Polyhedra strict (PPL)";
    default:
      throw "unknown type";
  }
}


