#include "apron_constraint_solver.h"
#include "var2expr.h"
#include <std_expr.h>
#include <std_types.h>

#include <iostream>

floatbv_typet get_float_type()
{
  floatbv_typet result;
  result.set_width(32);
  result.set_f(23);
  return result;
}

signedbv_typet get_int_type()
{
  signedbv_typet result;
  result.set_width(32);
  return result;
}



exprt bin_ar_expr(const exprt& e1, std::string type, const exprt& e2)
{
  assert(e1.type() == e2.type());
  exprt result(type);
  result.operands().push_back(e1);
  result.operands().push_back(e2);
  result.type() = e1.type();
  return result;
}

exprt get_var(const std::string& identifier, const typet& t)
{
  symbol_exprt result;
  result.set_identifier(identifier);
  result.type() = t;
  return result;
}

exprt get_float_var(const std::string& identifier)
{ return get_var(identifier, get_float_type()); }

exprt get_int_var(const std::string& identifier)
{ return get_var(identifier, get_int_type()); }

int main(int argc, const char** argv)
{
  contextt ctx;
  namespacet ns(ctx);

  apron_constraint_solvert solver(ns, BOX);
  
  exprt i5 = int2expr(5);
  exprt i0 = int2expr(0);
  exprt i1 = int2expr(1);

  //exprt f1 = float2expr(1.0f);
  //exprt fm1 = float2expr(-1.0f);
  //exprt f2 = float2expr(2.0f);
  //exprt fepsilon = float2expr(0.00001f);

  exprt x = get_int_var("x");
  exprt y = get_int_var("y");

  //exprt app0 = get_float_var("app0");
  //exprt diff0 = get_float_var("diff0");
  //exprt rad0 = get_float_var("rad0");
  //exprt inc = get_float_var("inc");
  //exprt diff1 = get_float_var("diff1");
  //exprt app1 = get_float_var("app1");
  
  //binary_relation_exprt eq1(app0, "=", diff0);
  //binary_relation_exprt eq2(diff0, "=", rad0);
  //binary_relation_exprt eq3(inc, "=", f1);
  /*binary_relation_exprt eq4(diff1, "=", 
    bin_ar_expr(  
      bin_ar_expr(
        diff0, "*", bin_ar_expr(fm1, "*", bin_ar_expr(rad0,"*",rad0))
      ),
      "/",
      bin_ar_expr(
        bin_ar_expr(f2, "*", inc),
        "*",
        bin_ar_expr(bin_ar_expr(f2, "*", inc), "+", f1)
      )
    ));*/

  binary_relation_exprt eq1(y, "<", i5);
  binary_relation_exprt eq2(y, ">", i0);
  binary_relation_exprt eq3(x, "=", bin_ar_expr(y, "+", i1));

  //binary_relation_exprt eq4(diff1, "=", bin_ar_expr(inc, "+", inc));
  //binary_relation_exprt lt1(diff0, "=", diff0);
  //binary_relation_exprt lt2(b, ">", a_plus_1);
  
  solver.set_to_true(eq1);
  solver.set_to_true(eq2);
  solver.set_to_true(eq3);
  //solver.set_to_true(eq4);

  if(solver.dec_solve() == decision_proceduret::D_UNSATISFIABLE)
    std::cout << "UNSAT" << std::endl;
  else
    std::cout << "UNKNOWN" << std::endl;

  return 0;
}
