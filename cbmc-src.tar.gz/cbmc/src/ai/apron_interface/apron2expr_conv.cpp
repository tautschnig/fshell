/*******************************************************************\

Module: Conversion from apron internal types to CPROVER expressions

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "apron2expr_conv.h"

#include <ansi-c/expr2c.h>
#include <rational.h>
#include <rational_tools.h>
#include <simplify_expr.h>

#include <sstream>
#include <iostream>

using namespace apron;


exprt apron2expr(const apron::abstract1& a, 
                 const contextt& ctx, 
                 apron::manager& man)
{ 
  apron2expr_convt c(ctx,man); 
  return c.convert(a);
}


exprt apron2expr_convt::convert(const abstract1& a)
{
  //std::cout << "ABSTRACT VALUE IS " << a << std::endl;
  
  tcons1_array t_arr = a.to_tcons_array(man);
  exprt result(ID_and, bool_typet());
  
  for(unsigned i = 0; i < t_arr.size(); i++)
  {
    result.copy_to_operands(convert(t_arr.get(i)));
  }

  if(result.operands().size() == 0)
    result.make_true();

  if(result.operands().size() == 1)
    return result.op0();

  return result;
}


bool all_zeroes(const std::string& d)
{
  for(unsigned i = 0; i < d.length(); i++)
    if(d[i] != '0')
      return false;

  return true;
}

void negate(exprt& e)
{
  if(e.id() == ID_unary_minus)
  {
    exprt negated = e.op0();
    e.swap(negated);
  } else 
  {
    if(e.is_constant() && 
      all_zeroes(to_constant_expr(e).get_value().as_string()))
    {
      return;
    }
    exprt negated(ID_unary_minus, e.type());
    negated.move_to_operands(e);
    e.swap(negated);
  }
}

const typet& apron2expr_convt::get_maxtype(
      const typet& t1, 
      const typet& t2)
{
  assert(t1.id() == ID_rational || t1.id() == ID_signedbv);
  assert(t2.id() == ID_rational || t2.id() == ID_signedbv);
  
  if(t1.id() == ID_rational)
    return t1;
  if(t2.id() == ID_rational)
    return t2;
  
  const signedbv_typet& b1 = to_signedbv_type(t1);
  const signedbv_typet& b2 = to_signedbv_type(t2);

  if(b1.get_width() > b2.get_width())
    return b1;
  else 
    return b2;
}

exprt apron2expr_convt::convert(const apron::tcons1& c)
{
  texpr1::const_iterator t = c.get_texpr();
  irep_idt cons_type;

  //apron constraints are a bit weird, the format is:
  //       left_child + right_child COMP 0
  
  switch(c.get_constyp())
  {
    case AP_CONS_EQ:
      cons_type = ID_equal;
      break; 
    case AP_CONS_SUPEQ: 
      cons_type = ID_ge;
      break;
    case AP_CONS_SUP:
      cons_type = ID_gt;
      break;
    case AP_CONS_EQMOD:
      throw "modulo constraints not supported";
      break;
    case AP_CONS_DISEQ:
      cons_type = ID_notequal;
      break;
  }

  if(t.get_discr() == AP_TEXPR_CST) {
    //false
    return false_exprt();
  }

  assert(t.get_discr() == AP_TEXPR_NODE);
  
  exprt left_child = convert(t.left());
  negate(left_child);
  exprt right_child = convert(t.right());

  exprt result(cons_type, typet(ID_bool));
  result.move_to_operands(right_child);
  result.move_to_operands(left_child);
  
  typet result_type = get_maxtype(result.op0().type(), result.op1().type());

  if(result.op0().type() != result_type)
    result.op0().make_typecast(result_type);
  if(result.op1().type() != result_type)
    result.op1().make_typecast(result_type);

  result.type().swap(result_type);

  simplify(result, ns);
  remove_apron_idioms(result);
  simplify(result, ns);

  make_overflow_safe(result);

  //std::cout << "translated " << c << " as " << std::endl << result.pretty() << std::endl;

  return result;
}

void apron2expr_convt::remove_apron_idioms(exprt& expr) 
{
  if(expr.id() == ID_mult)
  {
    //std::cout << std::endl << "===simplifying " << expr << std::endl;
    assert(expr.operands().size() == 2);
    exprt negated_lhs = expr.op0();
    exprt negated_rhs = expr.op1(); 

    negate(negated_rhs);
    negate(negated_lhs);

    simplify(negated_lhs, ns);
    simplify(negated_rhs, ns);
    
    if(negated_lhs.is_one()) {
    //-1*x == x
      expr.swap(expr.op1());
      negate(expr);
    } else if(negated_rhs.is_one()) {
    //x*-1 == -x
      expr.swap(expr.op0());
      negate(expr);
    }
  }

  Forall_operands(it, expr)
    remove_apron_idioms(*it);
}

irep_idt invert_rel(const irep_idt& id)
{
  if(id == ID_equal)
    return ID_equal;
  else if(id == ID_notequal)
    return ID_notequal;
  else if(id == ID_lt)
    return ID_gt;
  else if(id == ID_le)
    return ID_ge;
  else if(id == ID_gt)
    return ID_lt;
  else if(id == ID_ge)
    return ID_le;
  else
    throw "Cannot invert relation " + id.as_string();
}

void apron2expr_convt::create_bin_expr(
    const irep_idt& op, 
    exprt& lhs,
    exprt& rhs, 
    exprt& dest)
{

 
  dest.id(op);

  dest.move_to_operands(lhs);
  dest.move_to_operands(rhs);

  //get dest type
  typet dest_type = 
    get_maxtype(dest.op0().type(), dest.op1().type());

  dest.type().swap(dest_type);

  //typecast operands to dest type
  if(dest.op0().type() != dest.type())
  {
    dest.op0().make_typecast(dest.type());
  }
  if(dest.op1().type() != dest.type())
  {
    dest.op1().make_typecast(dest.type());
  }

}

exprt apron2expr_convt::convert(const apron::texpr1::const_iterator& t)
{
  exprt result;
  switch(t.get_discr())
  {
    case AP_TEXPR_CST:
      result = convert_constant(t);
      break;
    case AP_TEXPR_DIM:
      result = convert_variable(t);
      break;
    case AP_TEXPR_NODE:
      result = convert_operator(t);
      break;
  }
  //std::cout << "translated " << t << " as " << expr2c(result, namespacet(context)) << std::endl;

  return result;
}

exprt apron2expr_convt::
convert_constant(const apron::texpr1::const_iterator& t)
{ 
  const coeff& c = t.get_coeff(); 
  exprt result;
  std::stringstream s;

  switch(c.get_discr())
  {
    case AP_COEFF_SCALAR:
      s << c;
    break;
    case AP_COEFF_INTERVAL:
      throw "Translation of interval coefficients not implemented";
    break;
  }

  std::string str = s.str();
  
  //determine type (natural / rational)
  if(str.find('/') != std::string::npos)
  {
    size_t pos = str.find('/');
    std::string dividend_str = str.substr(0, pos);
    std::string divisor_str = str.substr(pos + 1);

    mp_integer dividend = string2integer(dividend_str);
    mp_integer divisor  = string2integer(divisor_str);

    rationalt r = dividend;
    r /= divisor;

    result = from_rational(r); 
  }
  else
  {
    mp_integer val = string2integer(str);

    unsigned bitwidth = 1;
    mp_integer tmp = val;
    while(tmp > 0)
    {
      tmp /= 2;
      bitwidth++;
    }
    bitwidth++;
    
    std::string binrep = integer2binary(val, bitwidth);
    signedbv_typet t(bitwidth);

    constant_exprt c(t);
    c.set_value(binrep);

    result.swap(c);
  }
    
  return result;
}

exprt apron2expr_convt::
convert_variable(const apron::texpr1::const_iterator& t)
{ 
  const var& v =  t.get_var();
  const std::string ident_string = v;

  irep_idt identifier(ident_string);
  
  symbolst::const_iterator it = context.symbols.find(identifier);
  if(it == context.symbols.end())
    throw "did not find variable \"" + ident_string + "\" in context";

  symbol_exprt result(it->first, it->second.type);
  return exprt(result);
}

exprt apron2expr_convt::
convert_operator(const apron::texpr1::const_iterator& t)
{ 
  irep_idt op;
  bool binary;
  switch(t.get_op())
  {
    case AP_TEXPR_ADD:
      op = ID_plus;
      binary = true;
      break;
    case AP_TEXPR_SUB:
      op = ID_minus;
      binary = true;
      break;
    case AP_TEXPR_MUL:
      op = ID_mult;
      binary = true;
      break;
    case AP_TEXPR_DIV:
      op = ID_div;
      binary = true;
      break;
    case AP_TEXPR_MOD:
      op = ID_mod;
      binary = true;
      break;
    case AP_TEXPR_NEG:
      op = ID_unary_minus;
      binary = false;
      break;
    case AP_TEXPR_CAST:
      op = ID_typecast;
      binary = false;
      break;
    case AP_TEXPR_SQRT:
      throw "not implemented";
      binary = false;
      break;
  }

  exprt result;

  if(binary)
  {
    //convert children
    exprt left_child = convert(t.left());
    exprt right_child = convert(t.right());

    create_bin_expr(op, left_child, right_child, result);
     
  } else {
    //unary operator
    result = convert(t.left());

    if(t.get_op() == AP_TEXPR_CAST)
    {
      //get destination type of cast
      typet target = translate_type(t.get_rtype());
      result.make_typecast(target);
    } else if(t.get_op() == AP_TEXPR_NEG) {
      negate(result);
    } else assert(0);

  }

  return result;
}

unsigned necessary_width(const exprt& e)
{
  const signedbv_typet& t = to_signedbv_type(e.type());
  unsigned width = t.get_width();

  if(e.is_constant())
  {
    mp_integer val = 
      binary2integer(to_constant_expr(e).get_value().as_string(), true); 
    if(val < 0)
      val = -val;
    unsigned bits = 1;
    while(val > 0) 
    {
      val /= 2;
      ++bits;
    }
    return bits;
  } else {
    return width;
  }
}

void apron2expr_convt::make_overflow_safe(exprt& e)
{
  Forall_operands(it, e)
    make_overflow_safe(*it);

  if(e.type().id() == ID_rational)
    //unbounded type cannot overflow 
    return;

  if(e.id() == ID_symbol)
    return;

  if(e.id() == ID_constant)
    return;

  const irep_idt& id = e.id();
  if(id == ID_typecast || id == ID_unary_minus) {
    //do nothing 
    return;
  } 

  assert(e.operands().size() == 2);
  unsigned w1 = necessary_width(e.op0());
  unsigned w2 = necessary_width(e.op1());

  unsigned new_width;

  if(id == ID_plus || id == ID_minus) {
    new_width = w1 > w2 ? w1 + 1 : w2 + 1;
  } else if(id == ID_mult) {
    new_width = w1+w2;
  } else if(id == ID_div || id == ID_mod || id == ID_equal || 
            id == ID_notequal || id == ID_ge || id == ID_gt ||
            id == ID_le || id == ID_lt) {
    new_width = w1 > w2 ? w1 : w2;
  } else assert(0); 
  
  signedbv_typet new_type;
  new_type.set_width(new_width);

  e.type().swap(new_type);

  if(e.op0().type() != e.type())
    e.op0().make_typecast(new_type);
  if(e.op1().type() != e.type())
    e.op1().make_typecast(new_type);
}

typet apron2expr_convt::translate_type(const ap_texpr_rtype_t& r_type)
{
  typet result;
  floatbv_typet float_result;

  switch(r_type)
  {
    case AP_RTYPE_REAL:
      throw "apron \"real\" type can't be translated";
      break;
    case AP_RTYPE_INT:
      result = signedbv_typet(32);
      return result;
      break;
    case AP_RTYPE_SINGLE:
      float_result.set_width(32);
      float_result.set_f(23);
      return float_result;
      break;
    case AP_RTYPE_DOUBLE:
      float_result.set_width(64);
      float_result.set_f(52);
      return float_result;
      break;
    case AP_RTYPE_EXTENDED:
      float_result.set_width(80);
      float_result.set_f(64);
      return float_result;
      break;
    case AP_RTYPE_QUAD:
      float_result.set_width(128);
      float_result.set_f(112);
      return float_result;
      break;
    default: 
      throw "unexpected apron type encountered";
  }

  assert(0);
}

//returns a safe result type (no overflows possible)
typet apron2expr_convt::get_safe_result_type(
    const irep_idt& op, 
    const typet& t1, 
    const typet& t2)
{
  if(t1.id() == ID_rational)
    return t1;
  if(t2.id() == ID_rational)
    return t2;

  const signedbv_typet& b1 = to_signedbv_type(t1);
  const signedbv_typet& b2 = to_signedbv_type(t2);

  if(op == ID_plus || op == ID_minus) {
    return b1.get_width() > b2.get_width() ? 
              signedbv_typet(b1.get_width()+1) : 
              signedbv_typet(b2.get_width()+1);
  } else if(op == ID_mult) {
    return signedbv_typet(b1.get_width() + b2.get_width() - 1);
  } else if(op == ID_div || op == ID_mod) {
    return get_maxtype(b1,b2);
  } else if(op == ID_unary_minus) {
    return t1;
  } else {
    assert(0); //should not occur here
    return t1;
  } 
}
