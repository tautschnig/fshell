/*******************************************************************\

Module: Wrapper for calls to apron

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef APRON_INTERFACE_APRON_WRAPPERT
#define APRON_INTERFACE_APRON_WRAPPERT

#include "apron_domain_type.h"

#include <apronxx.hh>
#include <apxx_box.hh>
#include <apxx_oct.hh>
#include <apxx_polka.hh>
#include <set>

#include <expr.h>
#include <decision_procedure.h>

using namespace apron;

class apron_wrappert : public decision_proceduret
{
public:
  typedef decision_proceduret SUB;

  apron_wrappert(const namespacet& ns, apron_domain_typet dt);

  virtual ~apron_wrappert();

  //not supported
  virtual exprt get(const exprt &expr) const
  { return exprt("nil"); }

  virtual void print_assignment(std::ostream &out) const
  { throw "print_assignment not supported"; }

  //add constraints to the solver
  virtual void set_to(const exprt &expr, bool value);

  virtual resultt dec_solve();

  virtual bool in_core(const exprt &expr) 
  { throw "in_core not supported"; }

  virtual std::string decision_procedure_text() const 
  { return "apron w. " + apron_domain_type_to_string(domain_type);}

protected:
  //add new variables to the environment
  typedef std::set<std::string> var_namest;

  void get_var_names(const exprt& e, 
                     var_namest& float_names, 
                     var_namest& int_names);

  exprt negate(const exprt& e);

  //DATA
  apron_domain_typet domain_type;
  //apron internal types
  manager* apron_man;
  environment env;

  typedef std::vector<exprt> constraintst;
  constraintst constraints;

  
};



#endif
