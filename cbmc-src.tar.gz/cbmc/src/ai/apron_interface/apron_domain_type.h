#ifndef APRON_DOMAIN_TYPES_H 
#define APRON_DOMAIN_TYPES_H 

#include <string>

typedef enum apron_domain_typet
{
  BOX, OCT, POLKA, POLKA_STRICT, PPL, PPL_STRICT
} apron_domain_typet;

std::string apron_domain_type_to_string(apron_domain_typet t);

#endif
