/*******************************************************************\

Module: Abstract DPLL

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "abstr_dpll.h"

#include "array_core_generalization.h"

#include "get_symbol_vals.h"

#include <find_expr.h>
#include <negate_expr.h>
#include <split_string.h>

#include <ansi-c/expr2c.h>

//#define DEBUGINFO 1


/*******************************************************************\

Function: abstr_dpllt::perform_analysis
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpllt::perform_analysis()
{
  decision_variables.clear();
  get_symbols(decision_variables);
  filter_symbols(decision_variables);
  get_ignored_symbols(ignored_symbols, options); 

  unsigned iteration = 0;

  init(current_element);

  bool conflict = conflict_or_proof();

  if(conflict)
  {
    std::cout << "PROOF COMPLETED" << std::endl;
    reset(); //clear remaining error elements
    return;
  }

  /*************** start main loop ******************/
  while(true)
  {

    if(iteration_limit >= 0 && iteration > unsigned(iteration_limit)) 
    {
      std::cout << "ITERATION LIMIT REACHED" << std::endl;
      return;
    }

#ifdef VERBOSE
    std::cout << std::endl 
      << "ITERATION (decision) " << iteration++ << std::endl
      <<"================ " << std::endl;
#endif

    std::cout << current_element.to_string() << std::endl;

    if(!decide(current_element))
    {
      std::cout << "FAILED TO VERIFY PROGRAM" << std::endl;
      std::cout << "Minimal unsafe element: " << current_element.to_string();
      break;
    }

    conflict = conflict_or_proof();

    if(!conflict)
    {
#ifdef VERBOSE
       std::cout << "FAILURE TO PROVE CASE" << std::endl;
#endif
    }
    else 
    {
#ifdef VERBOSE
       std::cout << "SUCCESSFULLY PROVEN CASE" << std::endl;
#endif 
      do 
      {
        generalize_proof(current_element);

        if(!learn_and_backtrack(current_element)) 
        {
          std::cout << "no further backtrack possible" << std::endl;
          reset(); //to clear remaining violations from proof
          goto end;
        }

#ifdef VERBOSE
        std::cout << std::endl 
        << "ITERATION (backtrack) " << iteration++ << std::endl
        <<"================ " << std::endl;
#endif 

        conflict = conflict_or_proof();

      } while(conflict);

    }
  } 
  /*************** end main loop ******************/
  
end: 
  std::cout << "== Procedure terminated after " << iteration 
            << " iterations " << std::endl;
}

void abstr_dpllt::get_symbols(const exprt& e, symbol_sett& s)
{
  if(e.id() == ID_symbol)
    s.insert(to_symbol_expr(e));
  forall_operands(it, e)
    get_symbols(*it, s);
}

void abstr_dpllt::get_symbols(symbol_sett& s)
{
  for(CFGt::const_nodes_vectort::const_iterator it = cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end(); it++)
  {
    if((*it)->type == ASSERT || (*it)->type == ASSUME)
    {
      get_symbols((*it)->reasoning_guard, s);
    } 
    else if((*it)->type == ASSIGN)
    {
      const code_assignt& assign = to_code_assign((*it)->code);
      get_symbols(assign.lhs(), s);
      get_symbols(assign.rhs(), s);
    } 
    else if((*it)->type == GOTO)
    {
      get_symbols((*it)->jump_condition, s);
    }
  }
}

void abstr_dpllt::filter_symbols(symbol_sett& s)
{
  symbol_sett filtered;
  std::string pattern = options.get_option("filter-dec-vars");

  for(symbol_sett::const_iterator it = s.begin();
      it != s.end(); it++)
  { 
    const irep_idt& type_id = it->type().id();

    //filter for numeric types
    if(type_id == ID_signedbv || type_id == ID_unsignedbv || 
       type_id == ID_floatbv)
    {
      std::string identifier = 
        to_symbol_expr(*it).get_identifier().as_string();

      if(identifier.find(pattern) != std::string::npos)
        filtered.insert(*it);
    }

  }

  filtered.swap(s);
}

abstr_elementt abstr_dpllt::get_initial_element()
{
  return current_element;
}



/*******************************************************************\

Function: abstr_dpllt::get_ignored_symbols
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpllt::get_ignored_symbols(
  std::set<irep_idt>& ids, const optionst& opt)
{
  std::string do_not_generalize = opt.get_option("do-not-generalize");
  std::vector<std::string> split;
  split_string(do_not_generalize, ',', split);

  while(split.size() > 0)
  {
    ids.insert(irep_idt(split.back()));
    split.pop_back();
  }
  
}



/*******************************************************************\

Function: abstr_dpllt::conflict_or_proof

  Inputs: 

 Outputs:

 Purpose: Returns true if either a conflict can be deduced or 
          we can prove the instance correct under the current 
          partial assignment

\*******************************************************************/

bool abstr_dpllt::conflict_or_proof()
{
  bool conflict = !deduce();

  if(!conflict)
  {
    local_exprst v;
    sub::perform_analysis();
    get_violated_assertions(v);

    //also a conflict if proof holds
    conflict |= (v.size() == 0);
  }
  return conflict;
}

//Since we are not interested in invariant generation, we can ignore everything after the last assert
void abstr_dpllt::init_analysis()
{
  sub::init_analysis();
  if(unnecessary_top_vec.size() > 0)
  {
    abstr_vec = unnecessary_top_vec;
    return;
  }
  //construct unnecessary top
  std::cout << "finding unnecessary nodes ...";
  
  std::set<const CFG_nodet*> necessary;
  std::vector<const CFG_nodet*> worklist;
  
  //find assertions
  for(CFGt::const_nodes_vectort::const_iterator 
        it = cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end(); it++) 
  {
    if((*it)->type == ASSERT && !(*it)->reasoning_guard.is_true())
    {
      necessary.insert(*it);
      worklist.push_back(*it);  
    }
  }

  //compute fixpoint mu X. assert_nodes u predecessor(X)
  while(worklist.size() > 0)
  {
    const CFG_nodet& next = *worklist.back(); worklist.pop_back();
    for(std::set<CFG_nodet*>::const_iterator it = next.predecessors.begin();
        it != next.predecessors.end(); ++it)
    {
      if(necessary.find(*it) == necessary.end())
      {
        //not seen before
        necessary.insert(*it);
        worklist.push_back(*it);
      }
    }
  }

  std::cout << " found " << (cfg.get_ordered_nodes().size() - necessary.size())
            << " unnecessary nodes" << std::endl;

  //now construct initial vector
  for(CFGt::const_nodes_vectort::const_iterator 
        it = cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end(); it++) 
  {
    if(necessary.find(*it) == necessary.end())
    {
      //node is unnecessary
      abstr_vec[(*it)->id] = domain.top();
    }
  }

  unnecessary_top_vec = abstr_vec;

}  
