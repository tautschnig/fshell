/*******************************************************************\

Module: Main Module 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "ai_parseoptions.h"

#ifdef HAVE_APRON
#include "apron_domain.h" 
#endif 

#include "domains/disequality_domain.h"
#include "domains/interval_domain.h"
#include "domains/diseq_interval_domain.h"
#include "domains/arr_diseq_interval_domain.h"
#include "domains/interval_array_domain.h"
#include "domains/expr_prop_domain.h"
#include "domains/float_interval_element.h"
#include "proof_growing_analysis.h"
#include "abstr_dpll_search.h"
#include "simplify_cfg.h"
#include "count_cfg_paths.h"
#include "loop_modified_vars.h"

#include <goto-programs/goto_convert_functions.h>
#include <goto-programs/goto_function_pointers.h>
#include <goto-programs/read_goto_binary.h>
#include <goto-programs/goto_check.h>
#include <goto-programs/goto_inline.h>

#include <pointer-analysis/value_set_analysis.h>
#include <pointer-analysis/goto_program_dereference.h>

#include <ansi-c/ansi_c_language.h>
#include <ansi-c/expr2c.h>

#include <langapi/mode.h>

#include <i2string.h>
#include <std_code.h>
#include <std_expr.h>
#include <config.h>

#include <algorithm>
#include <memory>

void ai_parseoptionst::help()
{
  std::cout << 
  "USAGE: ./ai <progrname>.c" << std::endl;
  std::cout <<
"Options:\n"
  "--help \t\t Display this message\n"
  "--show-symbol-table \n"
  "--show-goto-functions \n"
  "--function <f>\t\t Set function f as main function\n"
  "--box \t\t Apron box domain\n"
  "--polyhedra \t\t Apron polyhedra\n"
  "--octagon \t\t Apron octacgon\n"
  "--strict-polyhedra \t Apron strict polyhedra\n"
  "--widening k\t\t Perform widening after k loop iterations \n"
  "--disequality \t\t Use disquality domain\n"
  "--intervals \t\t Use intervals (non-apron) \n"
  "--proof-growing \t\t Use proof growing analysis \n"
  "--proof-search \t\t Use DPLL-style proof search \n"
  "--set-var-range \t\t Set range of variables for proof search\n"
  "--bmc-thresh \t\t Set relative range of variables at which bmc is called\n"
  "--diseq-itv \t\t Disequalities+intervals \n"
  "--arr-diseq-itv \t\t Disequalities+intervals+arrays\n"
  "--inline \t\t Inline function calls\n"
  "--itv-arrays \t\t Intervals + arrays (default)\n"
  "--max-array-size \t Maximum size of arrays that are emulated\n"
  "--block-inv-output <expr-id> \t Do not output invariants containing certain expressions\n"
  "--invariants\t\t Display invariants\n"
  "--rounding-mode \t\t Set rounding mode for FP\n"
  "--do-not-generalize <set>\t Comma separated set of expression ids that are ignored during --fattening\n"
  "--const-prop \t\t Constant propagation domain\n"\
  "--expr-prop \t\t Expression propagation domain\n"\
  "--preprocess-const-prop\t\t Preprocess CFG with constant propagation\n"
  "--preprocess-expr-prop\t\t Preprocess CFG with expression propagation\n"
  "--filter-dec-vars <filter_id>\t\t Only use var as decision vars whose identifier contains <filter_id>\n"
  "--unwind <n>\t\t Unwind each loop n times\n";

}

ai_parseoptionst::ai_parseoptionst(int argc, const char **argv):
  parseoptions_baset(AI_OPTIONS, argc, argv),
  language_uit("AI", cmdline)
{
}

void ai_parseoptionst::get_declarations(var_listt& l, const CFGt& p)
{
  for(CFGt::const_nodes_vectort::const_iterator it = 
        p.get_ordered_nodes().begin();
      it != p.get_ordered_nodes().end(); it++)
    if((*it)->type == DECL)
    {
      const code_declt& decl = to_code_decl((*it)->code);
      l.push_back(to_symbol_expr(decl.symbol()));
    }
}

#ifdef HAVE_APRON
bool is_not_supported_by_apron(const exprt& e)
{
  return !apron_domaint::is_supported(to_symbol_expr(e));
}
#endif 

std::auto_ptr<abstr_var_domaint> var_domain;
std::auto_ptr<array_struct_emulatort> emul;

std::auto_ptr<abstr_domaint> ai_parseoptionst::
get_domain(
    optionst& options, 
    CFGt& cfg, 
    goto_functionst::goto_functiont& fun,
    const namespacet& ns)
{
  ieee_floatt::rounding_modet rounding_mode = get_rounding_mode(options);

  if(options.get_option("domain") == "const-prop")
  {
    return std::auto_ptr<abstr_domaint>(new const_prop_domaint(ns));
  }
  else if(options.get_option("domain") == "expr-prop")
  {
    return std::auto_ptr<abstr_domaint>(new expr_prop_domaint(ns));
  }
  else if(options.get_option("domain") == "disequality")
  {
    return std::auto_ptr<abstr_domaint>(new disequality_domaint());
  } 
  else if(options.get_option("domain") == "diseq-itv") 
  {
    return std::auto_ptr<abstr_domaint>(
        new diseq_interval_domaint(rounding_mode));
  } 
  else if(options.get_option("domain") == "arr-diseq-itv") 
  {
	  return std::auto_ptr<abstr_domaint>(
        new arr_diseq_interval_domaint(rounding_mode));
  } 
  else if(options.get_option("domain") == "intervals") 
  {
    return std::auto_ptr<abstr_domaint>(
        new interval_domaint(rounding_mode));
  } 
  else if(options.get_option("domain") == "itv-arrays") 
  {
    emul = std::auto_ptr<array_struct_emulatort>(
        new array_struct_emulatort(options.get_int_option("max-array-size")));
    array_struct_emulatort& em = *emul;
    return std::auto_ptr<abstr_domaint>(
        new interval_array_domaint(em, rounding_mode));
  } 
  else 
  {
    //find all occurring variables
    var_listt list; 
    get_declarations(list, cfg);
    get_function_arguments(list, fun);

#ifdef HAVE_APRON
    //filter out variables that have unsupported type
    list.erase(
        std::remove_if(list.begin(), list.end(), is_not_supported_by_apron),
        list.end()
        );

    apron_domain_typet type;

    if(options.get_option("domain") == "box")
      type = BOX;
    else if(options.get_option("domain") == "octagon")
      type = OCT;
    else if(options.get_option("domain") == "polyhedra")
      type = POLKA;
    else if(options.get_option("domain") == "strict-polyhedra")
      type = POLKA_STRICT;
    else  
      type = BOX; //default
    return std::auto_ptr<abstr_domaint>(new apron_domaint(type, list, context));
#else
    throw "Apron support not linked in.";
#endif
  }

}

void ai_parseoptionst::
get_function_arguments(var_listt& l, const goto_functionst::goto_functiont& f)
{
  const code_typet::argumentst& args = f.type.arguments();

  std::cout << args.size() << " arguments in function " << std::endl;

  for(code_typet::argumentst::const_iterator it = args.begin();
      it != args.end(); it++)
  {
    l.push_back(symbol_exprt(it->get_identifier(), it->type()));
    std::cout << l.back().pretty() << std::endl;
  }
}


int ai_parseoptionst::doit()
{
  goto_functionst goto_functions;
  optionst options;

  register_languages();

  get_command_line_options(options);
  
  if(get_goto_program(goto_functions, options))
    return 0;

  std::cout << "got goto-program" << std::endl;

  namespacet ns(context);

  std::string main_function;

  if(cmdline.isset("inline"))
  {

    main_function = "main"; //after inlining everything is called main

  }
  else if(cmdline.isset("function"))
  {

    main_function = std::string("c::") + cmdline.getval("function");

  } else
  {

    main_function = "c::main";

  }

  if(goto_functions.function_map.find(main_function) == 
     goto_functions.function_map.end())
  {

    std::cout << "function " << main_function << " not found" << std::endl;   
    exit(1);

  }


  goto_functionst::goto_functiont& fun = 
    goto_functions.function_map[main_function];
    
  goto_programt &p = fun.body;

  CFGt cfg(context);
  cfg.initialize(p);


  std::cout << "CFG has " + i2string(cfg.size()) + " nodes" << std::endl;
  //unwind all loops n times
  if(options.get_option("unwind") != "")
  {
    loop_infot loop_info(cfg);
    unwind_cfg(cfg, options);
    std::cout << "CFG has " + i2string(cfg.size()) + " nodes" << std::endl;
  }

  if(cmdline.isset("count-paths"))
  {
    std::cout << "Counting loop-free paths ... " << std::endl;
    mp_integer paths = count_CFG_paths(cfg);
    std::cout << paths << " paths found" << std::endl;
    return 0;
  }

  std::cout << "Obtaining loops ... ";
  std::cout.flush();
  loop_infot loop_info(cfg);
  std::cout << std::endl;
  std::cout << "done" << std::endl;

  if(cmdline.isset("loop-modified"))
  {
    std::cout << "Running pointer analysis for modified vars... " << std::endl;
    value_set_points_to_infot points_to(cfg, goto_functions, main_function, ns);
    loop_modified_var_infot mod_info(loop_info, cfg, points_to); 

    std::cout << mod_info.to_string(ns) << std::endl;
    return 0;
  }

  //preprocess instance
  if(options.get_bool_option("preprocess-expr-prop"))
		simplify_with_expr_prop(cfg, loop_info, ns);
  else if(options.get_bool_option("preprocess-const-prop"))
		simplify_with_const_prop(cfg, loop_info, ns);



  cfg.output(std::cout);

  try {
    std::cout << "set widening to " 
              << options.get_int_option("widening") << std::endl;
    
    if(cmdline.isset("proof-growing") || cmdline.isset("proof-search"))
    { 
      emul = std::auto_ptr<array_struct_emulatort>(
        new array_struct_emulatort(options.get_int_option("max-array-size")));

      array_struct_emulatort& em = *emul;
      interval_array_domaint itv_domain(em, get_rounding_mode(options)); 

      //also set default mode to this rounding mode
      float_intervalt::set_default_rounding(
        get_rounding_mode(options));
      
      std::auto_ptr<abstr_dpllt> analysis;
      if(cmdline.isset("proof-growing"))
      {
        analysis = 
          std::auto_ptr<abstr_dpllt>( 
            new proof_growing_analysist(
              cfg, 
              loop_info,
              itv_domain, 
              options.get_int_option("widening"), 
              ns, options)
          );
      } 
      else 
      {
        analysis = 
          std::auto_ptr<abstr_dpllt>( 
            new abstr_dpll_searcht(
              cfg, 
              loop_info,
              itv_domain, 
              options.get_int_option("widening"), 
              ns, options)
          );
      }
      analysis->set_message_handler(get_message_handler());
      analysis->set_iteration_limit(
        options.get_int_option("iteration-limit"));
      analysis->perform_analysis();

      std::cout << std::endl << std::endl;
      //print_annotated_nodes(options, ns, cfg, *analysis);
      print_result(*analysis, options);
    } else {

      std::auto_ptr<abstr_domaint> domain = get_domain(options, cfg, fun, ns);

      abstr_fwd_analysist analysis(
          cfg,
          loop_info, 
          *domain, 
          options.get_int_option("widening"), 
          ns);

      analysis.perform_analysis();


      if(options.get_bool_option("invariants"))
        print_annotated_nodes(options, ns, cfg, analysis);
      
      print_result(analysis, options);
      std::cout << std::endl << std::endl;
    }

  } catch(const char* c)
  {
    error(c);
    return 1;
  } catch(std::string c)
  {
    error(c);
    return 1;
  }


  return 0;
}

void ai_parseoptionst::print_annotated_nodes(
    const optionst& options,
    const namespacet& n,
    const CFGt& cfg,
    const abstr_fwd_analysist& analysis)
{
  std::set<irep_idt> block_set;
  std::string block_string = options.get_option("block-inv-output");

  if(block_string != "")
  {
    parse_inv_block(block_string, block_set);
    assert(block_set.size() != 0);
  }

  for(CFGt::const_nodes_vectort::const_iterator it = 
          cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end();
      it++) 
  {
    std::cout <<
"*****************************************************************************"
      << std::endl;

    exprt invar = analysis.get_invariant(**it);
   
    prune_expr(block_set, invar);

    std::cout << expr2c(invar,n) << std::endl;
    
    std::cout << "**** ";
    //print location
    if((*it)->code.is_not_nil())
    {
      const irept& location = (*it)->code.find("#location");
      std::cout << location.get("file") << ":" << location.get("line") << " " 
                << "(" + location.get("function").as_string() + ")";
    } 
    std::cout << std::endl;

    cfg.output_node(**it, std::cout);
    ////std::cout << (*it)->code.pretty() << std::endl;
    //std::cout << analysis.get_invariant(*it).pretty() << std::endl;
  }
}

bool ai_parseoptionst::prune_expr(const std::set<irep_idt>& block_set, exprt& e)
{
  if(e.id() == ID_and) {
    exprt new_and(ID_and, e.type());

    Forall_operands(it, e) 
    {
      if(!prune_expr(block_set, *it))
        new_and.move_to_operands(*it);
    }

    e.swap(new_and);

    if(e.operands().size() == 0)
    {
      e.make_true();
    } 
    else if(e.operands().size() == 1)
    {
      exprt tmp = e.op0();
      e.swap(tmp);
    }
    
    return e.is_true();

  } else if(block_set.find(e.id()) != block_set.end()) {
    return true;
  } else {
    bool block = false;
    Forall_operands(it, e)
    {
      if(prune_expr(block_set, *it))
      {
        block = true;
        break;
      }
    }

    return block;
  }
}

void ai_parseoptionst::print_result(
    abstr_fwd_analysist& analysis, const optionst& options)
{

  abstr_fwd_analysist::local_exprst violations;
  analysis.get_violated_assertions(violations);

  if(violations.size() == 0)
  {
    std::cout << "**** Verification successful " << std::endl;
  } else {
    std::cout << "**** Verification failed " << std::endl 
      << "Found " << violations.size() << " possible assertion violations" << std::endl;

    if(!options.get_bool_option("show-violations"))
    {
      for(abstr_fwd_analysist::local_exprst::const_iterator it = 
          violations.begin(); it != violations.end(); it++)
      {
        std::cout << "********"
          << std::endl;
        analysis.get_cfg().output_node(*it->first, std::cout);
        std::cout << "Potential violation: " 
          <<  expr2c(it->second,analysis.ns) << std::endl;
      }
    }
  }

}

void ai_parseoptionst::get_command_line_options(optionst &options)
{
  if(config.set(cmdline))
  {
    usage_error();
    exit(1);
  }

  //keeping these around cause they might be important for goto-programs
  //not sure if they are
  options.set_option("simplify", true);
  options.set_option("substitution", true);
  options.set_option("bounds-check", false);
  options.set_option("div-by-zero-check", false);
  options.set_option("overflow-check", false);
  options.set_option("nan-check", false);
  options.set_option("pointer-check", false);
  options.set_option("assertions", true);
  options.set_option("assumptions", true);
  options.set_option("partial-loops", false);
  options.set_option("slice-formula", false);
  options.set_option("simplify-if", true);
  options.set_option("arrays-uf", "auto");

  //default
  options.set_option("domain", "intervals");

  if(cmdline.isset("block-inv-output")) {
    options.set_option(
      "block-inv-output", 
      cmdline.getval("block-inv-output"));
  }
  if(cmdline.isset("diseq-itv")) {
    options.set_option("domain", "diseq-itv");
  } 
  if(cmdline.isset("arr-diseq-itv")) {
    options.set_option("domain", "arr-diseq-itv");
  }
  if(cmdline.isset("intervals")) {
    options.set_option("domain", "intervals");
  }
  if(cmdline.isset("itv-arrays")) {
    options.set_option("domain", "itv-arrays");
  }
  if(cmdline.isset("box")) {
    options.set_option("domain", "box");
  }
  if(cmdline.isset("octagon")) {
    options.set_option("apron", true);
  }
  if(cmdline.isset("polyhedra")) {
    options.set_option("domain", "polyhedra");
  }
  if(cmdline.isset("polyhedra-strict")) {
    options.set_option("domain", "polyhedra-strict");
  }
  if(cmdline.isset("disequality")) {
    options.set_option("domain", "disequality");
  }
  if(cmdline.isset("const-prop")) {
    options.set_option("domain", "const-prop");
  } 
  if(cmdline.isset("expr-prop")) {
    options.set_option("domain", "expr-prop");
  }

  if(cmdline.isset("widening"))
    options.set_option("widening", cmdline.getval("widening"));
  else
    options.set_option("widening", "10");

  if(cmdline.isset("unwind"))
    options.set_option("unwind", cmdline.getval("unwind"));

  if(cmdline.isset("iteration-limit"))
    options.set_option("iteration-limit", cmdline.getval("iteration-limit"));
  else 
    options.set_option("iteration-limit", "-1");

  if(cmdline.isset("max-array-size"))
    options.set_option("max-array-size", cmdline.getval("max-array-size"));
  else
    options.set_option("max-array-size", "16");

  if(cmdline.isset("rounding-mode"))
    options.set_option("rounding-mode", cmdline.getval("rounding-mode"));
  else
    options.set_option("rounding-mode", "ROUND_TO_EVEN");

  if(cmdline.isset("do-not-generalize"))
    options.set_option(
      "do-not-generalize", 
      cmdline.getval("do-not-generalize"));

  if(cmdline.isset("filter-dec-vars"))
    options.set_option(
      "filter-dec-vars",
      cmdline.getval("filter-dec-vars"));

  options.set_option(
    "preprocess-const-prop",
    cmdline.isset("preprocess-const-prop"));

  options.set_option(
    "preprocess-expr-prop",
    cmdline.isset("preprocess-expr-prop"));

  options.set_option(
    "show-violations",
    cmdline.isset("show-violations"));

  options.set_option("invariants", cmdline.isset("invariants"));

  options.set_option("inline", cmdline.isset("inline"));

  if(cmdline.isset("set-var-range"))
    options.set_option("set-var-range", cmdline.getval("set-var-range"));
  if(cmdline.isset("bmc-thresh"))
    options.set_option("bmc-thresh", cmdline.getval("bmc-thresh"));
  else options.set_option("bmc-thresh", "0"); //deactivate bmc 

  if(cmdline.isset("bmc-bt-thresh"))
    options.set_option("bmc-bt-thresh", cmdline.getval("bmc-bt-thresh"));
  else
    options.set_option("bmc-bt-thresh", 2);


  options.set_option("bmc-thresh-rel", cmdline.isset("bmc-thresh-rel"));

  if(cmdline.isset("dec-heur-berkmin"))
    options.set_option("dec-heur", "berkmin");
  else if(cmdline.isset("dec-heur-range-rel"))
    options.set_option("dec-heur", "range-rel");
  else if(cmdline.isset("dec-heur-range"))
    options.set_option("dec-heur", "range");
  else //DEFAULT
    options.set_option("dec-heur", "range-rel");

  options.set_option("bmc-on-backtrack", cmdline.isset("bmc-on-backtrack"));
}

void ai_parseoptionst::register_languages()
{
  register_language(new_ansi_c_language);
}

bool ai_parseoptionst::
get_goto_program(goto_functionst &goto_functions, optionst& options)
{
  if(cmdline.args.size()==0)
  {
    error("Please provide a program to verify");
    return true;
  }

  try
  {
    if(cmdline.args.size()==1 &&
       is_goto_binary(cmdline.args[0]))
    {
      status("Reading GOTO program from file");

      if(read_goto_binary(cmdline.args[0],
           context, goto_functions, get_message_handler()))
        return true;
        
      config.ansi_c.set_from_context(context);

      if(cmdline.isset("show-symbol-table"))
      {
        show_symbol_table();
        return true;
      }
    }
    else
    {
      if(parse()) return true;
      if(typecheck()) return true;
      if(final()) return true;

      // we no longer need any parse trees or language files
      clear_parse();

      if(cmdline.isset("show-symbol-table"))
      {
        show_symbol_table();
        return true;
      }

      status("Generating GOTO Program");

      goto_convert(
        context, options, goto_functions,
        ui_message_handler);
    }

    if(process_goto_program(goto_functions, options))
      return true;
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  catch(std::bad_alloc)
  {
    error("Out of memory");
    return true;
  }
  
  return false;
}
   
bool ai_parseoptionst::
process_goto_program(goto_functionst &goto_functions, optionst& options)
{
  try
  {
    namespacet ns(context);

    status("Function Pointer Removal");
    remove_function_pointers(ns, goto_functions);

    // do partial inlining
    if(cmdline.isset("inline"))
      goto_inline(goto_functions, ns, ui_message_handler);
    else
      goto_partial_inline(goto_functions, ns, ui_message_handler);

    if(cmdline.isset("remove-pointers"))
    {
      status("Pointer analysis");
      value_set_analysist value_set_analysis(ns);
      value_set_analysis(goto_functions);
      remove_pointers(goto_functions, context, options, value_set_analysis);
    }
    
    // add generic checks
    goto_check(ns, options, goto_functions);
    
    // recalculate numbers, etc.
    goto_functions.update();

    // add loop ids
    goto_functions.compute_loop_numbers();

    // show it?
    if(cmdline.isset("show-goto-functions"))
    {
      goto_functions.output(ns, std::cout);
      return true;
    }
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  catch(std::bad_alloc)
  {
    error("Out of memory");
    return true;
  }
  
  return false;
}


void ai_parseoptionst::parse_inv_block(
    const std::string& c, 
    std::set<irep_idt>& blocked)
{
  std::stringstream ss(c);
  std::string item;
  while(std::getline(ss, item, ','))
    blocked.insert(irep_idt(item));
}

ieee_floatt::rounding_modet ai_parseoptionst::get_rounding_mode(
    const optionst& options)
{
  std::string rmode = options.get_option("rounding-mode");

  //get rounding mode
  if(rmode == "UNKNOWN")
    return ieee_floatt::UNKNOWN;
  else if(rmode == "ROUND_TO_EVEN")
    return ieee_floatt::ROUND_TO_EVEN;
  else if(rmode =="ROUND_TO_ZERO")
    return ieee_floatt::ROUND_TO_ZERO;
  else if(rmode =="ROUND_TO_PLUS_INF")
    return ieee_floatt::ROUND_TO_PLUS_INF;
  else if(rmode == "ROUND_TO_MINUS_INF")
    return ieee_floatt::ROUND_TO_MINUS_INF;
  else if(rmode == "UNKNOWN")
    return ieee_floatt::UNKNOWN;
  else if(rmode == "NONDETERMINISTIC")
    return ieee_floatt::NONDETERMINISTIC;
  
  std::cout << "Unknown rounding mode: " << rmode << std::endl;
  exit(1);
}


void ai_parseoptionst::simplify_with_const_prop(
    CFGt& cfg, 
    const loop_infot& loop_info,
    const namespacet& ns)
{ 
  std::cout << "constant propagation ... ";
  std::cout.flush();
  const_prop_domaint cp_domain(ns);
  abstr_fwd_analysist analysis(
    cfg, loop_info, cp_domain, 10, ns);
  std::cout << "done" << std::endl;
  analysis.perform_analysis();
  std::cout << "simplifying cfg ... ";
  simplify_cfg(analysis, ns, cfg);
  std::cout << "done " << std::endl;
}

void ai_parseoptionst::simplify_with_expr_prop(
    CFGt& cfg, 
    const loop_infot& loop_info,
    const namespacet& ns)
{ 
  std::cout << "expr propagation ... ";
  std::cout.flush();
  expr_prop_domaint expr_domain(ns);
  abstr_fwd_analysist analysis(
    cfg, loop_info, expr_domain, 10, ns);
  std::cout << "done" << std::endl;
  analysis.perform_analysis();
  std::cout << "simplifying cfg ... ";
  simplify_cfg(analysis, ns, cfg);
  std::cout << "done " << std::endl;
}


void ai_parseoptionst::unwind_cfg(
    CFGt& cfg, 
    const optionst& options)
{
  std::cout << "unwinding loops ...";
  std::cout.flush();

  int unwind = options.get_int_option("unwind");
  
  if(unwind < 1)
    throw "--unwind must be at least 1";   

  assert(unwind > 0);

  //in order to get around certain difficulties with loop_info types
  //we apply the strategy of unrolling loops from the deepest most loops down
  //wards
  
  unsigned max_depth = 0;
  
  {
    loop_infot loop_info(cfg);

    //first get the maximum depth of any loop
    for(std::list<loop_infot::loopt>::const_iterator it = 
        loop_info.loops.begin(); it != loop_info.loops.end(); it++)
    {
      max_depth = std::max(max_depth, it->depth());
    }
  }

  //now count depth up from maxdepth to zero, and unroll loops at that depth
  for(int depth = max_depth; depth >= 0; depth--)
  {
    loop_infot loop_info(cfg);
    //we can safely unroll sibling without inner loops with the same loop info
    for(std::list<loop_infot::loopt>::const_iterator it = 
          loop_info.loops.begin();
        it != loop_info.loops.end(); it++)
    {
      if(it->depth() == (unsigned) depth)
        cfg.unwind_loop(it->header, loop_info, unwind);
    }

    //after each iteration we need to recalculate loop info
    loop_info = loop_infot(cfg);
  }
  
  std::cout << "... done" << std::endl;
}

