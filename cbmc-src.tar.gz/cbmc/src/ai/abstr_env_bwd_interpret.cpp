#include "abstr_env.h"

#include <negate_expr.h>

/* backward interpretation of a boolean expression (result == true)*/
var_mapt abstr_env_domaint::bwd_interpret_bool(
  const exprt& e, 
  const var_mapt& context,
  bool result,
  fwd_mapt& cache)
{
  if(context.is_bot())
  {
    return var_mapt::bot();
  }

  const irep_idt& id = e.id();
  
  if(e.is_true())
  {
    if(result)
      return var_mapt();
    else
      return var_mapt::bot();
  }
  else if(e.is_false())
  {
    if(!result)
      return var_mapt();
    else
      return var_mapt::bot();
  }
  else if(id == ID_and || id == ID_or) {
    return bwd_interpret_bool_andor(e, context, result, cache);
  }
  else if(id == ID_not) 
  {
    return bwd_interpret_bool_not(e, context, result, cache);
  }
  else if(id == ID_equal || id == ID_notequal || 
          id == ID_ieee_float_equal || id == ID_ieee_float_notequal ||
          id == ID_lt || id == ID_le || id == ID_gt || id == ID_ge) 
  {
    return bwd_interpret_bool_binrel(e, context, result, cache);         
  }
  else if(id == ID_typecast) 
  {
    return bwd_interpret_bool_typecast(e, context, result, cache);
  }
  else if(id == ID_if)
  {
    return bwd_interpret_bool_if(e, context, result, cache);
  }
  else if(id == ID_implies)
  {
    return bwd_interpret_bool_implies(e, context, result, cache);
  }
  else if(id == ID_symbol)
  {
    return bwd_interpret_bool_symbol(e, context, result, cache);
  }
  else 
  {
    return context;
  } 
}

var_mapt abstr_env_domaint::bwd_interpret_bool_andor(
  const exprt& e, 
  const var_mapt& context,
  bool result,
  fwd_mapt& cache)
{
  //meet for and, join for or
  var_mapst results;
  results.reserve(e.operands().size());

  forall_operands(it, e)
    results.push_back(bwd_interpret_bool(*it, context, result, cache));

  assert(results.size() != 0);
  bool do_meet = (e.id() == ID_and && result) || (e.id() == ID_or && !result);

  for(var_mapst::iterator it = results.begin() + 1; it != results.end(); it++)
  {
    if(do_meet)
      meet_inplace(results.front(), *it);
    else 
      join_inplace(results.front(), *it);
  }
  return results.front();
}


var_mapt abstr_env_domaint::bwd_interpret_bool_not(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache)
{
  return bwd_interpret_bool(e.op0(), context, !result, cache);
}

var_mapt abstr_env_domaint::bwd_interpret_bool_binrel(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache)
{
  assert(e.operands().size() > 0);

  const exprt& bin_rel = e;

  if(bin_rel.op0().type().id() == ID_bool)
  {
    //handle "(bool) == (bool)" and "(bool != bool)"
    assert(bin_rel.operands().size() == 2 && bin_rel.op1().type().id() == ID_bool);
    if(bin_rel.id() == ID_equal)
    { 
      exprt both_false(ID_and, typet(ID_bool));
      both_false.copy_to_operands(bin_rel.op0());
      both_false.copy_to_operands(bin_rel.op1());
      both_false.op0().make_not(); 
      both_false.op1().make_not();

      exprt both_true(ID_and, typet(ID_bool));
      both_true.copy_to_operands(bin_rel.op0());
      both_true.copy_to_operands(bin_rel.op1());

      exprt or_expr(ID_or, typet(ID_bool));
      or_expr.move_to_operands(both_false);
      or_expr.move_to_operands(both_true);

      if(e.id() == ID_not)
        or_expr.make_not();

      return bwd_interpret_bool(or_expr, context, result, cache);

    } else if(bin_rel.id() == ID_notequal) {

      exprt equality = bin_rel;
      equality.id(ID_equal);
      equality.op0().make_not();

      if(e.id() == ID_not)
        equality.make_not();

      return bwd_interpret_bool(equality, context, result, cache);
    } 

    assert(0);
    return var_mapt::bot();
  } else {
    //perform arithmetic bwd interpretation
    var_elementst fwd_vals; fwd_vals.reserve(e.operands().size());
    forall_operands(it, bin_rel)
      fwd_vals.push_back(fwd_interpret(*it, context, &cache));

    var_domain.bwd_interpret_bool(bin_rel, fwd_vals, result);


    //check for bottom
    var_mapt result(context);
    for(var_elementst::const_iterator val_it = fwd_vals.begin();
        val_it != fwd_vals.end(); ++val_it)
    {
      if(val_it->is_bot())
      {
        result.set_bot();
        return result;
      }
    }

    var_elementst::const_iterator val_it = fwd_vals.begin();
    forall_operands(it, bin_rel)
    {
      bwd_interpret_arith(*it, context, *val_it, result, cache);
      ++val_it;
    }

    return result;
  }
} 

/* backward interpretation of an arithmetic expression */
void abstr_env_domaint::bwd_interpret_arith(
    const exprt& e, 
    const var_mapt& context,
    const var_elementt& value, 
    var_mapt& result,
    fwd_mapt& cache)
{

  if(context.is_bot())
  {
    result.set_bot();
    return;
  }

  var_elementst operand_vals;
  operand_vals.reserve(e.operands().size());

  if(e.id() == ID_symbol)
  {
    //constrain symbol in result to backward interpreted value
    var_elementt fwd_value = fwd_interpret(e, context, &cache);
    var_elementt val(value);

    set_variable_value(result, to_symbol_expr(e), fwd_value.meet(val));

  } else {
    var_elementst vals;
    vals.reserve(e.operands().size());

    forall_operands(it, e)
      vals.push_back(fwd_interpret(*it, context, &cache));

    //get backward interpretation of values
    var_domain.bwd_interpret_arith(e, value, vals);

    var_elementst::const_iterator val_it = vals.begin();
    forall_operands(it, e)
    {
      //recursively call backward interpretation
      bwd_interpret_arith(*it, context, *val_it, result, cache);
      ++val_it;
    }
  }
}

var_mapt abstr_env_domaint::bwd_interpret_bool_typecast(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache)
{
  assert(e.operands().size() == 1);
  assert(e.op0().type().id() != ID_bool);

  var_elementst fwd_vals; 

  fwd_vals.push_back(fwd_interpret(e.op0(), context, &cache));

  var_domain.bwd_interpret_bool(e, fwd_vals, result);

  var_mapt arith_result(context);

  bwd_interpret_arith(e.op0(), context, fwd_vals.front(), arith_result, cache);

  return arith_result;
}

var_mapt abstr_env_domaint::bwd_interpret_bool_symbol(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache)
{
  abstr_elementst op_vals;
  op_vals.push_back(fwd_interpret(e, context, &cache));

  var_domain.bwd_interpret_bool(e, op_vals, result);

  var_mapt result_map(context);
  set_variable_value(result_map, to_symbol_expr(e), op_vals.front());

  return result_map;
}


var_mapt abstr_env_domaint::bwd_interpret_bool_if(
  const exprt& e, 
  const var_mapt& context,
  bool result,
  fwd_mapt& cache)
{
  exprt case1(ID_and, typet(ID_bool));
  case1.copy_to_operands(e.op0());
  case1.copy_to_operands(e.op1());

  exprt case2(ID_and, typet(ID_bool));
  case2.copy_to_operands(e.op0());
  case2.copy_to_operands(e.op2());
  case2.op0().make_not();

  exprt transl_ite(ID_or, typet(ID_bool));
  transl_ite.move_to_operands(case1);
  transl_ite.move_to_operands(case2);
  
  return bwd_interpret_bool(transl_ite, context, result, cache); 

}

var_mapt abstr_env_domaint::bwd_interpret_bool_implies(
  const exprt& e, 
  const var_mapt& context,
  bool result,
  fwd_mapt& cache)
{ 
  assert(e.operands().size() == 2);

  exprt or_expr(ID_or, typet(ID_bool));
  or_expr.copy_to_operands(e.op0());
  or_expr.copy_to_operands(e.op1());

  or_expr.op0().make_not();

  return bwd_interpret_bool(or_expr, context, result, cache);
}
