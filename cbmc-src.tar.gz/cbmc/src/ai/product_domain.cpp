#include "product_domain.h"

void product_domaint::reduce(abstr_pairt& a) 
{
  abstr_elementt& a_elem1 = a.first;
  abstr_elementt& a_elem2 = a.second;

  if(a_elem1.is_bot())
  {
    a_elem2 = a2.bot();
    return;
  }
  
  if(a_elem2.is_bot())
  {
    a_elem1 = a1.bot();
    return;
  }


  abstr_elementt old_a1 = a_elem1;
  abstr_elementt old_a2 = a_elem2;

 do {
    abstr_elementt old_a1 = a_elem1;
    abstr_elementt old_a2 = a_elem2;

    exprt a1_expr = a_elem1.to_expr();
    exprt a2_expr = a_elem2.to_expr();

    a_elem1.apply_test(a2_expr, true);
    a_elem2.apply_test(a1_expr, true);
  } while(!old_a1.eq(a_elem1) || !old_a2.eq(a_elem2)) ;
}

abstr_elementt product_domaint::top() 
{
  return new_elem(new abstr_pairt(a1.top(), a2.top()));
}

abstr_elementt product_domaint::bot()
{
  return new_elem(new abstr_pairt(a1.bot(), a2.bot()));
}

bool product_domaint::is_top(const abstr_elementt& e)
{
  const abstr_pairt &p = read(e);
  return (a1.is_top(p.first) && a2.is_top(p.second));
}


bool product_domaint::is_bot(const abstr_elementt& e)
{
  const abstr_pairt &p = read(e);
  return (a1.is_bot(p.first) || a2.is_bot(p.second));
}


bool product_domaint::leq(const abstr_elementt& x, const abstr_elementt& y)
{
  const abstr_pairt &xp = read(x);
  const abstr_pairt &yp = read(y);
  
  return a1.leq(xp.first, yp.first) &&
         a2.leq(xp.second, yp.second);
}


void product_domaint::meet_inplace(abstr_pairt& x, const abstr_pairt& y)
{
  a1.meet(x.first, y.first);
  a2.meet(x.second, y.second);

  reduce(x);
}


void product_domaint::join_inplace(abstr_pairt& x, const abstr_pairt& y)
{
  a1.join(x.first, y.first);
  a2.join(x.second, y.second);

  reduce(x);
}


void product_domaint::widen_inplace(
      abstr_pairt& x, 
      const abstr_pairt& y, 
      const abstr_pairt& t)
{
  a1.widen(x.first, y.first, t.first);
  a2.widen(x.second, y.second, t.second);

  reduce(x);
}

void product_domaint::apply_assign_inplace(
      abstr_pairt& a, 
      const exprt& lhs, 
      const exprt& rhs)
{
  a1.apply_assign(a.first, lhs, rhs);
  a2.apply_assign(a.second, lhs, rhs);

  reduce(a);
}


void product_domaint::apply_test_inplace(
    abstr_pairt& a, 
    const exprt& e, 
    bool result)
{  
  a1.apply_test(a.first, e, result);
  a2.apply_test(a.second, e, result);

  reduce(a);
}


std::string product_domaint::to_string(const abstr_elementt& a)
{
  const abstr_pairt& p = read(a);
  return "<" + a1.to_string(p.first) + ", " + a2.to_string(p.second) + ">";
}


exprt product_domaint::to_expr(const abstr_elementt& a)
{
  const abstr_pairt& p = read(a);
  exprt result(ID_and, typet(ID_bool));

  exprt r1 = a1.to_expr(p.first);
  if(r1.is_false()) 
  { 
    result.swap(r1);
    return result;
  } else if(!r1.is_true()) {
    result.move_to_operands(r1);
  }

  exprt r2 = a2.to_expr(p.second);
  if(r2.is_false())
  {
    result.swap(r2);
    return result;
  } else if(!r2.is_true()) {
    result.move_to_operands(r2);
  }
  
  if(result.operands().size() == 0)
  {
    result.make_true();
  } else if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  return result;
}


abstr_elementt product_domaint::get_initial()
{
  abstr_pairt* p = new abstr_pairt(a1.get_initial(), a2.get_initial());

  reduce(*p);

  return new_elem(p);
}

 
