/*******************************************************************\

Module: Proof generalization using search on constants

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef BOUND_SEARCH_H
#define BOUND_SEARCH_H

#include <std_expr.h>
#include <ieee_float.h>
#include <arith_tools.h>

#include "domains/itv.h"

class bound_searcht
{
public:
  virtual bool has_next() = 0;
  //call with widen = true if the search should be continued in direction d
  virtual void next(bool widen) = 0;
  //set constant to the far end of the range (no effect on search)
  virtual ~bound_searcht() { }

};

class const_bound_searcht : public bound_searcht
{
public:
  virtual void set_to_far() = 0;

  //the following two functions are a bit of an ugly patch
  virtual void set_itv(itvt& itv) = 0;
  virtual void set_to_cur() = 0;
};

template <class numberT>
class bound_search_templt : public const_bound_searcht
{
public:
  bound_search_templt(const numberT& _c, int dir) :
     c(_c), d(dir), exp_mode(true) { } 

  bool has_next()
  { return near != far; }

  const numberT& get() { return c; }

protected:
  numberT c;
  const int d;
  numberT near, far;
  numberT cur;
  
  bool exp_mode;
  numberT delta; 
};


class int_bound_searcht : public bound_search_templt<mp_integer>
{
public:
  //constant: the constant to increase / decrease
  //d: direction (positive for increase, negative for decrease)
  int_bound_searcht(const mp_integer& constant, const typet& t, int d);
  
  virtual void next(bool widen);
  
  virtual void set_to_far()
  { c = far; }

  virtual void set_to_cur() 
  { c = cur; }

  virtual void set_itv(itvt& itv);

protected:
  void update_bounds(bool widen);
  unsigned steps;
};

class float_bound_searcht : public bound_search_templt<ieee_floatt>
{
public:
  //constant: the constant to increase / decrease
  //d: direction (positive for increase, negative for decrease)
  float_bound_searcht(const ieee_floatt& constant, int d);
  
  virtual void next(bool widen);
  
  virtual void set_to_far()
  { 
    ieee_floatt inf = cur;
    if(d > 0) inf.make_plus_infinity(); else inf.make_minus_infinity(); 
    c = inf.to_expr();
  }

  virtual void set_to_cur() 
  { c = cur; }

  ieee_floatt find_midpoint(
    const ieee_floatt& a, 
    const ieee_floatt& b,
    bool widen);

  //this is a slightly ugly solution. if important change later
  virtual void set_itv(itvt& itv);

protected:
  void update_bounds(bool widen);

  ieee_float_spect spec;
  ieee_floatt two;
  unsigned steps;
};

#endif 
