/*******************************************************************\

Module: Proof generalization tricks for arrays on top of core 
        generalization

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "array_core_generalization.h"


/*******************************************************************\

Function: array_core_generalizationt::repair_step
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void array_core_generalizationt::repair_step(
  const CFG_nodet& n,
  abstr_elementt& elem,
  const abstr_elementt& pre_from_proof,
  const id_sett& must_include)
{
  sub::repair_step(n, elem, pre_from_proof, must_include);

  exprt repaired_expr = elem.to_expr();
  exprt pre_from_proof_expr = pre_from_proof.to_expr();

  hash_set_cont<symbol_exprt, irep_hash> array_symbols;
  
  //find arrays
  find_arrays(repaired_expr, array_symbols);

  //insert all array / struct expressions from original proof whose symbols
  //occur in the current element
  add_invariants_by_symbol(
    array_symbols, 
    pre_from_proof_expr, 
    repaired_expr);

  elem = elem.get_domain().from_expr(repaired_expr);
}

/*******************************************************************\

Function: array_core_generalizationt::find_arrays
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void array_core_generalizationt::find_arrays(
    const exprt& e, 
    hash_set_cont<symbol_exprt, irep_hash>& s)
{
  if(e.id() == ID_symbol)
  {
    if(e.type().id() == ID_array)
      s.insert(to_symbol_expr(e));
  }
  else
    forall_operands(it, e)
    {
      find_arrays(*it, s);
    }
}

/*******************************************************************\

Function: array_core_generalizationt::add_invariants_by_symbol
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void array_core_generalizationt::add_invariants_by_symbol(
    const hash_set_cont<symbol_exprt, irep_hash>& ids,
    const exprt& src,
    exprt& e)
{
  assert(src.type().id() == ID_bool && e.type().id() == ID_bool);
  
  if(src.id() == ID_and)
  {
    forall_operands(it, src)
      add_invariants_by_symbol(ids, *it, e);
  }
  else
  {
    if(contains_symbol(src, ids))
    {
      if(e.id() != ID_and) 
      { //make sure e is an "and" expression
        exprt and_expr(ID_and, typet(ID_bool));
        if(!e.is_true())
          and_expr.move_to_operands(e);
        e.swap(and_expr);
      } 
      
      e.copy_to_operands(src);
    }
  }
  
  if(e.id() == ID_and && e.operands().size() == 1)
  {
    exprt tmp = e.op0();
    e.swap(tmp);
  }
}
  
bool array_core_generalizationt::contains_symbol(
    const exprt& e,
    const hash_set_cont<symbol_exprt, irep_hash>& ids)
{
  if(e.id() == ID_symbol)
  {
    return ids.find(to_symbol_expr(e)) != ids.end();
  } 
  else
  {
    forall_operands(it, e)
    {
      if(contains_symbol(*it, ids))
        return true;
    }
    return false;
  }
}
