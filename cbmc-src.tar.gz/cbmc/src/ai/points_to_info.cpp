/*******************************************************************\

Module: Points to information for a CFG f. pointers potentially 
        pointing to stack variables. 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "points_to_info.h"

#include <resolve_types.h>


void simple_points_to_infot::collect_type(const exprt& sym)
{
  typet t = sym.type();

  while(t.id() == ID_array)
  {
    typet tmp = t.subtype();
    t.swap(tmp);
  }

  type_map[t].insert(sym);
}

void simple_points_to_infot::collect_types(const std::set<symbol_exprt>& syms)
{
  for(std::set<symbol_exprt>::const_iterator it = syms.begin();
      it != syms.end(); it++)
  {
    collect_type(*it);
  }

#if 0
  forall_cfg_nodes(it, cfg)
  {
    if((*it)->type == DECL)
    {
      const code_declt& decl = to_code_decl((*it)->code);
      exprt sym = to_symbol_expr(decl.symbol());
      resolve_types(sym, ns);

      typet t = sym.type();
      collect_type(t);
    }
  }
#endif 
}

void simple_points_to_infot::points_to(
    const CFG_nodet& n, 
    const exprt& e,
    std::set<exprt>& set) const
{
  assert(e.type().id() == ID_pointer);
  const typet& subtype = e.type().subtype();
  assert(subtype.is_not_nil());
    
  type_mapt::const_iterator it = type_map.find(subtype);

  if(it != type_map.end())
    set.insert(it->second.begin(), it->second.end());
}

value_set_points_to_infot::value_set_points_to_infot(
  const CFGt& cfg,
  const goto_functionst& _goto_functions,
  const irep_idt& _function_name,
  const namespacet& ns)
  :
  points_to_infot(cfg), pointer_analysis(ns), 
  function_name(_function_name)
{
  goto_functions.copy_from(_goto_functions);

  //goto function must exist in goto program
  assert(goto_functions.function_map.find(function_name) != 
         goto_functions.function_map.end());

  goto_functionst::goto_functiont& function = 
    goto_functions.function_map[function_name];

  goto_programt& goto_program = function.body;
  assert(function.body_available = true);
  
  //convert to goto_program, remember mapping
  cfg.to_goto_program(goto_program, NULL, &node_target_map);

  //run pointer analysis
  pointer_analysis(goto_functions);
}
  
void value_set_points_to_infot::points_to(
  const CFG_nodet& n, 
  const exprt& e,
  std::set<exprt>& points_to_set) const
{
  node_target_mapt::const_iterator find_it = node_target_map.find(&n);

  if(find_it == node_target_map.end())
    throw "value_set_points_to_infot::Supplied map does not contain CFG_node";
  
  std::list<exprt> expr_list;
  pointer_analysis.get_values(find_it->second, e, expr_list);

  points_to_set.insert(expr_list.begin(), expr_list.end());
}

