/*******************************************************************\

Module: Abstract forward analysis

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_ANALYSIS_H
#define ABSTR_ANALYSIS_H

#include "inv_generator.h"
#include "abstr_domain.h"
#include "iteration_schedule.h"
#include "widening_strategy.h"

#include <expr.h>

#include <vector>
#include <iostream>

typedef std::vector<abstr_elementt> abstr_vect;

class abstr_fwd_analysis_baset : public inv_generatort
{
public:
  typedef inv_generatort SUB;
  typedef std::pair<const CFG_nodet*, exprt> local_exprt;
  typedef std::vector<local_exprt> local_exprst;
  const namespacet& ns;

public:
  abstr_fwd_analysis_baset(const CFGt& cfg, 
                      abstr_domaint& dom, 
                      iteration_schedulet& _schedule,
                      widening_strategyt& _widening_strategy,
                      const namespacet& _ns);

  virtual ~abstr_fwd_analysis_baset() { };

  virtual exprt get_invariant(const CFG_nodet& n) const;

  virtual void perform_analysis();
  
  virtual void reset() { init_analysis(); }
  //does not reset the current vector of abstract elements
  virtual void propagate(const CFG_nodet& n);

  virtual void get_violated_assertions(local_exprst& v); 

  virtual bool has_violated_assertions()
  { local_exprst l; get_violated_assertions(l); return !l.empty(); }

  //result of applying the transfer function between n1 and n2 to e
  virtual abstr_elementt transfer(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  abstr_domaint& get_domain() { return domain; }

  //allow access to the internal elements at each control flow
  //location. The invariant of a node "n" can be found at 
  //    get_abstr_vec()[n.id]
  const abstr_vect& get_abstr_vec() const { return abstr_vec; } 
  abstr_vect& get_abstr_vec() { return abstr_vec; }

protected:
  abstr_domaint& domain;
  iteration_schedulet& schedule;
  widening_strategyt& widening_strategy;
  abstr_vect abstr_vec; 

protected:
  virtual void init_analysis();

  virtual bool is_initial_node(const CFG_nodet& n);
  
  virtual abstr_elementt get_initial_element()
  { return domain.get_initial(); }

  /* join a vector of elements */
  virtual abstr_elementt join(abstr_vect&);

  /* get incoming abstract elements during fixpoint computation */
  virtual void get_incoming_elems(const CFG_nodet&, abstr_vect&);

  /* transfer functions for abstract elements */
  virtual abstr_elementt transfer_skip(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  virtual abstr_elementt transfer_function_call(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  virtual abstr_elementt transfer_goto(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  virtual abstr_elementt transfer_assign(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  virtual abstr_elementt transfer_assume(
      const abstr_elementt& e,
      const CFG_nodet& n1, 
      const CFG_nodet& n2);

  /* get / set abstract elements corresponding to a node */
  virtual abstr_elementt& get_abstr_elem(const CFG_nodet& n);

  virtual void set_abstr_elem(const CFG_nodet& n, abstr_elementt);

};

class abstr_fwd_analysist : public abstr_fwd_analysis_baset 
{
public:
  typedef abstr_fwd_analysis_baset SUB;

  abstr_fwd_analysist(const CFGt& cfg, 
                      const loop_infot& _loop_info,
                      abstr_domaint& dom,
                      unsigned widening_limit,
                      const namespacet& ns)
    : SUB(cfg, dom, _schedule, _widening_strategy, ns), 
      loop_info(_loop_info), _schedule(cfg, loop_info), 
      _widening_strategy(_schedule, widening_limit)
   { }

protected:
  const loop_infot& loop_info;
  fwd_iteration_schedulet _schedule;
  simple_widening_strategyt _widening_strategy;
};

#endif
