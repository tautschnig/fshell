#include "count_cfg_paths.h"


typedef hash_map_cont<const CFG_nodet*, mp_integer> path_mapt;

const mp_integer& count_CFG_paths_rec(const CFG_nodet& n, path_mapt& m);

/*******************************************************************\

Function: count_CFG_paths

  Inputs: 

 Outputs: The number of loop-free paths in the CFG

 Purpose:

\*******************************************************************/

mp_integer count_CFG_paths(const CFGt& cfg)
{
  typedef std::vector<const CFG_nodet*> node_vect;
  path_mapt paths;
  node_vect end_points;

  if(!cfg.get_initial().predecessors.empty())
    throw "count_CFG_paths: Cannot handle CFGs with initial nodes that have predecessors\n";

  paths[&cfg.get_initial()] = 1;

  //find nodes that do not have successors
  for(CFGt::nodes_sett::const_iterator it = cfg.begin(); it != cfg.end(); ++it)
  {
    const CFG_nodet& n = **it;
    if(n.successor_next == NULL) 
      end_points.push_back(*it);
  }

  if(end_points.empty())
    throw "count_CFG_paths: Cannot handle CFGs that have no exit nodes";
  
  mp_integer path_sum = 0;
  for(node_vect::const_iterator it = end_points.begin(); 
      it != end_points.end(); it++)
  {
    path_sum += count_CFG_paths_rec(**it, paths);
  }

  return path_sum;
}

const mp_integer& count_CFG_paths_rec(const CFG_nodet& n, path_mapt& m)
{
  path_mapt::const_iterator find_it = m.find(&n);

  if(find_it != m.end())
    return find_it->second; //return cached value

  //not in cache, get predecessors
  mp_integer& paths = m[&n];
  paths = 0;

  for(std::set<CFG_nodet*>::const_iterator it = n.predecessors.begin();
      it != n.predecessors.end(); ++it)
  {
    paths += count_CFG_paths_rec(**it, m);
  }

  return paths;
}
