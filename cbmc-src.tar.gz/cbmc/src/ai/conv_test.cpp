#include <solvers/flattening/boolbv.h>
#include <solvers/sat/satcheck.h>
#include <std_expr.h>


#include <iostream>


int main(void)
{
  contextt context;
  namespacet ns(context);

  symbol_exprt a("A", typet(ID_bool));
  symbol_exprt b("B", typet(ID_bool));
  symbol_exprt c("C", typet(ID_bool));

  not_exprt not_a(a);
  not_exprt not_b(b);
  not_exprt not_c(c);

  implies_exprt i1(a, not_b);
  implies_exprt i2(not_b, not_c);
  implies_exprt i3(not_c, not_a);
  
  satcheckt satcheck;
  boolbvt bv(ns, satcheck);

  bv.set_to_true(i1);
  bv.set_to_true(i2);
  bv.set_to_true(i3);

  //change this to set_to_false for a satisfiable result
  bv.set_to_true(a);

  switch(bv.dec_solve())
  {
    case decision_proceduret::D_UNSATISFIABLE:  
      std::cout << "UNSAT" << std::endl;
      break;
    case decision_proceduret::D_SATISFIABLE:  
      std::cout << "SAT" << std::endl;
      std::cout << "A:" << bv.get(a).to_string() << std::endl;
      std::cout << "B:" << bv.get(b).to_string() << std::endl;
      std::cout << "C:" << bv.get(c).to_string() << std::endl;

      break;
  }

  return 0;
}
