/*******************************************************************\

Module: Proof generalization using search on constants

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "bound_search.h"
#include "type2bounds.h"
#include "float_median.h"

int_bound_searcht::int_bound_searcht(
  const mp_integer& constant, 
  const typet& t, 
  int dir) : 
    bound_search_templt<mp_integer>(constant, dir),
    steps(0)
{
  near = constant;
  assert(t.id() == ID_signedbv ||
         t.id() == ID_unsignedbv);


  if(d > 0) 
  {
    far = max_representable(t);
    delta = 2;
  } else if(d < 0) {
    far = min_representable(t);
    delta = -2;
  } else
    throw "Direction must not be zero";

  cur = near;
}

void int_bound_searcht::set_itv(itvt& itv)
{
  assert(itv.type == itvt::INTBV);

  if(d < 0)
    itv.i().set(c, itv.i().upper());
  else
    itv.i().set(itv.i().lower(), c);

  assert(!itv.is_bot());
}

void float_bound_searcht::set_itv(itvt& itv)
{
  assert(itv.type == itvt::FLOAT);

  if(d < 0)
    itv.f().set(c, itv.f().upper());
  else
    itv.f().set(itv.f().lower(), c);

  assert(!itv.is_bot());
}

float_bound_searcht::float_bound_searcht(const ieee_floatt& _c, int dir) : 
  bound_search_templt<ieee_floatt>(_c, dir),
  steps(0)
{
  near = c;

  //std::cout << "********generalizing " << near << " " << dir << std::endl;

  spec = near.spec;
  
  two.from_float(2.0f);
  two.change_spec(spec);

  delta = two;

  if(d > 0) 
  {
    far = near;
    far.make_plus_infinity();
  } else if(d < 0) {
    far = near; 
    far.make_minus_infinity();
    delta.negate();
  } else
    throw "Direction must not be zero";

  cur = near;
}

void int_bound_searcht::update_bounds(bool widen)
{
  if(widen)
    near = cur;
  else
    if(d > 0)
      far = cur - 1;
    else 
      far = cur + 1;
}

void float_bound_searcht::update_bounds(bool widen)
{
  if(widen)
    near = cur;
  else
    if(d > 0)
    {
      far = cur;
      far.decrement();
    }
    else 
    {
      far = cur;
      far.increment();
    }
}


void int_bound_searcht::next(bool widen)
{
  assert(steps != 0 || widen);
  steps++;

  assert(has_next());
  update_bounds(widen);

  if(!has_next())
  {
    cur = near; 
  } else {
    if(exp_mode) 
    { //if in exponential mode, find a bound by widening exponentially
      if(widen)
      {
        cur += delta;
        assert(d != 0);

        if((d > 0 && cur > far) || (d < 0 && cur < far))
          cur = far;

        delta *= delta;
        if(d < 0) 
          delta.negate();

      } else {
        exp_mode = false;
      }
    } 

    if(!exp_mode)
    { //otherwise do binary search
      if(d > 0)
        cur = (near + far + 1) / 2;
      else
        cur = (near + far - 1) / 2;
    }
  }

  c = cur;
}


void float_bound_searcht::next(bool widen)
{
  steps++;
  assert(has_next());
  update_bounds(widen);

  static int counter = 0;
  counter++;

  //debug 
  ieee_floatt last_cur = cur;

  if(!has_next())
  {
    cur = near; 
  } else {
    if(exp_mode) 
    { //if in exponential mode, find a bound by widening exponentially
      if(widen)
      {
        //nudge it
        if(d > 0)
          cur.increment();
        else
          cur.decrement();
        
        if(cur.is_infinity())
        {
          if((d > 0 && cur.get_sign()) || (d < 0 && !cur.get_sign()));
          {
            //nudge it away from infinity, so we can actually add stuff
            //(in case we want search AWAY from this infinity value)
            if(d > 0)
              cur.increment();
            else
              cur.decrement();
          }
        }

        //make this better eventually
        cur += delta;

        assert(d != 0);
        if((d > 0 && cur >= far) || (d < 0 && cur <= far))
          cur = far;

        delta *= delta;

        if(d < 0)
          delta.negate();

      } else {
        exp_mode = false;
      }
    } 

    if(!exp_mode)
    { //otherwise do binary search
      ieee_floatt _near = near;
      ieee_floatt _far = far;
      
      if(_near.is_infinity())
      {
        if(_near.get_sign())
          _near.increment();
        else
          _near.decrement();
      }

      if(_far.is_infinity())
      {
        if(_far.get_sign())
          _far.increment();
        else
          _far.decrement();
      }

      cur = find_midpoint(_near, _far, widen);

      //always nudge cur towards far:
      if(cur != far) 
      {
        if(d > 0)
          cur.increment();
        else 
          cur.decrement();
      }
    }
  }

  assert(cur != last_cur || !has_next()); //ensure progress
  
  if(d > 0)
    assert(cur >= near && cur <= far);
  else
    assert(cur <= near && cur >= far);

  //std::cout << near.to_float() << " " << cur.to_float() << " "<< far.to_float() << std::endl;

  c = cur;
}

ieee_floatt float_bound_searcht::find_midpoint(
  const ieee_floatt& a, const ieee_floatt& b, bool widen)
{
  assert(!a.is_infinity() && !b.is_infinity() &&
         !a.is_NaN() && !b.is_NaN());
  
  return ieee_float_median(a,b);
}

