/*******************************************************************\

Module: Abstract domain framework. New domains are implemented by 
        deriving from abstr_domaint, abstr_elementt stays the same.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/


#ifndef ABSTR_ELEMENT_H
#define ABSTR_ELEMENT_H

#include <string>
#include <expr.h>

class abstr_elementt;

typedef std::vector<abstr_elementt> abstr_elementst;

#define forall_abstr_elements(it, a) \
  for(abstr_elementst::const_iterator it = a.begin(); it != a.end(); it++)

#define Forall_abstr_elements(it, a) \
  for(abstr_elementst::iterator it = a.begin(); it != a.end(); it++)

class abstr_domaint
{
public:
  //return top / bottom element
  virtual abstr_elementt top() = 0;
  virtual abstr_elementt bot() = 0;

  virtual bool is_top(const abstr_elementt& e) = 0;

  virtual bool is_bot(const abstr_elementt& e) = 0;

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2) = 0;

  bool geq(const abstr_elementt& a1, const abstr_elementt& a2) 
  { return leq(a2,a1); }
  
  virtual bool eq(const abstr_elementt& a1, const abstr_elementt& a2) 
  { return leq(a1,a2) && leq(a2,a1); }

  //functions return reference to changed first operand
  virtual abstr_elementt& meet(
      abstr_elementt&, 
      const abstr_elementt& e) = 0;

  virtual abstr_elementt& join(
      abstr_elementt&, 
      const abstr_elementt& e) = 0;

  virtual abstr_elementt& widen(
      abstr_elementt&, 
      const abstr_elementt& e, 
      const abstr_elementt& threshold) = 0;

  //return result of applying transfer function for c expression
  virtual abstr_elementt& apply_assign(
      abstr_elementt& a, 
      const exprt& lhs, 
      const exprt& rhs) = 0;

  //apply test to abstract element
  virtual abstr_elementt& apply_test(
      abstr_elementt& a, 
      const exprt& e, 
      bool result) = 0;

  virtual abstr_elementt join(const abstr_elementst& e);

  virtual abstr_elementt meet(const abstr_elementst& e);

  virtual std::string to_string(const abstr_elementt& a) = 0;

  virtual exprt to_expr(const abstr_elementt& a) = 0;

  //get initial element, before program starts
  virtual abstr_elementt get_initial() = 0;

  //get an abstract element representing expr
  virtual abstr_elementt from_expr(const exprt& e);

  //virtual destructor
  virtual ~abstr_domaint() { }

  virtual void get_used_symbols(
    const abstr_elementt& elem, hash_set_cont<exprt, irep_hash>& symbols) const
  { throw "not implemented"; }

protected:
  //memory management callbacks for abstr_elementt
  friend class abstr_elementt;
  virtual void register_abstr_elem(abstr_elementt& e) { }
  virtual void deregister_abstr_elem(abstr_elementt& e) { }
};

//abstr_elementt acts as a pointer to the real representation
//of the abstract element that lives inside the abstract domain
class abstr_elementt
{

public:
  /*************  constructors and destructors  **************/

  //destructor
  virtual ~abstr_elementt() { domain.deregister_abstr_elem(*this); }

  //constructor called by abstr_domain, do not call this
  abstr_elementt(abstr_domaint& dom, unsigned id);
  //constructor called by abstr_domain, do not call this
  abstr_elementt(abstr_domaint& dom, void* ptr);

  //copy constructor
  abstr_elementt(const abstr_elementt& e);

  abstr_elementt& operator=(const abstr_elementt& e);

  /*******************  Domain functions  ********************/

  //all methods change the element, reference is returned to changed "this"
  abstr_elementt& meet(const abstr_elementt& e);
  abstr_elementt& join(const abstr_elementt& e);

  abstr_elementt& widen(
      const abstr_elementt& e, 
      const abstr_elementt& threshold);

  //this <= arg in lattice-order?
  bool leq(const abstr_elementt& e) const;
  bool geq(const abstr_elementt& e) const;
  bool eq(const abstr_elementt& e) const;
  
  bool is_top() const;
  bool is_bot() const;

  /*************  transfer function and test *****************/
  abstr_elementt& apply_assign(const exprt& lhs, const exprt& rhs);
  abstr_elementt& apply_test(const exprt& e, bool result);
  std::string to_string() const;
  exprt to_expr() const;

  /****************** access internal data   *****************/
  const abstr_domaint& get_domain() const;
  abstr_domaint& get_domain();

  void* &ptr();

  void* const &ptr() const;

  unsigned& id();

  const unsigned& id() const;

protected:
  abstr_domaint& domain;

  //use either id or ptr to store data
  typedef union { unsigned id; void* ptr; } datat;
  datat dt;
  //true if id is used
  bool use_id;

  //abstr_elements are allocated only by domains
  friend class abstr_domaint;
};
#endif
