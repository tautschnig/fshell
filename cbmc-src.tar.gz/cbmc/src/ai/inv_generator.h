/*******************************************************************\

Module: Invariant generation interface for control-flow graphs

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef INV_GENERATOR_H
#define INV_GENERATOR_H

#include <goto-programs/control_flow_graph.h>
#include <vector>

class inv_generatort 
{
public:
  inv_generatort(const CFGt& _cfg)
    : cfg(_cfg) { }

  //get invariant corresponding to CFG_node
  virtual exprt get_invariant(const CFG_nodet& n) const = 0;
  
  const CFGt& get_cfg() { return cfg; }
  
protected:
  const CFGt& cfg;
};

#endif 
