
int main(void)
{
  int a[2][4] = {{0,1,2,3}, {1,2,3,4}};

  int x;
  
  if(x)
    x = 0;
  else 
    x = 1;
  
  int z = a[x][a[x][x]];

  return 0;
}
