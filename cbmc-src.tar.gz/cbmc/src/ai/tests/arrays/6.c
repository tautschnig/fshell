#define X 5
#define Y 5

int main(void)
{
  int test[X][Y] = { {0,0,0,0,0}, 
                     {0,0,0,0,0},
                     {0,0,0,0,0},
                     {0,0,0,0,0},
                     {0,0,0,0,0}};

  for(int x = 0; x < X; x++)
    for(int y = 0; y < Y; y++)
    {
      int mult = x * y;
      test[x][y] = mult;
    }
  
  int sum = 0;
  for(int x = 0; x < X; x++)
    for(int y = 0; y < Y; y++)
      sum += test[x][y];

  return 0;
}
