int nondet_int();

int main()
{
  int test[2][4] = {{0, 1, 2, 3},
                {4, 5, 6, 7}};
  
  
  int x;
  if(nondet_int())
    x = 0;
  else
    x = 1;

  int y = test[x][x+1]; //y in {1, 6}

  return 0;
}
