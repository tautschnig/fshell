

int main()
{
  unsigned i = 0;
  int a[4] = {1, 2, 3, 4};

  assert(a[i] != 4);
  
  return 0;
}
