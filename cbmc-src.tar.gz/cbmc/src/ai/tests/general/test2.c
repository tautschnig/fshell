
int main(void)
{
  int a;
  int b;

  if(a < 0)
  {
    b = a;
  } else {
    b = -a;
  }

  return 0;
}
