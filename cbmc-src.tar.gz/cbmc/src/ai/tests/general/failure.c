int g;


void foo()
{
  int * x;
  int * y;

  x = &g;

  y = x;


  int i;

  for(i = 0; i < 100; i++) {
    assert(i < 100);
  }

  assert(x == y);

}
