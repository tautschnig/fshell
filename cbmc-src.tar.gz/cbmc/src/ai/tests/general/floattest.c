

int main(void)
{
  float f;
  double d;
  int x;

  f = 0.0f;
  d = f;

  if(x) 
  {
    d-=5;
    f-=0.2f;
  } else {
    d+=5;
    f+=0.2f;
  }

  d = d*f*f*f;

  return 0;
}
