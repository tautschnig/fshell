
int main(void)
{
  int a;
  int b;

  a = b;

  return 0;
}
