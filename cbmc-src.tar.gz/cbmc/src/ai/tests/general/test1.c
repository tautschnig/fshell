
int main(void)
{
  int a,b,c,d;

  a = 0; 
  b = 1;
  c = 2;
  d = 3;
  
  d = a + b + c + d;

  return 0;
}
