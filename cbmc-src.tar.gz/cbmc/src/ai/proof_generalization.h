/*******************************************************************\

Module: Proof generalization

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef PROOF_GENERALIZATION_H
#define PROOF_GENERALIZATION_H

#include "abstr_fwd_analysis.h"

class proof_generalizationt
{
public:
  proof_generalizationt(
      abstr_fwd_analysist& _analysis)
    : analysis(_analysis)
    { }

  virtual void generalize() = 0;

  virtual ~proof_generalizationt() { }

protected:
  abstr_fwd_analysist& analysis;

};

#endif 
