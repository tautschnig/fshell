/*******************************************************************\

Module: Transformation between expression over arrays or structs 
        and auxiliary representing single primitive values

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ARRAY_STRUCT_EMULATOR_H
#define ARRAY_STRUCT_EMULATOR_H

#include <std_expr.h>
#include <std_types.h>
#include <hash_cont.h>

class array_struct_emulatort 
{
public:
  array_struct_emulatort(unsigned max_size)
    : max_dim_size(max_size),
      ID_original_expr("#original_expr")
  {
  } 

  //transform between orig expressions and corresponding symbol exprs
  bool get_orig_from_symbol(const symbol_exprt&, exprt&);

  //resolve index either to symbol representing array value or to value in case
  //of array literal
  exprt emulate(const exprt& e);
  void emulate(std::vector<exprt>&);

  //replace auxiliary array symbols by their corresponding orig expr and 
  //vice versa
  void replace_symbols_by_orig(exprt& e);

  //replace array and struct accesses by symbols where possible
  void replace_by_symbols(exprt& e);
  
  //get expressions corresponding to all accessible array values, 
  //and / or struct assignments
  void get_all_assignables(const exprt& e, std::vector<exprt>& syms);

  //return true if is an auxiliary symbol 
  virtual bool is_aux_symbol(const exprt& e)
  { return e.find(ID_original_expr).is_not_nil(); }

  bool supported(const typet& t);

  bool supported(const exprt& e, bool as_pointer = false);

  bool has_constant_indices(const exprt& e);

protected:
  unsigned max_dim_size;
  typedef hash_map_cont<exprt, symbol_exprt, irep_hash> expr2symbolt;
  expr2symbolt expr2symbol;
  const irep_idt ID_original_expr;

  long nr_assignables(const typet& t);
};

#endif
