/*******************************************************************\

Module: Abstract environments for per-variable abstractions
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_ENV_H
#define ABSTR_ENV_H

#include "abstr_domain.h"
#include "abstr_domain_mem.h"

#include <std_expr.h>


//TODO: Fix class hierarchy, so abstr_var_domaint does not have unsupported
//      methods

class abstr_var_domaint : virtual public abstr_domaint
{
public:
  //returns true when the variable domain can handle type t
  virtual bool supports_type(const typet& t) = 0;

  virtual abstr_elementt top(const typet& t) = 0;
  virtual abstr_elementt bot(const typet& t) = 0;

  virtual abstr_elementt fwd_interpret(
      const exprt& op, 
      const abstr_elementst& op_values) = 0;

  virtual void bwd_interpret_arith(
      const exprt& op, 
      const abstr_elementt& result, 
      abstr_elementst& op_values) = 0;

  virtual void bwd_interpret_bool(
      const exprt& op, 
      abstr_elementst& op_values, 
      bool result) = 0;

  virtual std::string to_string(
      const abstr_elementt&, 
      const symbol_exprt& e) = 0;
    
  //returns true if the abstract element concretizes to a single constant
  //if is_singleton() is true, to_expr() is expected to return a constant
  virtual bool is_singleton(const abstr_elementt& e) = 0;

  virtual exprt to_expr(
      const abstr_elementt&, 
      const symbol_exprt& e) = 0;

  //unsupported methods
  virtual abstr_elementt top()
  { throw "not supported";}
  virtual abstr_elementt bot()
  { throw "not supported";}
  virtual abstr_elementt get_initial()
  { throw "not supported";}
};

class var_mapt : public hash_map_cont<symbol_exprt, abstr_elementt, irep_hash> 
{
public:
  static var_mapt top() { return var_mapt(); }
  static var_mapt bot() { var_mapt r; r.set_bot(); return r; } 
  
  //returns top
  var_mapt() : __bot(false) { }

  void set_bot() { __bot = true; clear(); }
  void set_top() { __bot = false; clear(); } 

  bool is_bot() const { return __bot; }
  bool is_top() const { return !__bot && empty(); }

  std::string to_string();

protected:
  bool __bot;
};

typedef std::vector<var_mapt> var_mapst;

class abstr_env_domaint : public abstr_domain_memt<var_mapt>
{
public:
  abstr_env_domaint(abstr_var_domaint& domain)
    : var_domain(domain) { }

  typedef abstr_elementt var_elementt;
  typedef abstr_elementt env_elementt;
  typedef std::vector<var_elementt> var_elementst;
  typedef std::vector<env_elementt> env_elementst;

  typedef var_mapt::const_iterator const_iterator;

  //allows iterator access to abstract elements
  const_iterator begin(abstr_elementt& e);
  const_iterator end(abstr_elementt& e);

  //create an abstract element from a list of abstract assignments
  env_elementt from_abstr_assignments(
    const std::vector<symbol_exprt>& symbols,
    const var_elementst& v);

  var_elementt get_abstr_val(
      const env_elementt&,
      const symbol_exprt&) const;

  void set_abstr_val(
      env_elementt& e,
      const symbol_exprt& s,
      const var_elementt& v);
  
  //return the number of non-top assigned valeus
  unsigned nr_assigned_vals(const env_elementt&, const symbol_exprt&);

  void to_abstr_assignments(
    const env_elementt& e,
    std::vector<symbol_exprt>& symbols,
    var_elementst& v);

  virtual void meet_inplace(
      var_mapt&, 
      const var_mapt& e);

  virtual void join_inplace(
      var_mapt&, 
      const var_mapt& e);

  virtual void widen_inplace(
      var_mapt&, 
      const var_mapt& e, 
      const var_mapt& threshold);

  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      var_mapt& a, 
      const exprt& lhs, 
      const exprt& rhs);
  
  //apply assignments in parallel
  virtual void apply_parallel_assign_inplace(
      var_mapt& a, 
      const std::vector<exprt>& lhs, 
      const std::vector<exprt>& rhs);

  //return result of applying test for c expression
  virtual void 
    apply_test_inplace(var_mapt& a, const exprt& e, bool result);

  virtual abstr_elementt top();
  virtual abstr_elementt bot();

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  virtual env_elementt get_initial() { return top(); }

  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a, 
                        const std::vector<symbol_exprt>& v);

  const var_mapt& get_var_map(const abstr_elementt& a) { return read(a); }
  var_mapt& get_var_map(abstr_elementt& a) { return write(a); }

  /* returns the abstract forward interpretation of "e" under "context" */
  virtual var_elementt fwd_interpret(
    const exprt& e, 
    const abstr_elementt& context)
  { return fwd_interpret(e, read(context), NULL); }
  
  abstr_var_domaint& get_var_domain() { return var_domain; }

  virtual void get_used_symbols(
    const abstr_elementt& elem, hash_set_cont<exprt, irep_hash>& symbols) const;

protected:
  abstr_var_domaint& var_domain;
  
  typedef hash_map_cont<const exprt, const var_elementt, irep_hash> fwd_mapt;
  
  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      const var_mapt& src, 
      const exprt& lhs, 
      const exprt& rhs,
      var_mapt& dest);

  /* returns the abstract forward interpretation of "e" under "context" */
  virtual var_elementt fwd_interpret_nocache(
      const exprt& e, 
      const var_mapt& context,
      fwd_mapt* cache);

  virtual var_elementt fwd_interpret(
      const exprt& e, 
      const var_mapt& context,
      fwd_mapt* cache);

  /* backward interpretation of a Boolean expression evaluating to true */
  virtual var_mapt bwd_interpret_bool(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache
  );

  /* backward interpretation of an arithmetic expression */
  virtual void bwd_interpret_arith(
    const exprt& e, 
    const var_mapt& context,
    const var_elementt& value, 
    var_mapt& result,
    fwd_mapt& cache
  );

  void set_variable_value(
      var_mapt& a,
      const symbol_exprt& s, 
      const var_elementt& val);

  var_elementt get_variable_value(
      const var_mapt& a,
      const symbol_exprt& s );


  //forward interpretation functions
  virtual var_elementt fwd_interpret_symbol(
    const exprt& e, 
    const var_mapt& context);

  virtual var_elementt fwd_interpret_if(
    const exprt& e, 
    const var_mapt& context,
    fwd_mapt* cache);

  virtual var_elementt fwd_interpret_implies(
    const exprt& e, 
    const var_mapt& context,
    fwd_mapt* cache);

  //backward interpretation functions
  virtual var_mapt bwd_interpret_bool_andor(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool_not(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool_binrel(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool_typecast(
    const exprt& e, 
    const var_mapt& context, 
    bool result,
    fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool_if(
    const exprt& e, 
    const var_mapt& context, 
    bool result,
    fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool_implies(
    const exprt& e, 
    const var_mapt& context, 
    bool result,
    fwd_mapt& cache);

};

#endif 
