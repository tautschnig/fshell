/*******************************************************************\

Module: Obtain variables modified in loops

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "loop_modified_vars.h"

#include <std_code.h>
#include <ansi-c/expr2c.h>

#include <sstream>

/*******************************************************************\

Function: loop_modified_var_infot::loop_modified_var_infot

 Purpose: Constructor calls analysis

\*******************************************************************/

loop_modified_var_infot::loop_modified_var_infot(
    const loop_infot& loop, 
    const CFGt& c,
    const points_to_infot& p)
  : loop_info(loop), cfg(c), points_to_info(p)
{
  do_analysis();
}

/*******************************************************************\

Function: loop_modified_var_infot::get_modified

 Purpose: return the set of modified values corresponding to this loop

\*******************************************************************/

const loop_modified_var_infot::expr_sett& 
loop_modified_var_infot::get_modified(const CFG_nodet* id) const
{
  mod_mapt::const_iterator it = mod_map.find(id);

  if(it == mod_map.end())
    throw "Loop id not found";

  return it->second;
}


/*******************************************************************\

Function: loop_modified_var_infot::do_analysis

 Purpose: Perform the actual analysis

\*******************************************************************/

void loop_modified_var_infot::do_analysis()
{
  forall_cfg_nodes(it, cfg)
  {
    const CFG_nodet& n = **it;
    if(n.type == ASSIGN)
    {
      const code_assignt& assign = to_code_assign(n.code);
      const exprt& lhs = assign.lhs();
      loopt *loop = loop_info.get_closest_containing_loop(*it);

      if(loop == NULL)
        continue;

      expr_sett s;
      analyse_assign(lhs, n, s);

      do
      {
        mod_map[loop->header].insert(s.begin(), s.end());
        loop = loop->parent;
      } while(loop != NULL);

      
    }
  }
}


/*******************************************************************\

Function: loop_modified_var_infot::analyse_assign

  Inputs: 

 Outputs:

 Purpose: Insert set of possibly changes stack symbols into target_set

\*******************************************************************/

void loop_modified_var_infot::analyse_assign(
    const exprt& lhs, 
    const CFG_nodet& n, 
    expr_sett& target_set)
{
  if(lhs.id() == ID_symbol)
  {
    target_set.insert(lhs);
  } 
  else if(lhs.id() == ID_index)
  {
    if(lhs.type().id() == ID_pointer)
      analyse_dereference(to_index_expr(lhs), n, target_set);
    else
      analyse_assign(to_index_expr(lhs).array(), n, target_set);
  }
  else if(lhs.id() == ID_member)
  {
    analyse_assign(to_member_expr(lhs).struct_op(), n, target_set);
  }
  else if(lhs.id() == ID_dereference)
  {
    analyse_dereference(to_dereference_expr(lhs), n, target_set);
  }
  else  if(lhs.id() == ID_object_descriptor)
  {
    analyse_assign(to_object_descriptor_expr(lhs).object(), n, target_set);
  } else if(lhs.id() == ID_unknown)
  {
    //ignore
  } else if(lhs.id() == "NULL-object")
  {
    //ignore
  }
  else
    throw "implement me: " + lhs.id_string();
}

/*******************************************************************\

Function: loop_modified_var_infot::analyse_dereference

 Purpose: Analyse dereference

\*******************************************************************/

void loop_modified_var_infot::analyse_dereference(
    const exprt& lhs, 
    const CFG_nodet& n, 
    expr_sett& target_set)
{
  expr_sett derefs;
  collect_targets(lhs, n, derefs);

  for(expr_sett::const_iterator it = derefs.begin(); 
      it != derefs.end(); ++it)
  {
    analyse_assign(*it, n, target_set);
  }
}


/*******************************************************************\

Function: loop_modified_var_infot::collect_targets

 Purpose: Collect all possible targets of dereference expressions

\*******************************************************************/

void loop_modified_var_infot::collect_targets(
    const exprt& lhs,
    const CFG_nodet& n,
    expr_sett& targets)
{
  assert(targets.size() == 0);

  exprt lhs_copy = lhs;

  std::vector<std::set<exprt> > op_targets;
    
  Forall_operands(it, lhs_copy)
  {
    op_targets.push_back(expr_sett());
    collect_targets(*it, n, op_targets.back());
  }

  //construct all combinations of targets
  construct_combinations(lhs_copy, op_targets, targets);
 
  //now resolve each of the possible targets in turn
  if(lhs.id() == ID_dereference || 
     (lhs.id() == ID_index && 
      to_index_expr(lhs).array().type().id() == ID_pointer))
  {
    expr_sett new_targets;

    for(std::set<exprt>::iterator it = targets.begin();
        it != targets.end(); it++)
    {
      const exprt& e = *it;

      if(lhs.id() == ID_dereference)
      {
        expr_sett points_to_set;
        points_to_info.points_to(
          n, 
          to_dereference_expr(e).pointer(), 
          points_to_set);

        new_targets.insert(points_to_set.begin(), points_to_set.end());   
      } 
      else 
      {
        const index_exprt& ie = to_index_expr(e);
        expr_sett points_to_set;
        points_to_info.points_to(n, ie.array(), points_to_set);
        for(std::set<exprt>::const_iterator it = points_to_set.begin();
            it != points_to_set.end(); ++it)
        {
          exprt ie_cp(ie);
          exprt resolved_ptr = *it;
          to_index_expr(ie_cp).array().swap(resolved_ptr);
          assert(to_index_expr(ie_cp).array().type().subtype().is_not_nil());
          new_targets.insert(ie_cp);
        }
      }
    }

    new_targets.swap(targets);
  } 

}

/*******************************************************************\

Function: loop_modified_var_infot::construct_combinations

 Purpose: Construct all possible combinations of subexpressions

\*******************************************************************/

void loop_modified_var_infot::construct_combinations(
  const exprt& lhs, 
  const std::vector<expr_sett>& op_targets, 
  expr_sett& targets, 
  int cur_op)
{
  if(cur_op == -1)
  {
    if(op_targets.size() == 0)
    {
      targets.insert(lhs);
      return;
    }
    else
      cur_op = 0;
  }

  assert(cur_op >= 0 && unsigned(cur_op) <= lhs.operands().size());
  assert(lhs.operands().size() == op_targets.size());
  
  for(expr_sett::const_iterator it = op_targets[cur_op].begin();
      it != op_targets[cur_op].end(); it++)
  {
    exprt lhs_copy = lhs;
    exprt resolved_op = *it;

    lhs_copy.operands()[cur_op].swap(resolved_op);
    if(unsigned(cur_op) == op_targets.size() - 1)
    {
      targets.insert(lhs_copy);
    }
    else
      construct_combinations(lhs_copy, op_targets, targets, cur_op+1);
  }
}

std::string loop_modified_var_infot::to_string(const namespacet& ns) const
{
  std::stringstream ss;

  for(CFGt::const_nodes_vectort::const_iterator it = 
          cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end();
      it++) 
  {
    mod_mapt::const_iterator find_it = mod_map.find(*it);
    if(find_it != mod_map.end())
    {
      ss << "*******************************************" << std::endl;
      const expr_sett &s = find_it->second;
      ss << "modified: { ";
      for(expr_sett::const_iterator j = s.begin(); j != s.end(); ++j)
      {
        ss << expr2c(*j, ns);
        expr_sett::const_iterator j_next = j;
        if(++j_next != s.end())
          ss << ", ";
      }
      ss << " }" << std::endl; 
    }
    cfg.output_node(**it, ss);
  }

  return ss.str();
}
