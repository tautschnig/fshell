#include "abstr_domain.h"

abstr_elementt abstr_domaint::join(const abstr_elementst& e)
{
  assert(e.size() > 0);

  abstr_elementt result = e.front();
  for(abstr_elementst::const_iterator it = e.begin() + 1;
      it != e.end(); it++)
  {
    result.join(*it);
  }

  return result;
}

abstr_elementt abstr_domaint::meet(const abstr_elementst& e)
{
  assert(e.size() > 0);

  abstr_elementt result = e.front();
  for(abstr_elementst::const_iterator it = e.begin() + 1;
      it != e.end(); it++)
  {
    result.meet(*it);
  }

  return result;
}
abstr_elementt abstr_domaint::from_expr(const exprt& e)
{ 
  abstr_elementt r = top(); 
  r.apply_test(e, true); 
  return r; 
}

abstr_elementt::abstr_elementt(abstr_domaint& dom, unsigned id)
    : domain(dom), use_id(true) 
{ 
  dt.id = id; domain.register_abstr_elem(*this); 
}


abstr_elementt::abstr_elementt(abstr_domaint& dom, void* ptr)
    : domain(dom), use_id(false)
{ 
  dt.ptr = ptr; domain.register_abstr_elem(*this); 
}


abstr_elementt::abstr_elementt(const abstr_elementt& e)
  : domain(e.domain), dt(e.dt), use_id(e.use_id)
{ 
  use_id = e.use_id; 
  domain.register_abstr_elem(*this); 
}

abstr_elementt&
abstr_elementt::operator=(const abstr_elementt& e)
{ 
  if(&e.domain != &domain) 
    throw "Cannot assign elements belonging to different domains";

  domain.deregister_abstr_elem(*this);
  dt = e.dt; use_id = e.use_id; 
  domain.register_abstr_elem(*this); 

  return *this;
}

//all methods change the element, reference is returned to changed "this"
abstr_elementt& abstr_elementt::meet(const abstr_elementt& e)
{ 
  return domain.meet(*this, e); 
}

abstr_elementt& abstr_elementt::join(const abstr_elementt& e)
{ 
  return domain.join(*this, e); 
}

abstr_elementt& abstr_elementt::widen(
    const abstr_elementt& e, 
    const abstr_elementt& threshold)
{ 
  return domain.widen(*this, e, threshold); 
}

  //this <= arg in lattice-order?
bool abstr_elementt::leq(const abstr_elementt& e) const
{ 
  return domain.leq(*this, e); 
}

bool abstr_elementt::geq(const abstr_elementt& e) const
{ 
  return domain.geq(*this, e); 
}



bool abstr_elementt::eq(const abstr_elementt& e) const
{ 
  return domain.eq(*this, e); 
}
  
bool abstr_elementt::is_top() const
{ 
  return domain.is_top(*this); 
}

bool abstr_elementt::is_bot() const
{ 
  return domain.is_bot(*this); 
}

abstr_elementt& abstr_elementt::apply_assign(
    const exprt& lhs, 
    const exprt& rhs)
{ 
  return domain.apply_assign(*this, lhs, rhs); 
}

abstr_elementt& abstr_elementt::apply_test(const exprt& e, bool result)
{ 
  return domain.apply_test(*this, e, result); 
}

std::string abstr_elementt::to_string() const
{ 
  return domain.to_string(*this); 
}

exprt abstr_elementt::to_expr() const
{ 
  return domain.to_expr(*this); 
}

const abstr_domaint& abstr_elementt::get_domain() const 
{ 
  return domain; 
}

abstr_domaint& abstr_elementt::get_domain() 
{ 
  return domain; 
}

void* &abstr_elementt::ptr() 
{ 
  if(use_id) 
    throw "Accessing pointer in id-using element"; 
  return dt.ptr; 
}

void* const &abstr_elementt::ptr() const
{ 
  if(use_id) 
    throw "Accessing pointer in id-using element"; 
  return dt.ptr; 
}

unsigned& abstr_elementt::id() 
{ 
  if(use_id) 
    throw "Accessing id in pointer-using element"; 
  return dt.id; 
}

const unsigned& abstr_elementt::id() const
{ 
  if(use_id) 
    throw "Accessing id in pointer-using element"; 
  return dt.id; 
}

