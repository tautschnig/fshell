/*******************************************************************\

Module: Proof generalization using search on constants

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "search_generalization.h"

#include "bounds_search.h"

#include <flatten_expr.h>
#include <type2bounds.h>
#include <float_median.h>
#include <find_expr.h>
#include <resolve_types.h>


#include <memory>

search_generalizationt::search_generalizationt(
    abstr_fwd_analysist& _analysis, 
    interval_array_domaint& _itv_dom, 
    const namespacet& ns)
: sub(_analysis, ns), itv_dom(_itv_dom)
{ }

void search_generalizationt::generalize_step(
    const CFG_nodet& n, 
    abstr_elementt& elem,
    const id_sett& do_not_touch)
{
  if(!(n.type == ASSERT || n.type == ASSUME || 
      n.type == GOTO || n.type == ASSIGN))
    return;

  assert(valid_pre(n, elem, new_proof));
  
  bounds_searcht bs(elem, itv_dom, itv_dom.get_itv_var_domain());
  
  bool valid = true;
  while(bs.has_next())
  {
    bs.next(valid);
    valid = valid_pre(n, elem, new_proof);
  }

  assert(valid_pre(n, elem, new_proof));
}

//repair by search
void search_generalizationt::repair_step(
    const CFG_nodet& n, 
    abstr_elementt& broken_pre,
    const abstr_elementt& proof,
    const id_sett& must_include) 
{ 
  //first attempt simple repair
  if(n.type != GOTO && n.type != ASSUME &&
     n.type != ASSIGN && n.type != ASSERT)
  {
    assert(n.successor_next != NULL);
    assert(n.successor_jump == NULL);
    //if n.successor_next == NULL then no repair would be necessary
    
    broken_pre = get_invariant(new_proof, *n.successor_next);
    return;
  } 

  assert(valid_pre(n, proof, new_proof));

  abstr_domaint &dom = analysis.get_domain();

  exprt broken_pre_expr = broken_pre.to_expr();
  exprt proof_expr = proof.to_expr();
  
  //flatten elements into a big conjunction
  make_flat(proof_expr, ID_and, typet(ID_bool));

  assert(proof_expr.id() == ID_and);
  
  //slap on the original proof element
  and_exprt patched_proof(broken_pre_expr, proof_expr);

  //find out which symbols can possibly have an impact on validity of the triple
  hash_set_cont<exprt, irep_hash> trans_symbols, post_symbols;
  get_transition_symbols(n, trans_symbols);
  get_post_symbols(n, post_symbols);

  //remove all subexpressions that do not contain interesting symbols
  Forall_operands(it, patched_proof.op1())
  {
     if(!it->is_false() && 
        !has_subexpr(*it, trans_symbols) && 
        !has_subexpr(*it, post_symbols))
     {

       true_exprt t;
       *it = t;

       /*REMOVE ME
       abstr_elementt a = dom.from_expr(patched_proof); 
       if(!valid_pre(n, a, new_proof))
       {
         cfg.output_node(n, std::cout);
         std::cout << "Repaired: " << a.to_string() << std::endl;
         if(n.successor_next != NULL)
          std::cout << "Next: " 
                    << new_proof[n.successor_next->id].to_string() << std::endl;
         if(n.successor_jump != NULL)
          std::cout << "Jump: " 
                    << new_proof[n.successor_jump->id].to_string() << std::endl;
          
         std::cout << "Post symbols: ";
         for(hash_set_cont<exprt, irep_hash>::const_iterator it = 
                post_symbols.begin(); it != post_symbols.end(); it++)
         {
           std::cout << to_symbol_expr(*it).get_identifier()<< " " << std::endl;
         }
 
         std::cout << std::endl;

         std::cout << "Trans symbols: ";
         for(hash_set_cont<exprt, irep_hash>::const_iterator it = 
                trans_symbols.begin(); it != trans_symbols.end(); it++)
         {
           std::cout << to_symbol_expr(*it).get_identifier()<< " " << std::endl;
         }
         std::cout << std::endl;
         assert(0);
       }*/

     }
  }


  {
    abstr_elementt a = dom.from_expr(patched_proof); 
    //this must still be valid, because we only removed uninteresting things
    assert(valid_pre(n, a, new_proof));
  }


  //try removing each newly added element in turn
  Forall_operands(it, patched_proof.op1())
  { 
    if(it->is_true())
      continue; //skip removed parts

    //swap the element with dummy (= TRUE) and
    //check whether the proof still works
    exprt t = true_exprt();
    
    //replace by dummy
    it->swap(t);

    abstr_elementt a = dom.from_expr(patched_proof); 
    if(!valid_pre(n, a, new_proof))
      it->swap(t); //it was necessary, move it back
  }

  broken_pre = dom.from_expr(patched_proof);

}

/*******************************************************************\

Function: search_generalizationt::get_post_symbols

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void search_generalizationt::get_post_symbols(
    const CFG_nodet& n, 
    hash_set_cont<exprt, irep_hash>& set)
{
  //get symbols in post
  if(n.successor_next != NULL)
  {
    get_all_symbols(new_proof[n.successor_next -> id], set);
  }
  if(n.successor_jump != NULL)
  {
    get_all_symbols(new_proof[n.successor_jump -> id], set);
  }
}

/*******************************************************************\

Function: search_generalizationt::get_post_subexpr

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void search_generalizationt::get_post_subexpr(
    const CFG_nodet& n, 
    hash_set_cont<exprt, irep_hash>& set)
{
  //get symbols in post
  if(n.successor_next != NULL)
  {
    exprt p = new_proof[n.successor_next -> id].to_expr();
    get_all_subexpr(p, set);
  }
  if(n.successor_jump != NULL)
  {
    exprt p = new_proof[n.successor_jump -> id].to_expr();
    get_all_subexpr(p, set);
  }
}

/*******************************************************************\

Function: search_generalizationt::get_trans_symbols

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void search_generalizationt::get_transition_symbols(
    const CFG_nodet& n, 
    hash_set_cont<exprt, irep_hash>& set)
{
  exprt code;
  switch(n.type)
  {
    case ASSERT:
    case ASSUME:
      //std::cout << "reasoning guard " << n.reasoning_guard.pretty() 
      //          << std::endl;
      code = n.reasoning_guard;
      break;
    case GOTO:
      //std::cout << "jump cond " << n.jump_condition.pretty() 
      //          << std::endl;
      code = n.jump_condition;
      break;
    case ASSIGN:
      //std::cout << "assignment " << n.code.pretty() 
      //          << std::endl;
      code = n.code;
      break;
    default:
      break;
  }
  
  resolve_types(code, ns);
  //std::cout << "CODE: " << code.pretty() << std::endl;
  find_expr(code, ID_symbol, set);

}


void search_generalizationt::get_all_symbols(
  const abstr_elementt& n,
  hash_set_cont<exprt, irep_hash>& s) 
{
  n.get_domain().get_used_symbols(n, s);
}
