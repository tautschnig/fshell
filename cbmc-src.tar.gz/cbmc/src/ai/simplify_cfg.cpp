/*******************************************************************\

Module: Simplify CFG using an invariant generator

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "simplify_cfg.h"
#include "simplify_cfg_class.h"
#include "resolve_types.h"

#include "inv_generator.h"
#include <find_expr.h>

#include <replace_expr.h>
#include <simplify_expr.h>

void simplify_cfg_node(
    const inv_generatort& inv, 
    const namespacet& ns, 
    CFG_nodet& n)
{
  simplify_cfgt s(inv, ns);
  s.simplify_cfg_node(n);
}

void simplify_cfg(
    const inv_generatort& inv, 
    const namespacet& ns, 
    CFGt& cfg)
{
  simplify_cfgt s(inv, ns);
  s.simplify_cfg(cfg);
}

void simplify_cfgt::simplify_cfg_node(CFG_nodet& n)
{
  replace_mapt m;

  if(n.type == ASSERT || n.type == ASSUME || 
     n.type == GOTO || n.type == ASSIGN)
  {
    exprt i = inv.get_invariant(n);
    get_replace_map_from_inv(i, m);

    switch(n.type)
    {
      case ASSERT:
      case ASSUME:
        resolve_types(n.reasoning_guard, ns);
        replace_expr(m, n.reasoning_guard);
        simplify(n.reasoning_guard, ns);
        break;
      case GOTO:
        resolve_types(n.jump_condition, ns);
        replace_expr(m, n.jump_condition);
        simplify(n.jump_condition, ns);
        break;
      case ASSIGN:
        //replace rhs
        resolve_types(n.code, ns);
        replace_expr(m, to_code_assign(n.code).rhs());
        simplify(to_code_assign(n.code).rhs(), ns);
        simplify_indices_only(m, to_code_assign(n.code).lhs());
        break;
      default: assert(0);
    }
    
  }
}

void simplify_cfgt::simplify_cfg(CFGt& cfg)
{
  expr_sett used_symbols;

  forall_cfg_nodes(it, cfg)
  {
    CFG_nodet& n = **it;

    //simplify single nodes
    simplify_cfg_node(n);

    //record used symbols
    switch(n.type)
    {
      case ASSIGN:
        get_used_symbols(to_code_assign(n.code).lhs(), used_symbols);
        find_expr(to_code_assign(n.code).rhs(), ID_symbol, used_symbols);
        break;
      case ASSERT:
      case ASSUME:
        find_expr(n.reasoning_guard, ID_symbol, used_symbols);
        break;
      case GOTO:
        find_expr(n.jump_condition, ID_symbol, used_symbols);
        break;
      case FUNCTION_CALL: 
        forall_operands(it, to_code_function_call(n.code).op2())
        {
          find_expr(*it, ID_symbol, used_symbols);
        }
        break;

      default: //do nothing
        break;
    }
  }

  for(expr_sett::const_iterator it = used_symbols.begin(); 
      it != used_symbols.end(); it++)
  {
    std::cout << it->to_string() << std::endl;
  }
    std::cout << used_symbols.size() << std::endl;

  //replace all assignment nodes by skip if the assigned symbol is never used
  //fancier dataflow analysis here would be better
  forall_cfg_nodes(it, cfg)
  {
    CFG_nodet& n = **it;
    if(n.type == ASSIGN)
    {
      const exprt& s = get_assigned_symbol(to_code_assign(n.code).lhs());
      if(s.id() == ID_symbol && used_symbols.find(s) == used_symbols.end())
      {
        //symbol is never used
        n.type = SKIP;
        n.code.make_nil();
      }

    }
  }
}


bool simplify_cfgt::is_constant(const exprt& e)
{
  const irep_idt& id = e.id();
  return e.is_constant() || id == ID_array || id == ID_struct;
}

void simplify_cfgt::get_replace_map_from_inv(const exprt& inv, replace_mapt& m)
{
  if(inv.id() == ID_and)
  {
    forall_operands(it, inv)
      get_replace_map_from_inv(*it, m);
  } 
  else if(inv.id() == ID_equal || inv.id() == ID_ieee_float_equal)
  {
    assert(inv.operands().size() == 2);
    if(inv.op0().id() == ID_symbol)
      m[inv.op0()] = inv.op1();
    else if(inv.op1().id() == ID_symbol)
      m[inv.op1()] = inv.op0();
  }
}

void simplify_cfgt::simplify_indices_only(const replace_mapt& repl_map, exprt& e)
{
  if(e.id() == ID_index)
  {
    simplify_indices_only(repl_map, to_index_expr(e).array());
    replace_expr(repl_map, to_index_expr(e).index());
    simplify(e, ns);
  }
}

const exprt& simplify_cfgt::get_assigned_symbol(const exprt& lhs)
{
  if(lhs.id() == ID_index)
    return get_assigned_symbol(to_index_expr(lhs).array());
  else if(lhs.id() == ID_member)
    return get_assigned_symbol(to_member_expr(lhs).struct_op());
  else
    return lhs;
}

void simplify_cfgt::get_used_symbols(
    const exprt& lhs,
    expr_sett& used_symbols)
{
  if(lhs.id() == ID_index)
  {
    const index_exprt& index_expr = to_index_expr(lhs);
    find_expr(index_expr.index(), ID_symbol, used_symbols);
    get_used_symbols(index_expr.array(), used_symbols);
  } 
  else if(lhs.id() == ID_member)
  {
    return get_used_symbols(to_member_expr(lhs).struct_op(), used_symbols);
  } 
  else if(lhs.id() ==  ID_symbol) 
  {
    //do nothing, this is the assigned symbol   
  } 
  else
  {
    //anything else, just assume the symbols occurring below are used
    find_expr(lhs, ID_symbol, used_symbols);
  } 
}
