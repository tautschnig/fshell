/*******************************************************************\

Module: Abstract domain framework. New domains are implemented by 
        deriving from abstr_domaint, abstr_elementt stays the same.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef COUNT_CFG_PATHS_H
#define COUNT_CFG_PATHS_H

#include <goto-programs/control_flow_graph.h> 
#include <arith_tools.h>

//return nr of loop-free paths
mp_integer count_CFG_paths(const CFGt& cfg);

#endif
