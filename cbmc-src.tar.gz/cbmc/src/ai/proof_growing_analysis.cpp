#include "proof_growing_analysis.h"

#include "array_core_generalization.h"
#include "search_generalization.h"
#include "global_search_generalization.h"

#include "get_symbol_vals.h"

#include <find_expr.h>
#include <negate_expr.h>

#include <ansi-c/expr2c.h>

//#define DEBUGINFO 1

/*******************************************************************\

Function: proof_growing_analysist::decide
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool proof_growing_analysist::decide(abstr_elementt& elem)
{
  propt::resultt r = solver.prop_solve();
  
  //we can't further refine a decision

  if(r == propt::P_SATISFIABLE)
  {
    exprt result_expr = get_symbol_vals(boolbv, decision_variables);
    elem = domain.from_expr(result_expr);
  } 
  else return false; 

  return true;
}

/*******************************************************************\

Function: proof_growing_analysist::generalize_proof
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void proof_growing_analysist::generalize_proof(abstr_elementt& elem) 
{
  //std::cout << "*** Generalizing proof *********************" << std::endl;
  //search_generalizationt sg(*this, itv_array_domain, ns);
  //sg.ignore_symbols(ignored_symbols);
  //sg.generalize();
  global_search_generalizationt 
    gg(*this, 
        itv_array_domain, 
        itv_array_domain.get_itv_var_domain(),
        elem);

  gg.generalize();

  //std::cout << "*** Done Generalizing proof ****************" << std::endl;
}

/*******************************************************************\

Function: proof_growing_analysist::learn_and_backtrack
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool proof_growing_analysist::learn_and_backtrack(abstr_elementt& elem) 
{
  const CFG_nodet& initial_node = cfg.get_initial();

  //add constraints to SAT solver
  exprt initial_invar = get_invariant(initial_node);
  std::cout << "INITIAL VALUE OF GENERALIZED PROOF: " 
            << expr2c(initial_invar, ns) << std::endl;

  boolbv.set_to_false(initial_invar);

  //get new initial assignment from proof 
  bool has_decision = decide(elem);

  return has_decision;
}

/*******************************************************************\

Function: proof_growing_analysist::init()

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void proof_growing_analysist::init(abstr_elementt& elem)
{
  convert_symbols(decision_variables, boolbv);
}

/*******************************************************************\

Function: proof_growing_analysist::convert_symbols
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void proof_growing_analysist::convert_symbols(const symbol_sett &s, boolbvt& bv)
{
  for(symbol_sett::const_iterator it = s.begin(); it != s.end(); it++)
  { 
    bvt bv;

    boolbv.convert_bv(*it, bv);

    if(it->type().id() == ID_floatbv)
    {
      exprt eq(ID_ieee_float_equal, typet(ID_bool));
      eq.copy_to_operands(*it);
      eq.copy_to_operands(*it);
      boolbv.set_to_true(eq); //generate non nan values
    }
  }
}


