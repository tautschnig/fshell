/*******************************************************************\

Module: Proof generalization using search on constants

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "bounds_search.h"

bounds_searcht::bounds_searcht(
    abstr_elementt& _elem,
    abstr_env_domaint& _abstr_env,
    interval_var_domaint& _itv_var) : 
  elem(_elem),  
  abstr_env(_abstr_env), 
  itv_var(_itv_var), done(false), drop_mode(true)
{ 
  var_mapt& m = abstr_env.get_var_map(elem);

  if(elem.is_top() || elem.is_bot())
  {
    done = true;
    return;
  }

  //init search entries
  for(var_mapt::iterator it = m.begin(); it != m.end(); it++)
  {
    itvt& itv = itv_var.get_internal(it->second);

    assert(!itv.is_bot());

    if(itv.is_top())
      continue; //ignore top

    //make a new search type of the appropriate type for upper and lower bound
    if(itv.type == itvt::FLOAT)
    {
      float_intervalt& f = itv.f();

      search_entries.push_back(
          search_entryt(&itv, new float_bound_searcht(f.lower(), -1)));
      search_entries.push_back(
          search_entryt(&itv, new float_bound_searcht(f.upper(), 1)));
    } 
    else if(itv.type == itvt::INTBV)
    {
      intbv_intervalt& i = itv.i();

      search_entries.push_back(
          search_entryt(
            &itv, new int_bound_searcht(i.lower(), i.get_type(), -1)));
      search_entries.push_back(
          search_entryt(
            &itv, new int_bound_searcht(i.upper(), i.get_type(), 1)));
    }
  }
  
  cur = 0;
} 

void bounds_searcht::next(bool widen)
{
  static int bounds_counter = 0;
  bounds_counter++;

  //std::cout << "called with widen = " << widen << std::endl;
  assert(!done);
  bool mode_switch = false;

  if(drop_mode)
  {
    if(cur > 0)
    {
      if(widen)
      {
        //remove from search
        if(cur != int(search_entries.size()))
          std::swap(search_entries[cur-1], search_entries.back());
        cur--;

        //HERE SOME POINTERS DIE
        delete search_entries.back().s;
        search_entries.back().s = NULL;
        search_entries.resize(search_entries.size()-1);

        //std::cout << "removed " << (cur - 1) << std::endl;
      } else {
        //undo last change 
        search_entryt& e = search_entries[cur-1];
        itvt& itv = *e.itv;
        const_bound_searcht& s = *e.s;

        s.set_to_cur();
        s.set_itv(itv);
        //std::cout << "couldn't remove " << (cur - 1) << std::endl;
      }
    }
    
    //if we are not done
    if(cur < int(search_entries.size()))
    {
      //set current one to far
      search_entryt& e = search_entries[cur];
      itvt& itv = *e.itv;
      const_bound_searcht& s = *e.s;

      s.set_to_far();
      s.set_itv(itv);

      cur++;
    } 
    else 
    {
      //here we are done with drop mode
      drop_mode = false;
      mode_switch = true;
      cur = search_entries.size() - 1;
      done = (search_entries.size() == 0);
      if(done)
        return;
      //std::cout << "done with drop mode " << std::endl;
    }
  }

  //here we enter search proper
  if(!drop_mode)
  {
    if(mode_switch)
      widen = true; //we always widen after switching 
  
    if(widen)
    {
      //find next element where "has_next" is true
      int old_cur = cur;
      do 
      {
        cur = (cur + 1) % search_entries.size();
      } while(cur != old_cur && !search_entries[cur].s->has_next());

      //std::cout << "found new elem " << cur << std::endl;
      if(!search_entries[cur].s->has_next())
      {
        //std::cout << "but it doesn't have next, so we are done "<< std::endl;
        //no more entries
        done = true;
        return;
      }
    }  

    //get current element
    search_entryt& e = search_entries[cur];
    itvt& itv = *e.itv;
    const_bound_searcht& s = *e.s;
    
    //get next bound for current element
    s.next(widen); 
    s.set_itv(itv);
  }
}


bounds_searcht::~bounds_searcht()
{
  for(unsigned i = 0; i < search_entries.size(); i++)
    delete search_entries[i].s;
}
