#include "iteration_schedule.h"

fwd_iteration_schedulet::
fwd_iteration_schedulet(const CFGt& _cfg, const loop_infot& _loop_info)
  : sub(_cfg, _loop_info)
{
  fwd_iteration_schedulet::reset(_cfg.get_initial());
}

void fwd_iteration_schedulet::
reset(const CFG_nodet& n)
{
  node_stack.clear();
  on_stack.clear();

  node_stack.push_back(loop_framet(NULL));
  
  const CFG_nodet* initial = &n;

  node_stack.back().node_queue.push(initial);
  on_stack.insert(initial->id);
}

void fwd_iteration_schedulet::
clear_all_empty()
{
  while(node_stack.size() > 0 && node_stack.back().node_queue.empty())
    node_stack.pop_back();
}

bool
fwd_iteration_schedulet::
empty() const
{
  return node_stack.size() == 0;
}

bool fwd_iteration_schedulet::is_loop_header() const
{
  if(empty())
    throw "is_loop_header called when there is no next node";

  const CFG_nodet& n = top();

  const loop_infot::loopt* l = 
    loop_info.get_closest_containing_loop(&n);

  return l != NULL && l->header->id == n.id;
}

unsigned fwd_iteration_schedulet::loop_depth() const
{
  if(empty())
    throw "loop_depth called on empty schedule";
  return node_stack.size()-1;
}

unsigned fwd_iteration_schedulet::iterations_in_loop(unsigned d) const
{
  return node_stack[d].iterations;
}

unsigned fwd_iteration_schedulet::iterations_in_loop() const
{
  return iterations_in_loop(loop_depth());
}

const CFG_nodet&
fwd_iteration_schedulet::
top() const
{
  if(empty())
    throw "get_next called on empty schedule";

  return *node_stack.back().node_queue.top();
}

void fwd_iteration_schedulet::
enqueue_successor(const CFG_nodet& n)
{
  if(on_stack.find(n.id) != on_stack.end())
    return;

  //find loopframe depth
  unsigned p = 1;

  for(  ; p < node_stack.size() && node_stack[p].loop->contains(n); p++);
  p--;
  //p now contains innermost loop in frame which contains n
  
  //enqueue node
  node_stack[p].node_queue.push(&n);
  on_stack.insert(n.id);
}


void
fwd_iteration_schedulet::
pop(bool value_changed)
{
  assert(!empty());

  const CFG_nodet& n = top();

  //erase from hashset
  on_stack.erase(top().id);
  //pop queue
  node_stack.back().node_queue.pop();
  
  //enqueue successors
  if(value_changed) 
  {
    if(n.successor_next != NULL)
      enqueue_successor(*n.successor_next);

    if(n.successor_jump != NULL)
      enqueue_successor(*n.successor_jump);
  }

  //clear all empty stacks
  clear_all_empty();

  if(empty())
    return;

  /** push new loopframe on stack if current node is a loop header **/
  loop_framet& cur_frame = node_stack.back();
  const CFG_nodet& cur_node = *cur_frame.node_queue.top();
  const loop_infot::loopt* l = loop_info.get_closest_containing_loop(&cur_node);

  if(l != NULL &&  l != cur_frame.loop)
  {
    /*current node is not contained in the current loop, 
      must be the entry-point to a new nested loop */
    assert(cur_node.id == l->header->id);
    //take the current node off the old loopframe
    cur_frame.node_queue.pop();
    //push a new loopframe on the stack
    node_stack.push_back(loop_framet(l));
    //push the current node on the newly created frame
    node_stack.back().node_queue.push(&cur_node);
  } else
  {
    //if the current node is the loop header, increase the iteration count
    if(l != NULL && l->header->id == cur_node.id)
      node_stack.back().iterations++;
  }
}
