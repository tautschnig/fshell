/*******************************************************************\

Module: Obtain variables modified in loops

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef LOOP_MODIFIED_VARS_H
#define LOOP_MODIFIED_VARS_H

#include "points_to_info.h"

#include <goto-programs/loops.h>
#include <hash_cont.h>
#include <set>
#include <string>


class loop_modified_var_infot 
{
public:
  typedef loop_infot::loopt loopt;
  typedef std::set<exprt> expr_sett;

  loop_modified_var_infot(
    const loop_infot& loop, 
    const CFGt& cfg,
    const points_to_infot& p);

  const expr_sett& get_modified(const loopt& loop) const
  { return get_modified(loop.header); }

  const expr_sett& get_modified(const CFG_nodet* header) const;
    
  std::string to_string(const namespacet& ns) const;
  
protected:
  const loop_infot& loop_info;
  const CFGt& cfg;
  const points_to_infot& points_to_info;

  void do_analysis();

  void analyse_assign(
    const exprt& lhs, 
    const CFG_nodet& n, 
    expr_sett& target_set);

  void analyse_dereference(
    const exprt& lhs, 
    const CFG_nodet& n, 
    expr_sett& target_set);

  void collect_targets(
    const exprt& lhs,
    const CFG_nodet& n,
    expr_sett& targets);

  void construct_combinations(
  const exprt& lhs, 
  const std::vector<expr_sett>& op_targets, 
  expr_sett& targets, 
  int cur_op = -1);

  typedef hash_map_cont<const CFG_nodet*, expr_sett> mod_mapt;
  mod_mapt mod_map;
};

#endif
