/*******************************************************************\

Module: Abstract forward analysis

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "abstr_fwd_analysis.h"

#include <resolve_types.h>

#include <i2string.h>
#include <std_expr.h>
#include <simplify_expr.h>
#include <std_expr.h>

#include <string>
#include <queue>

//#define DEBUG_OUTPUT

exprt abstr_fwd_analysis_baset::get_invariant(const CFG_nodet& n) const
{
  if(n.id < 0 || (unsigned) n.id > cfg.size())
    throw "Illegal CFG node id: " + i2string(n.id);

  if(cfg.size() != abstr_vec.size())
  {
    throw "get_invariant called without calling perform_analysis first";
  }
  
  const abstr_elementt& elem = abstr_vec[n.id];
  return elem.to_expr();
}

void abstr_fwd_analysis_baset::propagate(const CFG_nodet& n)
{
  schedule.reset(n);

  abstr_vect incoming;

  abstr_elementt top = domain.top();

  unsigned iterations = 0;

  /************ compute post- fixpoint **************/
  int last_node = -1;
  while(!schedule.empty())
  {
    const CFG_nodet& n = schedule.top();
    last_node = n.id;
    iterations++;

    //cfg.output_node(n, std::cout);

    incoming.clear();
    get_incoming_elems(n, incoming);
    
    abstr_elementt new_elem = join(incoming);
    abstr_elementt old_elem = get_abstr_elem(n);

#ifdef DEBUG_OUTPUT
    std::cout << "old: " << old_elem.to_string() << std::endl;
    std::cout << "new: " << new_elem.to_string() << std::endl;
    std::cout << std::endl;
#endif 
    
    bool value_changed;
    value_changed = !new_elem.eq(old_elem);

    //this is needeed to make propagate work when parts of 
    //proof are manually changed
    if(value_changed)
      new_elem.join(old_elem);

    if(value_changed)
    {
      if(widening_strategy.apply_widening())
        new_elem = old_elem.widen(new_elem, top);

      set_abstr_elem(n, new_elem);
    } 

    schedule.pop(value_changed);
  }
  /****************************************************/
  
}

void abstr_fwd_analysis_baset::perform_analysis()
{
  //initialize all invariants to false
  init_analysis();

  propagate(cfg.get_initial());
    
}

abstr_elementt abstr_fwd_analysis_baset::join(abstr_vect& vec)
{
  abstr_elementt result = domain.bot();

  for(abstr_vect::iterator it = vec.begin(); 
      it != vec.end();
      it++)
    result.join(*it);

  return result;
}


void abstr_fwd_analysis_baset::get_violated_assertions(local_exprst& l) 
                                         
{

  for(CFGt::const_nodes_vectort::const_iterator it = cfg.get_ordered_nodes().begin();
      it != cfg.get_ordered_nodes().end();
      it++) 
  {
    if((*it)->type == ASSERT)
    {
      exprt guard = (*it)->reasoning_guard;
      resolve_types(guard, ns);

      abstr_elementt a = get_abstr_elem(**it);

      if(!a.apply_test(guard, false).is_bot())
      {
        local_exprt violation(*it, a.to_expr());
        l.push_back(violation);
      }

    }
  }

}


void abstr_fwd_analysis_baset::set_abstr_elem(
    const CFG_nodet& n, 
    abstr_elementt a)
{
  assert(n.id >= 0 && (unsigned) n.id < cfg.size());
  abstr_elementt& old = abstr_vec[n.id];
  old = a;
}

abstr_elementt& abstr_fwd_analysis_baset::get_abstr_elem(const CFG_nodet& n)
                                         
{
  assert(n.id >= 0 && (unsigned) n.id < cfg.size());
  assert(unsigned(n.id) < abstr_vec.size());
  return abstr_vec[n.id];
}

void abstr_fwd_analysis_baset::get_incoming_elems(
    const CFG_nodet& n, 
    abstr_vect& v)
{
  for(std::set<CFG_nodet*>::const_iterator it = n.predecessors.begin();
      it != n.predecessors.end(); it++)
  {
    v.push_back(transfer(get_abstr_elem(**it), **it, n));
  }

  //if n is the initial node also add the initial element
  if(is_initial_node(n))
  {
    v.push_back(get_initial_element());
  }
}

abstr_elementt abstr_fwd_analysis_baset::transfer(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
#ifdef DEBUG_OUTPUT
  std::cout << "transferring " << n1.id << " to " << n2.id << std::endl;
#endif
  switch(n1.type) 
  {
    case ASSERT:
    case SKIP:
    case DECL:
    case LOCATION:
    case OTHER:
    case NO_INSTRUCTION_TYPE:
    case END_FUNCTION:
      return transfer_skip(e,n1,n2);
      break;
    case FUNCTION_CALL:
      return transfer_function_call(e, n1, n2);
      break;
    case GOTO:
      return transfer_goto(e,n1,n2);
      break;
    case ASSUME:
      return transfer_assume(e,n1,n2);
      break;
    case ASSIGN:
      return transfer_assign(e,n1,n2);
      break;

    case START_THREAD:
    case END_THREAD:
    case DEAD:
    case ATOMIC_BEGIN:
    case ATOMIC_END:
    case THROW:
    case CATCH:
    case RETURN:
      throw "Instruction type not implemented";
  }

  return domain.top();
}


abstr_elementt abstr_fwd_analysis_baset::transfer_skip(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
  return e;
}

abstr_elementt abstr_fwd_analysis_baset::transfer_function_call(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
  throw "function calls not implemented";
}

abstr_elementt abstr_fwd_analysis_baset::transfer_goto(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
  exprt jump_condition = n1.jump_condition;
  resolve_types(jump_condition, ns);
  abstr_elementt result(e);
  
  if(n1.successor_next == &n2)
  {
    //n2 is the false successor
    return result.apply_test(jump_condition, false);
  } else {
    //n2 is the true successor
    assert(n1.successor_jump == &n2);
    return result.apply_test(jump_condition, true);
  } 
}


abstr_elementt abstr_fwd_analysis_baset::transfer_assume(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
  abstr_elementt result(e);
  exprt guard = n1.reasoning_guard;
  resolve_types(guard, ns);
  return result.apply_test(guard, true);
}

abstr_elementt abstr_fwd_analysis_baset::transfer_assign(
    const abstr_elementt& e,
    const CFG_nodet& n1, 
    const CFG_nodet& n2)
{
  abstr_elementt result(e);
  code_assignt assign = to_code_assign(n1.code);

  resolve_types(assign.lhs(), ns);
  resolve_types(assign.rhs(), ns);

  return result.apply_assign(assign.lhs(), assign.rhs());
}

void abstr_fwd_analysis_baset::init_analysis()
{
  abstr_vec.clear();
  abstr_vec.resize(cfg.size(), domain.bot());
}

bool abstr_fwd_analysis_baset::is_initial_node(const CFG_nodet& n)
{
  return &n == &cfg.get_initial();
}  

abstr_fwd_analysis_baset::abstr_fwd_analysis_baset(
  const CFGt& cfg, 
  abstr_domaint& dom, 
  iteration_schedulet& _schedule,
  widening_strategyt& _widening_strategy,
  const namespacet& _ns)
    : SUB(cfg), ns(_ns), domain(dom), schedule(_schedule),
      widening_strategy(_widening_strategy) 
{ 
  abstr_vec.resize(cfg.size(), domain.bot());
}
