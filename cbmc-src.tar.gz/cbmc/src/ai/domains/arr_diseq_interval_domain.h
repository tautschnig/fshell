/*******************************************************************\

Module: Naive implementation of a reduced product between intervals 
        and disequalities/equalities
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ARR_DISEQ_INTERVAL_DOMAIN_H
#define ARR_DISEQ_INTERVAL_DOMAIN_H


#include "../product_domain.h"
#include "array_disequality_domain.h"
#include "disequality_domain.h"
#include "interval_array_domain.h"

class arr_diseq_interval_domaint : public product_domaint
{
public:
  typedef product_domaint sub;

  arr_diseq_interval_domaint(ieee_floatt::rounding_modet r = ieee_floatt::UNKNOWN) :
    sub(diseq_domain, interval_array_domain), 
    array_emul(4),
    diseq_domain(array_emul),
    interval_array_domain(array_emul, r) { }

  //override 
  virtual void reduce(abstr_pairt& p);

  virtual ~arr_diseq_interval_domaint() { }

  virtual void apply_assign_inplace(
      abstr_pairt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  virtual void apply_test_inplace(
      abstr_pairt& a, 
      const exprt& e,
      bool result);

protected:
  virtual void reduce_diseq2intervals( 
    abstr_elementt& diseq, 
    abstr_elementt& itv); 

  virtual void reduce_intervals2diseq( 
    abstr_elementt& diseq, 
    abstr_elementt& itv); 

  virtual void simplify_with_intervals(
    const abstr_elementt& interval_element,
    exprt& e);

  virtual void simplify_indices(
    const abstr_elementt& interval_element,
    exprt& e);
  
  array_struct_emulatort array_emul;
  array_diseq_domaint diseq_domain;
  interval_array_domaint interval_array_domain;

};

#endif
