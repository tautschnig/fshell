#include "interval_array_domain.h"

abstr_elementt interval_array_domaint::from_itv_assignments(
    const std::vector<symbol_exprt>& s, 
    const std::vector<itvt>& v)
{
  std::vector<abstr_elementt> elems;

  std::vector<symbol_exprt>::const_iterator it2 = s.begin();

  for(std::vector<itvt>::const_iterator it = v.begin();
      it != v.end(); it++)
  {
    assert(
      (it2->type().id() == ID_floatbv && it->type == itvt::FLOAT) ||
      (it2->type().id() == ID_signedbv && it->type == itvt::INTBV) ||
      (it2->type().id() == ID_unsignedbv && it->type == itvt::INTBV));

    elems.push_back(interval_var_domain.from_itv(*it));
    it2++;
  }

  return from_abstr_assignments(s, elems);
}
