/*******************************************************************\

Module: Simple constant propagation domain, 
        very limited functionality. 
        
        Solves a specific problem in proof growing. 
        Not fit for public consumption in its current state.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef CONST_PROP_DOMAIN_H
#define CONST_PROP_DOMAIN_H

#include "../abstr_domain_mem.h"

#include <hash_cont.h>
#include <std_expr.h>
#include <namespace.h>

class symbol_mapt : public hash_map_cont<exprt, exprt, irep_hash> 
{
public:
  symbol_mapt(bool top = true)
    : bot(!top) { }

  void set_top() { bot = false; clear(); }
  bool is_top() const { return !bot && size()==0; }

  void set_bot() { bot = true;}
  bool is_bot() const { return bot; }

protected:
  bool bot;
};

class const_prop_domaint : public abstr_domain_memt<symbol_mapt>
{
public: 
  const_prop_domaint(const namespacet& _ns)
    : ns(_ns) { } 

  virtual abstr_elementt top();
  virtual abstr_elementt bot();

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  virtual std::string to_string(const abstr_elementt& a);
  virtual exprt to_expr(const abstr_elementt& a);
  virtual abstr_elementt get_initial() { return top(); }

  virtual void  meet_inplace(symbol_mapt&, const symbol_mapt& e);

  virtual void  join_inplace(symbol_mapt&, const symbol_mapt& e);

  virtual void widen_inplace(
      symbol_mapt&, 
      const symbol_mapt& e, 
      const symbol_mapt& threshold);

  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      symbol_mapt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  //return result of applying test for c expression
  virtual void apply_test_inplace(
      symbol_mapt& a, 
      const exprt& e, 
      bool result);

  virtual void fwd_interpret(
      const symbol_mapt& context,
      exprt& e);

protected:
  const namespacet& ns;

  virtual bool accept_rhs(const exprt& e);

  bool is_constant(const exprt& e);
  
  void to_symbol_assignment(exprt& lhs, exprt& rhs);
};


#endif
