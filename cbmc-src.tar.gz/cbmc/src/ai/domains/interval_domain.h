/*******************************************************************\

Module: Convenience class to for interval domain 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef INTERVAL_DOMAIN_H
#define INTERVAL_DOMAIN_H

#include "../abstr_env.h"
#include "interval_var_domain.h"
#include <ieee_float.h>


class interval_domaint : public abstr_env_domaint 
{
public:
  interval_domaint(ieee_floatt::rounding_modet r = ieee_floatt::UNKNOWN) 
    : abstr_env_domaint(interval_var_domain), interval_var_domain(r)
      { }

  ieee_floatt::rounding_modet get_rounding_mode()
  { return interval_var_domain.get_rounding_mode(); }

  //later assignments supersede earlier assignments
  abstr_elementt from_itv_assignments(
      const std::vector<symbol_exprt>&, 
      const std::vector<itvt>&);

  interval_var_domaint& get_itv_var_domain()
  { return interval_var_domain; }

protected:
  interval_var_domaint interval_var_domain;
};

#endif 
