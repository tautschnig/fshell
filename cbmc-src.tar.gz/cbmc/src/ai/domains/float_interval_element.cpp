/*******************************************************************\

Module: Floating point interval

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "float_interval_element.h"

#include <float_median.h>

#include <std_types.h>

#include <iomanip>

#include <limits>


ieee_floatt::rounding_modet float_intervalt::_rmode = 
  ieee_floatt::UNKNOWN;

bool float_intervalt::sound_nan = true;

/*******************************************************************\

Function: float_intervalt::float_intervalt

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

float_intervalt::float_intervalt(ieee_floatt::rounding_modet r)
{
  set_rounding_mode(r);
  set_top();
}


/*******************************************************************\

Function: float_intervalt::float_intervalt

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

float_intervalt::float_intervalt(const typet& t, ieee_floatt::rounding_modet r)
  : spec(to_floatbv_type(t))
{
  set_rounding_mode(r);

  u.change_spec(spec);
  u.rounding_mode = u_round;
  l.change_spec(spec);
  l.rounding_mode = l_round;
  set_top();

  type = t;
}

/*******************************************************************\

Function: float_intervalt::set_rounding_mode

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::set_rounding_mode(ieee_floatt::rounding_modet r)
{
  rounding_mode = r;

  switch(r)
  {
    case ieee_floatt::ROUND_TO_EVEN:
    case ieee_floatt::ROUND_TO_ZERO:
    case ieee_floatt::ROUND_TO_PLUS_INF:
    case ieee_floatt::ROUND_TO_MINUS_INF:
      l_round = u_round = r;
      break;
    case ieee_floatt::UNKNOWN: 
    case ieee_floatt::NONDETERMINISTIC:
      l_round = ieee_floatt::ROUND_TO_MINUS_INF;
      u_round = ieee_floatt::ROUND_TO_PLUS_INF;
  } }

/*******************************************************************\

Function: float_intervalt::set_top

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::set_top() 
{
  top = true; 
}

/*******************************************************************\

Function: float_intervalt::set_bot

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::set_bot() 
{
  l = one(); u = zero(); top = false;
}

/*******************************************************************\

Function: float_intervalt::change_type

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::change_type(const floatbv_typet& _type)
{
  spec = ieee_float_spect(_type);
  l.change_spec(spec);
  u.change_spec(spec);

  type = _type;
}

/*******************************************************************\

Function: float_intervalt::set

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::set(const ieee_floatt& _l, const ieee_floatt& _u)
{
  if(_l.spec != spec || _u.spec != spec)
    throw "Incompatible floating point format";

  if(_l.is_NaN() || _u.is_NaN())
  {
    set_top();
    return;
  }
  
  assert(_l.spec == _u.spec);
  assert(_l.spec == l.spec);
  l = _l;
  u = _u;
  l.rounding_mode = l_round;
  u.rounding_mode = u_round;

  top = false;
}

/*******************************************************************\

Function: float_intervalt::zero

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

ieee_floatt float_intervalt::zero() const
{
  ieee_floatt r(spec);
  r.make_zero();
  return r;
}

/*******************************************************************\

Function: float_intervalt::minus_zero

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

ieee_floatt float_intervalt::minus_zero() const
{
  ieee_floatt r(spec);
  r.make_zero();
  r.negate();
  return r;
}

/*******************************************************************\

Function: float_intervalt::one

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

ieee_floatt float_intervalt::one() const
{
  mp_integer i(1);
  ieee_floatt r(spec);
  r.from_integer(i);
  return r;
}


/*******************************************************************\

Function: float_intervalt::to_expr

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

exprt float_intervalt::to_expr() const
{
  if(is_singleton())
  {
    return lower().to_expr();
  } else {
    typet t("interval");
    t.subtype() = type;

    constant_exprt constant(t);

    exprt l_expr = lower().to_expr();
    exprt u_expr = upper().to_expr();
    constant.move_to_operands(l_expr);
    constant.move_to_operands(u_expr);

    return constant; 
  }

}


/*******************************************************************\

Function: float_intervalt::operator-

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

float_intervalt float_intervalt::operator-( void ) const //unary minus
{ 
  float_intervalt r(*this); 

  if(is_top() || is_bot()) return r;

  ieee_floatt l = r.lower(); 
  
  ieee_floatt u = r.upper();
  
  l.negate(); u.negate(); 
  
  r.set(u, l); 

  return r;
}

/*******************************************************************\

Function: float_intervalt::square
 
  Inputs:

 Outputs:

 Purpose: Square the interval, This is different from multiplying an
          interval by itself: [-3,3] * [-3,3] = [-9,9]
                              [-3,3]^2 = [0,9]

\*******************************************************************/

void float_intervalt::square()
{
  if(is_top() || is_bot())
    return;

  ieee_floatt l_square = l;
  l_square*=l;
  ieee_floatt u_square = u;
  u_square*=u;

  if(l < zero() && u > zero())
  {
    //interval starts at zero
    set(zero(), std::max(l_square, u_square));
  }
  else 
  {
    //interval starts at lower square
    if(l_square < u_square)
      set(l_square, u_square);
    else 
      set(u_square, l_square);
  }

  normalize();
}

/*******************************************************************\

Function: float_intervalt::halve_lower

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::halve_lower(bool median)
{
  if(is_singleton())
    return;

  ieee_floatt inc_l = lower();
  inc_l.increment();

  
  if(inc_l == upper())
    set(lower(), lower());
  else
  {
    ieee_floatt mid = 
      median ? ieee_float_median(lower(), upper()) :
               ieee_float_average(lower(), upper());
    set(lower(), mid);
  }

}

/*******************************************************************\

Function: float_intervalt::halve_upper

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void float_intervalt::halve_upper(bool median)
{
  if(is_singleton())
    return;
  
  ieee_floatt inc_l = lower();
  inc_l.increment();

  if(inc_l == upper())
    set(upper(), upper());
  else
  {
    ieee_floatt mid = 
      median ? ieee_float_median(lower(), upper()) :
               ieee_float_average(lower(), upper());
    mid.increment();
    set(mid, upper());
  }
}

bool float_intervalt::complement(const float_intervalt& c)
{
  if(lower() == c.lower())
  {
    set(upper(), c.upper());
    if(!is_singleton());
    inc_lower();
  } 
  else if(upper() == c.upper())
  {
    set(c.lower(), lower());
    if(!is_singleton())
      dec_upper();
  } else return false;
  
  return true;
}

float_intervalt& float_intervalt::negate()
{
  ieee_floatt ln = l;
  ieee_floatt un = u;
  ln.negate(); un.negate();
  set(un, ln);
  return *this;
}

bool float_intervalt::
is_bot() const
{
  return
    !top && (u < l ||
    (u.is_zero() && u.get_sign() && l.is_zero() && !l.get_sign()));
}

float_intervalt& float_intervalt::
join(const float_intervalt& i)
{
  if(is_top())
  {
    return *this;
  }
  if(i.is_top())
  {
    set_top(); return *this;
  }
  if(is_bot())
  {
    *this = i; return *this;
  }
  if(i.is_bot())
  {
    return *this;
  }


  if(l > i.l || (l >= i.l && !l.get_sign()))//to fix 0.0f / -0.0f comparison
    l = i.l;
  if(u < i.u || (u <= i.u && u.get_sign())) //to fix 0.0f / -0.0f comparison
    u = i.u;
  normalize();
  return *this;
}

float_intervalt& float_intervalt::meet(const float_intervalt& i)
{
  if(is_top())
  {
    *this = i;
    return *this;
  }
  if(i.is_top())
  {
    return *this;
  }
  if(is_bot())
  {
    return *this;
  }
  if(i.is_bot())
  {
    set_bot();
    return *this;
  }


  if(l < i.l || (l <= i.l && l.get_sign())) //to fix 0.0f / -0.0f comparison
    l = i.l;
  if(u > i.u || (u >= i.u && !u.get_sign())) //to fix 0.0f / -0.0f comparison
    u = i.u;
  normalize();
  return *this;
}

float_intervalt& float_intervalt::operator+=(
    const float_intervalt& i)
{
  if(arith_handle_special(i))
    return *this;
  
  //handle infinity
  if((l.is_infinity() && l.get_sign() &&
        i.u.is_infinity() && !i.u.get_sign()) ||
      (i.l.is_infinity() && i.l.get_sign() &&
       u.is_infinity() && !u.get_sign()))
  {
    if(sound_nan)
      set_top();
    else
      set_non_nan();
    return *this;
  }

  l += i.l;
  u += i.u;

  normalize();
  return *this;
}

float_intervalt& float_intervalt::operator-=(
    const float_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;


  if((l.is_infinity() && l.get_sign() &&
        i.l.is_infinity() && i.l.get_sign()) ||
      (i.u.is_infinity() && !i.u.get_sign() &&
       u.is_infinity() && !u.get_sign()))
  {
    if(sound_nan)
      set_top();
    else
      set_non_nan();

    return *this;
  }
  l -= i.u;
  u -= i.l;

  normalize();
  return *this;
}

float_intervalt& float_intervalt::operator/=(
    const float_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;
  
  ieee_floatt z = zero();

  if(sound_nan)
  {
    //infinity divided by infinity is NaN
    if((l.is_infinity() || u.is_infinity()) &&
        (i.l.is_infinity() || i.u.is_infinity()))
    {
      set_top();
      normalize();
      return *this;
    }
  }

  bool contains_zero = (l <= z && z <= u);
  bool i_contains_zero = (i.l <= z && z <= i.u);


  //0 / 0 is NaN
  if(contains_zero && i_contains_zero)
  {
    if(sound_nan)
      set_top();
    else
    {
      bool from_plus_zero = !l.get_sign();
      bool i_from_plus_zero = !i.l.get_sign();
      bool to_minus_zero = u.get_sign();
      bool i_to_minus_zero = i.u.get_sign();

      if(from_plus_zero && i_from_plus_zero)
      {
        l.make_zero();
        l.set_sign(false);
        u.make_plus_infinity();
      } 
      else if(to_minus_zero && i_to_minus_zero)
      {
        l.make_minus_infinity();
        u.make_zero();
        u.set_sign(true);
      } 
      else 
      {
        set_non_nan();
      }
    }

    normalize();
    return *this;
  }

  assert(l.rounding_mode == i.l.rounding_mode &&
         u.rounding_mode == i.u.rounding_mode);

  ieee_floatt _l;
  ieee_floatt _u;

  if(l.rounding_mode != u.rounding_mode)
  {
    ieee_floatt ll_rp = l; ll_rp.rounding_mode = u.rounding_mode; ll_rp /= i.l;
    ieee_floatt ll_rm = l; ll_rm.rounding_mode = l.rounding_mode; ll_rm /= i.l;
    ieee_floatt lu_rp = l; lu_rp.rounding_mode = u.rounding_mode; lu_rp /= i.u;
    ieee_floatt lu_rm = l; lu_rm.rounding_mode = l.rounding_mode; lu_rm /= i.u;
    ieee_floatt ul_rp = u; ul_rp.rounding_mode = u.rounding_mode; ul_rp /= i.l;
    ieee_floatt ul_rm = u; ul_rm.rounding_mode = l.rounding_mode; ul_rm /= i.l;
    ieee_floatt uu_rp = u; uu_rp.rounding_mode = u.rounding_mode; uu_rp /= i.u;
    ieee_floatt uu_rm = u; uu_rm.rounding_mode = l.rounding_mode; uu_rm /= i.u;

    if(!sound_nan)
    {
      //(unsoundly) fix possible NaNs due to multiplications 
      //between zero and infinity
      if(ll_rp.is_NaN() || ll_rm.is_NaN())
      { 
        ll_rp.make_plus_infinity(); 
        ll_rp.set_sign(l.get_sign() != i.l.get_sign()); 
        ll_rm.make_plus_infinity(); 
        ll_rm.set_sign(l.get_sign() != i.l.get_sign()); 
      }
      if(lu_rp.is_NaN() || lu_rm.is_NaN())
      { 
        lu_rp.make_plus_infinity(); 
        lu_rp.set_sign(l.get_sign() != i.u.get_sign()); 
        lu_rm.make_plus_infinity(); 
        lu_rm.set_sign(l.get_sign() != i.u.get_sign()); 
      }
      if(ul_rp.is_NaN() || ul_rm.is_NaN())
      { 
        ul_rp.make_plus_infinity(); 
        ul_rp.set_sign(u.get_sign() != i.l.get_sign()); 
        ul_rm.make_plus_infinity(); 
        ul_rm.set_sign(u.get_sign() != i.l.get_sign()); 
      }
      if(uu_rp.is_NaN() || uu_rm.is_NaN())
      { 
        uu_rp.make_plus_infinity(); 
        uu_rp.set_sign(u.get_sign() != i.u.get_sign()); 
        uu_rm.make_plus_infinity(); 
        uu_rm.set_sign(u.get_sign() != i.u.get_sign()); 
      }
    }

    _l =
      std::min(std::min(std::min(ll_rp, ll_rm), std::min(ul_rp, ul_rm)),
          std::min(std::min(lu_rp, lu_rm), std::min(uu_rp, uu_rm)));

    _u =
      std::max(std::max(std::max(ll_rp, ll_rm), std::max(ul_rp, ul_rm)),
          std::max(std::max(lu_rp, lu_rm), std::max(uu_rp, uu_rm)));
  } else {
    ieee_floatt ll = l; ll.rounding_mode = u.rounding_mode; ll /= i.l;
    ieee_floatt lu = l; lu.rounding_mode = u.rounding_mode; lu /= i.u;
    ieee_floatt ul = u; ul.rounding_mode = u.rounding_mode; ul /= i.l;
    ieee_floatt uu = u; uu.rounding_mode = u.rounding_mode; uu /= i.u;

    if(!sound_nan)
    {
      //unsoundly fix nan mult result
      if(ll.is_NaN())
      {
        ll.make_plus_infinity(); ll.set_sign(l.get_sign() != i.l.get_sign()); 
      }
      if(lu.is_NaN())
      {
        lu.make_plus_infinity(); lu.set_sign(l.get_sign() != i.u.get_sign()); 
      }
      if(ul.is_NaN())
      {
        ul.make_plus_infinity(); ul.set_sign(u.get_sign() != i.l.get_sign()); 
      }
      if(uu.is_NaN())
      {
        uu.make_plus_infinity(); uu.set_sign(u.get_sign() != i.u.get_sign()); 
      }
    }

    _l = std::min(std::min(ll, lu), std::min(ul,uu));
    _u = std::max(std::max(ll, lu), std::max(ul,uu));
  }

  //handle zeros
  if(i_contains_zero)
  {
    //both -0 and 0 are contained, then the result is between -INF and INF
    if(!i.lower().is_zero() && !i.upper().is_zero())
    { 
      _l.make_minus_infinity();
      _u.make_plus_infinity();
    } 
    else if(i.lower().is_zero() && !i.upper().is_zero())
    {
      if(i.lower().get_sign())
      {
        //[-0, c]
        _l.make_minus_infinity();
        _u.make_plus_infinity();
      } 
      else 
      {
        //[0, c]
        ieee_floatt lz, uz;
        lz = l;
        lz /= i.lower(); 
        uz = u;
        uz /= i.lower();
        _l = std::min(std::min(lz, uz), _l);
        _u = std::max(std::max(lz, uz), _u);
      }
    } 
    else if(!i.lower().is_zero() && i.upper().is_zero())
    {
      if(!i.upper().get_sign())
      {
        //[-c, 0]
        _l.make_minus_infinity();
        _u.make_plus_infinity();
      } 
      else 
      {
        //[-c, -0]
        ieee_floatt lz, uz;
        lz = l; lz /= i.upper(); 
        uz = u; uz /= i.upper();
        _l = std::min(std::min(lz, uz), _l);
        _u = std::max(std::max(lz, uz), _u);
      }
    } 
    else
    {
      assert(i.lower().is_zero() && i.upper().is_zero());
      assert(i.lower().get_sign() || !i.upper().get_sign());

      //should already be handled by previous code
      assert(_l.is_infinity() && _u.is_infinity());     
    }
  } 

  set(_l, _u);

  return *this;
}


float_intervalt& float_intervalt::operator*=(
    const float_intervalt& i)
{
  if(arith_handle_special(i))
    return *this;

  if(sound_nan)
  {
    bool this_has_infinite = l.is_infinity() || u.is_infinity();
    bool i_has_infinite = i.l.is_infinity() || i.u.is_infinity();

    bool this_has_zero = contains(zero());
    bool i_has_zero = i.contains(zero());

    if(((this_has_infinite && i_has_zero) || (this_has_zero && i_has_infinite)))
    {
      set_top();
      return *this;
    }
  }

  assert(i.l.rounding_mode == l.rounding_mode &&
         i.u.rounding_mode == u.rounding_mode);

  if(l.rounding_mode != u.rounding_mode)
  {
    ieee_floatt ll_rp = l; ll_rp.rounding_mode = u.rounding_mode; ll_rp *= i.l;
    ieee_floatt ll_rm = l; ll_rm.rounding_mode = l.rounding_mode; ll_rm *= i.l;
    ieee_floatt lu_rp = l; lu_rp.rounding_mode = u.rounding_mode; lu_rp *= i.u;
    ieee_floatt lu_rm = l; lu_rm.rounding_mode = l.rounding_mode; lu_rm *= i.u;
    ieee_floatt ul_rp = u; ul_rp.rounding_mode = u.rounding_mode; ul_rp *= i.l;
    ieee_floatt ul_rm = u; ul_rm.rounding_mode = l.rounding_mode; ul_rm *= i.l;
    ieee_floatt uu_rp = u; uu_rp.rounding_mode = u.rounding_mode; uu_rp *= i.u;
    ieee_floatt uu_rm = u; uu_rm.rounding_mode = l.rounding_mode; uu_rm *= i.u;

    if(!sound_nan)
    {
      //(unsoundly) fix possible NaNs due to multiplications 
      //between zero and infinity
      if(ll_rp.is_NaN() || ll_rm.is_NaN())
      { 
        ll_rp.make_zero(); ll_rp.set_sign(l.get_sign() != i.l.get_sign()); 
        ll_rm.make_zero(); ll_rm.set_sign(l.get_sign() != i.l.get_sign()); 
      }
      if(lu_rp.is_NaN() || lu_rm.is_NaN())
      { 
        lu_rp.make_zero(); lu_rp.set_sign(l.get_sign() != i.u.get_sign()); 
        lu_rm.make_zero(); lu_rm.set_sign(l.get_sign() != i.u.get_sign()); 
      }
      if(ul_rp.is_NaN() || ul_rm.is_NaN())
      { 
        ul_rp.make_zero(); ul_rp.set_sign(u.get_sign() != i.l.get_sign()); 
        ul_rm.make_zero(); ul_rm.set_sign(u.get_sign() != i.l.get_sign()); 
      }
      if(uu_rp.is_NaN() || uu_rm.is_NaN())
      { 
        uu_rp.make_zero(); uu_rp.set_sign(u.get_sign() != i.u.get_sign()); 
        uu_rm.make_zero(); uu_rm.set_sign(u.get_sign() != i.u.get_sign()); 
      }

    }

    l =
      std::min(std::min(std::min(ll_rp, ll_rm), std::min(ul_rp, ul_rm)),
          std::min(std::min(lu_rp, lu_rm), std::min(uu_rp, uu_rm)));

    u =
      std::max(std::max(std::max(ll_rp, ll_rm), std::max(ul_rp, ul_rm)),
          std::max(std::max(lu_rp, lu_rm), std::max(uu_rp, uu_rm)));
  } else {
    ieee_floatt ll = l; ll.rounding_mode = u.rounding_mode; ll *= i.l;
    ieee_floatt lu = l; lu.rounding_mode = u.rounding_mode; lu *= i.u;
    ieee_floatt ul = u; ul.rounding_mode = u.rounding_mode; ul *= i.l;
    ieee_floatt uu = u; uu.rounding_mode = u.rounding_mode; uu *= i.u;

    if(!sound_nan)
    {
      //unsoundly fix nan mult result
      if(ll.is_NaN())
      {
        ll.make_zero(); ll.set_sign(l.get_sign() != i.l.get_sign()); 
      }
      if(lu.is_NaN())
      {
        lu.make_zero(); lu.set_sign(l.get_sign() != i.u.get_sign()); 
      }
      if(ul.is_NaN())
      {
        ul.make_zero(); ul.set_sign(u.get_sign() != i.l.get_sign()); 
      }
      if(uu.is_NaN())
      {
        uu.make_zero(); uu.set_sign(u.get_sign() != i.u.get_sign()); 
      }

    }

    l = std::min(std::min(ll, lu), std::min(ul,uu));
    u = std::max(std::max(ll, lu), std::max(ul,uu));
  }

  normalize();
  return *this;
}

float_intervalt& float_intervalt::operator%=(
    const float_intervalt& i)
{
  throw "modulo not supported by float";
}

bool float_intervalt::
leq(const float_intervalt& t) const
{ 
  if(is_top())
    return t.is_top();
  if(is_bot())
    return true;
  if(t.is_bot())
    return is_bot();
  if(t.is_top())
    return true;

  return (u <= t.u && l >= t.l);
}


bool float_intervalt::
eq(const float_intervalt& t) const
{ 
  if(is_top() && t.is_top()) 
    return true;
  if(is_bot() && t.is_bot())
    return true;
  
  if(!is_top() && !is_bot() && 
     !t.is_top() && !t.is_bot())
    return (u == t.u && l == t.l);
  
  return false;
}


std::string float_intervalt::to_string() const 
{

  std::stringstream ss;
  if(is_top())
    ss << "top";
  else if(is_bot()) 
    ss << "bot";
  else
  {
    if(l.is_float())
      //in order to get scientific format
      ss << std::setprecision(std::numeric_limits<float>::digits10+5)
         << "[" << l.to_float() 
         /*<< "(" << 
            to_constant_expr(l.to_expr()).get_value()
         << ")" 
         */
         << ", " 
         << u.to_float() 
         /*<< "(" << 
            to_constant_expr(u.to_expr()).get_value()
         << ")" 
         */
         << "]";
    else if(l.is_double())
      //in order to get scientific format
      ss << std::setprecision(std::numeric_limits<double>::digits10+5)
         << "[" << l.to_double() << ", " << u.to_double() << "]";
    else 
      ss << "[" << l << ", " << u << "]";
  }

  return ss.str();
}


bool float_intervalt::arith_handle_special(
    const float_intervalt& i)
{
  if(is_bot())
    return true;

  if(i.is_bot())
  {
    *this = i;
    return true;
  }
  if(is_top())
    return true;

  if(i.is_top())
  {
    *this = i;
    return true;
  }
  
  return false;
}

