/*******************************************************************\

Module: Simple constant propagation domain, 
        very limited functionality. 
        
        Solves a specific problem in proof growing. 
        Not fit for public consumption in its current state.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef EXPR_PROP_DOMAIN_H
#define EXPR_PROP_DOMAIN_H

#include "const_prop_domain.h"

class expr_prop_domaint : public const_prop_domaint
{
public:
  typedef const_prop_domaint sub;

  expr_prop_domaint(const namespacet& _ns)
    : sub(_ns) { } 

  virtual void apply_assign_inplace(
      symbol_mapt& a, 
      const exprt& lhs, 
      const exprt& rhs);
  
protected:
  virtual bool accept_rhs(const exprt& e);

  bool contains_expr(const exprt& what, const exprt& where);

};

#endif
