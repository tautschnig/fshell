/*******************************************************************\

Module: Composite class of float/integer intervals
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ITV_H
#define ITV_H

#include "../abstr_domain.h"

#include "interval_element.h"
#include "float_interval_element.h"
#include <memory>

class itvt
{
protected:
  typedef std::auto_ptr<intbv_intervalt> iptrt;
  typedef std::auto_ptr<float_intervalt> fptrt;
  iptrt _i;
  fptrt _f;
public:
  typedef enum {INTBV, FLOAT, OTHER} itv_typet;

  itv_typet type;

  //true if type != intbv, float and bottom = true
  bool other_bottom;

  //create top element
  itvt(
    const typet& t, 
    ieee_floatt::rounding_modet r = float_intervalt::get_default_rounding());

  itvt(const float_intervalt& __f)
    : _f(new float_intervalt(__f)), type(itvt::FLOAT), other_bottom(false) { } 

  itvt(const intbv_intervalt& __i)
    : _i(new intbv_intervalt(__i)), 
      type(itvt::INTBV), other_bottom(false) { } 

  itvt()
    : type(itvt::OTHER), 
      other_bottom(false) { } 

  //copy constr
  itvt(const itvt& i);
  
  const itvt& operator=(const itvt&i);

  void set_bot();
  void set_top();

  bool is_bot() const;
  bool is_top() const;

  itvt& meet(const itvt& i);
  itvt& join(const itvt& i);

  bool leq(const itvt& i) const;
  bool eq(const itvt& i) const;

  bool is_singleton() const;
  exprt to_expr() const;

  bool contains_zero() const;
  bool is_zero() const;

  bool complement(const itvt& context);
  void halve_lower(bool median = true);
  void halve_upper(bool median = true);

  std::string to_string() const;
  
  bool contains_min() const;
  bool contains_max() const;

  bool disjunct(const itvt& itv) const;

  inline intbv_intervalt& i() { return *_i; }
  inline float_intervalt& f() { return *_f; }
  inline const intbv_intervalt& i() const { return *_i; }
  inline const float_intervalt& f() const { return *_f; }

};

#endif
