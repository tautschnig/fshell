/*******************************************************************\

Module: Actual implementation of apron abstract domain adaptor.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef APRON_DOMAIN_WRAP_H
#define APRON_DOMAIN_WRAP_H

#include "abstr_domain_mem.h"
#include "apron_domain.h"

#include "apron_interface/apron_domain_type.h"

#include <context.h>
#include <namespace.h>
#include <std_expr.h>

#include <apronxx.hh>
#include <apxx_box.hh>
#include <apxx_oct.hh>
#include <apxx_polka.hh>

#include <memory>

class apron_domain_wrapt : public abstr_domain_memt<apron::abstract1> 
{
public:
  apron_domain_wrapt(apron_domain_typet t, const var_listt& l, const contextt& c);
  virtual ~apron_domain_wrapt();

  /*************************** additional functions ***************************/

  //returns true if the symbol can be handled by the abstract domain
  static bool is_supported(const symbol_exprt& e);

  /***************************** domain functions *****************************/
  virtual abstr_elementt top();
  virtual abstr_elementt bot();

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  virtual void meet_inplace(
      apron::abstract1&, 
      const apron::abstract1& e);

  virtual void join_inplace(
      apron::abstract1&, 
      const apron::abstract1& e);

  virtual void widen_inplace(
      apron::abstract1&, 
      const apron::abstract1& e, 
      const apron::abstract1& threshold);

  virtual void apply_assign_inplace(
      apron::abstract1& a, 
      const exprt& lhs, 
      const exprt& rhs);

  virtual void apply_test_inplace(
      apron::abstract1& a, 
      const exprt& e);

  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a) ;

  virtual abstr_elementt get_initial() { return top(); }

  //this class is friends with its wrapping class apron_domaint, so that
  //calls to protected methods can be properly forwarded
  friend class apron_domaint;

protected:
  std::auto_ptr<apron::manager> apron_man;
  apron::environment env;

  const contextt& context;
  const namespacet ns;

  apron::environment build_environment(const var_listt& l);
  typedef std::set<std::string> var_namest;

  //grep out variables in expression and separate their identifiers into
  //float_vars and int_vars
  void get_var_names(const exprt& e, 
                     var_namest& float_vars, 
                     var_namest& int_vars);
  
  std::string get_var_name(const exprt& e);
  
  //modify a by adding boolean constraint e
  virtual void fwd_interpret_bool(const exprt& e, 
                                  apron::abstract1& a);
  
  inline bool is_inequality(const exprt& e);
};


#endif

