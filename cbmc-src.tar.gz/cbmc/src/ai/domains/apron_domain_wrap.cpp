/*******************************************************************\

Module: Actual implementation of apron abstract domain adaptor.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "apron_domain_wrap.h"
#include "apron_interface/expr2apron_conv.h"
#include "apron_interface/apron2expr_conv.h"
#include <std_expr.h>
#include <ansi-c/expr2c.h>

#include <sstream>

apron_domain_wrapt::
apron_domain_wrapt(apron_domain_typet t, const var_listt& l, const contextt& c) 
  : apron_man(NULL), context(c), ns(c)
{
  switch(t)
  {
    case BOX:
      apron_man = std::auto_ptr<apron::manager>(new apron::box_manager);
    case OCT:
      apron_man = std::auto_ptr<apron::manager>(new apron::oct_manager);
      break;
    case POLKA:
      apron_man = std::auto_ptr<apron::manager>(new apron::polka_manager(false));
      break;
    case POLKA_STRICT:
      apron_man = std::auto_ptr<apron::manager>(new apron::polka_manager(true));
      break;
    case PPL: 
    case PPL_STRICT:
      throw "PPL not supported yet";
      break;
  }

  env = build_environment(l);
}

apron_domain_wrapt::
~apron_domain_wrapt()
{
}


bool apron_domain_wrapt::is_supported(const symbol_exprt& e)
{
  return expr2apron_convt::has_supported_type(e);
}


//get variable names occurring in expressions and classify them as 
//int or float variables
void apron_domain_wrapt::get_var_names(const exprt& e, 
                                       var_namest& float_names,
                                       var_namest& int_names)
{
  if(e.id() == "symbol")
  {
    if(!is_supported(to_symbol_expr(e)))
      throw "Type of variable not supported by apron: \n" +
             e.pretty();
    //determine whether float or int and add to list
    symbol_exprt s = to_symbol_expr(e);
    
    std::string ident = s.get_identifier().as_string();

    if(e.type().id() == "floatbv") 
    {
      float_names.insert(ident);
    } else if(e.type().id() == "signedbv")
    {
      int_names.insert(ident);
    } else
      assert(0);

  } else
    throw "Non-symbol expression found in variable list";
}

//build an environment from a list of variables
apron::environment apron_domain_wrapt::
build_environment(const var_listt& l)
{ 
  using apron::var;

  var_namest float_names, int_names;
  for(var_listt::const_iterator it = l.begin(); it != l.end(); it++) 
    get_var_names(*it, float_names, int_names);

  //copy variables to list
  std::vector<var> float_vars, int_vars;

  for(var_namest::const_iterator it = float_names.begin(); 
      it != float_names.end(); it++)
    float_vars.push_back(var(*it));

  for(var_namest::const_iterator it = int_names.begin(); 
      it != int_names.end(); it++)
    int_vars.push_back(var(*it));

  //initialize environment with variables
  return apron::environment(int_vars, float_vars);
}

bool apron_domain_wrapt::
leq(const abstr_elementt& a1, const abstr_elementt& a2) 
{
  const apron::abstract1 &e1 = read(a1);
  const apron::abstract1 &e2 = read(a2);
  return e1 <= e2;
}

abstr_elementt apron_domain_wrapt::top()
{ 
  return new_elem(new apron::abstract1(*apron_man, env, apron::top()));
}

abstr_elementt apron_domain_wrapt::bot()
{ 
  return new_elem(new apron::abstract1(*apron_man, env, apron::bottom()));
}

bool apron_domain_wrapt::is_top(const abstr_elementt& e) 
{ 
  return read(e).is_top(*apron_man);
}

bool 
apron_domain_wrapt::is_bot(const abstr_elementt& e) 
{ 
  return read(e).is_bottom(*apron_man);
}

void
apron_domain_wrapt::meet_inplace(
    apron::abstract1& a1, 
    const apron::abstract1& a2)
{ 
  a1.meet(*apron_man, a2);
}

void
apron_domain_wrapt::join_inplace(
    apron::abstract1& a1, 
    const apron::abstract1& a2)
{ 
  a1.join(*apron_man, a2);
}

void
apron_domain_wrapt::widen_inplace(
    apron::abstract1& a1, 
    const apron::abstract1& a2, 
    const apron::abstract1& threshold)
{ 
  apron::widening(*apron_man, a1, a2, threshold);
}


std::string
apron_domain_wrapt::get_var_name(const exprt& var) 
{
  return to_symbol_expr(var).get_identifier().as_string();
}

void
apron_domain_wrapt::apply_assign_inplace(
    apron::abstract1& a, 
    const exprt& lhs, 
    const exprt& rhs) 
{
  if(lhs.id() == ID_index)
  {
    //TODO arrays not supported yet
  } else if(lhs.id() == ID_member)
  {
    //TODO members not implemented yet
  } else if(lhs.id() == ID_symbol)
  {
    std::string ident = get_var_name(lhs);
    apron::var variable(ident);
    if(!env.contains(variable))
      return;

    a.assign(*apron_man, variable, expr2apron_arith(env, rhs));
  } else
  {
    throw "Unsupported lhs expression in assignment: " + lhs.pretty();
  }
}

void
apron_domain_wrapt::apply_test_inplace(apron::abstract1& a, const exprt& e)
{
  fwd_interpret_bool(e, a);
}

std::string apron_domain_wrapt::to_string(const abstr_elementt& a) 
{ 
  return expr2c(to_expr(a),ns);
}

exprt apron_domain_wrapt::to_expr(const abstr_elementt& a) 
{ 
  exprt result = apron2expr(read(a), context, *apron_man);
  return result;
}



bool apron_domain_wrapt::is_inequality(const exprt& e)
{
  const irep_idt& id = e.id();
  return 
    (id == ID_equal || id == ID_ieee_float_equal ||
     id == ID_notequal || id == ID_ieee_float_notequal ||
     id == ID_lt || id == ID_gt || id == ID_le || id == ID_ge);

}

void apron_domain_wrapt::fwd_interpret_bool(const exprt& e, 
                                            apron::abstract1& r)
                                       
{
  assert(e.type().id() == ID_bool);
  const irep_idt& id = e.id();

  if(is_inequality(e) || (id == ID_not && is_inequality(e.op0())) ||
      e.is_constant() || (id == ID_not && e.op0().is_constant())  ||
      id == ID_typecast || (id == ID_not && e.op0().id() == ID_typecast))
  {
    //these cases can be handled by the apron translation
    //TODO: consider caching
    apron::tcons1 arr[1] = { expr2apron_ineq(env, e) };
    apron::tcons1_array arr_cl(1, arr);
    r.meet(*apron_man, arr_cl);
  } else if(id == ID_and)
  {
    assert(e.operands().size() == 2);
    apron::abstract1 r2 = r;
    fwd_interpret_bool(e.op0(), r);
    fwd_interpret_bool(e.op1(), r2);
    r.meet(*apron_man, r2);
  } else if(id == ID_or)
  {
    assert(e.operands().size() == 2);
    apron::abstract1 r2 = r;
    fwd_interpret_bool(e.op0(), r);
    fwd_interpret_bool(e.op1(), r2);
    r.join(*apron_man, r2);
  } else if(id == ID_not && e.op0().id() == ID_and)
  {
    exprt demorgan = e.op0();
    demorgan.id(ID_or);
    Forall_operands(it, demorgan)
      it->make_not();
    fwd_interpret_bool(demorgan, r);
  } else if(id == ID_not && e.op0().id() == ID_or)
  {
    exprt demorgan = e.op0();
    demorgan.id(ID_and);
    Forall_operands(it, demorgan)
      it->make_not();
    fwd_interpret_bool(demorgan, r);
  } else if(id == ID_not && e.op0().id() == ID_if) {
    exprt cp = e.op0();
    cp.op1().make_not();
    cp.op2().make_not(); 
    fwd_interpret_bool(cp, r);
  } else if(id == ID_if) {
    //boolean ite
    exprt case1(ID_and, typet(ID_bool));
    case1.copy_to_operands(e.op0());
    case1.copy_to_operands(e.op1());

    exprt case2(ID_and, typet(ID_bool));
    case2.copy_to_operands(e.op0());
    case2.copy_to_operands(e.op2());
    case2.op0().make_not();

    exprt transl_ite(ID_or, typet(ID_bool));
    transl_ite.move_to_operands(case1);
    transl_ite.move_to_operands(case2);
    
    fwd_interpret_bool(transl_ite, r);
  } else
    throw "Unimplemented Boolean expression: \n" + e.pretty(); 

}


