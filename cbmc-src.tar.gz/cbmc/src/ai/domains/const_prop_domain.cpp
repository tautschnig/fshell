/*******************************************************************\

Module: Simple constant propagation domain

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "const_prop_domain.h"

#include <simplify_expr.h>
#include <replace_expr.h>

#include <sstream>

abstr_elementt const_prop_domaint::top()
{
  return new_elem(new symbol_mapt());
}

abstr_elementt const_prop_domaint::bot()
{
  return new_elem(new symbol_mapt(false));
}

bool const_prop_domaint::is_top(const abstr_elementt& e)
{
  return read(e).is_top();
}

bool const_prop_domaint::is_bot(const abstr_elementt& e)
{
  return read(e).is_bot();
}

bool const_prop_domaint::leq(
    const abstr_elementt& a1, 
    const abstr_elementt& a2)
{
  const symbol_mapt& m1 = read(a1);
  const symbol_mapt& m2 = read(a2);

  if(m1.is_bot())
    return true;
  if(m2.is_bot())
    return false;
  
  for(symbol_mapt::const_iterator it2 = m2.begin(); it2 != m2.end(); it2++)
  {
    symbol_mapt::const_iterator find_iter = m1.find(it2->first);

    if(find_iter == m1.end())
    {
      return false;
    } else {
      //check for inconsistent constant
      if(it2->second != find_iter->second)
        return false;
    }

  }

  return true;
}

std::string const_prop_domaint::to_string(const abstr_elementt& a)
{
  if(a.is_top())
    return "top";
  if(a.is_bot())
    return "bot";

  const symbol_mapt& m = read(a);

  std::stringstream ss;
  ss << "{ ";

  for(symbol_mapt::const_iterator it = m.begin(); it != m.end(); )
  {
    ss << to_symbol_expr(it->first).get_identifier() << " = " 
              << it->second.to_string();

    if(++it != m.end())
      ss << ", " << std::endl;
  }

  ss << " }";

  return ss.str();
}

exprt const_prop_domaint::to_expr(const abstr_elementt& a)
{
  const symbol_mapt& m = read(a);

  if(m.is_bot())
    return false_exprt();
  
  exprt and_expr(ID_and, typet(ID_bool));

  for(symbol_mapt::const_iterator it = m.begin(); it != m.end(); it++)
  {
    exprt eq(ID_equal, typet(ID_bool));
    eq.copy_to_operands(it->first); 
    eq.copy_to_operands(it->second);

    and_expr.move_to_operands(eq);
  }

  if(and_expr.operands().size() == 0)
    and_expr.make_true();
  else if(and_expr.operands().size() == 1)
  {
    exprt tmp = and_expr.op0();
    and_expr.swap(tmp);
  }

  return and_expr;
}


void const_prop_domaint::join_inplace(symbol_mapt& m1, const symbol_mapt& m2)
{
  if(m1.is_bot())
  {
    m1 = m2;
    return;
  }
  if(m2.is_bot())
  {
    return;
  }

  symbol_mapt result;

  for(symbol_mapt::const_iterator it1 = m1.begin(); it1 != m1.end(); it1++)
  {
    symbol_mapt::const_iterator find_iter = m2.find(it1->first);

    if(find_iter != m2.end())
    {
      //only include consistent information
      if(it1->second == find_iter->second)
        result[find_iter->first] = find_iter->second;
    }

  }
  
  m1.swap(result);
}

void const_prop_domaint::meet_inplace(symbol_mapt& m1, const symbol_mapt& m2)
{
  if(m1.is_bot())
    return;
  if(m2.is_bot())
  {
    m1.set_bot();
    return;
  }
    
  symbol_mapt result;

  for(symbol_mapt::const_iterator it1 = m1.begin(); it1 != m1.end(); it1++)
  {
    symbol_mapt::const_iterator find_iter = m2.find(it1->first);

    if(find_iter == m2.end())
      result[find_iter->first] = find_iter->second;
    else if(find_iter->second != it1->second)
    {
      result.set_bot();
      break;
    }
  }
  
  m1.swap(result);
}


void const_prop_domaint::widen_inplace(
    symbol_mapt& m1, 
    const symbol_mapt& m2, 
    const symbol_mapt& threshold)
{
  join_inplace(m1, m2);
}

void const_prop_domaint::apply_assign_inplace(
    symbol_mapt& a, 
    const exprt& _lhs, 
    const exprt& _rhs)
{
  if(a.is_bot())
    return;
    
  exprt lhs = _lhs;
  exprt rhs = _rhs;
  
  //get rid of index expressions 
  to_symbol_assignment(lhs, rhs);

  if(lhs.id() == ID_symbol)
  {
    fwd_interpret(a, rhs);

    if(accept_rhs(rhs))
    {
      a[to_symbol_expr(lhs)] = rhs;
    } 
    else 
    {
      //havoc symbol information
      a.erase(to_symbol_expr(lhs));
    }
  } 
  else if(lhs.id() == ID_dereference)
  {
    //havoc everything, evil pointers
    a.clear();
    return;
  } 
}


void const_prop_domaint::fwd_interpret(
    const symbol_mapt& context,
    exprt& e)
{
  replace_expr(context, e);
  simplify(e, ns);
}

//return result of applying test for c expression
void const_prop_domaint::apply_test_inplace(
    symbol_mapt& a, 
    const exprt& e, 
    bool result)
{
  //check for infeasibilty
  exprt fwd_value = e;
  fwd_interpret(a, fwd_value);
  
  if((fwd_value.is_true() && !result) || (fwd_value.is_false() && result))
    a.set_bot();
}

bool const_prop_domaint::accept_rhs(
    const exprt& e)
{
  return is_constant(e);
}

bool const_prop_domaint::is_constant(
    const exprt& e)
{
  if(e.id() == ID_constant)
    return true;

  if(e.id() == ID_symbol)
    return false;
  
  if(e.operands().size() == 0)
    return false; //we don't trust these things to be constant

  //the following assumes that the current operator is a function
  //of its operands.
  forall_operands(it, e)  
    if(!is_constant(*it))
      return false;

  return true;
}

void const_prop_domaint::to_symbol_assignment(exprt& lhs, exprt& rhs)
{
  if(lhs.id() == ID_member)
  {
    member_exprt& m = 
      to_member_expr(lhs);
    
    const exprt& component_name = m.find_expr(ID_component_name);
    assert(component_name.is_not_nil());
    
    with_exprt w(m.struct_op(), exprt(ID_member_name), rhs);
    w.where().set(ID_component_name, component_name);
    
    exprt struct_op = m.struct_op();
    lhs.swap(struct_op);
    rhs.swap(w);
    
    to_symbol_assignment(lhs, rhs);
  }
  else if(lhs.id() == ID_index)
  {
    index_exprt& i = 
      to_index_expr(lhs);
    
    with_exprt w(i.array(), i.index(), rhs);
    
    exprt arr = i.array();
    lhs.swap(arr);
    rhs.swap(w);
    to_symbol_assignment(lhs, rhs);
  } 
}
