#include "disequality_domain.h"

#include <negate_expr.h>

#include <ansi-c/expr2c.h>
#include <std_types.h>


abstr_elementt
disequality_domaint::top()
{
  return new_elem(new disequality_elementt(numbering));
}

abstr_elementt
disequality_domaint::bot()
{
  return new_elem(new disequality_elementt(numbering, true));
}

bool 
disequality_domaint::leq(const abstr_elementt& a1, const abstr_elementt& a2) 
{
  return read_unsafe(a1).leq(read_unsafe(a2));
}


bool 
disequality_domaint::is_top(const abstr_elementt& e)
{
  return read(e).is_top();
}

bool 
disequality_domaint::is_bot(const abstr_elementt& e)
{
  return read(e).conflicting();
}

std::string 
disequality_domaint::to_string(const abstr_elementt& a)
{
  contextt context;
  namespacet ns(context);
  return expr2c(to_expr(a), ns);
}

exprt 
disequality_domaint::to_expr(const abstr_elementt& a)
{
  disequality_elementt d = read(a);
  exprt e = d.to_expr();

  return e;
}

void
disequality_domaint::meet_inplace(
    disequality_elementt& a, 
    const disequality_elementt& e)
{
  a.add_constraints(e);
}

void
disequality_domaint::join_inplace(
    disequality_elementt& a, 
    const disequality_elementt& e)
{
  a.intersect_constraints(e);
}

void 
disequality_domaint::widen_inplace(
    disequality_elementt& a, 
    const disequality_elementt& e, 
    const disequality_elementt& threshold)
{
  join_inplace(a,e);
  return;
}

void
disequality_domaint::apply_assign_inplace(
    disequality_elementt& a, 
    const exprt& lhs, 
    const exprt& rhs)
{
  if(lhs.id() == ID_symbol)
  {
    const symbol_exprt& lhs_expr = to_symbol_expr(lhs);

    //remove old info first
    abstr_valt v = fwd_interpret(rhs);

    if(!v.top)
    {
      //check if v.sym can be replaced by another representative
      if(v.sym == lhs_expr)
        a.get_other_equal(v.sym, v.sym);

      a.remove(lhs_expr);

      if(v.sym != lhs_expr)
      {
        if(v.equal)
          a.set_expr_equal(lhs_expr, v.sym);
        else 
          a.set_expr_notequal(lhs_expr, v.sym);
      }

    } else {

      a.remove(lhs_expr);
    }

  } 
  //std::cout << "applied assign, result = " << std::endl << a.to_expr().pretty() << std::endl;
}

void
disequality_domaint::apply_test_inplace(
    disequality_elementt& a, 
    const exprt& e, bool result)
{
  //TODO: naive implementation, can be made much more exact / general
  /*if(e.operands().size() != 2 || 
     e.op0().id() != ID_symbol || e.op1().id() != ID_symbol)
    return;*/
  
  if(e.id() == ID_equal)
  {
    if(result)
      a.set_expr_equal(e.op0(), e.op1());
    else 
      a.set_expr_notequal(e.op0(), e.op1());
  } 
  else if(e.id() == ID_ieee_float_equal)
  {
    if(result)
      a.set_expr_equal(e.op0(), e.op1());
    else {
      //do nothing preserve soundness for fp
    }
  } else if(e.id() == ID_notequal)
  {
    if(!result)
      a.set_expr_equal(e.op0(), e.op1());
    else 
      a.set_expr_notequal(e.op0(), e.op1());
  }
  else if(e.id() == ID_ieee_float_notequal)
  {
    if(!result)
      a.set_expr_equal(e.op0(), e.op1());
    else {
      //do nothing, preserve soundness for fp
    }
  }
  else if(e.id() == ID_lt || e.id() == ID_gt) 
  {
    if(result)
      a.set_expr_notequal(e.op0(), e.op1());
  } else if(e.id() == ID_le || e.id() == ID_ge)
  {
    if(!result)
      a.set_expr_notequal(e.op0(), e.op1());
  }
  else if(e.id() == ID_not)
  {
    return apply_test_inplace(a, e.op0(), !result);
  }
}

disequality_domaint::abstr_valt 
disequality_domaint::fwd_interpret(const exprt& e)
{
  const irep_idt& id = e.id();
  //TODO: merge this with disequality_elementt::set_expr

  if(id == ID_symbol)
  {
    return abstr_valt(to_symbol_expr(e), true);
  } else if(id == ID_plus || id == ID_minus) {
    assert(e.operands().size() == 2);
    abstr_valt op0val = fwd_interpret(e.op0());
    abstr_valt op1val = fwd_interpret(e.op1());

    if(e.op0().is_constant()) //value + nonzero constant of same type != value
    {
      if(e.op0().is_zero())
        return op1val;
      else if(!op1val.top && op1val.equal && e.type().id() != ID_floatbv) 
      { //does not work for floats since (f + 0.00000001) == f is possible
        op1val.equal = false;
        return op1val;
      }
      else return abstr_valt();
    } 
    else if(e.op1().is_constant())
    {
      if(e.op1().is_zero())
        return op0val;
      else if(!op0val.top && op0val.equal && e.type().id() != ID_floatbv) 
      {
        op0val.equal = false;
        return op0val;
      }
      else return abstr_valt();

    } 
  } else if(id == ID_bitxor)
  {
    //bitxor with any nonzero constant changes the value
    assert(e.operands().size() == 2);
    abstr_valt op0val = fwd_interpret(e.op0());
    abstr_valt op1val = fwd_interpret(e.op1());

    //op0 = constant 
    if(e.op0().is_constant())
    {
      if(e.op0().is_zero()) //xor with zero does not change anything
      {
        return op1val;
      } else if(!op1val.top && op1val.equal)
      {
        op1val.equal = false;
        return op1val;
      }
    } 

    //op1 = constant 
    if(e.op1().is_constant())
    {
      if(e.op1().is_zero()) //xor with zero does not change anything
      {
        return op0val;
      } else if(!op0val.top && op0val.equal)
      {
        op0val.equal = false;
        return op0val;
      }
    } 
    
  } else if(e.id() == ID_typecast) {
    if(e.type().id() == ID_pointer && e.op0().type().id() == ID_pointer)
      return fwd_interpret(e.op0());
  } 
  /*else if(e.id() == ID_address_of)
  {
    if(e.op0().id() == ID_index)
    {
      const index_exprt& index = to_index_expr(e.op0());
      exprt index_it = index;

      while(index_it.id() == ID_index)
      {
        if(!to_index_expr(index_it).index().is_zero())
          return abstr_valt();
        
        index_it.swap(to_index_expr(index_it).array());
      }

      return fwd_interpret(index_it);
    }
  }*/ //we shouldn't need this

  return abstr_valt();
}
