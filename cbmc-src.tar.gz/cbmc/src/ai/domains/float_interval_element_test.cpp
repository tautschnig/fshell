/*******************************************************************\

Module: Unit tester for float interval element

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "float_interval_element.h"
#include <std_types.h>
#include <cstdlib>
#include <cmath>

#define PINF (1.0f/0.0f)
#define NINF (-1.0f/0.0f)

typedef float_intervalt fi_elemt;

typet get_float_type()
{
  floatbv_typet ft;
  ft.set_width(32);
  ft.set_f(23);

  return ft;
}

ieee_floatt get_ieee(float f)
{
  ieee_floatt r;
  r.from_float(f);
  return r;
}

float random_float()
{
  union
  {
    float f;
    unsigned i;
  } u;

  unsigned r = ((unsigned) random()) % 15;

  switch(r)
  {
    case 0:
      return PINF;
      break;
    case 1:
      return NINF;
      break;
    case 2:
      return PINF+NINF;
      break;
    default: 
      u.i=std::rand();
      u.i=(u.i<<16)^std::rand();
      return u.f;
  }
}

void check_arithmetic(bool silent)
{
  std::string op;

  float a = random_float();
  float b = random_float();

  float am,ap,bm,bp;
  do {
    am = std::abs(random_float());
  } while(isnan(am));
  do {
    ap = std::abs(random_float());
  } while(isnan(am));
  do {
    bm = std::abs(random_float());
  } while(isnan(am));
  do {
    bp = std::abs(random_float());
  } while(isnan(am));

  float al, au, bl, bu;
  //get interval bounds
  al = a - am;
  au = a + ap;
    
  //get interval bounds
  bl = b - bm;
  bu = b + bp;

  ieee_floatt i_al, i_au;
  i_al.from_float(al);
  i_au.from_float(au);

  ieee_floatt i_bl, i_bu;
  i_bl.from_float(bl);
  i_bu.from_float(bu);

  float_intervalt a_elem(get_float_type()), b_elem(get_float_type());
  a_elem.set(i_al, i_au);
  b_elem.set(i_bl, i_bu);

  float_intervalt result_elem = a_elem;

  float result = a;
 
  switch(std::rand()%4) 
  {
    case 0: op = "+";
      result_elem += b_elem;
      result += b;
      break;
    case 1: op = "-";
      result_elem -= b_elem;
      result -= b;
      break;
    case 2: op = "*";
      result_elem *= b_elem;
      result *= b;
      break;
    case 3: op = "/";
      result_elem /= b_elem;
      result /= b;
      break;
    default:
      assert(0);
  }

  ieee_floatt check_result;
  check_result.from_float(result);

  if(!result_elem.contains(check_result))
  {
    std::cout << a_elem << " " << op << " " << b_elem 
              << " gives " << result_elem << std::endl 
              << "but " << a << " " << op << " " << b << " = " 
              << result << " (= " <<check_result << ")"<< std::endl << std::endl;
    exit(1);
  }

  if(!silent)
  {
    std::cout << a_elem << " " << op << " " << b_elem 
      << " gives " << result_elem << std::endl 
      << " and " << a << " " << op << " " << b << " = " 
      << result << " (= " <<check_result << ")"<< std::endl << std::endl;
  }
}

int main(int argc, char* argv[])
{
  ieee_floatt test;
  test.from_float(PINF + NINF);//nan
  
  float_intervalt elem(get_float_type());
  elem.set(test, test);
  assert(elem.is_top());

  std::cout << "top test: " << elem << std::endl;

  std::srand(time(NULL));

  std::cout << "== Non-silent tests: " << std::endl; 
  for(unsigned i = 0; i < 100; i++)
  {
    check_arithmetic(false);
  }

  for(unsigned i = 0; i < 100000; i++)
  {
    if(i % 10000 == 0)
      std::cout << "== checked " << i << std::endl; 
    check_arithmetic(true);
  }

  return 0;
}
