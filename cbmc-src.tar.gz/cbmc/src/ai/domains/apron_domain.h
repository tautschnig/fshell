/*******************************************************************\

Module: Wrapper class for apron abstract domain library, to avoid 
        include references to apron library files. This class just
        hands over all methods to the actual apron abstract domain
        referenced by the apron_domain_wrapped pointer.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef APRON_DOMAIN_H
#define APRON_DOMAIN_H

#include "../abstr_domain.h"

#include "../apron_interface/apron_domain_type.h"
#include <context.h>
#include <std_expr.h>

#include <set>

typedef std::vector<symbol_exprt> var_listt;

class apron_domaint : public abstr_domaint
{
public:
  apron_domaint(apron_domain_typet t, const var_listt&, const contextt&);

  /*************************** additional functions ***************************/

  //returns true if the symbol can be handled by the abstract domain
  static bool is_supported(const symbol_exprt& e);

  /***************************** domain functions *****************************/
  //return top / bottom element
  virtual abstr_elementt top();
  virtual abstr_elementt bot();

  virtual abstr_elementt& meet(abstr_elementt&, const abstr_elementt& e);

  virtual abstr_elementt& join(abstr_elementt&, const abstr_elementt& e);

  virtual abstr_elementt& widen(
      abstr_elementt&, 
      const abstr_elementt& e, 
      const abstr_elementt& threshold);

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  //return result of applying a transfer function for a c command
  virtual abstr_elementt& apply_assign(abstr_elementt& a, 
                                      const exprt& lhs, 
                                      const exprt& rhs);

  //return result of applying test for c expression
  virtual abstr_elementt& apply_test(abstr_elementt& a, const exprt& e);

  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a);

  //get initial element, before program starts
  virtual abstr_elementt get_initial();

  //virtual destructor
  virtual ~apron_domaint();

protected:
  virtual void register_abstr_elem(abstr_elementt& e);
  virtual void deregister_abstr_elem(abstr_elementt& e);

  void* apron_domain_wrap;
};
#endif
