/*******************************************************************\

Module: Abstract element implementation for interval domain

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "interval_element.h"

#include <type2bounds.h>
#include <arith_tools.h>

intbv_intervalt::intbv_intervalt()
  : top(true)
{
}

intbv_intervalt::intbv_intervalt(const typet& t)
  : top(true)
{
  set_bv_bounds(t);
}


intbv_intervalt::intbv_intervalt(const typet& t, int lower, int upper)
  : top(true)
{
  set_bv_bounds(t);
  set(mp_integer(lower), mp_integer(upper));
}

exprt intbv_intervalt::to_expr() const
{
  if(is_singleton())
  {
    exprt l_expr = from_integer(lower(), type);
    return l_expr;
  } else {
    typet t("interval");
    t.subtype() = type;

    constant_exprt constant(t);

    exprt l_expr = from_integer(lower(), type);
    exprt u_expr = from_integer(upper(), type);
    constant.move_to_operands(l_expr);
    constant.move_to_operands(u_expr);

    return constant;
  }
 
}

std::string intbv_intervalt::to_string() const 
{
  std::stringstream ss;
  if(is_top())
    ss << "top";
  else if(is_bot()) 
    ss << "bot";
  else
    ss << "[" << l << ", " << u << "]";

  return ss.str();
}

void intbv_intervalt::square()
{
  if(is_top()) return;
  if(is_bot()) return;

  mp_integer l_square = l*l;
  mp_integer u_square = u*u;

  if(l < zero() && u > zero())
  {
    //interval starts at zero
    set(zero(), std::max(l_square, u_square));
  }
  else 
  {
    //interval starts at lower square
    if(l_square < u_square)
      set(l_square, u_square);
    else 
      set(u_square, l_square);
  }

  normalize();
}

void intbv_intervalt::set_bv_bounds(const typet& t)
{
  if(t.id() != ID_signedbv && t.id() != ID_unsignedbv)
    throw "unsupported type in intbv_intervalt: " + t.id_string();

  min = min_representable(t);
  max = max_representable(t);

  type = t;
  
  normalize();
}


void intbv_intervalt::set(const mp_integer& _l, const mp_integer& _u)
{
  if(_l == min && _u == max) 
    set_top(); 
  else
  { top = false; l = _l; u = _u; normalize(); }
}


void intbv_intervalt::normalize()
{
  if(is_bot()) 
    set_bot(); 
  else if(is_top()) 
    set_top(); 

  if(lower() < min || upper() > max) 
    handle_overflow();
  else if(lower() == min && upper() == max) 
    set_top(); 
}

bool intbv_intervalt::leq(const intbv_intervalt& t) const
{
  if(is_top())
    return t.is_top();
  if(is_bot())
    return true;
  if(t.is_bot())
    return is_bot();
  if(t.is_top())
    return true;

  return (u <= t.u && l >= t.l);
}

bool intbv_intervalt::eq(const intbv_intervalt& t) const
{
  if(is_top() && t.is_top()) 
    return true;
  if(is_bot() && t.is_bot())
    return true;
  
  if(!is_top() && !is_bot() && 
     !t.is_top() && !t.is_bot())
    return (u == t.u && l == t.l);
  
  return false;
}

bool intbv_intervalt::arith_handle_special(
    const intbv_intervalt& i)
{
  if(is_bot())
    return true;

  if(i.is_bot())
  {
    *this = i;
    return true;
  }
  if(is_top())
    return true;

  if(i.is_top())
  {
    *this = i;
    return true;
  }
  
  return false;
}

intbv_intervalt& intbv_intervalt::
join(const intbv_intervalt& i)
{
  if(is_top())
  {
    return *this;
  }
  if(i.is_top())
  {
    set_top(); return *this;
  }
  if(is_bot())
  {
    *this = i; return *this;
  }
  if(i.is_bot())
  {
    return *this;
  }
   

  if(l > i.l)
    l = i.l;
  if(u < i.u)
    u = i.u;
  normalize();
  return *this;
}

intbv_intervalt& intbv_intervalt::meet(const intbv_intervalt& i)
{
  if(is_top())
  {
    *this = i;
    return *this;
  }
  if(i.is_top())
  {
    return *this;
  }
  if(is_bot())
  {
    return *this;
  }
  if(i.is_bot())
  {
    set_bot();
    return *this;
  }


  if(l < i.l)
    l = i.l;
  if(u > i.u)
    u = i.u;
  normalize();
  return *this;
}

intbv_intervalt& intbv_intervalt::operator+=(
    const intbv_intervalt& i)
{
  if(arith_handle_special(i))
    return *this;

  l += i.l;
  u += i.u;
  normalize();
  return *this;
}

intbv_intervalt& intbv_intervalt::operator-=(
    const intbv_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;

  l -= i.u;
  u -= i.l;
  normalize();
  return *this;
}

intbv_intervalt& intbv_intervalt::operator*=(
    const intbv_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;
  
  mp_integer ll = l * i.l;
  mp_integer lu = l * i.u;
  mp_integer ul = u * i.l;
  mp_integer uu = u * i.u;
  
  l = std::min(ll,std::min(lu,std::min(ul,uu)));
  u = std::max(ll,std::max(lu,std::max(ul,uu)));
  
  normalize();

  return *this;
}


intbv_intervalt& intbv_intervalt::operator/=(
    const intbv_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;
  
  if(i.contains(zero()))
  {
    top = true;
    normalize();
    return *this;
  } 
  
  assert(i.u < zero() || i.l > zero());

  mp_integer ll = l / i.l;
  mp_integer lu = l / i.u;
  mp_integer ul = u / i.l;
  mp_integer uu = u / i.u;
  
  l = std::min(ll,std::min(lu,std::min(ul,uu)));
  u = std::max(ll,std::max(lu,std::max(ul,uu)));

  normalize();
  return *this;
}

intbv_intervalt& intbv_intervalt::operator%=(
    const intbv_intervalt& i)
{

  if(arith_handle_special(i))
    return *this;

  if(i.contains(zero()))
  {
    top = true;
    normalize();
    return *this;
  } 

  if(is_singleton() && i.is_singleton())
  {
    mp_integer result = lower();
    result %= i.lower();
    set(result, result);
  }

  mp_integer max_mod = std::max(i.u, -i.l) - one();

  if(l < zero())
    set(-max_mod, max_mod);
  else
    set(zero(), max_mod);

  return *this;
}


/*******************************************************************\

Function: intbv_intervalt::halve_lower

  Inputs: 

 Outputs:

 Purpose: Halve this interval, choose lower half

\*******************************************************************/

void intbv_intervalt::halve_lower()
{
  if(is_singleton())
    return;
  
  if(lower() + 1 == upper())
    set(lower(), lower());
  else
    set(lower(), (upper()+lower())/2);
}

/*******************************************************************\

Function: intbv_intervalt::halve_upper

  Inputs: 

 Outputs:

 Purpose: Halve this interval, choose upper half

\*******************************************************************/

void intbv_intervalt::halve_upper()
{
  if(is_singleton())
    return;
  
  if(lower() + 1 == upper())
    set(upper(), upper());
  else
    set((upper()+lower())/2+1, upper());
}
