
#define DEBUG_DISEQ
#include "disequality_element.h"
#include <std_types.h>

symbol_exprt a;
symbol_exprt b;
symbol_exprt c;
symbol_exprt d;
symbol_exprt e;

symbol_exprt new_int_sym(std::string id)
{
  return symbol_exprt(id, signedbv_typet(32));
}

void test1(disequality_elementt& e1)
{
  e1.set_equal(a,b);
  e1.set_equal(b,c);

  e1.set_equal(d,e);
  assert(e1.is_consistent());
  
  //d == e
  assert(e1.equal(d,e));
  assert(e1.equal(d,d));
  assert(e1.equal(e,e));

  //a == b == c
  assert(e1.equal(a,a));
  assert(e1.equal(b,a));
  assert(e1.equal(c,a));
  assert(e1.equal(a,b));
  assert(e1.equal(b,b));
  assert(e1.equal(c,b));
  assert(e1.equal(a,c));
  assert(e1.equal(b,c));
  assert(e1.equal(c,c));

  assert(!e1.equal(a,d));
  assert(!e1.equal(a,e));
  assert(!e1.equal(b,d));
  assert(!e1.equal(b,e));
  assert(!e1.equal(c,d));
  assert(!e1.equal(c,e));
 
  e1.set_notequal(c,d);
  assert(e1.notequal(a,d));
  assert(e1.notequal(a,e));
  assert(e1.notequal(b,d));
  assert(e1.notequal(b,e));
  assert(e1.notequal(c,d));
  assert(e1.notequal(c,e));

  e1.set_equal(a,d);
  assert(e1.conflicting());
  assert(e1.is_consistent());

  e1.clear();
}

void test2(disequality_elementt& de)
{
  symbol_exprt arr[5] = {a,b,c,d,e}; 

  for(unsigned i = 0; i < 5; i++)
  {
    for(unsigned j = 0; j < i; j++)
      for(unsigned k = 0; k < i; k++)
        de.set_equal(arr[j], arr[k]);

    for(unsigned j = i; j < 5; j++)
      for(unsigned k = i; k < 5; k++)
        de.set_equal(arr[j], arr[k]);

    if(i > 0 && i < 4)
      de.set_notequal(arr[0], arr[4]);

    assert(!de.conflicting());
    assert(de.is_consistent());

    for(unsigned j = 0; j < 5; j++)
      de.remove(arr[j]);

    assert(de.is_top());
    assert(de.is_consistent());
  }
}


void test3(disequality_elementt& de)
{
  symbol_exprt arr[5] = {a,b,c,d,e}; 

  for(unsigned i = 0; i < 5; i++)
  {
    for(unsigned j = 0; j < i; j++)
      de.set_equal(arr[j], arr[j]);

    for(unsigned j = i; j < 5; j++)
      de.set_equal(arr[j], arr[j]);

    if(i > 0 && i < 4)
      de.set_notequal(arr[0], arr[4]);

    assert(!de.conflicting());
    assert(de.is_consistent());

    for(unsigned j = 0; j < 5; j++)
      de.remove(arr[j]);
  }
}

void test4(disequality_elementt& d1, disequality_elementt& d2)
{
  d1.clear(); d2.clear();
  d1.set_equal(a,b);
  d1.set_equal(b,c); //d1: a == b == c
  
  assert(d1.leq(d1));
  assert(d1.is_consistent() && d2.is_consistent());

  assert(!d2.leq(d1));
  assert(d1.leq(d2));

  d2.set_equal(a,c);//d2: a == c
  assert(!d2.leq(d1));
  assert(d1.leq(d2));
  assert(d1.is_consistent() && d2.is_consistent());

  d2.set_equal(b,a); //d2 a == b == c
  assert(d1.leq(d2) && d2.leq(d1));

  d1.set_notequal(c,d); //d1 a == b == c, c != d
  assert(d1.is_consistent() && d2.is_consistent());
  assert(!d2.leq(d1));
  assert(d1.leq(d2));

  d1.set_equal(d,e);
  d2.set_notequal(e,c);
  assert(!d2.leq(d1) && d1.leq(d2));
  assert(d1.is_consistent() && d2.is_consistent());
}


void test5(disequality_elementt& d1, disequality_elementt& d2)
{
  d1.clear(); d2.clear();
  d1.set_equal(a,b);
  d2.set_equal(b,c);
  d2.set_notequal(c,d);

  d1.add_constraints(d2);
  assert(d1.notequal(a,d));
  assert(d1.is_consistent() && d2.is_consistent());
  
  d1.clear(); d2.clear();

  d1.set_equal(a,b);
  d1.set_equal(c,d);
  d1.set_notequal(b,c);

  d2.set_equal(a,b);
  d2.set_equal(a,c);
  d2.set_equal(a,d);
  d2.set_equal(a,e);

  d1.intersect_constraints(d2);
  assert(!d1.notequal(a,d));
  assert(d1.equal(a,b));
  assert(d1.equal(c,d));
  assert(!d1.equal(b,c));
  assert(d1.is_consistent() && d2.is_consistent());
}

void test6(disequality_elementt& d1, disequality_elementt& d2)
{
  d1.clear();
  d1.set_equal(a,b);
  d1.set_notequal(b,c);
  d1.set_notequal(c,d);
  d1.set_equal(d,e);

  d2 = d1;
  disequality_elementt d3 = d1;
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());
  
  d1.intersect_constraints(d2);
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());
  d1.add_constraints(d2);
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());
  d1.intersect_constraints(d2);
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());
  d1.add_constraints(d2);
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());

  assert(d1.leq(d2));
  assert(d2.leq(d1));
  assert(d2.leq(d3));
  assert(d3.leq(d2));
  assert(d1.leq(d3));
  assert(d3.leq(d1));
  assert(d1.is_consistent());
  assert(d2.is_consistent());
  assert(d3.is_consistent());
}

int main(void)
{
  disequality_elementt::numberingt n;
  disequality_elementt e1(n);
  disequality_elementt e2(n);

  a = new_int_sym("a");
  b = new_int_sym("b");
  c = new_int_sym("c");
  d = new_int_sym("d");
  e = new_int_sym("e");

  test2(e1); 
  test3(e1);
  test1(e1); 
  test4(e1,e2);
  test5(e1,e2);
  test6(e1,e2);

  std::cout << "all tests passed" << std::endl;

  return 0;
}
