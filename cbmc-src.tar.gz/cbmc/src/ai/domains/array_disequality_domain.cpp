/*******************************************************************\

Module: Disequality domain with some array support

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "array_disequality_domain.h"

/*******************************************************************\

Function: array_diseq_domaint::to_expr

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

exprt array_diseq_domaint::to_expr(const abstr_elementt& a)
{
  exprt result = sub::to_expr(a);
  emul.replace_symbols_by_orig(result);

  return result;
}

/*******************************************************************\

Function: array_diseq_domaint::apply_assign_inplace

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void array_diseq_domaint::apply_assign_inplace(
    disequality_elementt& a, 
    const exprt& lhs, 
    const exprt& rhs)
{
  exprt lhs_repl = lhs;
  exprt rhs_repl = rhs;

  emul.replace_by_symbols(lhs_repl);
  emul.replace_by_symbols(rhs_repl);

  replace_address_of_index(lhs_repl);
  replace_address_of_index(rhs_repl);

  sub::apply_assign_inplace(a, lhs_repl, rhs_repl);
}

/*******************************************************************\

Function: array_diseq_domaint::apply_test_inplace

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void array_diseq_domaint::apply_test_inplace(
    disequality_elementt& a, 
    const exprt& e,
    bool result)
{
  exprt e_repl = e;

  //as_pointer = true, since we want to get expressions of the form &(a[0]) 
  emul.replace_by_symbols(e_repl);
  replace_address_of_index(e_repl);
  
  sub::apply_test_inplace(a, e_repl, result);
}

/*******************************************************************\

Function: array_diseq_domaint::replace_address_of_index
 
  Inputs:

 Outputs:

 Purpose: Replaces statements of the form &(a[..][..]) if the index
          is supported as a pointer

\*******************************************************************/

void array_diseq_domaint::replace_address_of_index(exprt& e)
{
  if(e.id() == ID_address_of && e.op0().id() == ID_index)
  {
    if(emul.supported(to_index_expr(e.op0()), true) &&
       emul.has_constant_indices(to_index_expr(e.op0())))
    {
      //return the corresponding symbol instead
      exprt emulated = emul.emulate(to_index_expr(e.op0()));
      e.op0().swap(emulated);
      return;
    }
  }

  Forall_operands(it, e)
    replace_address_of_index(*it);
}

/*******************************************************************\

Function: array_diseq_domaint::fwd_interpret

  Inputs: 

 Outputs:

 Purpose: Override to fix problems with turning arrays into symbols

\*******************************************************************/

disequality_domaint::abstr_valt 
array_diseq_domaint::fwd_interpret(const exprt& e)
{
  if(e.id() == ID_address_of && e.op0().id() == ID_symbol)
  {
    return sub::fwd_interpret(e.op0());

    /*if(emul.supported(to_index_expr(e.op0()), true) &&
       emul.has_constant_indices(to_index_expr(e.op0())))
    {
      //return the corresponding symbol instead
      exprt result = emul.emulate(to_index_expr(e.op0()));
      return abstr_valt(to_symbol_expr(result), true);
    }*/
  }

  return sub::fwd_interpret(e);
}
