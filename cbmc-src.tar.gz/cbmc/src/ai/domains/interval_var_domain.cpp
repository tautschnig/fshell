#include "interval_var_domain.h"
#include <arith_tools.h>
#include <std_types.h>
#include <memory>

abstr_elementt interval_var_domaint::top(const typet& t)
{
  return new_elem(new itvt(t, rounding_mode)); 
}

abstr_elementt interval_var_domaint::bot(const typet& t)
{ 
  std::auto_ptr<itvt> r(new itvt(t, rounding_mode)); 
  switch(r->type)
  {
    case itvt::FLOAT:
      r->f().set_bot(); 
      break;
    case itvt::INTBV:
      r->i().set_bot(); 
      break;
    case itvt::OTHER:
      r->other_bottom = true;
      break;
  }

  return new_elem(r.release());
} 


bool interval_var_domaint::is_top(const abstr_elementt& e)
{
  return read(e).is_top();
}


bool interval_var_domaint::is_bot(const abstr_elementt& e)
{
  return read(e).is_bot();
}


bool interval_var_domaint::leq(
    const abstr_elementt& a1, 
    const abstr_elementt& a2)
{
  assert(read(a1).type == read(a2).type);

  const itvt& p = read(a1);
  switch(p.type)
  {
    case itvt::FLOAT:
      return p.f() <= read(a2).f();
      break;
    case itvt::INTBV:
      return p.i() <= read(a2).i();
      break;
    case itvt::OTHER:
      return !p.other_bottom || read(a2).other_bottom;
      break;
  }
  
  assert(0);
  return true;
}


std::string interval_var_domaint::to_string(
    const abstr_elementt& a, 
    const symbol_exprt& s)
{

  const itvt& p = read(a);
  std::string r;
  switch(p.type)
  {
    case itvt::FLOAT:
      r =  s.get_identifier().as_string() + " in FLOAT: " + p.f().to_string();
      break;
    case itvt::INTBV:
      r =  s.get_identifier().as_string() + " in INT: " + p.i().to_string();
      break;
    case itvt::OTHER:
      r =  s.get_identifier().as_string() + " in OTHER: " + 
           (p.other_bottom ? "bot" : "top");
      break;
  }
  
  return r;
}

std::string interval_var_domaint::to_string(const abstr_elementt& a)
{
  const itvt& p = read(a);
  switch(p.type)
  {
    case itvt::FLOAT:
      return "FLOAT:" + p.f().to_string();
      break;
    case itvt::INTBV:
      return "INT: " + p.i().to_string();
      break;
    case itvt::OTHER:
      return (p.other_bottom ? "OTHER: bot" : "OTHER: top");
      break;
  }
  
  assert(0);
  return "";
}

exprt interval_var_domaint::to_expr_intbv(
    const intbv_intervalt& b, 
    const symbol_exprt& s)
{
  exprt result(ID_and, typet(ID_bool));

  if(b.is_top())
  {
    result.make_true();
    return result;
  } else if(b.is_bot()) {
    result.make_false();
    return result;
  }

  signedbv_typet boolt(32);
  typet t = 
    (s.type().id() == ID_bool) ? boolt : s.type();

  if(b.lower() == b.upper())
  {
    //add symbol = lower()
    exprt l = from_integer(b.lower(), t);

    exprt eq(ID_equal, typet(ID_bool));

    eq.copy_to_operands(s);
    eq.copy_to_operands(l);
    result.swap(eq);
  } else {
    if(b.lower() != b.get_min()) { //add lower() <= symbol
      exprt l = from_integer(b.lower(), t);
      exprt ineq(ID_le, typet(ID_bool));
      ineq.copy_to_operands(l);
      ineq.copy_to_operands(s);
      result.move_to_operands(ineq);
    }

    if(b.upper() != b.get_max()) { //add symbol <= upper
      exprt u= from_integer(b.upper(), t);
      exprt ineq(ID_le, typet(ID_bool));
      ineq.copy_to_operands(s);
      ineq.copy_to_operands(u);
      result.move_to_operands(ineq);
    }
  }
  
  if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  assert(result.operands().size() > 0);

  return result;

}

exprt interval_var_domaint::to_expr_float(
    const float_intervalt& b, 
    const symbol_exprt& s)
{
  exprt result(ID_and, typet(ID_bool));

  if(b.is_top())
  {
    result.make_true();
    return result;
  } else if(b.is_bot()) {
    result.make_false();
    return result;
  }

  if(b.lower() == b.upper())
  {
    //add symbol = lower()
    exprt l = b.lower().to_expr();
    exprt eq(ID_equal, typet(ID_bool));
    eq.copy_to_operands(s);
    eq.copy_to_operands(l);
    result.swap(eq);
  } else {
    exprt l = b.lower().to_expr();
    exprt ineql(ID_le, typet(ID_bool));
    ineql.copy_to_operands(l);
    ineql.copy_to_operands(s);
    result.move_to_operands(ineql);

    exprt u= b.upper().to_expr();
    exprt inequ(ID_le, typet(ID_bool));
    inequ.copy_to_operands(s);
    inequ.copy_to_operands(u);
    result.move_to_operands(inequ);
  }

  if(result.operands().size() == 1)
    result.swap(result.op0());

  assert(result.operands().size() > 0);
  
  return result;
}

exprt interval_var_domaint::to_expr(
    const abstr_elementt& a, 
    const symbol_exprt& s)
{
  const itvt& itv = read(a);
  switch(itv.type)
  {
    case itvt::FLOAT:
      return to_expr_float(itv.f(), s);
      break;
    case itvt::INTBV:
      return to_expr_intbv(itv.i(), s);
      break;
    case itvt::OTHER:
      if(itv.other_bottom)
      {
        exprt r;
        r.make_false();
        return r;
      } else {
        exprt r;
        r.make_true();
        return r;
      }
      break;
  }

  assert(0);
  return exprt();
}


abstr_elementt interval_var_domaint::get_initial()
{
  throw "get_initial without type not supported";
}

void interval_var_domaint::meet_inplace(itvt& i, const itvt& e)
{
  assert(i.type == e.type);
  i.meet(e);
}


void interval_var_domaint::join_inplace(itvt& i, const itvt& e)
{
  assert(i.type == e.type);
  i.join(e);
}

void interval_var_domaint::widen_inplace(
    itvt& i, 
    const itvt& e, 
    const itvt& threshold)
{

  assert(i.type == e.type);
  switch(i.type)
  {
    case itvt::FLOAT:
      assert(i.f().leq(threshold.f()) && e.f().leq(threshold.f()));
      if(e.f().upper() > i.f().upper())
      {
        i.f().set(i.f().lower(), threshold.f().upper());
      }

      if(e.f().lower() < i.f().lower())
      {
        i.f().set(threshold.f().lower(), i.f().upper());
      }

      break;
    case itvt::INTBV:
      assert(i.i().leq(threshold.i()) && e.i().leq(threshold.i()));
      i = threshold;
      break;
    case itvt::OTHER:
      assert(!threshold.other_bottom || (e.other_bottom && i.other_bottom));
      i.other_bottom = 
        threshold.other_bottom || (i.other_bottom && e.other_bottom);
      break;
  }
}


bool interval_var_domaint::is_singleton(const abstr_elementt& a)
{
  return read(a).is_singleton();
}


exprt interval_var_domaint::to_expr(const abstr_elementt& a)
{
  return read(a).to_expr();
}
