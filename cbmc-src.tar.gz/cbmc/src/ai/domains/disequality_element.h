/*******************************************************************\

Module: Domain element for equalities and disequalities between 
        variables. Keeps track of information of the form "x = y" 
        and "x != y".
        
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef DISEQUALITY_ELEMENT_H
#define DISEQUALITY_ELEMENT_H

#include "union_find_ext.h"

#include <numbering.h>
#include <hash_cont.h>
#include <std_expr.h>
#include <iostream>

#include <set>
#include <string>


template <typename varT, typename hashT>
class disequality_element_baset 
{
public:
  typedef hash_numbering<varT,hashT> numberingt;

  disequality_element_baset(numberingt& _n, bool _conflict = false) :
    n(_n), conflict(_conflict) { }

  disequality_element_baset(const disequality_element_baset& d) :
    n(d.n), conflict(d.conflict), diseq(d.diseq), uuf(d.uuf) { }

  disequality_element_baset& operator=(const disequality_element_baset& d) 
  { n = d.n; conflict = d.conflict; diseq = d.diseq; uuf = d.uuf;return *this; }
  
  //returns false if the element becomes bottom
  virtual bool set_equal(const varT& a, const varT& b);
  bool set_equal(unsigned a, unsigned b);

  //returns false if the element becomes bottom
  virtual bool set_notequal(const varT& a, const varT& b);

  bool set_notequal(unsigned a, unsigned b);

  //returns true if a and b are known to be equal
  bool equal(const varT& a, const varT& b) const;
  bool equal(unsigned a, unsigned b) const;
  //returns true if a and b are known to be unequal
  bool notequal(const varT& a, const varT& b) const;
  bool notequal(unsigned a, unsigned b) const;

  //remove information about a
  void remove(const varT& a);

  bool conflicting() const { return conflict; }

  void clear()
  { uuf.clear(); diseq.clear(); conflict = false; }

  //true if this disequality_element has no constraints
  bool is_top() const;

  //true if every constraint in *this is also in d
  bool leq(const disequality_element_baset<varT,hashT>& d) const;

  //adds constraints in d to *this
  void add_constraints(const disequality_element_baset<varT,hashT>& d);

  //removes constraints that do not hold in d
  void intersect_constraints(const disequality_element_baset<varT,hashT>& d);

  void widen(
      const disequality_element_baset<varT, hashT>& d, 
      const disequality_element_baset<varT, hashT>& t);

  void swap(disequality_element_baset<varT,hashT>& d)
  { std::swap(conflict,d.conflict); diseq.swap(d.diseq); uuf.swap(d.uuf); }

  
  //return true if o could be replaced by a variable that is not v but equal
  bool get_other_equal(const varT& v, varT& o);

#ifdef DEBUG_DISEQ
  //debug, check consistency of representation
  bool is_consistent();
#endif

protected:
  numberingt &n;

  typedef std::set<unsigned> edgest;
  typedef hash_map_cont<unsigned, edgest> diseqt; 

  bool conflict;

  //disequality constraints are stored redundantly, i.e., a != b is
  //represented as a in diseq[b] and b in diseq[a]
  diseqt diseq;

  mutable unsigned_union_find_extt uuf;
  
  //returns the numbering of a variable
  unsigned number(const varT& v);

  unsigned number(const varT& v) const;

  //replace all references to old_nr with new_nr in nodes in edges
  void replace_in_diseq(unsigned old_nr, unsigned new_nr, const edgest& e);

  //remove all disequality edges to nr from the nodes in edges
  void remove_diseq(unsigned nr, const edgest& e);

};

class disequality_elementt 
        : public disequality_element_baset<symbol_exprt, irep_hash> 
{
public:
  typedef disequality_element_baset<symbol_exprt,irep_hash> SUB;

  //handle equality/disequality of arbitrary expressions
  virtual bool set_expr(const exprt& a, const exprt& b, bool equal);
  virtual bool set_expr_notequal(const exprt& a, const exprt& b);
  virtual bool set_expr_equal(const exprt& a, const exprt& b);

  exprt to_expr();
  std::string to_string();

  disequality_elementt(numberingt& n, bool conflict = false) 
    : SUB(n, conflict) { }

protected:
  void cast_to_equal(exprt &e1, exprt& e2);
  void array_to_pointer(exprt& e);

};


template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
leq(const disequality_element_baset<varT,hashT>& d) const
{
  if(conflicting())
    return true;
  else if(d.conflicting())
    return false;

  if(!uuf.leq(d.uuf))
    return false;
  
  for(diseqt::const_iterator it = d.diseq.begin(); it != d.diseq.end(); it++)
  {
    //disequality constraints should only be associated with roots
    assert(d.uuf.find_fast(it->first) == it->first || it->second.size() == 0);
    if(it->second.size() == 0)
      continue;

    unsigned root = uuf.find_fast(it->first);

    diseqt::const_iterator diseq_find = diseq.find(root);
    if(diseq_find != diseq.end()) {
      //both elements have disequalities
      const edgest& edges = diseq_find->second;

      for(edgest::const_iterator e_it = it->second.begin(); 
          e_it != it->second.end(); e_it++)
      {
        //check whether each disequality in d has a disequality in *this
        unsigned edge_root = uuf.find_fast(*e_it);
        if(edges.find(edge_root) == edges.end())
          return false;
      }
    } else {
      //we have no disequalities, but the other element has some
      return false;
    }
  }

  return true;
}

template <typename varT, typename hashT>
unsigned disequality_element_baset<varT,hashT>::
number(const varT& v) 
{
  return n.number(v);
}


template <typename varT, typename hashT>
unsigned disequality_element_baset<varT,hashT>::
number(const varT& v) const
{
  unsigned r;
  bool error = n.get_number(v,r);
  assert(!error);
  return r;
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
equal(unsigned a, unsigned b) const
{
  if(conflict)
    return true;

  return uuf.find_fast(a) == uuf.find_fast(b);
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
equal(const varT& a, const varT& b) const
{
  return equal(number(a),number(b));
}


template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
notequal(const varT& a, const varT& b) const
{
  return notequal(number(a),number(b));
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
notequal(unsigned a, unsigned b) const
{
  if(conflict)
    return true;

  unsigned a_root = uuf.find_fast(a);

  diseqt::const_iterator it = 
    diseq.find(a_root);

  if(it == diseq.end())
    return false;
  
  unsigned b_root = uuf.find_fast(b);

  return it->second.find(b_root) != it->second.end();
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
set_equal(const varT& a, const varT& b)
{
  return set_equal(number(a),number(b));
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
set_equal(unsigned a, unsigned b)
{
  if(conflict)
    return false;

  if(notequal(a,b))
  {
    conflict = true;
    return false;
  }

  unsigned old_a_root = uuf.find_fast(a);
  unsigned old_b_root = uuf.find_fast(b);
    
  //already the same, return
  if(old_a_root == old_b_root)
    return true;

  //std::cout << "set_equal " << number(a) << ", " << number(b) << std::endl;
  uuf.make_union(a,b);

  //reappend disequalities to new root
  unsigned new_root = uuf.find_fast(a);
  
  unsigned was_root;

  if(old_a_root == new_root)
    was_root = old_b_root;
  else
  {
    assert(old_b_root == new_root);
    was_root = old_a_root;
  }

  diseqt::iterator old_edges_it = diseq.find(was_root);

  if(old_edges_it != diseq.end())
  {
    edgest& old_edges = old_edges_it->second;
    replace_in_diseq(was_root, new_root, old_edges);
    diseq[new_root].insert(old_edges.begin(), 
                           old_edges.end());
    old_edges.clear();
  }

  return true;
}


template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
set_notequal(const varT& a, const varT& b)
{
  return set_notequal(number(a),number(b));
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
set_notequal(unsigned a, unsigned b)
{
  if(conflict)
    return false;

  if(equal(a,b))
  {
    conflict = true;
    return false;
  }
  
  //std::cout << "set_notequal " << number(a) << ", " << number(b) << std::endl;

  unsigned root_a = uuf.find_fast(a); 
  unsigned root_b = uuf.find_fast(b);

  diseq[root_a].insert(root_b);
  diseq[root_b].insert(root_a);

  return true;
}

template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::
add_constraints(const disequality_element_baset<varT,hashT>& de)
{
  if(conflicting() || de.conflicting())
  {
    conflict = true;
    return;
  }

  //add equality constraints
  for(unsigned i = 0; i < de.uuf.size(); i++)
  {
    unsigned root = de.uuf.find_fast(i);
    if(root != i)
      set_equal(i,root);
  }

  //add disequality constraints
  for(diseqt::const_iterator d_it = de.diseq.begin(); 
      d_it != de.diseq.end(); ++d_it)
  {
    unsigned a_nr = d_it->first;
    const edgest& e = d_it->second;

    for(edgest::iterator e_it = e.begin(); e_it != e.end(); ++e_it)
      set_notequal(a_nr, *e_it);
  }

}


template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::
intersect_constraints(const disequality_element_baset<varT,hashT>& de)
{
  if(de.conflicting())
    return;

  if(conflicting())
  {
    *this = de;
    return;
  }

  disequality_element_baset<varT,hashT> new_elem(n);
  
  //TODO: implement more efficiently
  for(unsigned i = 0; i < n.size(); i++)
    for(unsigned j = i+1; j < n.size(); j++)
  {
    if(equal(i,j) && de.equal(i,j))
      new_elem.set_equal(i,j);
    else if(notequal(i,j) && de.notequal(i,j))
      new_elem.set_notequal(i,j);
  }

  this->swap(new_elem);
}


template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::
remove(const varT& a)
{
  unsigned a_nr = number(a);
  
  if(!uuf.is_root(a_nr))
  {
    /* Variable a is not a root, hence we just isolate it.
       Since disequalities are stored with roots, we need 
       to expend no extra effort to maintain consistency */
    uuf.isolate(a_nr);
  }
  else
  {
    /* Variable a is a root. we therefore need to isolate it, 
       and reassociate the disequalities with the new root
       of the cluster*/

    bool has_other = (uuf.count(a_nr) > 1);
    unsigned other_nr = has_other ? uuf.get_other(a_nr) : 0;
    
    uuf.isolate(a_nr);
    
    diseqt::iterator it = 
      diseq.find(a_nr);
    
    if(it == diseq.end())
      /* there are no associated disequalities */
      return;

    if(!has_other) {
      /* the old cluster was a singleton, remove references to a_nr */
      remove_diseq(a_nr, it->second);
      it->second.clear();
    } else {
      /* get new root of old cluster */
      assert(a_nr != other_nr);

      unsigned new_root = uuf.find_fast(other_nr);
      replace_in_diseq(a_nr, new_root, it->second);

      assert(diseq[other_nr].size() == 0);
      diseq[other_nr] = it->second; 
      it->second.clear();
    }

  } //endif - Variable a was a root
}

template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::
replace_in_diseq(unsigned old_nr, unsigned new_nr, const edgest& e)
{
  for(edgest::const_iterator it = e.begin(); it != e.end(); it++)
  {
    diseqt::iterator e_it = diseq.find(*it);

    assert(e_it != diseq.end());
    
    size_t removed = e_it->second.erase(old_nr);
    assert(removed);
    e_it->second.insert(new_nr);
  }
}


template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::
remove_diseq(unsigned nr, const edgest& e)
{
  for(edgest::const_iterator it = e.begin(); it != e.end(); it++)
  {
    diseqt::iterator e_it = diseq.find(*it);
    assert(e_it != diseq.end());
    size_t removed = e_it->second.erase(nr);
    assert(removed);
  }
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
is_top() const
{
  if(conflict) 
    return false;

  for(diseqt::const_iterator it = diseq.begin();
      it != diseq.end(); it++)
  {
    if(it->second.size() != 0)
      return false;
  }

  if(uuf.count_roots() != uuf.size())
    return false;

  return true;
}

template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
get_other_equal(const varT& v, varT& o)
{
  unsigned vnr = number(v);

  for(unsigned i = 0; i < n.size(); i++)
  {
    if(vnr != i && equal(vnr, i)) 
    {
      o = n[i];
      return true;
    }
  }

  return false;
}

/*
template <typename varT, typename hashT>
void disequality_element_baset<varT,hashT>::intersect_constraints(
    const disequality_element_baset<varT, hashT>& d)
{
  if(is_top())
    return;

  if(conflicting())
  {
    *this = d;
    return;
  }

  if(d.is_top())
  {
    clear();
    return;
  }

  if(d.conflicting())
  {
    return;
  }

  disequality_element_baset<varT,hashT> new_elem(n);

  for(unsigned i = 0; i < n.size(); i++)
  {
    unsigned root = uuf.find_fast(i);
    if(root != i)
    {
      //i is not a root
      if(d.equal(i,root))
      {
        //keep in join
        new_elem.set_equal(i,root);
      }       
      
      assert(diseq[i].size() == 0);
    } else {
      //check disequalities associate with root

      const edgest& edges = diseq[i];
      for(edgest::const_iterator it = edges.begin(); it != edges.end(); it++)
      {
        unsigned j = *it;
        if(d.notequal(i,j))
        {
          //keep i != j in join
          new_elem.set_notequal(i, j); 
        }       
      }

    }

  } //end for

  swap(new_elem);
}*/


#ifdef DEBUG_DISEQ
template <typename varT, typename hashT>
bool disequality_element_baset<varT,hashT>::
is_consistent()
{
  for(diseqt::iterator it = diseq.begin(); it != diseq.end();
      it++)
  {
    //only roots have disequality edges
    if(it->second.size() > 0)
      assert(uuf.is_root(it->first));

    //edges are bidirectional
    edgest& edges = it->second;
    for(edgest::iterator it2 = edges.begin(); it2 != edges.end(); it2++)
    {
      unsigned nr_a = it->first;
      unsigned nr_b = *it2;
      assert(diseq[nr_b].find(nr_a) != diseq[nr_b].end());

      if(uuf.find_fast(nr_a) == uuf.find_fast(nr_b))
        assert(conflicting());
    }

    //if there are conflicting values then conflict must be set
  }

  return true;
}
#endif



#endif
