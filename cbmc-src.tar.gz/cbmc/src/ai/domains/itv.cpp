/*******************************************************************\

Module: Composite class of float/integer intervals
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "itv.h"


itvt::itvt(const typet& t, ieee_floatt::rounding_modet r)
  : other_bottom(false)
{
  if(t.id() == ID_floatbv)
  {
    _f = fptrt(new float_intervalt(t, r));
    type = itvt::FLOAT;
  } else if(t.id() == ID_signedbv || t.id() == ID_unsignedbv) {
    _i = iptrt(new intbv_intervalt(t));
    type = itvt::INTBV;
  } else if(t.id() == ID_bool) {
    //use 32 bit signed integer to represent
    signedbv_typet bool_t(32);
    _i = iptrt(new intbv_intervalt(bool_t));
    type = itvt::INTBV;
  } else {
    type = itvt::OTHER;
  }
}

void itvt::set_top()
{
  switch(type)
  {
    case itvt::INTBV:
      i().set_top();
      break;

    case itvt::FLOAT:
      f().set_top();
      break;

    case itvt::OTHER:
      other_bottom = false;
      break;
  }
}

void itvt::set_bot()
{
  switch(type)
  {
    case itvt::INTBV:
      i().set_bot();
      break;

    case itvt::FLOAT:
      f().set_bot();
      break;

    case itvt::OTHER:
      other_bottom = false;
      break;
  }
}

itvt& itvt::meet(const itvt& itv)
{
  assert(type == itv.type);
  switch(type)
  {
    case itvt::FLOAT:
      f().meet(itv.f());
      break;
    case itvt::INTBV:
      i().meet(itv.i());
      break;
    case itvt::OTHER:
      other_bottom = other_bottom || itv.other_bottom;
      break;
  }
  
  return *this;
}


itvt& itvt::join(const itvt& itv)
{
  assert(type == itv.type);
  switch(type)
  {
    case itvt::FLOAT:
      f().join(itv.f());
      break;
    case itvt::INTBV:
      i().join(itv.i());
      break;
    case itvt::OTHER:
      other_bottom = other_bottom && itv.other_bottom;
      break;
  }
  
  return *this;
}

bool itvt::contains_zero() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().contains(f().zero());
      break;
    case itvt::INTBV:
      return i().contains(i().zero());
      break;
    default: 
      return !other_bottom;
      break;
  }
}

bool itvt::is_zero() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().is_zero();
      break;
    case itvt::INTBV:
      return i().is_zero();
      break;
    default: 
      return false;
      break;
  }
}

bool itvt::leq(const itvt& itv) const
{
  assert(type == itv.type);
  switch(type)
  {
    case itvt::FLOAT:
      return f().leq(itv.f());
      break;
    case itvt::INTBV:
      return i().leq(itv.i());
      break;
    default: 
      return other_bottom || !itv.other_bottom;
      break;
  }
}

bool itvt::eq(const itvt& itv) const
{
  assert(type == itv.type);
  switch(type)
  {
    case itvt::FLOAT:
      return f().eq(itv.f());
      break;
    case itvt::INTBV:
      return i().eq(itv.i());
      break;
    default:
      return other_bottom == itv.other_bottom;
      break;
  }
}


bool itvt::is_top() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().is_top();
      break;
    case itvt::INTBV:
      return i().is_top();
      break;
    default:
      return !other_bottom;
      break;
  }
}

bool itvt::is_bot() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().is_bot();
      break;
    case itvt::INTBV:
      return i().is_bot();
      break;
    default:
      return other_bottom;
      break;
  }
}


/*******************************************************************\

Function: itvt::complement

  Inputs: 

 Outputs:

 Purpose: Constructs the complement of *this in context, such that
          join(complement,*this) == context and meet(

\*******************************************************************/

bool itvt::complement(const itvt& c)
{
  assert(c.type == type);

  if(c.is_bot())
    return false;
  
  if(!leq(c))
    return false;

  if(c.leq(*this))
    return false;

  if(is_bot())
  {
    *this = c;
    return true;
  }

  switch(type)
  {
    case itvt::FLOAT:
      return f().complement(c.f());
      break;
    case itvt::INTBV:
      if(i().lower() == c.i().lower())
      {
        i().set(i().upper(), c.i().upper());
        if(!i().is_singleton())
          i().inc_lower();
      } 
      else if(i().upper() == c.i().upper())
      {
        i().set(c.i().lower(), i().lower());
        if(!is_singleton())
          i().dec_upper();
      } else return false;
      break;
    default:
      assert(0);
      break;
  }
  assert(!is_bot());
  return true;
}

void itvt::halve_lower(bool median)
{
  switch(type)
  {
    case itvt::FLOAT:
      f().halve_lower(median);
      break;
    case itvt::INTBV:
      i().halve_lower();
      break;
    default:
      assert(0);
      break;
  }
}

void itvt::halve_upper(bool median)
{
  switch(type)
  {
    case itvt::FLOAT:
      f().halve_upper(median);
      break;
    case itvt::INTBV:
      i().halve_upper();
      break;
    default:
      assert(0);
      break;
  }
}

std::string itvt::to_string() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().to_string();
      break;
    case itvt::INTBV:
      return i().to_string();
      break;
    default:
      if(other_bottom)
        return "Bot";
      else 
        return "Top";
      break;
  }
}

bool itvt::contains_min() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().contains_min();
      break;
    case itvt::INTBV:
      return i().contains_min();
      break;
    default:
      if(other_bottom)
        return false;
      else 
        return true;
      break;
  }

}

bool itvt::contains_max() const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().contains_max();
      break;
    case itvt::INTBV:
      return i().contains_max();
      break;
    default:
      if(other_bottom)
        return false;
      else 
        return true;
      break;
  }
}

bool itvt::disjunct(const itvt& itv) const
{
  switch(type)
  {
    case itvt::FLOAT:
      return f().disjunct(itv.f());
      break;
    case itvt::INTBV:
      return i().disjunct(itv.i());
      break;
    default:
      if(other_bottom || itv.other_bottom)
        return false;
      else 
        return true;
      break;
  }
}


/*******************************************************************\

Function: itvt::to_expr

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

exprt itvt::to_expr() const
{
  switch(type)
  {
    case INTBV:
      return i().to_expr();
      break;
    case FLOAT:
      return f().to_expr();
      break;
    default:
      if(other_bottom)
        return false_exprt();
      else
        return true_exprt();
      break;
  }
}

/*******************************************************************\

Function: itvt::is_singleton

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

bool itvt::is_singleton() const
{
  switch(type)
  {
    case INTBV:
      return i().is_singleton();
      break;
    case FLOAT:
      return f().is_singleton();
      break;
    default:
      return false;
      break;
  }
}

/*******************************************************************\

Function: itvt::operator=

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

const itvt& itvt::operator=(const itvt&i)
{
  if(i._i.get() != NULL)
    _i = iptrt(new intbv_intervalt(i.i()));
  if(i._f.get() != NULL)
    _f = fptrt(new float_intervalt(i.f()));
  type = i.type;
  other_bottom = i.other_bottom;
  return *this;
}

/*******************************************************************\

Function: itvt::operator=

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

itvt::itvt(const itvt& i)
  : _i(i.type == INTBV ? new intbv_intervalt(i.i()) : NULL),
    _f(i.type == FLOAT ? new float_intervalt(i.f()) : NULL),
    type(i.type), other_bottom(i.other_bottom)
{ }
