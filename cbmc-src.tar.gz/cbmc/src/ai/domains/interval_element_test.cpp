/*******************************************************************\

Module: Unit tester for interval element

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "interval_element.h"
#include <std_types.h>


typet get_bv_typet(bool signed_type, unsigned width)
{
  if(signed_type)
    return signedbv_typet(width);
  else
    return unsignedbv_typet(width);
}

void test1();
void test2();
void test3();
void test4();

int main(void)
{
  std::cout <<
  "===========================================" << std::endl <<
  "== UNIT TEST: interval_element_test " << std::endl <<
  "===========================================" << std::endl;


  try {
    test1();
    test2();
    test3();
    test4();
  } catch (const char* str)
  {
    std::cout << str << std::endl;
    assert(0);
  } catch (const std::string str) {
    std::cout << str << std::endl;
    assert(0);
  }
  std::cout <<
  "======================= UNIT TEST SUCCESSFUL " << std::endl;
  return 0;
}

void test1()
{
  typet s32 = get_bv_typet(true, 32);

  //top element
  intbv_intervalt i1(s32);
  assert(i1.is_top());

  i1.meet(i1);
  assert(i1.is_top());

  i1.join(i1);
  assert(i1.is_top());
  
  i1.set_bot();
  assert(i1.is_bot());

  i1.meet(i1);
  assert(i1.is_bot());
  
  i1.join(i1);
  assert(i1.is_bot());

  i1 = intbv_intervalt(s32, -10,10);
  intbv_intervalt i2(s32, 5,15);
  intbv_intervalt i3(s32, 5,10);
  
  intbv_intervalt tmp = i1;
  tmp.meet(i2);
  assert(tmp == i3);

  tmp = i1;
  i2.set(20,30);
  i3.set(-10,30);
  tmp.join(i2);

  assert(tmp == i3);
}

void test2()
{
  typet s32 = get_bv_typet(true, 32);

  //top element
  intbv_intervalt i(s32, -10, 10);

  intbv_intervalt tmp = i;
  intbv_intervalt one(s32, 1, 1);

  assert(tmp != one);
  
  tmp.meet(one);
  assert(tmp == one);

  tmp = one;
  tmp.join(i);
  assert(i == tmp);
  
  tmp = one;
  tmp += one;
  tmp += one;
  tmp += one;
  tmp += one;
  tmp += tmp;
  assert(tmp <= i);
  tmp += one;
  assert(!(tmp > i) && !(tmp < i));
}

//check overflow
void test3()
{
  typet u32 = get_bv_typet(false, 32);
  intbv_intervalt u(u32, 0, 0);
  intbv_intervalt one(u32, 1, 1);
  intbv_intervalt two(u32, 2, 2);


  intbv_intervalt tmp = u;
  tmp -= one;
  assert(tmp.is_top());
  
  tmp = one;
  
  for(unsigned i = 0; i < 31; i++) 
  {
    tmp *= two;
  }

  assert(!tmp.is_top());
  tmp *= two;
  assert(tmp.is_top());

  typet s32 = get_bv_typet(true, 32);
  intbv_intervalt s(s32,-2147483647, 2147483646); 
  assert(!s.is_top());
  s *= two;
  assert(s.is_top());
}

void check_comp(char op, int a, int b, int c, int d, int e, int f)
{
  typet s32 = get_bv_typet(true, 32);
  intbv_intervalt o1(s32, a, b);
  intbv_intervalt o2(s32, c, d);
  intbv_intervalt r(s32, e, f);

  intbv_intervalt actual_result(s32);

  switch(op)
  {
    case '+':
      actual_result = o1 + o2;
      break;
    case '-':
      actual_result = o1 - o2;
      break;
    case '%':
      actual_result = o1 % o2;
      break;
    case '*':
      actual_result = o1 * o2;
      break;
    case '/':
      actual_result = o1 / o2;
      break;
    default:
      assert(0);
  }
  
  std::cout << o1 << " " << op << " " << o2 << " = " 
            << actual_result << std::endl;

  assert(actual_result == r);
}

void test4()
{
  typet s32 = get_bv_typet(true, 32);
  check_comp('+', -2,7,  5,6,  3,13);
  check_comp('*', -2,7,  5,6,  -12,42);
  check_comp('-', -2,7,  5,6,  -8,2);
  check_comp('%', -2,7,  5,6,  -5,5);
  check_comp('/', -2,7,  5,6,  0,1);
}
