/*******************************************************************\

Module: Disequality domain

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef DISEQUALITY_DOMAIN_H
#define DISEQUALITY_DOMAIN_H

#include "../abstr_domain_mem.h"
#include "disequality_element.h"

class disequality_domaint : public abstr_domain_memt<disequality_elementt> 
{
public:
  disequality_domaint() { }

  virtual ~disequality_domaint() { } 

  virtual abstr_elementt top();

  virtual abstr_elementt bot();

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);
 
  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a);

  virtual abstr_elementt get_initial() { return top(); };

  virtual void meet_inplace(
      disequality_elementt&, 
      const disequality_elementt& e);

  virtual void join_inplace(
      disequality_elementt&, 
      const disequality_elementt& e);

  virtual void widen_inplace(
      disequality_elementt&, 
      const disequality_elementt& e, 
      const disequality_elementt& threshold);

  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      disequality_elementt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  //return result of applying test for c expression
  virtual void apply_test_inplace(
      disequality_elementt& a, 
      const exprt& e,
      bool result);
  
  //used for forward interpretations of expressions
  class abstr_valt {
  public:
    abstr_valt(const symbol_exprt& s, bool eq)
      : sym(s), equal(eq), top(false) { } 

    abstr_valt()
      : equal(false), top(true) { } 

    symbol_exprt sym;
    bool equal;
    bool top;
  };

  virtual abstr_valt fwd_interpret(const exprt& e);

protected:
  typedef disequality_elementt::numberingt numberingt;
  numberingt numbering;

};

#endif
