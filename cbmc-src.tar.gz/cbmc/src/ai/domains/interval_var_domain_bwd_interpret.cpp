#include "interval_var_domain.h"

void interval_var_domaint::bwd_interpret_arith(
    const exprt& op, 
    const abstr_elementt& result, 
    abstr_elementst& op_values) 
{
  
  if(op.id() == ID_typecast)
  {
    switch(read(result).type)
    {
      case itvt::FLOAT: 
        bwd_interpret_float_typecast(op, result, op_values); break;
      case itvt::INTBV: 
        bwd_interpret_int_typecast(op, result, op_values); break;
      default: /* do nothing */ break;
    }
  } 

  abstr_elementt fwd = fwd_interpret(op, op_values);

  //also check whether result is impossible 
  //TODO: it's a bit clunky to do both, but arithmetic bwd_interpretation
  //is not fully precise 
  fwd.meet(result);

  //result impossible
  if(fwd.is_bot())
  {
    Forall_abstr_elements(it, op_values)
    {
      write(*it).set_bot();
    }
  }
    //TODO: increase precision
}


void interval_var_domaint::bwd_interpret_int_typecast(
    const exprt& op, 
    const abstr_elementt& result, 
    abstr_elementst& op_values) 
{
  //TODO: Implement
  assert(op_values.size() == 1);
  itvt& itv = write(op_values.front());
  
  switch(itv.type)
  {
    case itvt::FLOAT: //float to int typecast
      break;
    case itvt::INTBV: //int to int typecast
      break;
    default: //do nothing
      break;
  }

}


void interval_var_domaint::bwd_interpret_float_typecast(
    const exprt& op, 
    const abstr_elementt& result, 
    abstr_elementst& op_values) 
{
  assert(op_values.size() == 1);
  itvt& itv = write(op_values.front());
  const itvt& r_itv = read(result);

  itvt cp;
  switch(itv.type)
  {
    case itvt::FLOAT: //float to float typecast
      cp = r_itv;
      assert(cp.type == itvt::FLOAT);
      cp.f().change_type(to_floatbv_type(op.op0().type()));
      itv = cp;
      break;
    case itvt::INTBV: //int to float typecast
      break;
    default: //do nothing
      break;
  }
}



void interval_var_domaint::bwd_interpret_bool_equal(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  if(result)
  {
    itvt& itv1 = write(op_values.front());
    itvt& itv2 = write(op_values.back());

    assert(op_values.size() == 2);
    assert(itv1.type == itv2.type);

    op_values.front().meet(op_values.back());
    op_values.back() = op_values.front();
  } else
  {
    bwd_interpret_bool_notequal(op, op_values, true);
  }
}

void interval_var_domaint::bwd_interpret_bool_notequal(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  if(result)
  {
    assert(op_values.size() == 2);

    itvt& itv1 = write(op_values.front());
    itvt& itv2 = write(op_values.back());
    assert(itv1.type == itv2.type);

    if(itv1.type == itvt::INTBV)
    {
      intbv_intervalt& i1 = itv1.i();
      intbv_intervalt& i2 = itv2.i();

      if(i1.is_singleton() && i2.is_singleton() && 
          i1.lower() == i2.lower())
      {
        i1.set_bot();
        i2.set_bot();
      } else if(i1.is_singleton()) {
        if(i1.lower() == i2.lower()) {
          i2.inc_lower();
        } else if(i1.lower() == i2.upper()) {
          i2.dec_upper();
        }
      } else if(i2.is_singleton()) {
        if(i2.lower() == i1.lower()) {
          i1.inc_lower();
        } else if(i2.lower() == i1.upper()) {
          i1.dec_upper();
        }
      }
    } 
    else if(itv1.type == itvt::FLOAT)
    { 
      float_intervalt& f1 = itv1.f();
      float_intervalt& f2 = itv2.f();

      if(f1.is_top() || f2.is_top())
        return;

      if(f1.is_singleton() && f2.is_singleton() && 
          f1.lower() == f2.lower())
      {
        f1.set_bot();
        f2.set_bot();
      } else if(f1.is_singleton()) {
        if(f1.lower() == f2.lower()) {
          f2.inc_lower();
        } else if(f1.lower() == f2.upper()) {
          f2.dec_upper();
        }
      } else if(f2.is_singleton()) {
        if(f2.lower() == f1.lower()) {
          f1.inc_lower();
        } else if(f2.lower() == f1.upper()) {
          f1.dec_upper();
        }
      }
    } 
  } 
  else
  {
    bwd_interpret_bool_equal(op, op_values, true);
  }
}

void interval_var_domaint::bwd_interpret_bool_le(
    const exprt& op, 
    abstr_elementst& op_values, bool result)
{
  assert(op_values.size() == 2);

  itvt& itv1 = write(op_values.front());
  itvt& itv2 = write(op_values.back());
  assert(itv1.type == itv2.type);

  //there might be problems here with comparisons against zero
  if(itv1.type == itvt::INTBV)
  {
    if(result)
    {
      intbv_intervalt& i1 = itv1.i();
      intbv_intervalt& i2 = itv2.i();

      i1.set(i1.lower(), std::min(i1.upper(), i2.upper()));
      i2.set(std::max(i1.lower(), i2.lower()), i2.upper());

    } else {
      bwd_interpret_bool_gt(op, op_values, true);
    }

  } else if(itv1.type == itvt::FLOAT)
  {
    float_intervalt& f1 = itv1.f();
    float_intervalt& f2 = itv2.f();

    if(result) {

      if(!f2.is_top())
      {
        f1.set(f1.lower_or_infty(), std::min(f1.upper_or_infty(), f2.upper()));
      }
      if(!f1.is_top())
      {
        f2.set(std::max(f1.lower(), f2.lower_or_infty()), f2.upper_or_infty());
      }

    } else {
      if(! (f1.is_top() || f2.is_top()) )
        bwd_interpret_bool_gt(op, op_values, true);
    }

  }


}

void interval_var_domaint::bwd_interpret_bool_ge(
    const exprt& op, 
    abstr_elementst& op_values, bool result)
{
  assert(op_values.size() == 2);
  itvt& itv1 = write(op_values.front());
  itvt& itv2 = write(op_values.back());
  assert(itv1.type == itv2.type);

  if(itv1.type == itvt::INTBV)
  {
    if(result)
    {
      intbv_intervalt& i1 = itv1.i();
      intbv_intervalt& i2 = itv2.i();

      i1.set(std::max(i1.lower(),i2.lower()), i1.upper());
      i2.set(i2.lower(), std::min(i1.upper(), i2.upper()));
    } else {
      bwd_interpret_bool_lt(op, op_values, true);
    }
  } else if (itv1.type == itvt::FLOAT) {
    float_intervalt& f1 = itv1.f();
    float_intervalt& f2 = itv2.f();

    if(result)
    {
      if(!f2.is_top())
        f1.set(std::max(f1.lower_or_infty(),f2.lower()), f1.upper_or_infty());
      if(!f1.is_top())
        f2.set(f2.lower_or_infty(), std::min(f1.upper(), f2.upper_or_infty()));

    } else 
    {
      if( !(f1.is_top() || f2.is_top()) )
        bwd_interpret_bool_lt(op, op_values, true);
    }

  }

}

void interval_var_domaint::bwd_interpret_bool_lt(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  assert(op_values.size() == 2);
  itvt& itv1 = write(op_values.front());
  itvt& itv2 = write(op_values.back());
  assert(itv1.type == itv2.type);

  if(itv1.type == itvt::INTBV)
  {
    if(result)
    {
      intbv_intervalt& i1 = itv1.i();
      intbv_intervalt& i2 = itv2.i();

      i1.set(i1.lower(), std::min(i1.upper(), i2.upper() - 1));
      i2.set(std::max(i1.lower()+1, i2.lower()), i2.upper());
    } else {
      bwd_interpret_bool_ge(op, op_values, true);
    }

  } else if(itv1.type == itvt::FLOAT) {

    float_intervalt& f1 = itv1.f();
    float_intervalt& f2 = itv2.f();

    if(result) {
      if(!f2.is_top())
      {
        //get next representable number smaller than f2.upper
        ieee_floatt f2_lt_upper = f2.upper();
        f2_lt_upper.decrement();
        
        f1.set(f1.lower_or_infty(), std::min(f1.upper_or_infty(), f2_lt_upper));
      }
      if(!f1.is_top())
      {
        //get next representable number greater than f1.lower
        ieee_floatt f1_gt_lower = f1.lower();
        f1_gt_lower.increment();

        f2.set(std::max(f1_gt_lower, f2.lower_or_infty()), f2.upper_or_infty());
      }

    } else {
      if(! (f1.is_top() || f2.is_top()) ) //could be nan
        bwd_interpret_bool_ge(op, op_values, true); 
    }
  }

}

void interval_var_domaint::bwd_interpret_bool_gt(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  assert(op_values.size() == 2);
  itvt& itv1 = write(op_values.front());
  itvt& itv2 = write(op_values.back());
  assert(itv1.type == itv2.type);

  if(itv1.type == itvt::INTBV)
  {
    if(result)
    {
      intbv_intervalt& i1 = itv1.i();
      intbv_intervalt& i2 = itv2.i();

      i1.set(std::max(i1.lower(),i2.lower()+1), i1.upper());
      i2.set(i2.lower(), std::min(i1.upper()-1, i2.upper()));
    } else {
      bwd_interpret_bool_le(op, op_values, true);
    }
  } else if(itv1.type == itvt::FLOAT) 
  {
    float_intervalt& f1 = itv1.f();
    float_intervalt& f2 = itv2.f();

    if(result) {

      if(!f2.is_top())
      {
        ieee_floatt f2_gt_lower = f2.lower();
        f2_gt_lower.increment();
        f1.set(std::max(f1.lower_or_infty(),f2_gt_lower), f1.upper_or_infty());
      }
      if(!f1.is_top())
      {
        ieee_floatt f1_lt_upper = f1.upper();
        f1_lt_upper.decrement();
        f2.set(f2.lower_or_infty(),std::min(f1_lt_upper, f2.upper_or_infty()));
      }

    } else {
      if(! (f1.is_top() || f2.is_top()) )
        bwd_interpret_bool_le(op, op_values, true);
    }

  }
}


void interval_var_domaint::bwd_interpret_bool_ieee_equal(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  assert(op_values.size() == 2);
  float_intervalt& f1 = write(op_values.front()).f();
  float_intervalt& f2 = write(op_values.back() ).f();

  //special handling w.r.t. result due to FP weirdness originating in NaN
  if(result)
  {
    ieee_floatt zero = f1.zero();
    ieee_floatt minus_zero = f1.minus_zero();
    
    if((f1.contains(zero) || f1.contains(minus_zero)) &&
       (f2.contains(zero) || f2.contains(minus_zero)))
    {
      //since -0.0f == 0.0f
      float_intervalt zeroes = f1;
      zeroes.set(minus_zero, zero);

      float_intervalt ext_f1 = f1;
      float_intervalt ext_f2 = f2;
      ext_f1.join(zeroes);
      ext_f2.join(zeroes);

      f1.meet(ext_f2);
      f2.meet(ext_f1);
    } else {
      //no problems with zero
      f1.meet(f2);
      f2.meet(f1);
    }
    
  } else {
    if(! (f1.is_top() || f2.is_top()) ) 
    {
      //treat as an ieee_notequal
      bwd_interpret_bool_ieee_notequal(op, op_values, !result);
    } else {
      //Top could be NaN, cannot infer anything
    }
  }
}


void interval_var_domaint::bwd_interpret_bool_ieee_notequal(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{  
  assert(op_values.size() == 2);
  float_intervalt& f1 = write(op_values.front()).f();
  float_intervalt& f2 = write(op_values.back() ).f();

  if(result)
  {
    if(! (f1.is_top() || f2.is_top()) ) 
    {
      if(f1.is_singleton() && f2.is_singleton() && f1.eq(f2))
      {
        f1.set_bot(); f2.set_bot();
      } else if(f1.is_zero() && f2.is_zero())
      {
        f1.set_bot(); f2.set_bot();
      }
      else if(f1.is_zero())
      {
        if(ieee_equal(f1.lower(),f2.lower()))
        {
          ieee_floatt smallest = f1.zero();
          smallest.increment();  //contains smallest positive value
          f2.set(smallest, f2.upper());
        } 
        else if(ieee_equal(f1.lower(),f2.upper()))
        {
          ieee_floatt smallest = f1.zero();
          smallest.negate(); //contains -0.0
          smallest.decrement();  //contains smallest negative value
          f2.set(f2.lower(), smallest);
        }
      }
      else if(f1.is_singleton())
      {
        if(f1.lower() == f2.lower())
          f2.inc_lower();
        else if(f1.lower() == f2.upper())
          f2.dec_upper();
      } 
      else if(f2.is_zero())
      {
        if(ieee_equal(f2.lower(),f1.lower()))
        {
          ieee_floatt smallest = f2.zero();
          smallest.increment();  //contains smallest strictly positive value
          f1.set(smallest, f1.upper());
        } 
        else if(ieee_equal(f2.lower(),f1.upper()))
        {
          ieee_floatt smallest = f2.zero();
          smallest.negate(); //contains -0.0
          smallest.decrement();  //contains largest strictly negative value
          f1.set(f1.lower(), smallest);
        }
      }
      else if(f2.is_singleton())
      {
        if(f2.lower() == f1.lower())
          f1.inc_lower();
        else if(f2.lower() == f1.upper())
          f1.dec_upper();
      }
    } else {
      //Top could be NaN, cannot infer anything
    }

  } else {
    //if none of the operands is NaN, handle as an ieee_equal
    if(!f1.is_top() && !f2.is_top())
      bwd_interpret_bool_ieee_equal(op, op_values, true);
  }
}

void interval_var_domaint::bwd_interpret_bool_symbol(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  bwd_interpret_bool_typecast(op, op_values, result);
}

void interval_var_domaint::bwd_interpret_bool_typecast(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  assert(op_values.size() == 1);

  itvt& itv = write(op_values.front());

  if(itv.type == itvt::INTBV)   
  {
    intbv_intervalt& i = itv.i();
    
    if(result)
    {
      if(i.lower() == i.zero())
        i.inc_lower();
      if(i.upper() == i.zero())
        i.dec_upper();
    } 
    else 
    {
      intbv_intervalt i2(i);
      i2.set(i.zero(), i.zero());
      i.meet(i2);
    }
  } 
  else if(itv.type == itvt::FLOAT) 
  {
    float_intervalt& f = itv.f();
    
    if(result && !f.is_top())
    {
      if(ieee_equal(f.lower(),f.zero()))
      {
        ieee_floatt smallest_pos_val = f.zero();
        smallest_pos_val.increment();
        f.set(smallest_pos_val, f.upper());
      }

      if(ieee_equal(f.upper(),f.zero()))
      {
        ieee_floatt largest_neg_val = f.zero();
        largest_neg_val.negate();
        largest_neg_val.decrement();
        f.set(f.lower(), largest_neg_val);
      }
    } 
    else 
    {
      ieee_floatt neg_zero = f.zero();
      neg_zero.negate();
      float_intervalt f2(f);
      f2.set(neg_zero, f.zero());

      f.meet(f2);
    }

  }
}


/*******************************************************************\

Function: interval_var_domaint::bwd_interpret_bool

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void interval_var_domaint::bwd_interpret_bool(
    const exprt& op, 
    abstr_elementst& op_values,
    bool result)
{
  const irep_idt& id = op.id();

  if(id == ID_equal) {
    bwd_interpret_bool_equal(op, op_values, result);
  } else if(id == ID_notequal) {
    bwd_interpret_bool_notequal(op, op_values, result);
  } else if(id == ID_le) {
    bwd_interpret_bool_le(op, op_values, result);
  } else if(id == ID_lt) {
    bwd_interpret_bool_lt(op, op_values, result);
  } else if(id == ID_ge) {
    bwd_interpret_bool_ge(op, op_values, result);
  } else if(id == ID_gt) {
    bwd_interpret_bool_gt(op, op_values, result);
  } else if(id == ID_ieee_float_equal) {
    bwd_interpret_bool_ieee_equal(op, op_values, result);
  } else if(id == ID_ieee_float_notequal) {
    bwd_interpret_bool_ieee_notequal(op, op_values, result);
  } else if(id == ID_typecast) { //typecast to bool
    bwd_interpret_bool_typecast(op, op_values, result);
  } else if(id == ID_symbol) {
    bwd_interpret_bool_symbol(op, op_values, result);
  } else {
    //can't handle this operation, (soundly) do nothing
  }
}

