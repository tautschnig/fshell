/*******************************************************************\

Module: Floating point interval

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef FLOAT_INTERVAL_ELEMENT_H
#define FLOAT_INTERVAL_ELEMENT_H


#include "interval_element.h"

#include <ieee_float.h>
#include <mp_arith.h>

class float_intervalt
{
public:
  //switch on and off sound handling of NaN values
  static void set_sound_NaN(bool _sound) {sound_nan = _sound; }
  static bool get_sound_NaN() { return sound_nan; }

  static void set_default_rounding(ieee_floatt::rounding_modet rounding)
  { _rmode = rounding;  }

  static ieee_floatt::rounding_modet get_default_rounding() { return _rmode; }


  float_intervalt(ieee_floatt::rounding_modet rounding = _rmode);

  float_intervalt(
    const typet& t,
    ieee_floatt::rounding_modet rounding = _rmode);
  
  void set(const ieee_floatt& _l, const ieee_floatt& _u);

  void set_top(); 

  void set_bot();

  bool is_bot() const;

  bool is_top() const
  { return top; }

  bool leq(const float_intervalt& t) const;

  bool eq(const float_intervalt& t) const;

  float_intervalt& join(const float_intervalt&);
  float_intervalt& meet(const float_intervalt&);

  bool is_zero() const
  { return !top && l.is_zero() && u.is_zero(); } 

  void change_type(const floatbv_typet& t);

  ieee_floatt zero() const;
  ieee_floatt minus_zero() const;
  ieee_floatt one() const;

  exprt to_expr() const;

  bool operator==(const float_intervalt& t) const {return eq(t);}
  bool operator!=(const float_intervalt& t) const {return !(*this == t);}
  bool operator<=(const float_intervalt& t) const {return leq(t);}
  bool operator>=(const float_intervalt& t) const {return t.leq(*this);}
  bool operator<(const float_intervalt& t) const 
    {return *this<=t && !(t<=*this);}
  bool operator>(const float_intervalt& t) const 
    {return *this>=t && !(t>=*this);}

  float_intervalt operator+(const float_intervalt& t) const
  { float_intervalt r(*this); r+=t; return r;}
  float_intervalt operator-(const float_intervalt& t) const
  { float_intervalt r(*this); r-=t; return r;}
  float_intervalt operator*(const float_intervalt& t) const
  { float_intervalt r(*this); r*=t; return r;}
  float_intervalt operator/(const float_intervalt& t) const
  { float_intervalt r(*this); r/=t; return r;}
  float_intervalt operator%(const float_intervalt& t) const
  { float_intervalt r(*this); r%=t; return r;}
  float_intervalt operator-( void ) const; //unary minus

  float_intervalt& operator+=(const float_intervalt&);
  float_intervalt& operator-=(const float_intervalt&);
  float_intervalt& operator*=(const float_intervalt&);
  float_intervalt& operator/=(const float_intervalt&);
  float_intervalt& operator%=(const float_intervalt&);

  float_intervalt& negate(); 

  bool is_singleton() const
  { return !is_top() && (u == l); }

  void square();

  bool contains(const ieee_floatt& n) const
  { return is_top() || (l <= n && u >= n); }

  //float top does not have lower and upper bounds due to possible NaN
  const ieee_floatt& lower() const { assert(!top); return l; }
  const ieee_floatt& upper() const { assert(!top); return u; }

  //returns ninf / pinf if top is true
  const ieee_floatt& lower_or_infty() 
  { if(top) l.make_minus_infinity(); return l; }
  const ieee_floatt& upper_or_infty()
  { if(top) u.make_plus_infinity(); return u; }

  //largest non-top element 
  void set_non_nan()
  {
    ieee_floatt ninf(l), pinf(l);
    ninf.make_minus_infinity();
    pinf.make_plus_infinity();
    set(ninf, pinf);
  }

  bool is_non_nan() const { 
    return !top && l.is_infinity() && l.get_sign() 
                && u.is_infinity() && !u.get_sign(); 
  }
  
  void dec_lower() 
  { if(!is_top() && !is_bot()) l.decrement(); }

  void inc_lower() 
  { if(!is_top() && !is_bot()) l.increment(); }

  void inc_upper() 
  { if(!is_top() && !is_bot()) u.increment(); }

  void dec_upper() 
  { if(!is_top() && !is_bot()) u.decrement(); }

  void set_rounding_mode(ieee_floatt::rounding_modet);

  void halve_lower(bool median = true);
  void halve_upper(bool median = true);

  bool complement(const float_intervalt& context);

  bool contains_min() const { 
     return top || (lower().is_infinity() && lower().get_sign()); }

  bool contains_max() const { 
     return top || (upper().is_infinity() && !upper().get_sign()); }

  //returns true if the intervals have no common elements
  bool disjunct(const float_intervalt& i) const
  { return is_bot() || i.is_bot() || 
    (!is_top() && !i.is_top() && (u < i.l || l > i.u)); }
 
  void normalize()
  { if(is_bot()) set_bot(); else if(is_top()) set_top(); }

  std::string to_string() const;

protected:
  bool arith_handle_special(const float_intervalt& i);

  ieee_floatt::rounding_modet rounding_mode;
  ieee_floatt::rounding_modet l_round;
  ieee_floatt::rounding_modet u_round;

  ieee_float_spect spec;
  ieee_floatt u, l;
  bool top;
  typet type;

  static ieee_floatt::rounding_modet _rmode;
  //true -- arithmetic operations can cause NaN
  static bool sound_nan;

};

#endif
