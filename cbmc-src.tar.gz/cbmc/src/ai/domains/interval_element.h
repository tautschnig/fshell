/*******************************************************************\

Module: Abstract element implementation for interval domain

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef INTERVAL_ELEMENT_H
#define INTERVAL_ELEMENT_H

#include <mp_arith.h>
#include <std_types.h>
#include <std_expr.h>
#include <ieee_float.h>

#include <algorithm>
#include <sstream>


class intbv_intervalt 
{
public:
  //uninitialized interval
  intbv_intervalt();

  //create bounded interval from signedbv or unsignedbv
  intbv_intervalt(const typet& t);

  intbv_intervalt(const typet& t, int l, int u);

  exprt to_expr() const;

  void set_top()
  { top = true; l = min; u = max;  }

  void set_bot()
  { l = one(); u = zero(); top = false; }

  bool contains(const mp_integer& n) const
  { return (l <= n && u >= n); }

  void set(const mp_integer& _l, const mp_integer& _u);

  std::string to_string() const;

  intbv_intervalt& join(const intbv_intervalt&);
  intbv_intervalt& meet(const intbv_intervalt&);

  bool leq(const intbv_intervalt& t) const;
  bool eq(const intbv_intervalt& t) const;

  bool is_bot() const
  { return !top && u < l; }

  bool is_top() const
  { return top; }

  bool is_zero() const
  { return !top && l.is_zero() && u.is_zero(); } 

  const mp_integer& lower() const { return l; }

  const mp_integer& upper() const { return u; }

  intbv_intervalt operator+(const intbv_intervalt& t) const
  { intbv_intervalt r(*this); r+=t; return r;}
  intbv_intervalt operator-(const intbv_intervalt& t) const
  { intbv_intervalt r(*this); r-=t; return r;}
  intbv_intervalt operator*(const intbv_intervalt& t) const
  { intbv_intervalt r(*this); r*=t; return r;}
  intbv_intervalt operator/(const intbv_intervalt& t) const
  { intbv_intervalt r(*this); r/=t; return r;}
  intbv_intervalt operator%(const intbv_intervalt& t) const
  { intbv_intervalt r(*this); r%=t; return r;}
  intbv_intervalt operator-( void ) const //unary minus
  { intbv_intervalt r(*this); r.set(-r.upper(), -r.lower()); return r;}


  intbv_intervalt& operator+=(const intbv_intervalt&);
  intbv_intervalt& operator-=(const intbv_intervalt&);
  intbv_intervalt& operator*=(const intbv_intervalt&);
  intbv_intervalt& operator/=(const intbv_intervalt&);
  intbv_intervalt& operator%=(const intbv_intervalt&);

  bool operator==(const intbv_intervalt& t) const {return eq(t);}
  bool operator!=(const intbv_intervalt& t) const {return !(*this == t);}
  bool operator<=(const intbv_intervalt& t) const {return leq(t);}
  bool operator>=(const intbv_intervalt& t) const {return t.leq(*this);}
  bool operator<(const intbv_intervalt& t) const 
    {return *this<=t && !(t<=*this);}
  bool operator>(const intbv_intervalt& t) const 
    {return *this>=t && !(t>=*this);}

  mp_integer zero() const
  { return mp_integer(0); }
  mp_integer one() const
  { return mp_integer(1); } 

  void normalize();

  void set_bv_bounds(const typet& t);

  void dec_lower() 
  { if(!is_top() && !is_bot()) set(l-1, u); }

  void inc_lower() 
  { if(!is_top() && !is_bot()) set(l+1, u); }

  void inc_upper() 
  { if(!is_top() && !is_bot()) set(l, u+1); }

  void dec_upper() 
  { if(!is_top() && !is_bot()) set(l, u-1); }

  void square();

  //set to lower half
  void halve_lower();

  //set to upper half
  void halve_upper();
 
  mp_integer get_max() const { return max;} 
  mp_integer get_min() const { return min;}

  bool contains_min() const { return l == min; }
  bool contains_max() const { return u == max; }

  bool is_singleton() const
  { return !is_top() && (u == l); }

  bool disjunct(const intbv_intervalt& i) const
  { return is_bot() || i.is_bot() || 
    (!is_top() && !i.is_top() && (u < i.l || l > i.u)); }

  const typet& get_type() { return type; }

protected:
  typet type;
  mp_integer min;
  mp_integer max;
  mp_integer l,u;
  bool top;

  void handle_overflow() { set_top(); }

  bool arith_handle_special(const intbv_intervalt& i);
};


#endif
