#include "apron_domain.h"

#include "apron_domain_wrap.h"

#define DOM_PTR reinterpret_cast<apron_domain_wrapt*>(apron_domain_wrap)

apron_domaint::apron_domaint(apron_domain_typet t, const var_listt& l, const contextt& c)
{
  apron_domain_wrap = (void*) new apron_domain_wrapt(t,l,c);
}

//destructor
apron_domaint::~apron_domaint()
{ 
  assert(apron_domain_wrap != NULL);
  delete DOM_PTR;
}

bool apron_domaint::is_supported(const symbol_exprt& e)
{
  return apron_domain_wrapt::is_supported(e);
}


//return top / bottom element
abstr_elementt apron_domaint::top() 
{ 
  return DOM_PTR->top();
}

abstr_elementt apron_domaint::bot() 
{ 
  return DOM_PTR->bot();
}


abstr_elementt& 
apron_domaint::meet(abstr_elementt& a1, const abstr_elementt& a2) 
{ 
  return DOM_PTR->meet(a1, a2);
}


abstr_elementt& 
apron_domaint::join(abstr_elementt& a1, const abstr_elementt& a2) 
{ 
  return DOM_PTR->join(a1, a2);
}

abstr_elementt& 
apron_domaint::widen(
    abstr_elementt& a1, 
    const abstr_elementt& a2, 
    const abstr_elementt& threshold) 
{ 
  return DOM_PTR->widen(a1,a2,threshold);
}


bool apron_domaint::is_top(const abstr_elementt& e) 
{ 
  return DOM_PTR->is_top(e);
}


bool apron_domaint::is_bot(const abstr_elementt& e) 
{ 
  return DOM_PTR->is_bot(e);
}


bool apron_domaint::leq(
    const abstr_elementt& a1, 
    const abstr_elementt& a2) 
{ 
  return DOM_PTR->leq(a1,a2); 
}


//return result of applying transfer function for c expression
abstr_elementt& apron_domaint::apply_assign(
    abstr_elementt& a, 
    const exprt& lhs,
    const exprt& rhs) 
{ 
  return DOM_PTR->apply_assign(a, lhs, rhs);
}

//return result of applying test for c expression
abstr_elementt& apron_domaint::apply_test(abstr_elementt& a, const exprt& e) 
{ 
  return DOM_PTR->apply_test(a, e);
}


std::string apron_domaint::to_string(const abstr_elementt& a) 
{ 
  return DOM_PTR->to_string(a);
}


exprt apron_domaint::to_expr(const abstr_elementt& a) 
{ 
  return DOM_PTR->to_expr(a);
}


//get initial element, before program starts
abstr_elementt apron_domaint::get_initial() 
{ 
  return DOM_PTR->get_initial();
}


void apron_domaint::register_abstr_elem(abstr_elementt& e) 
{ 
  DOM_PTR->register_abstr_elem(e);
}

void apron_domaint::deregister_abstr_elem(abstr_elementt& e) 
{ 
  DOM_PTR->deregister_abstr_elem(e);
}


