#include "arr_diseq_interval_domain.h"

void arr_diseq_interval_domaint::reduce(abstr_pairt& p)
{
  abstr_elementt& diseq = p.first;
  abstr_elementt& itv = p.second;

  abstr_elementt old_diseq = diseq;
  abstr_elementt old_itv = itv;

  do {
    old_diseq = diseq;
    old_itv = itv;

    reduce_diseq2intervals(diseq, itv);
    reduce_intervals2diseq(diseq, itv);
  } while(!old_diseq.eq(diseq) || !old_itv.eq(itv));
}


void arr_diseq_interval_domaint::reduce_diseq2intervals(
    abstr_elementt& diseq,
    abstr_elementt& itv)
{
  if(diseq.is_bot())
  {
    itv = a2.bot();
    return;
  }

  exprt diseq_expr = diseq.to_expr();
  itv.apply_test(diseq_expr, true);
}

void arr_diseq_interval_domaint::reduce_intervals2diseq(
    abstr_elementt& diseq,
    abstr_elementt& itv)
{
  if(itv.is_bot())
  {
    diseq = a1.bot();
    return;
  }

  var_mapt vmap = interval_array_domain.get_var_map(itv);

  var_mapt::const_iterator it2;

  for(var_mapt::const_iterator it1 = vmap.begin(); it1 != vmap.end(); it1++)
  {

    for(it2 = it1, it2++; it2 != vmap.end(); it2++) 
    {
      if(it1->first.type() != it2->first.type())
        continue;

      exprt d(ID_notequal, typet(ID_bool));
      d.copy_to_operands(it1->first);
      d.copy_to_operands(it2->first);

      //check for disequality
      abstr_elementt v1 = it1->second;
      v1.meet(it2->second);

      if(v1.is_bot())
      {
        diseq.apply_test(d, true); //add 1 != 2 to diseq
        continue;
      }

      //check for equality
      abstr_elementt diseq_temp = diseq;
      diseq_temp.apply_test(d, true);
      if(diseq_temp.is_bot())
      {
        d.id(ID_equal); //add 1 == 2 to diseq
        diseq.apply_test(d, true);
      }

    }
  }
}


void arr_diseq_interval_domaint::simplify_with_intervals(
  const abstr_elementt& interval_element,
  exprt& e)
{
  abstr_env_domaint::var_elementt index_val =
    interval_array_domain.fwd_interpret(e, interval_element);

  exprt index_const = index_val.to_expr();
  if(index_const.is_constant() && index_const.type().id() == e.type().id())
    e.swap(index_const);
    
  Forall_operands(it, e)
    simplify_with_intervals(interval_element, *it);
}

void arr_diseq_interval_domaint::simplify_indices(
    const abstr_elementt& interval_element,
    exprt& e)
{
  if(e.id() == ID_index)
  {
    simplify_with_intervals(interval_element, to_index_expr(e).index());
  }
  
  Forall_operands(it, e)
    simplify_indices(interval_element, *it);
}

void arr_diseq_interval_domaint::apply_test_inplace(
  abstr_pairt& a, 
  const exprt& e,
  bool result)
{  
  //first apply interval test
  a2.apply_test(a.second, e, result);
  
  exprt filtered = e;
  simplify_indices(a.second, filtered);
  a1.apply_test(a.first, filtered, result);

  reduce(a);
}

void arr_diseq_interval_domaint::apply_assign_inplace(
      abstr_pairt& a, 
      const exprt& lhs, 
      const exprt& rhs)
{
  //first filter exprs with pre-assignment interval information
  exprt f_lhs = lhs;
  exprt f_rhs = rhs;
  simplify_indices(a.second, f_lhs);
  simplify_indices(a.second, f_rhs);

  a1.apply_assign(a.first, f_lhs, f_rhs);
  a2.apply_assign(a.second, lhs, rhs);

  reduce(a);
}

