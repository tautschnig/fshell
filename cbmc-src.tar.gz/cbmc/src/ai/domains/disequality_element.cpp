#include "disequality_element.h"

#include <ansi-c/expr2c.h>
#include <std_expr.h>

#include <vector>
#include <set>
#include <sstream>

//TODO: the set_expr stuff is VERY hacky and needs to be redone

std::string disequality_elementt::to_string()
{
  typedef std::set<symbol_exprt> var_sett;
  var_sett eq_clusters[n.size()];

  std::stringstream ss;
  
  for(unsigned i = 0; i < n.size(); i++)
  {
    unsigned root = uuf.find_fast(i);
    eq_clusters[root].insert(n[i]);
  }

  for(unsigned i = 0; i < n.size(); i++)
  {
    var_sett& eq_cluster = eq_clusters[i];
    if(eq_cluster.size() > 1)
    {
      var_sett::const_iterator it = eq_cluster.begin();
      ss << "[" << it->get_identifier(); 
      const typet& t = it->type();
      for(it++; it != eq_cluster.end(); it++)
      {
        ss << "==";
        
        if(it->type() != t)
        {
          //typecast 
          ss << '(' << t.to_string() << ") ";
        }
          
        ss << it->get_identifier();
      }
      ss << "], "; 
    }
  }

  //print disequalities
 
  for(diseqt::const_iterator d_it = diseq.begin(); 
      d_it != diseq.end(); 
      d_it++)
  {
    const symbol_exprt& lhs = n[d_it->first];
    const edgest& edges = d_it->second;

    for(edgest::const_iterator e_it = edges.begin(); 
        e_it != edges.end(); e_it++)
    {
      //avoid redundant x != y && y != x constraints
      if(d_it->first < *e_it)
      {
        const symbol_exprt& rhs = n[*e_it];
        ss << lhs.get_identifier() << "!=" ;
        
        if(lhs.type() != rhs.type())
          ss << '(' << lhs.type().to_string() << ')' << std::endl;

        ss << rhs.get_identifier() << ", ";
      }
    }
  }

  ss << std::endl;
  return ss.str();
}

exprt disequality_elementt::to_expr() 
{
  exprt result(ID_and, typet(ID_bool));

  if(is_top())
  {
    result.make_true();
    return result;
  }

  if(conflicting())
  {
    result.make_false();
    return result;
  }

  
  for(unsigned i = 0; i < n.size(); i++)
    for(unsigned j = i+1; j < n.size(); j++)
  {
    if(uuf.find_fast(i) == uuf.find_fast(j))
    {
      equality_exprt e(n[i], n[j]);

      cast_to_equal(e.op0(), e.op1());

      result.move_to_operands(e);
    }
  }
  
  for(diseqt::const_iterator d_it = diseq.begin(); 
      d_it != diseq.end(); 
      d_it++)
  {
    const symbol_exprt& lhs = n[d_it->first];
    const edgest& edges = d_it->second;

    for(edgest::const_iterator e_it = edges.begin(); 
        e_it != edges.end(); e_it++)
    {
      //avoid redundant x != y && y != x constraints
      if(d_it->first < *e_it)
      {
        const symbol_exprt& rhs = n[*e_it];
        binary_relation_exprt notequal(ID_notequal);
        notequal.op0() = lhs;
        notequal.op1() = rhs;
        
        cast_to_equal(notequal.op0(), notequal.op1());

        result.move_to_operands(notequal);
      }
    }
  }

  if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  return result;
}

/* cast array to pointer with &(A[0]) construction */
void disequality_elementt::array_to_pointer(exprt& e)
{
  if(e.type().id() != ID_array) 
    return;

  //make zero index
  constant_exprt zero(unsignedbv_typet(64));
  std::stringstream ss; 
  for(unsigned i = 0; i < 64; i++)
    ss << ' ';
  zero.set_value(ss.str());

  index_exprt index(e, zero); 
  while(index.type().id() == ID_array)
  {
    index_exprt new_expr(index, zero);
    index.swap(new_expr);
  }
    
  address_of_exprt addr(index);

  e.swap(addr);
}


void disequality_elementt::cast_to_equal(exprt& e1, exprt& e2)
{
  if(e1.type() == e2.type())
    return;

  else if(e1.type().id() == ID_pointer && 
          e2.type().id() != ID_pointer)
  {
    //this occurs sometimes when we use symbols to represent array values
    //use address of 
    address_of_exprt addr_of(e2);
    e2.swap(addr_of);

  } else if(e2.type().id() == ID_pointer && 
            e1.type().id() != ID_pointer)
  {
    //use address of 
    address_of_exprt addr_of(e1);
    e1.swap(addr_of);
  } 

  //cast between pointers
  if(e1.type() != e2.type() &&
     e1.type().id() == ID_pointer && e2.type().id() == ID_pointer)
    e2.make_typecast(e1.type());
  
  assert(e1.type() == e2.type());
}


bool disequality_elementt::set_expr_equal(const exprt& a, const exprt& b)
{
  return set_expr(a,b,true);
}

bool disequality_elementt::set_expr_notequal(const exprt& a, const exprt& b)
{
  return set_expr(a,b,false);
}

bool disequality_elementt::set_expr(const exprt& a, const exprt& b, bool equal)
{
  if(conflict)
    return false;

  if(a.id() == ID_symbol && b.id() == ID_symbol)
  {
    if(equal)
      return set_equal(to_symbol_expr(a), to_symbol_expr(b));
    else
      return set_notequal(to_symbol_expr(a), to_symbol_expr(b));

  } else if(b.type().id() == ID_pointer || a.type().id() == ID_pointer)
  {
    exprt b_it = b;
    while(b_it.id() == ID_typecast)
    {
      exprt tmp = b_it.op0();
      b_it.swap(tmp);
    }

    exprt a_it = a;
    while(a_it.id() == ID_typecast)
    {
      exprt tmp = a_it.op0();
      a_it.swap(tmp);
    }

    if(a_it.id() == ID_address_of)
    {
      exprt tmp = a_it.op0();
      a_it.swap(tmp);
    }
    if(b_it.id() == ID_address_of)
    {
      exprt tmp = b_it.op0();
      b_it.swap(tmp);
    }

    if(a_it.id() == ID_symbol && b_it.id() == ID_symbol)
    {
      //set equal despite differing type
      if(equal)
        return SUB::set_equal(to_symbol_expr(a_it), to_symbol_expr(b_it));
      else
        return SUB::set_notequal(to_symbol_expr(a_it), to_symbol_expr(b_it));
    } 

  }
  
  //no change 
  return true;
}

