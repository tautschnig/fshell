/*******************************************************************\

Module: Convenience class to for interval w. arrays domain 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef INTERVAL_ARRAY_DOMAIN_H
#define INTERVAL_ARRAY_DOMAIN_H

#include "../array_abstr_env.h"
#include "interval_var_domain.h"

class interval_array_domaint : public array_abstr_envt
{
public:
  interval_array_domaint(
    array_struct_emulatort& emul, 
    ieee_floatt::rounding_modet r = ieee_floatt::UNKNOWN) 
      : array_abstr_envt(interval_var_domain, emul), 
        array_emul(emul), interval_var_domain(r) { }
  
  array_struct_emulatort& array_emulator() { return array_emul; }
  interval_var_domaint& var_domain() { return interval_var_domain; }

  interval_var_domaint& get_itv_var_domain() { return interval_var_domain; }

  //later assignments supersede earlier assignments
  abstr_elementt from_itv_assignments(
      const std::vector<symbol_exprt>&, 
      const std::vector<itvt>&);

protected:
  array_struct_emulatort& array_emul;
  interval_var_domaint interval_var_domain;
};

#endif 
