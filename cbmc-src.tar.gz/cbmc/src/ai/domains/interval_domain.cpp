#include "interval_domain.h"

abstr_elementt interval_domaint::from_itv_assignments(
    const std::vector<symbol_exprt>& s, 
    const std::vector<itvt>& v)
{
  std::vector<abstr_elementt> elems;

  for(std::vector<itvt>::const_iterator it = v.begin();
      it != v.end(); it++)
  {
    elems.push_back(interval_var_domain.from_itv(*it));
  }

  return from_abstr_assignments(s, elems);
}
