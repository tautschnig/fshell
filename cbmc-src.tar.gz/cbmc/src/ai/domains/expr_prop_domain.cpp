/*******************************************************************\

Module: Simple constant propagation domain, 
        very limited functionality. 
        
        Solves a specific problem in proof growing. 
        Not fit for public consumption in its current state.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "expr_prop_domain.h"

void expr_prop_domaint::apply_assign_inplace(
  symbol_mapt& a, 
  const exprt& _lhs, 
  const exprt& _rhs)
{
  if(a.is_bot())
    return; 

  //first do a normal assignment 
  sub::apply_assign_inplace(a, _lhs, _rhs); 

  //but now we need to remove all expressions that map 
  //to expressions containing the lhs symbol;
  
  //first get the lhs symbol
  exprt lhs = _lhs;
  exprt rhs = _rhs;

  to_symbol_assignment(lhs, rhs);
  
  assert(lhs.id() == ID_symbol);
  
  symbol_mapt result;
  for(symbol_mapt::const_iterator it = a.begin();
      it != a.end(); it++)
  {
    if(!contains_expr(lhs, it->second))
      result[it->first] = it->second;
  }

  result.swap(a);
}

//we propagate all expressions
bool expr_prop_domaint::accept_rhs(const exprt& e)
{
  return true;
}

bool expr_prop_domaint::contains_expr(const exprt& what, const exprt& where)
{
  if(what == where)
    return true;
  
  forall_operands(it, where)
    if(contains_expr(what, *it))
      return true;

  return false;
}
