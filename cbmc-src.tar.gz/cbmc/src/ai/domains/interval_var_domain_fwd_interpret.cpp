#include "interval_var_domain.h"

#include <arith_tools.h>
#include <memory>
#include <algorithm>


abstr_elementt interval_var_domaint::fwd_interpret(
    const exprt& op, 
    const abstr_elementst& op_values)
{

  if(op.type().id() == ID_signedbv || op.type().id() == ID_unsignedbv)
    return fwd_interpret_int(op, op_values);

  else if(op.type().id() == ID_floatbv)
    return fwd_interpret_float(op, op_values);

  else if(op.type().id() == ID_bool)
    return fwd_interpret_bool(op, op_values);

  else return top(op.type());
}

abstr_elementt interval_var_domaint::fwd_interpret_int(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  const irep_idt& id = op.id();

  if(id == ID_plus || id == ID_minus || id == ID_mult || 
     id == ID_div  || id == ID_mod   ||
     id == ID_unary_minus || id == ID_unary_plus) 
  {
    return fwd_interpret_int_arith(op, op_values);
  } 

  else if(id == ID_typecast)  
  {
    return fwd_interpret_int_typecast(op, op_values);
  } 

  else if(id == ID_constant) 
  {
    return fwd_interpret_int_constant(op, op_values);
  } 
  
  else if(id == ID_bitand || id == ID_bitor || 
          id == ID_bitnot || id == ID_bitxor)
  {
    return fwd_interpret_int_bitwise(op, op_values);
  }
  
  else {
    return top(op.type());
  }
    //cannot interpret, return top

}

abstr_elementt interval_var_domaint::fwd_interpret_bool_binary(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  assert(op_values.size() == 2);

  bool can_be_true;
  bool can_be_false;

  const itvt &itv1 = read(op_values.front());
  const itvt &itv2 = read(op_values.back());

  const irep_idt& id = op.id();

  std::auto_ptr<itvt> result = std::auto_ptr<itvt>(new itvt(op.type(), rounding_mode));

  if(itv1.is_bot() || itv2.is_bot())
  {
    can_be_true = false;
    can_be_false = false;
  } 
  else if(itv1.is_top() || itv2.is_top())
  {
    can_be_true = true;
    can_be_false = true;
  }
  else if(id == ID_equal || id == ID_notequal || 
          id == ID_ieee_float_equal || id == ID_ieee_float_notequal)
  {
    bool can_be_equal;
    bool can_be_notequal;

    if(id == ID_equal || id == ID_notequal)
      assert(itv1.type != itvt::FLOAT);
    else
      assert(itv1.type == itvt::FLOAT);


    itvt tmp = itv1;
    tmp.meet(itv2);

    can_be_equal = 
      !tmp.is_bot() || 
      (itv1.contains_zero() && itv2.contains_zero());
    
    can_be_notequal = 
      !itv1.eq(itv2) || 
      (!itv1.is_singleton() &&
       !(itv1.type == itvt::FLOAT && 
         itv1.is_zero())); //special case -0.0f, 0.0f

    bool equality = (id == ID_equal || id == ID_ieee_float_equal);
    
    can_be_true = (equality)  ? can_be_equal : can_be_notequal;
    can_be_false = (equality) ? can_be_notequal : can_be_equal;
  } 
  else if(id == ID_gt || id == ID_ge || id == ID_le || id == ID_lt) 
  {
    bool can_be_gt, can_be_ge, can_be_lt, can_be_le;

    switch(itv1.type)
    {
      case itvt::INTBV:
        can_be_gt = itv1.i().upper() > itv2.i().lower();
        can_be_ge = itv1.i().upper() >= itv2.i().lower();
        can_be_lt = itv1.i().lower() < itv2.i().upper();
        can_be_le = itv1.i().lower() <= itv2.i().upper();
        break;

      case itvt::FLOAT:
        can_be_gt = itv1.f().upper() > itv2.f().lower();
        can_be_ge = itv1.f().upper() >= itv2.f().lower();
        can_be_lt = itv1.f().lower() < itv2.f().upper();
        can_be_le = itv1.f().lower() <= itv2.f().upper();
        break;

      default:
        //should never reach here, since top / bot values are handled above
        assert(0); 
        break;
    }


    if(id == ID_gt)
    {
      can_be_true = can_be_gt;
      can_be_false = can_be_le;
    } 
    else if(id == ID_ge) 
    {
      can_be_true = can_be_ge;
      can_be_false = can_be_lt;
    } 
    else if(id == ID_lt)
    {
      can_be_true = can_be_lt;
      can_be_false = can_be_ge;
    } 
    else if(id == ID_le)
    {
      can_be_true = can_be_le;
      can_be_false = can_be_gt;
    } else assert(0);
  } 
  else 
  {
    can_be_true = true;
    can_be_false = true;
  }

  mp_integer upper, lower;
  lower = can_be_false ? 0 : 1;
  upper = can_be_true ? 1 : 0;
  
  result->i().set(lower, upper);
  assert(!result->is_bot());

  return new_elem(result.release());
}


abstr_elementt interval_var_domaint::fwd_interpret_bool(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  const irep_idt& id = op.id();
  bool can_be_true;
  bool can_be_false;
  
  
  if(id == ID_not || id == ID_typecast) {
    assert(op_values.size() == 1);
    const itvt& itv = read(op_values.front());

    switch(itv.type)
    {
      case itvt::INTBV:
        can_be_false = itv.i().contains(itv.i().zero());
        can_be_true = !itv.i().is_bot() && 
                      !(can_be_false && itv.i().is_singleton());
        break;
      case itvt::FLOAT:
        can_be_false = itv.f().contains(itv.f().zero());
        can_be_true = !itv.f().is_bot() && 
                      !(itv.f().lower().is_zero() && itv.f().upper().is_zero());
        break;
      case itvt::OTHER:
        can_be_false = can_be_true = true;
        break;
      default: 
        throw "impossible";
    }

    if(id == ID_not)
    {
      std::swap(can_be_false, can_be_true);
    }

  } 
  else if(id == ID_and) 
  {
    can_be_true = true;
    can_be_false = false;
    forall_abstr_elements(it, op_values)
    {
      const itvt& i = read(*it);
      can_be_true = can_be_true && !i.is_zero();
      can_be_false = can_be_false || i.contains_zero();
    }
  } 
  else if(id == ID_or) 
  {
    can_be_true = false;
    can_be_false = true;
    forall_abstr_elements(it, op_values)
    {
      const itvt& i = read(*it);
      can_be_true = can_be_true || !i.is_zero();
      can_be_false = can_be_false && i.contains_zero();
    }

  }  
  else if(op.operands().size() == 2)
  {
    return fwd_interpret_bool_binary(op, op_values);
  }
  else
  {
    can_be_true = can_be_false = true;
  }
  
  std::auto_ptr<itvt> result = std::auto_ptr<itvt>(new itvt(op.type(), rounding_mode));
  result->i().set(
    can_be_false ? result->i().zero() : result->i().one(), 
    can_be_true  ? result->i().one()  : result->i().zero());
  
  return new_elem(result.release());
}



abstr_elementt interval_var_domaint::fwd_interpret_float(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  const irep_idt& id = op.id();

  if(id == ID_plus || id == ID_minus || id == ID_mult || 
     id == ID_div  || 
     id == ID_unary_minus || id == ID_unary_plus) 
  {
    return fwd_interpret_float_arith(op, op_values);
  } 

  else if(id == ID_typecast)  
  {
    return fwd_interpret_float_typecast(op, op_values);
  } 

  else if(id == ID_constant) 
  {
    return fwd_interpret_float_constant(op, op_values);
  } 
  
  else {
    return top(op.type());
  }
}

#define REDUCE_ELEMENTS_INTBV(it, list, result, func) \
  assert(list.size() > 0); \
(result) = read(list.front()).i(); \
for(abstr_elementst::const_iterator it = ++(list).begin();\
    it != (list).end(); ++it)  \
{ (result). func (read(*it).i()) ; }


abstr_elementt interval_var_domaint::fwd_interpret_int_arith(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  intbv_intervalt &i = (*itv).i();
  

  const irep_idt& id = op.id();

  if(id == ID_plus) {
    REDUCE_ELEMENTS_INTBV(it, op_values, i, operator+=);
  } else if(id == ID_minus) {
    REDUCE_ELEMENTS_INTBV(it, op_values, i, operator-=);

  } else if(id == ID_mult) {
    //special treatment of squares
    if(op.operands().size() == 2 && op.op0() == op.op1())
    {
      i = read(op_values.front()).i();
      assert(i.eq(read(op_values.back()).i()));
      i.square();
    } else {
      REDUCE_ELEMENTS_INTBV(it, op_values, i, operator*=);
    }
  } else if(id == ID_div) {
    assert(op_values.size() == 2);
    REDUCE_ELEMENTS_INTBV(it, op_values, i, operator/=);
  } else if(id == ID_mod) {
    assert(op_values.size() == 2);
    REDUCE_ELEMENTS_INTBV(it, op_values, i, operator%=);

  } else if(id == ID_unary_plus) {
    return op_values.front();

  } else if(id == ID_unary_minus) {
    assert(op_values.size() == 1);
    i = -read(op_values.front()).i();

  }

  return new_elem(itv.release());
}


#define REDUCE_ELEMENTS_FLOAT(it, list, result, func) \
  assert(list.size() > 0); \
(result) = read(list.front()).f(); \
for(abstr_elementst::const_iterator it = ++(list).begin();\
    it != (list).end(); ++it)  \
{ (result). func (read(*it).f()) ; }

abstr_elementt interval_var_domaint::fwd_interpret_float_arith(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  float_intervalt &f = (*itv).f();

  const irep_idt& id = op.id();

  if(id == ID_plus) {
    REDUCE_ELEMENTS_FLOAT(it, op_values, f, operator+=);

  } else if(id == ID_minus) {
    REDUCE_ELEMENTS_FLOAT(it, op_values, f, operator-=);

  } else if(id == ID_mult) {
    //special treatment of squares
    if(op.operands().size() == 2 && op.op0() == op.op1())
    {
      f = read(op_values.front()).f();
      assert(f.eq(read(op_values.back()).f()));
      f.square();
    } else {
      REDUCE_ELEMENTS_FLOAT(it, op_values, f, operator*=);
    }
  } else if(id == ID_div) {
    assert(op_values.size() == 2);
    REDUCE_ELEMENTS_FLOAT(it, op_values, f, operator/=);

  } else if(id == ID_mod) {
    assert(op_values.size() == 2);
    REDUCE_ELEMENTS_FLOAT(it, op_values, f, operator%=);

  } else if(id == ID_unary_plus) {
    return op_values.front();

  } else if(id == ID_unary_minus) {
    assert(op_values.size() == 1);
    f = -read(op_values.front()).f();
  }

  return new_elem(itv.release());

}


abstr_elementt interval_var_domaint::fwd_interpret_float_typecast(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  assert(op.type().id() == ID_floatbv && op.id() == ID_typecast);

  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  float_intervalt &f = (*itv).f();

  const typet& src_type = op.op0().type();
  const itvt& op_val = read(op_values.front());

  if(src_type.id() == ID_floatbv)
  {
    assert(op_val.type == itvt::FLOAT);
    f = op_val.f();
    f.change_type(to_floatbv_type(op.type()));
    return new_elem(itv.release());

  } else if(src_type.id() == ID_signedbv ||
            src_type.id() == ID_unsignedbv ||
            src_type.id() == ID_bool) 
  {
    assert(op_val.type == itvt::INTBV);
    const intbv_intervalt& i = op_val.i();
    if(i.is_bot())
    {
      f.set_bot();
      return new_elem(itv.release());
    } else if(i.is_top())
    {
      f.set_top();
      return new_elem(itv.release());
    }
    
    ieee_floatt new_l = f.lower_or_infty();
    ieee_floatt new_u = f.upper_or_infty();

    new_l.from_integer(i.lower());
    new_u.from_integer(i.upper());
    
    f.set(new_l,new_u);
    return new_elem(itv.release());
  } else return top(op.type());
}

abstr_elementt interval_var_domaint::fwd_interpret_float_constant(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  assert(op.type().id() == ID_floatbv && op.id() == ID_constant);
  
  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  float_intervalt &f = (*itv).f();
  
  f.change_type(to_floatbv_type(op.type())); 
  ieee_floatt c;
  c.from_expr(op);

  f.set(c,c);
  
  return new_elem(itv.release());
}


abstr_elementt interval_var_domaint::fwd_interpret_int_typecast(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  intbv_intervalt &i = (*itv).i();

  if( op.op0().type().id() == ID_unsignedbv ||
      op.op0().type().id() == ID_signedbv  || 
      op.op0().type().id() == ID_bool)
  {
    //casts from int and bool
    assert(op_values.size() == 1);
    const itvt& op_val = read(op_values.front());
    assert(op_val.type == itvt::INTBV);
    i = op_val.i();
    i.set_bv_bounds(op.type());
  } 
  else if( op.op0().type().id() == ID_floatbv)
  {
    const itvt& op_val = read(op_values.front());
    assert(op_val.type == itvt::FLOAT);

    if(op_val.f().is_top())
      return new_elem(itv.release()); // do nothing

    if(op_val.f().lower().is_infinity() ||
       op_val.f().upper().is_infinity())
      return new_elem(itv.release()); // do nothing

    mp_integer lower = op_val.f().lower().to_integer();
    mp_integer upper = op_val.f().upper().to_integer();
  
    if(lower < i.get_min() ||
       upper > i.get_max())
      return new_elem(itv.release()); // do nothing

    i.set(lower, upper);
    
    return new_elem(itv.release()); // do nothing

  } 
  else
  {
    //other casts return top
  }

  return new_elem(itv.release());
}


abstr_elementt interval_var_domaint::fwd_interpret_int_constant(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  std::auto_ptr<itvt> itv(new itvt(op.type(), rounding_mode)); 
  intbv_intervalt &i = (*itv).i();

  assert(op_values.size() == 0);

  mp_integer val;
  if(to_integer(op, val))
    throw "could not parse bitvector constant: " + op.to_string();
  i.set(val,val);

  return new_elem(itv.release());
}


bool interval_var_domaint::fwd_interpret_int_bitwise_xor(
      intbv_intervalt& result,
      const intbv_intervalt& op1, 
      const intbv_intervalt& op2)
{
  if(op2.is_singleton() && op2.lower() == 1)
  {
    //case of xor with 1
    
    mp_integer l = op1.lower();
    if(op1.lower().is_odd()) 
    {
      l = op1.lower() - 1;
      if(op1.is_singleton())
      {
        result.set(l, l);
        return true;
      }
    }

    mp_integer u = op1.upper();
    if(op1.upper().is_even())
    {
      u = op1.upper() + 1;
      if(op1.is_singleton())
      {
        result.set(u, u);
        return true;
      }
    }

    result.set(l, u);
    return true;
    
  }

  return false;
}


abstr_elementt interval_var_domaint::fwd_interpret_int_bitwise(
    const exprt& op, 
    const abstr_elementst& op_values)
{
  const irep_idt& id = op.id();
  std::auto_ptr<itvt> r(new itvt(op.type(), rounding_mode));

  if(id == ID_bitnot)
  {
    return top(op.type());
  }

  assert(op_values.size() == 2);
  const intbv_intervalt& i1 = read(op_values.front()).i();
  const intbv_intervalt& i2 = read(op_values.back()).i();

  if(id == ID_bitand)
  {
    return top(op.type());
  } 
  
  else if(id == ID_bitor) 
  {
    return top(op.type());
  }

  else if(id == ID_bitxor)
  {
    //handle special case of xor with 1
    if(fwd_interpret_int_bitwise_xor(r->i(), i1, i2))
      return new_elem(r.release());

    if(fwd_interpret_int_bitwise_xor(r->i(), i2, i1))
      return new_elem(r.release());

    return top(op.type());
  }

  else assert(0);

}

