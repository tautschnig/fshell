/*******************************************************************\

Module: Disequality domain with some array support

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ARRAY_DISEQUALITY_DOMAIN_H
#define ARRAY_DISEQUALITY_DOMAIN_H

#include "disequality_domain.h"
#include "../array_struct_emulator.h"

class array_diseq_domaint : public disequality_domaint
{
public:
  typedef disequality_domaint sub;

  array_diseq_domaint(array_struct_emulatort& emulator) 
    : emul(emulator) { } 

  virtual ~array_diseq_domaint() { } 

  virtual exprt to_expr(const abstr_elementt& a);

  virtual abstr_valt fwd_interpret(const exprt& e);

  //special handling for array accesses
  virtual void apply_assign_inplace(
      disequality_elementt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  //return handling for array accesses
  virtual void apply_test_inplace(
      disequality_elementt& a, 
      const exprt& e,
      bool result);

 
protected:
  array_struct_emulatort& emul;

  void replace_address_of_index(exprt& e);
};

#endif
