/*******************************************************************\

Module: Union find with some extra functions (should be merged into 
        the codebase)
        
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef UNION_FIND_EXT_H
#define UNION_FIND_EXT_H

#include <union_find.h>

class unsigned_union_find_extt : public unsigned_union_find 
{
public:
  //find + set parent of found element to root
  // => increases speed of subsequent lookups
  unsigned find_fast(unsigned nr);

  bool leq(unsigned_union_find_extt& uuf);
  
};

#endif
