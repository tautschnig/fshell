#include "union_find_ext.h"


bool
unsigned_union_find_extt::leq(unsigned_union_find_extt& uuf) 
{
  for(unsigned i = 0; i < uuf.nodes.size(); i++)
  {
    unsigned root = uuf.find_fast(i);
    if(find_fast(i) != find_fast(root))
      return false;
  }

  return true;
}

unsigned unsigned_union_find_extt::find_fast(unsigned nr) 
{
  if(nr >= size()) return nr;
  if(nodes[nr].root) 
    return nr;
  else 
    return (nodes[nr].parent = find_fast(nodes[nr].parent));
}


