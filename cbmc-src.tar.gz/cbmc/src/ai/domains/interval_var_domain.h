/*******************************************************************\

Module: Domain of interval variable values
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef INTERVAL_VAR_DOMAIN_H
#define INTERVAL_VAR_DOMAIN_H

#include "../abstr_env.h"
#include "../abstr_domain_mem.h"

#include "itv.h"

class interval_var_domaint : public abstr_domain_memt<itvt>, 
                             public abstr_var_domaint
{
public:
  interval_var_domaint(ieee_floatt::rounding_modet r) 
    : rounding_mode(r) { } 

  ieee_floatt::rounding_modet get_rounding_mode()
  { return rounding_mode; }
  
  //supports signed, unsigned, float symbols, and bool
  virtual bool supports_type(const typet& t) 
  { return t.id() == ID_signedbv ||
           t.id() == ID_unsignedbv ||
           t.id() == ID_floatbv || 
           t.id() == ID_bool; }
  
  abstr_elementt from_itv(const itvt& itv)
  {
    return new_elem(new itvt(itv));
  }

  virtual abstr_elementt top(const typet& t);
  virtual abstr_elementt bot(const typet& t);

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  virtual abstr_elementt get_initial();

  virtual void meet_inplace(itvt&, const itvt& e);

  virtual void join_inplace(itvt&, const itvt& e);

  virtual void widen_inplace(
      itvt&, 
      const itvt& e, 
      const itvt& threshold);
 
  virtual std::string to_string(const abstr_elementt& a, const symbol_exprt& s);

  virtual exprt to_expr(const abstr_elementt& a, const symbol_exprt& s);

  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a);

  virtual bool is_singleton(const abstr_elementt& a);

  virtual void apply_assign_inplace(
      itvt& a, 
      const exprt& lhs, 
      const exprt& rhs)
  { throw "not supported"; }

  virtual void apply_test_inplace(
      itvt& a, 
      const exprt& e,
      bool result)
  { throw "not supported"; }

  virtual ~interval_var_domaint() { }

protected:
  ieee_floatt::rounding_modet rounding_mode;


  /* Forward interpretation functions */
  virtual abstr_elementt fwd_interpret(
      const exprt& op, 
      const abstr_elementst& op_values);
  
  virtual abstr_elementt fwd_interpret_int(
      const exprt& op, 
      const abstr_elementst& op_values);

  //C-"Booleans" are treated as 32-bit signed integers
  virtual abstr_elementt fwd_interpret_bool(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_bool_binary(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_float(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_int_arith(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_float_arith(
      const exprt& op, 
      const abstr_elementst& op_values);
 
  virtual abstr_elementt fwd_interpret_int_typecast(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_float_typecast(
      const exprt& op, 
      const abstr_elementst& op_values);
 
  virtual abstr_elementt fwd_interpret_int_constant(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_float_constant(
      const exprt& op, 
      const abstr_elementst& op_values);

  virtual abstr_elementt fwd_interpret_int_bitwise(
      const exprt& op, 
      const abstr_elementst& op_values);

  //returns true if one of the rules worked, call with op1,op2 and op2, op1
  virtual bool fwd_interpret_int_bitwise_xor(
      intbv_intervalt& result,
      const intbv_intervalt& op1, 
      const intbv_intervalt& op2);

  virtual void bwd_interpret_arith(
      const exprt& op, 
      const abstr_elementt& result, 
      abstr_elementst& op_values);

  virtual void bwd_interpret_int_typecast(
      const exprt& op, 
      const abstr_elementt& result, 
      abstr_elementst& op_values);

  virtual void bwd_interpret_float_typecast(
      const exprt& op, 
      const abstr_elementt& result, 
      abstr_elementst& op_values);



  virtual void bwd_interpret_bool(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_typecast(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_equal(
      const exprt& op, 
      abstr_elementst& op_values);

  virtual void bwd_interpret_bool_notequal(
      const exprt& op, 
      abstr_elementst& op_values);

  virtual void bwd_interpret_bool_le(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_lt(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_ge(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_gt(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_ieee_equal(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);

  virtual void bwd_interpret_bool_ieee_notequal(
      const exprt& op, 
      abstr_elementst& op_values,
      bool result);


  virtual exprt to_expr_intbv(const intbv_intervalt& a, const symbol_exprt& s);
  virtual exprt to_expr_float(const float_intervalt& a, const symbol_exprt& s);
 
};

#endif
