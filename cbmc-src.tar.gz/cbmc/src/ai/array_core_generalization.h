/*******************************************************************\

Module: Proof repair tricks for arrays on top of core 
        generalization using a SAT solver

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ARRAY_CORE_GENERALIZATION_H
#define ARRAY_CORE_GENERALIZATION_H

#include "core_generalization.h"

#include <set>

class array_core_generalizationt : virtual public core_generalizationt
{
public:
  typedef core_generalizationt sub;

  array_core_generalizationt(
      abstr_fwd_analysist& _analysis, 
      const namespacet& ns) 
  : proof_step_generalizationt(_analysis, ns),
    core_generalizationt(_analysis, ns)  { }

  virtual void generalize_step(
    const CFG_nodet& n, 
    abstr_elementt& elem,
    const id_sett& do_not_generalize)
  { sub::generalize_step(n, elem, do_not_generalize); }

  //locally repair broken proof step
  virtual void repair_step(
    const CFG_nodet&, 
    abstr_elementt& broken_pre,
    const abstr_elementt& proof,
    const id_sett& must_include);

protected:
  //find array/struct subexpressions
  void find_arrays(
    const exprt& e, 
    hash_set_cont<symbol_exprt, irep_hash>& s);

  //add boolean subexpressions over arrays with ids in src to e
  void add_invariants_by_symbol(
    const hash_set_cont<symbol_exprt, irep_hash>&, 
    const exprt& src,
    exprt& e);

  bool contains_symbol(
    const exprt& e,
    const hash_set_cont<symbol_exprt, irep_hash>&);
};

#endif 
