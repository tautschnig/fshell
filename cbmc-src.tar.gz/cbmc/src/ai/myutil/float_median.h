/*******************************************************************\

Module: Approximate the median float value in the discrete interval
        of floating point values [lower, upper]

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef FLOAT_MEDIAN_H
#define FLOAT_MEDIAN_H

#include <ieee_float.h>

/* approximate the median, infinities are treated as very large numbers */
ieee_floatt ieee_float_median(const ieee_floatt& l, const ieee_floatt& u);

/* approximate the median, infinities are treated as very large numbers */
ieee_floatt ieee_float_average(const ieee_floatt& l, const ieee_floatt& u);

#endif
