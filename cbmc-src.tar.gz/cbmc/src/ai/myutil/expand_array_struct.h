/*******************************************************************\

Module: Expand array / struct expression into a list of member 
        expressions and / or index expressions with constant indices,
        such that each resulting value has non-array / non-struct type.

        E.g., int a[4] => {a[0], a[1], a[2], a[3]

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef EXPAND_ARRAY_STRUCT_H
#define EXPAND_ARRAY_STRUCT_H

#include <expr.h>
#include <vector>

void expand_array_struct(const exprt& e, std::vector<exprt>& result);

#endif
