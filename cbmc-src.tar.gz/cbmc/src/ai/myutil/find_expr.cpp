/*******************************************************************\

Module: Find all subexpressions with a certain id

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "find_expr.h"
#include "flatten_expr.h"

void find_expr(const exprt& src, const irep_idt& id, expr_sett& dest)
{
  if(src.id() == id) 
    dest.insert(src);

  forall_operands(it, src)
  {
    find_expr(*it, id, dest);
  }
}

void get_all_subexpr(const exprt& src, expr_sett& dest)
{
  dest.insert(src);
  forall_operands(it, src)
    get_all_subexpr(*it, dest);
}

bool has_subexpr(const exprt& src, const expr_sett& pattern)
{
  if(pattern.find(src) != pattern.end())
    return true; //found

  forall_operands(it, src)
  {
    if(has_subexpr(*it, pattern))
      return true; //found subexpression
  }
  //not found
  return false;
}

bool has_subexpr(const exprt& src, const exprt& pattern)
{
  if(src == pattern)
    return true; //found

  forall_operands(it, src)
  {
    if(has_subexpr(*it, pattern))
      return true; //found subexpression
  }
  //not found
  return false;
}


void find_conjuncts(const exprt& _src, 
                    const expr_sett& pattern,
                    expr_sett& dest)
{
  exprt src = flat_expr(_src, ID_and, typet(ID_bool));
  forall_operands(it, src)
  {
    if(has_subexpr(*it, pattern))
      dest.insert(*it);
  }
}
