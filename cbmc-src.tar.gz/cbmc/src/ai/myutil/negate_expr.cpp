#include "negate_expr.h"

#include <arith_tools.h>

bool negate_expr(exprt& e)
{
  assert(e.type().id() == ID_bool);

  if(e.id() == ID_equal) 
    e.id(ID_notequal);
  else if(e.id() == ID_notequal) 
    e.id(ID_equal);
  else if(e.id() == ID_ieee_float_equal)
    e.id(ID_ieee_float_notequal);
  else if(e.id() == ID_ieee_float_notequal)
    e.id(ID_ieee_float_equal);
  else if(e.id() == ID_lt)
    e.id(ID_ge);
  else if(e.id() == ID_le)
    e.id(ID_gt);
  else if(e.id() == ID_gt)
    e.id(ID_le);
  else if(e.id() == ID_ge)
    e.id(ID_lt);
  else if(e.id() == ID_not)
    e.swap(e.op0());
  else if(e.is_true())
  {
    e.make_false();
  }
  else if(e.is_false())
  {
    e.make_true();
  }
  else if(e.id() == ID_and) {
    //de morgan
    e.id(ID_or);
    e.op0().make_not();
    e.op1().make_not();
  } else if(e.id() == ID_or) {
    e.id(ID_and);
    e.op0().make_not();
    e.op1().make_not();
  } else if(e.id() == ID_typecast && e.type().id() == ID_bool) {
    mp_integer zero(0);
    exprt zero_expr = from_integer(zero, e.op0().type());

    exprt eq = exprt(ID_equal, typet(ID_bool));
    eq.move_to_operands(e.op0());
    eq.move_to_operands(zero_expr);
    eq.swap(e);
  } else if(e.id() == ID_if) {
    e.op1().make_not();
    e.op2().make_not();
  } else {
    e.negate();
    return false;
  }
  
  return true;
}
