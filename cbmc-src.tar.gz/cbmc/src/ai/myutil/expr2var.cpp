#include "expr2var.h"

long parse_long_value(const exprt& expr)
{
  long result = 0;
  std::string value = expr.get_string("value");
  assert(value.length() <= 64);
  for(unsigned i = 0; i < value.length(); i++)
  {
    switch(value[i])
    {
      case '0':
        break; 
      case '1':
        result = result | (1l << (value.length() - 1 - i));
        break; 
      default:
        assert(0);
    }
  }

  return result;
}

int parse_int_value(const exprt& expr)
{
  int result = 0;
  std::string value = expr.get_string("value");
  assert(value.length() <= 32);
  for(unsigned i = 0; i < value.length(); i++)
  {
    switch(value[i])
    {
      case '0':
        break; 
      case '1':
        result = result | (1 << (value.length() - 1 - i));
        break; 
      default:
        assert(0);
    }
  }

  return result;
}

float parse_float(const exprt& expr)
{
  assert(expr.type().id() == "floatbv");
  assert(expr.type().get_string("width") == "32");

  int tmp = parse_int_value(expr);
  return *((float*) ((void*) &tmp));
} 

double parse_double(const exprt& expr)
{
  assert(expr.type().id() == "floatbv");
  assert(expr.type().get_string("width") == "64");

  long tmp = parse_long_value(expr);
  return *((double*) ((void*) &tmp));
  return 0;
}

int parse_int(const exprt& expr)
{ 
  assert(expr.type().id() == "signedbv");
  assert(expr.type().get_string("width") == "32");
  
  return parse_int_value(expr);
}

long parse_long(const exprt& expr)
{
  assert(expr.type().id() == "signedbv");
  assert(expr.type().get_string("width") == "64");

  return parse_long_value(expr);
}

unsigned int parse_uint(const exprt& expr)
{
  assert(expr.type().id() == "unsignedbv");
  assert(expr.type().get_string("width") == "32");

  int tmp = parse_int_value(expr);
  return *((unsigned int *) ((void*) &tmp));
}

unsigned long parse_ulong(const exprt& expr)
{
  assert(expr.type().id() == "unsignedbv");
  assert(expr.type().get_string("width") == "64");

  long tmp = parse_long_value(expr);
  return *(reinterpret_cast<unsigned long*>(&tmp));
}

