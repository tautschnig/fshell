/*******************************************************************\

Module: Find all subexpressions with a certain id

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef MYUTIL_FIND_EXPR_H
#define MYUTIL_FIND_EXPR_H

#include <hash_cont.h>
#include <expr.h>

#define forall_expr_sett(it, s) \
  for(expr_sett::const_iterator it = (s).begin(); (it) != (s).end(); ++(it))

typedef hash_set_cont<exprt, irep_hash> expr_sett;

void find_expr(const exprt& src, const irep_idt&, expr_sett& dest);

void get_all_subexpr(const exprt& src, expr_sett& dest);

bool has_subexpr(const exprt& src, const expr_sett& pattern);

bool has_subexpr(const exprt& src, const exprt& pattern);

//find all (top-level) conjuncts in src which contain a matching expression
void find_conjuncts(const exprt& src, 
                    const expr_sett& pattern,
                    expr_sett& dest);

#endif
