#ifndef __DOTIREP__
#define __DOTIREP__

#include <irep.h>
#include <iostream>
#include <string>


void dot_irep(std::ostream& os, const std::string& gr_name, const irept& irep, bool type = true);
int ps_irep(const std::string& name, const irept& irep,bool type = true);
void dot_irep(const std::string& name, const irept& irep, bool type = true);
int ps_unique_irep(const std::string& name, const irept& irep, bool type = true);


std::ostream& operator<<(std::ostream& os, const dstring& str);

#endif
