#include "split_string.h"

#include <sstream>

void split_string(
    const std::string& in, 
    char c, 
    std::vector<std::string>& out)
{
  //tokenize by ","
  std::stringstream ss(in);
  std::string token;
  while(std::getline(ss, token, c))
  {
    if(token != "")
      out.push_back(token);
  }

}
