/*******************************************************************\

Module: Get maximum and minimum bounds from integer type

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "type2bounds.h"

#include <arith_tools.h>

#include <std_types.h>
#include <limits.h>

mp_integer max_representable(const typet& t)
{
  //offset not supported yet
  assert(t.find("#offset").is_nil());
  
  static mp_integer u32max = power(mp_integer(2), 32) - 1;
  static mp_integer i32max = power(mp_integer(2), 31) - 1;

  static mp_integer u64max = power(mp_integer(2), 64) - 1;
  static mp_integer i64max = power(mp_integer(2), 63) - 1;

  bool is_signed;
  if(t.id() == ID_signedbv)
    is_signed = true;
  else if(t.id() == ID_unsignedbv)
    is_signed = false;
  else
    assert(0);

  unsigned width = to_bitvector_type(t).get_width();
  
  if(is_signed)
  {
    switch(width)
    {
      case 32:
        return i32max;
      case 64:
        return i64max;
      default:
        return power(mp_integer(2), mp_integer(width)-1) - 1;
    }
  } else {
    switch(width)
    {
      case 32:
        return u32max;
      case 64:
        return u64max;
      default:
        return power(mp_integer(2), mp_integer(width)) - 1;
    }
  }
}

mp_integer min_representable(const typet& t)
{
  assert(t.id() == ID_unsignedbv || t.id() == ID_signedbv);
  //offset not supported yet
  assert(t.find("#offset").is_nil());

  bool is_signed;
  if(t.id() == ID_signedbv)
    is_signed = true;
  else if(t.id() == ID_unsignedbv)
    is_signed = false;
  else
    assert(0);

  if(is_signed)
  {
    return -max_representable(t)-1;
  } else {
    return mp_integer(0);
  }

}
