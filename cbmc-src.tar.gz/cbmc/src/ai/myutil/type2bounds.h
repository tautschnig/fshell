/*******************************************************************\

Module: Get maximum and minimum bounds from integer type

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef TYPE2BOUNDS_H
#define TYPE2BOUNDS_H

#include <mp_arith.h>
#include <type.h>

mp_integer max_representable(const typet& t);
mp_integer min_representable(const typet& t);

#endif 
