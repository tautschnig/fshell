/*******************************************************************\

Module: Return the symbol that is being assigned to.
        Works for C programs

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef MYUTIL_GET_ASSIGNED_SYMBOL_H
#define MYUTIL_GET_ASSIGNED_SYMBOL_H

#include <std_code.h>
#include <std_expr.h>

const symbol_exprt& get_assigned_symbol(const code_assignt&);

#endif

