/*******************************************************************\

Module: Negation of Boolean expressions

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef NEGATE_EXPR_H
#define NEGATE_EXPR_H

#include <expr.h>

//return true if successful
bool negate_expr(exprt& e);

#endif
