/*******************************************************************\

Module: Split string at character

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef SPLIT_STRING_H
#define SPLIT_STRING_H

#include <string>
#include <vector>

void split_string(
    const std::string& in, 
    char c, 
    std::vector<std::string>& out);

#endif

