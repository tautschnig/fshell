/*******************************************************************\

Module: Flatten expression tree for a given type.
        E.g., AND(a,AND(b,c)) => AND(a,b,c)

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef FLATTEN_EXPR_H
#define FLATTEN_EXPR_H

#include <expr.h>

//destroys old e
void make_flat(exprt& e, const irep_idt& id, const typet& t);

exprt flat_expr(const exprt& e, const irep_idt& id, const typet& t);

#endif
