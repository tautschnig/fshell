/*******************************************************************\

Module: Flatten expression tree for a given type.
        E.g., AND(a,AND(b,c)) => AND(a,b,c)

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "flatten_expr.h"

void make_flat_aux(
    exprt& e, 
    exprt& result, 
    const irep_idt& id, 
    const typet& t)
{
  if(e.id() == id)
  {
    assert(t == e.type());
    Forall_operands(it, e)
      make_flat_aux(*it, result, id, t);
  } else {
    result.move_to_operands(e);
  }
}

void make_flat(
    exprt& e, 
    const irep_idt& id, 
    const typet& t)
{
  exprt result(id, typet(t));

  make_flat_aux(e, result, id, t);

  result.swap(e);
}

exprt flat_expr(const exprt& e, const irep_idt& id, const typet& type)
{
  exprt copy(e);
  make_flat(copy, id, type);
  return copy;
}
