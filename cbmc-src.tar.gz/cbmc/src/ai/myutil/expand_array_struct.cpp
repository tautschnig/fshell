/*******************************************************************\

Module: Expand array / struct expression into a list of member 
        expressions and / or index expressions with constant indices,
        such that each resulting value has non-array / non-struct type.

        E.g., int a[4] => {a[0], a[1], a[2], a[3]

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "expand_array_struct.h"

#include <arith_tools.h>
#include <std_types.h>
#include <std_expr.h>


/*******************************************************************\

Function: expand_array_struct
 
  Inputs: Expression of type array (constant, non-infty size) or struct

 Outputs: 

 Purpose:

\*******************************************************************/

void expand_array_struct(const exprt& e, std::vector<exprt>& result)
{
  if(e.type().id() == ID_array) 
  {
    //get size
    exprt size_expr = to_array_type(e.type()).size();
    mp_integer size; 
    bool failed = to_integer(size_expr, size);
    assert(!failed && size > 0);
    for(mp_integer i = 0; i < size; ++i)
    {
      //recursively expand all indices
      exprt index_constant = from_integer(i, size_expr.type());
      index_exprt index_expr(e, index_constant);
      expand_array_struct(index_expr, result);
    }
  } 
  else if(e.type().id() == ID_struct) 
  {
    const struct_typet& t = to_struct_type(e.type());

    for(struct_union_typet::componentst::const_iterator it = 
          t.components().begin();
        it != t.components().end(); 
        it++)
    {
      //recursively expand all components
      const irep_idt& component_name = it->get_name();
      member_exprt m(e, component_name);
      m.type() = it->type();

      expand_array_struct(m, result);
    }
  }
  else 
  {
    result.push_back(e);
  } 

}
