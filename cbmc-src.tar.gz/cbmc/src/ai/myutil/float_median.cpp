#include "float_median.h"

#include <arith_tools.h>

//#define DEBUG_MODE

#ifdef DEBUG_MODE
void check_result(const ieee_floatt& r, const ieee_floatt& l, const ieee_floatt& u, unsigned counter)
{
  assert(!l.is_NaN() && !r.is_NaN() && !u.is_NaN());

  if(!((l <= r && r <= u) || 
      (l >= r && r >= u)))
  { 
    std::cout << "median out of range: " << l << " <= " << r << " <= " << u
              << std::endl;

    std::cout << "counter: " << counter << std::endl;
    
    std::cout << "----- l: " << l.to_expr() << std::endl;
    std::cout << "----- r: " << r.to_expr() << std::endl;
    std::cout << "----- u: " << u.to_expr() << std::endl;

    assert(0);
  }

}
#endif //DEBUG_MODE

/*******************************************************************\

Function: ieee_float_median
 
  Inputs:

 Outputs:

 Purpose: This return a rough approximation of the median. Useful
          for binary search on floats. Results are always nudged
          towards the smaller of the two numbers, i.e.,
          if one of the inputs is larger than the other, it will 
          never be returned as a result.

\*******************************************************************/

ieee_floatt ieee_float_median(const ieee_floatt& _l, const ieee_floatt& _u)
{
  ieee_floatt l = _l,u = _u;
  static unsigned counter = 0;
  counter ++;

  //do not want
  if(l.is_NaN() || u.is_NaN())
  {
    l.make_NaN();
    return l;
  }

 
  //if one of them is zero, make signs equal
  if(l.is_zero() && l.get_sign() != u.get_sign())
    l.negate();

  if(u.is_zero() && l.get_sign() != u.get_sign())
    u.negate();
 
  if(l == u)
    return l;

  //if the signs differ split at zero
  if(l.get_sign() != u.get_sign())
  {
    l.make_zero();
    return l;
  }

  //if they are just one apart, return smaller one
  ieee_floatt ltpp = l < u ? l : u;
  ltpp.increment();
  if(ltpp == (l < u ? u : l))
    return l < u ? l : u;

  //both are infinity, return infinity
  if(l.is_infinity() && u.is_infinity())
    return l;

  assert(l.spec == u.spec);
  const ieee_float_spect& spec = l.spec;

  //nudge inputs away from infinity
  if(l.is_infinity())
    l.next_representable(l.get_sign());

  if(u.is_infinity())
    u.next_representable(u.get_sign());

  bool sign = l.get_sign();
  
  //make numbers positive
  if(sign)
  {
    l.negate();
    u.negate();
  }

  //choose l closer to zero
  if(u < l)
  {
    std::swap(u,l);
  }

    //get some useful fractions
  mp_integer min_normal_frac = 
    power(2, l.spec.f);
  mp_integer max_normal_frac = 
    power(2, l.spec.f+1)-1;
  mp_integer max_denormal_frac =
    min_normal_frac - 1;

  //get exponents and fractions
  mp_integer l_e = l.get_exponent();
  mp_integer l_f = l.get_fraction();
  mp_integer u_e = u.get_exponent();
  mp_integer u_f = u.get_fraction();

  //result
  mp_integer r_e;
  mp_integer r_f;
  
  //normalize representation
  if(l_f < min_normal_frac && l_f != 0)
  { //l denormal
    l_f += min_normal_frac;
    --l_e;
  } 

  if(u_f < min_normal_frac && u_f != 0)
  { //u denormal
    u_f += min_normal_frac;
    --u_e;
  } 
    
  //case where one is zero
  if(l.is_zero() || u.is_zero())
  {
    mp_integer nz_f, nz_e;
    if(l.is_zero())
    {
      nz_f = u_f;
      nz_e = u_e;
    } else {
      nz_f = l_f;
      nz_e = l_e;
    }
      
    //is exponent already minimal ? 
    if(nz_e != -spec.bias())
    {
      //not yet minimal, bring closer to minimal 
      r_e = (-spec.bias() + nz_e) / 2;

      if(r_e == nz_e)
        --r_e;
      
      r_f = min_normal_frac;
      r_f += r_f/2; //middle fraction
    } else {
      //exponent is minimal, bring fraction closer to min fraction
      r_e = nz_e;
      r_f = (min_normal_frac + nz_f) / 2;
      if(r_f == nz_f)
        --r_f; 
    }
  } else {
    //no zeroes 

    //check if exponents differ
    if(l_e != u_e)
    {   
      //exponents are not equal, choose average exponent
      r_e = (l_e + u_e) / 2;

      if(r_e == u_e) 
      {
        //make fraction minimal so we get closer to zero (and hence to l)
        r_f = min_normal_frac;

        if(r_f == u_f) //nudge away from upper, let's jump to the next exp
          --r_f;  
      } 
      else if(r_e == l_e)
      {
        //make fraction maximal so we get away from zero (and hence to u)
        r_f = max_normal_frac;
        
        if(r_f == l_f) //nudge and jump to next exp like there's no tomorrow
          ++r_f;
      }
      else 
      {
        //new exponent, choose minimum fraction (for kicks)
        r_f = min_normal_frac;
      }

    } else {
      //exponents are equal, choose average fraction
      r_f = (l_f + u_f) / 2;
      r_e = l_e;
    }
  }

  //denormalize representation
  if(r_e == -spec.bias())
  {
    ++r_e;
    r_f -= min_normal_frac;
  }

  //for some reason we have to subtract spec.f before calling build
  ieee_floatt result(spec);
  result.build(r_f,r_e - spec.f);
  assert(result.get_sign() == false);

  //adjust sign
  if(sign)
    result.negate();

  //nudge towards to smaller number if necessary
  if(_u < _l)
  {
    if(_l == result)
      result.decrement();
  } else if(_l < _u) {
    if(_u == result)
      result.decrement();
  }

#ifdef DEBUG_MODE
  check_result(result, _l, _u, counter);
#endif 
  
  return result;
}

ieee_floatt ieee_float_average(const ieee_floatt& a, const ieee_floatt& b)
{
  assert(!a.is_NaN() && !b.is_NaN());
  
  ieee_floatt result, l, u;

  if(a < b)
  {
    l = a;
    u = b;
  }
  else
  {
    l = b;
    u = a;
  }

  if(l == u)
    return l;

  if(l.get_sign() && l.is_infinity())
    l.increment();

  if(!u.get_sign() && u.is_infinity())
    u.decrement();
  
  {
    //if they are only one apart return the smaller one
    ieee_floatt lplus = l;
    lplus.increment();
    if(lplus == u)
      return l;
  }
  
  ieee_floatt two;
  two.from_float(2.0f);

  if(l.get_sign() == u.get_sign())
  {
    ieee_floatt diff = l;
    diff-=u;
    diff/=two;
    if(diff.get_sign()) diff.negate();
    result = l;
    result += diff;
  } else {
    result = l;
    result+= u;
    result/=two;
  }

  return result;
}
