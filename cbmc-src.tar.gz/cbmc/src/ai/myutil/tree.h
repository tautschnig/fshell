/*******************************************************************\

Module: Tree datastructure 
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_DOMAIN_TREE_H
#define ABSTR_DOMAIN_TREE_H

#include <vector>

template <class elemT>
class treet
{
public:
  elemT* value;
  
  typedef std::vector<treet*> tree_ptrst;
  tree_ptrst children;

  treet(const elemT* elem) : value(elem) { }

  //destroys children
  treet(const elemT* elem, tree_ptrst& _children)
    : value(elem) { children.swap(_children); }

  ~treet() 
  {
    delete value;
    for(unsigned i = 0; i < children.size(); i++)
      delete children[i];
  }

};

#endif 
