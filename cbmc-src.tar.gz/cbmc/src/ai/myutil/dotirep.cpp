#include "dotirep.h"
#include <deque>
#include <set>
#include <fstream>
#include <map>
#include <sstream>

#include <stdlib.h>

using namespace std;

string filter_string(const string& str)
{
  string ret;
  ret.reserve(str.length());
  for(unsigned i = 0; i < str.length(); i++)
  {
    switch(str[i])
    {
      case '"':
        ret.push_back('\\');
        ret.push_back('"');
        break;
      case '\\':
        ret.push_back('\\');
        ret.push_back('\\');
        break;
      case '\n':
        ret.push_back('\\');
        ret.push_back('n');
        break;
      default:
        ret.push_back(str[i]);
    }
  }
  return ret;
}

void dot_irep(ostream& os, const string& gr_name, const irept& irep, bool type)
{
  os << "digraph \"" << gr_name << "\" {" << endl;
  set<const irept*>  visited;
  deque<const irept*> wklst;
  wklst.push_back(&irep);
  while(!wklst.empty())
  {
    const irept* curr = wklst.front();
    wklst.pop_front();
    if(!visited.insert(curr).second)
     continue;

    os << "\"" << curr << "\" [label=\""<< filter_string(curr->id().as_string()) << "\"];" << endl;

    // Named sub
    const irept::named_subt& ns = curr->get_named_sub();
    for(irept::named_subt::const_iterator nsit = ns.begin();
      nsit != ns.end(); nsit++)
    {
      if(nsit->first.as_string() == "type" && !type) continue;
       os << "\"" << curr << "\" -> \""<< &(nsit->second)
       << "\" [label=\"" <<  filter_string(nsit->first.as_string()) <<  "\"];" << endl;
       wklst.push_back(&(nsit->second));
    }

#if 1
    // Comments
    const irept::named_subt& cm = curr->get_comments();
    for(irept::named_subt::const_iterator cmit = cm.begin();
      cmit != cm.end(); cmit++)
    {
       os << "\"" << curr << "\" -> \""<< &(cmit->second)
       << "\" [label=\"" <<  filter_string(cmit->first.as_string()) <<  "\"];" << endl;
       wklst.push_back(&(cmit->second));
    }
#endif

    // Unamed sub
    const irept::subt& s = curr->get_sub();
    for(unsigned i = 0; i < s.size(); i++)
    {
       os << "\"" << curr << "\" -> \""<< &(s[i])
       << "\" [label=\"" <<  i <<  "\"];" << endl;
       wklst.push_back(&(s[i]));
    }

  }

  os <<"}"<< endl;
}

void dot_irep(const string& name, const irept& irep, bool type)
{
  ofstream doto;
  doto.open((name+ ".dot").c_str());
  dot_irep(doto, "gr", irep, type);
  doto.close();
}


int ps_irep(const string& name, const irept& irep, bool type)
{
  ofstream doto;
  doto.open((name+ ".dot").c_str());
  dot_irep(doto, "gr", irep, type);
  doto.close();
  string cmd = "dot -Gsize=\"11.7,8.3\" -Tps " + name + ".dot > " + name + ".ps";
  return system(cmd.c_str());
}


int ps_unique_irep(const string& name, const irept& irep, bool type)
{
  static map<string,unsigned> versionmap;

  stringstream ss;
  ss << (versionmap[name]++);
  string version;
  ss >> version;
  string unique_name = name +".~"+version;

  ofstream doto;
  doto.open((unique_name+ ".dot").c_str());
  dot_irep(doto, "gr", irep, type);
  doto.close();
  string cmd = "dot -Gsize=\"7.5,10.5\" -Tps " + unique_name + ".dot > " + unique_name + ".ps";
  return system(cmd.c_str());
}
