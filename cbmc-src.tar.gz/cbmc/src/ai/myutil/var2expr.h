#ifndef VAR2EXPR_H
#define VAR2EXPR_H 

#include <expr.h>

//parse expressions representing constants into various formats

exprt float2expr(float f);

exprt double2expr(double f);

exprt int2expr(int i);

exprt long2expr(long i);

exprt uint2expr(unsigned i);

exprt ulong2expr(unsigned long i);


#endif
