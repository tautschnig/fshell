/*******************************************************************\

Module: Convert exprt constants into c-types 

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/


#ifndef EXPR2VAR_H
#define EXPR2VAR_H

#include <expr.h>

//parse expressions representing constants into various formats

float parse_float(const exprt& expr);
double parse_double(const exprt& expr);

int parse_int(const exprt& expr);
long parse_long(const exprt& expr);

unsigned int parse_uint(const exprt& expr);
unsigned long parse_ulong(const exprt& expr);


#endif
