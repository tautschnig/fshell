/*******************************************************************\

Module: Return the symbol that is being assigned to.
        Works for C programs

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "get_assigned_symbol.h"

const symbol_exprt& aux(const exprt& e)
{
  if(e.id() == ID_member)
  {
    return aux(to_member_expr(e).struct_op());
  } else if(e.id() == ID_index)
  {
    return aux(to_index_expr(e).array());
  } else if(e.id() == ID_symbol)
  {
    return to_symbol_expr(e); 
  }else 
  {
    throw "get_assigned_symbol: not supported " + e.id_string() ;
  }
}

const symbol_exprt& get_assigned_symbol(const code_assignt& assign)
{
  return aux(assign.lhs());
}
