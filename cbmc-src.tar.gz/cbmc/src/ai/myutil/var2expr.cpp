#include "var2expr.h"

#include "ansi-c/literals/convert_float_literal.h"
#include "ansi-c/literals/convert_integer_literal.h"

#include <std_types.h>
#include <std_expr.h>

#include <config.h>

#include <sstream>

bool init_ansi_c = false;

void init_config()
{
  if(init_ansi_c) return;
 
  config.ansi_c.set_32(); 

  init_ansi_c = true;
}

exprt float2expr(float f) 
{
  init_config();
  std::stringstream s;

  s << f;
  if(s.str().find('.') != std::string::npos)
  {
    //no decimal point
    s << ".0";
  }
  s << "f";

  return convert_float_literal(s.str());
}

exprt double2expr(double f) 
{
  init_config();
  std::stringstream s;

  s << f;
  if(s.str().find('.') != std::string::npos)
  {
    //no decimal point
    s << ".0";
  }
 
  return convert_float_literal(s.str());
}

exprt int2expr(int i)
{
  init_config();
  std::stringstream s;

  s << i;
  
  return convert_integer_literal(s.str(), 10);
}

exprt long2expr(long i)
{
  init_config();
  std::stringstream s;

  s << i << "l";
  
  return convert_integer_literal(s.str(), 10);
}

exprt uint2expr(unsigned i) 
{
  init_config();
  std::stringstream s;

  s << i << "u";
  
  return convert_integer_literal(s.str(), 10);
}

exprt ulong2expr(unsigned long i)
{
  init_config();
  std::stringstream s;

  s << i << "ul";
  
  return convert_integer_literal(s.str(), 10);
}


