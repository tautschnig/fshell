/*******************************************************************\

Module: Recursively resolve all symbol types using namespace
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "resolve_types.h"

#include <irep_ids.h>
#include <std_types.h>

void resolve_types(exprt& e, const namespacet& ns)
{
  if(e.type().id() == ID_symbol)
  {
    typet new_type = ns.follow(e.type());
    e.type().swap(new_type);
  }

  if(e.type().id() == ID_struct)
  {
    //resolve types
    struct_typet& t = to_struct_type(e.type());
    for(struct_typet::componentst::iterator it = t.components().begin();
        it != t.components().end(); it++)
    {
      resolve_types(*it, ns);
    }
  }

  Forall_operands(it, e)
    resolve_types(*it, ns);
}
