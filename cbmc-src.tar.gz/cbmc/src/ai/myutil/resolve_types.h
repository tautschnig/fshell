/*******************************************************************\

Module: Recursively resolve all "symbol" type references using namespace
Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef RESOLVE_TYPES_H
#define RESOLVE_TYPES_H

#include <expr.h>
#include <namespace.h>

void resolve_types(exprt& e, const namespacet& ns);

#endif 
