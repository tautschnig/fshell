/*******************************************************************\

Module: BMC with additional interval constraints.
        All assigned variables are constrained to value ranges
        given by invariants.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "itv_invar_bmc.h"
#include <std_expr.h>
#include <message_stream.h>
#include <time_stopping.h>

#include <ansi-c/expr2c.h>

#include <sstream>

itv_invar_bmct::itv_invar_bmct(
  const CFGt& cfg, 
  message_handlert& mh,
  const optionst& _options,
  const symbol_sett& _constrain_vars)
  : bmct(cfg.context, mh), 
    constrain_vars(_constrain_vars),
    cfg(cfg), 
    aux_symbol_counter(0), bv_cbmc(ns, satcheck)
{
  options = _options;
  std::cout << "creating instrumented goto-program for bmc" << std::endl;

  //create new goto_functiont
  goto_functionst::goto_functiont& goto_function = 
    goto_functions.function_map[goto_functions.main_id()];
  goto_programt& goto_program = goto_function.body;

  //create goto program
  cfg.to_goto_program(goto_program);
  goto_function.body_available = true;

  std::cout << "symbolically executing goto-program" << std::endl;

  symex.set_message_handler(get_message_handler());
  symex.set_verbosity(get_verbosity());
  symex.options=options;

  symex.last_location.make_nil();

  try
  {
    // get unwinding info
    setup_unwind();

    symex(goto_functions);
  } 

  catch(std::string &error_str)
  {
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
  }
  
  std::cout << "translating to SAT" << std::endl;
  equation.convert(bv_cbmc);

  for(symbol_sett::const_iterator it = constrain_vars.begin();
      it != constrain_vars.end(); ++it)
  {
    const symbol_exprt& s = *it;
    //check whether all expected symbols have been converted  
    if(!check_converted(to_first_ssa(s)))
    {
      std::cout << "*** WARNING: SSA VARIABLE " << to_first_ssa(s).to_string()
                << " DOES NOT OCCUR IN EQUATION" << std::endl;
    }
    //now create constraints to control these variables
    symbol_exprt en_ub = new_aux_symbol("enable_upper", typet(ID_bool));
    symbol_exprt en_lb = new_aux_symbol("enable_lower", typet(ID_bool));
    enable_upper[s] = en_ub;
    enable_lower[s] = en_lb;

    symbol_exprt ub = new_aux_symbol("upper_bound", s.type());
    symbol_exprt lb = new_aux_symbol("lower_bound", s.type());
    upper_bounds[s] = ub;
    lower_bounds[s] = lb;

    binary_relation_exprt lb_expr(lb, ID_le, to_first_ssa(s));
    binary_relation_exprt ub_expr(ub, ID_ge, to_first_ssa(s));

    //convert
    implies_exprt i1(en_lb, lb_expr);
    implies_exprt i2(en_ub, ub_expr);

    upper_bound_exprs[s] = ub_expr;
    lower_bound_exprs[s] = lb_expr;
    
    bv_cbmc.set_to_true(i1);
    bv_cbmc.set_to_true(i2);
    
    
  }

}

bool itv_invar_bmct::check_converted(const exprt& e)
{
  unsigned nr_vars = satcheck.no_variables();
  
  if(e.type().id() == ID_bool)
  {
    bv_cbmc.convert(e);
  } else 
  {
    bvt bv;
    bv_cbmc.convert_bv(e, bv);
  }
  
  //if variables have increased, then it wasn't found 
  //in cache
  return satcheck.no_variables() == nr_vars;
}


symbol_exprt itv_invar_bmct::to_first_ssa(const symbol_exprt& s)
{
  symbol_exprt result(s);
  
  //TODO: HACKY
  result.set_identifier(s.get_identifier().as_string() + "#0");

  return result;
}



symbol_exprt itv_invar_bmct::new_aux_symbol(const std::string& s, const typet& t)
{
  std::stringstream ss;
  ss << "##itv_invar_aux##" << s << aux_symbol_counter++;
  return symbol_exprt(ss.str(), t); 
}

void itv_invar_bmct::set_bound_assumptions(
    const symbol_exprt& sym, 
    const std::string& val, 
    bool lower)
{
  unsigned no_vars = satcheck.no_variables();

  literalt enable = 
    bv_cbmc.convert( lower ? enable_lower[sym] : enable_upper[sym]);

  assumptions.push_back(enable);

  assume_symbol( lower ? lower_bounds[sym] : upper_bounds[sym], val);

  assert(no_vars == satcheck.no_variables());
}

void itv_invar_bmct::set_bound_assumptions()
{
  assumptions.clear();

  for(sym_const_mapt::const_iterator it = lower_bound_vals.begin();
      it != lower_bound_vals.end(); it++)
  {
    set_bound_assumptions(it->first, it->second.get_value().as_string(), true);
  }

  for(sym_const_mapt::const_iterator it = upper_bound_vals.begin();
      it != upper_bound_vals.end(); it++)
  {
    set_bound_assumptions(it->first, it->second.get_value().as_string(), false);
  }
}


void itv_invar_bmct::assume_symbol(const symbol_exprt& sym, const std::string& val)
{
  bvt constant; 
  bv_cbmc.convert_bv(sym, constant);

  assert(val.size() == constant.size());
  for(unsigned i = 0;  i < constant.size(); ++i)
  {
    char c = val[val.size() - i - 1];

    if(c == '0')
      assumptions.push_back(constant[i].negation());
    else if(c == '1')
      assumptions.push_back(constant[i]);
    else
      assert(0);
  }
}


bool itv_invar_bmct::do_bmc()
{
  //get assumptions
  set_bound_assumptions();

  status("Running "+bv_cbmc.decision_procedure_text());

  //set collected assumptions
  satcheck.set_assumptions(assumptions);

  fine_timet sat_start=current_time();
  decision_proceduret::resultt dec_result=bv_cbmc.dec_solve();
  fine_timet sat_stop=current_time();

  std::cout << "took ";
  output_time(sat_stop-sat_start, std::cout);
  std::cout << " seconds" << std::endl;

  if(dec_result == decision_proceduret::D_SATISFIABLE)
  {
    std::cout << "PROOF FAILED" << std::endl;
#if 0
    for(symbol_sett::const_iterator it = constrain_vars.begin();
        it != constrain_vars.end(); ++it)
    {
      std::cout << "symbol " << it->get_identifier() << " has value " 
                << std::endl;
      exprt val = bv_cbmc.get(to_first_ssa(*it));

      std::cout << "Upper bound expression" 
                << upper_bound_exprs[*it] << " has value " 
                << bv_cbmc.get(upper_bound_exprs[*it]) << std::endl;
      std::cout << "Lower bound expression" 
                << lower_bound_exprs[*it] << " has value " 
                << bv_cbmc.get(lower_bound_exprs[*it]) << std::endl;
    }
#endif 
    return false;
  } else if(dec_result == decision_proceduret::D_UNSATISFIABLE)
  {
    std::cout << "PROOF SUCCEEDED" << std::endl;
    return true;
  } else assert(0);
}


exprt itv_invar_bmct::generalize()
{
  and_exprt result;
  for(sym_const_mapt::const_iterator it = lower_bound_vals.begin();
      it != lower_bound_vals.end(); it++)
  {
    const symbol_exprt& sym = it->first;

    assert(enable_lower.find(sym) != enable_lower.end());
    const symbol_exprt& en_sym = enable_lower[sym];
  
    literalt l;
    bool found_lit = !bv_cbmc.literal(en_sym, 0, l);
    assert(found_lit);
    
    bool in_conflict = satcheck.is_in_conflict(l);
    if(in_conflict)
    {
      constant_exprt constant = generalize_constant(sym, true, it->second);
      binary_relation_exprt lb_expr(sym, ID_ge, constant);

      result.move_to_operands(lb_expr);
    }
  }

  for(sym_const_mapt::const_iterator it = upper_bound_vals.begin();
      it != upper_bound_vals.end(); it++)
  {
    const symbol_exprt& sym = it->first;

    assert(enable_upper.find(sym) != enable_upper.end());
    const symbol_exprt& en_sym = enable_upper[sym];
  
    literalt l;
    bool found_lit = !bv_cbmc.literal(en_sym, 0, l);
    assert(found_lit);
    
    bool in_conflict = satcheck.is_in_conflict(l);
    if(in_conflict)
    {
      constant_exprt constant = generalize_constant(sym, false, it->second);
      binary_relation_exprt ub_expr(sym, ID_le, constant);
      result.move_to_operands(ub_expr);
    }
  }


  if(result.operands().size() == 0)
  {
    result.make_true();
  } 
  else if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }

  return result;
} 


constant_exprt itv_invar_bmct::generalize_constant(
    const symbol_exprt& sym, 
    bool lb, 
    const constant_exprt& c)
{
  const symbol_exprt& bound_sym = lb ? lower_bounds[sym] : upper_bounds[sym];
  const bitvector_typet& t = to_bitvector_type(bound_sym.type());
  unsigned width = t.get_width();
  assert(width > 0);

  const std::string& old_val = c.get_value().as_string();
  assert(old_val.size() == width);
  bool sign = false;

  if(t.id() == ID_signedbv || t.id() == ID_floatbv)
  {
    sign = (old_val[0] == '1');
  }

  //we find out how many literals starting from zero are don't cares
  unsigned dcs; 
  for(dcs = 0; dcs < width; dcs++)
  {
    //get literal
    literalt l;
    bool found = !bv_cbmc.literal(bound_sym, dcs, l);
    assert(found);
    bool in_conflict = satcheck.is_in_conflict(l);
    if(in_conflict)
      break;
  } 

  //we can force the don't cares into a direction that generalizes our bound
    
  //build value
  std::vector<char> val;
  if(dcs == width)//concrete value completely unnecessary (this shouldnt happen)
  {
    if(t.id() == ID_unsignedbv)
    {
      val.resize(width, lb ? '0' : '1'); // make zero / max
    } 
    else if(t.id() == ID_signedbv)
    {
      val.resize(width-1, '1'); // make min/max
      val.push_back(lb ? '1' : '0');
    } 
    else if(t.id() == ID_floatbv)
    {
      const floatbv_typet& ft = to_floatbv_type(t);
      val.resize(ft.get_f(), '0');
      val.resize(ft.get_width()-1, '1');
      val.push_back(lb ? '1' : '0'); //-inf / +inf
    } else assert(0);

  } 
  else
  {
    bool towards_zero = (sign && !lb) || (!sign && lb);
    if(dcs > 0)
    {
      std::cout << "Found " << dcs << " don't cares.\n"
                << " sign = " << sign << ", lb = " << lb << ", toward zero = "
                << towards_zero << std::endl;
    }
    val.resize(dcs, towards_zero ? '0' : '1');
    while(val.size() != old_val.size())
      val.push_back(old_val[old_val.size()-val.size()-1]); 
      //copy remaining values

    //if this is a float, check that we didn't make a NaN
    if(t.id() == ID_floatbv)
    {
      const floatbv_typet& ft = to_floatbv_type(t);
      bool f_zero = true;
      for(unsigned j = 0; j < ft.get_f() && f_zero; j++)
        f_zero = f_zero && (val[j] == '0');
      bool e_one = true;
      for(unsigned j = ft.get_f(); j < ft.get_width()-1 && e_one; j++)
        e_one = e_one && (val[j] == '1');
      
      if(!f_zero && e_one) //we made a NaN
      {
        for(unsigned j = 0; j < ft.get_f(); j++)
          val[j] = '0'; //change it into a +/-inf
      }
    }
  }
  assert(val.size() == old_val.size());

  std::stringstream new_val;
  for(int j = val.size()-1; j >= 0; j--)
    new_val << val[j];

  if(new_val.str().compare(old_val) != 0)
    std::cout << "Generalized " << (lb ? "lower bound" : "upper bound") 
              << " for " << sym.get_identifier() << " from " 
            << std::endl << old_val << " to " << std::endl 
            << new_val.str() << std::endl;

  constant_exprt result = c;
  result.set_value(irep_idt(new_val.str()));
  return result;
}
