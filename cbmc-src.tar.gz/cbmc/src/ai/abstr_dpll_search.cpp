/*******************************************************************\

Module: Abstract DPLL using search, clause learning, backtracking

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "abstr_dpll_search.h"

#include "global_search_generalization.h"

#include <flatten_expr.h>
#include <split_string.h>

#include <limits.h>
#include <fstream>
#include <cstdlib>

/*******************************************************************\

Function: abstr_dpll_searcht::decision_heuristic

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::decision_heuristic(int& v, itvt& itv)
{
  switch(dec_heur)
  {
    case BERKMIN:
      return dec_heur_berkmin(v, itv);
      break;
    case RANGE:
      return dec_heur_largest_range(v, itv, false);
      break;
    case RANGE_REL:
      return dec_heur_largest_range(v, itv, true);
      break;
    default:
      throw "impossible";
  }
}

/*******************************************************************\

Function: abstr_dpll_searcht::largest_relative_range
 
  Inputs:

 Outputs:

 Purpose: Decide by choosing the variable with the largest
          range, relative to its initial range

\*******************************************************************/

bool abstr_dpll_searcht::dec_heur_largest_range(
    int& v, 
    itvt& itv,
    bool relative)
{
  //find the variable with the highest relative range
  std::vector<double> scores;

  get_scores(scores, relative);

  double max_score = -1;
  int max_var = -1;
  std::cout << "scores: ";
  for(unsigned i = 0; i < scores.size(); i++)
  {
    std::cout << scores[i] << " ";
    if(scores[i] >= 0 && scores[i] >= max_score)
    {
      max_score = scores[i];
      max_var = i;
    }
  }
  std::cout << std::endl;

  if(max_var == -1)
    return false;

  v = max_var;
  itv = values[v]; //get current value
  itv.halve_lower(false);

  return true;
}

/*******************************************************************\

Function: abstr_dpll_searcht::dec_heur_berkmin
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::dec_heur_berkmin(
    int& v, 
    itvt& itv)
{
  int i;

  clauset unsat_lits;

  for(i = clauses.size() - 1; i > 0; i--)
  {
    assert(unsat_lits.size() == 0);
    const clauset& c = clauses[i];
    unsigned contradicted = 0; //for sanity check

    //collect unsatisfied lits
    for(clauset::const_iterator it = c.begin(); it != c.end(); it++)
    {
      const literalt& l = *it;
      const itvt& cur_val = values[l.first];

      if(!cur_val.leq(l.second))
      {
        if(!cur_val.disjunct(l.second))
          unsat_lits.push_back(l);
        else 
          ++contradicted;
      }
    }

    assert(contradicted < c.size()); //otherwise we'd have a contradicted clause

    if(unsat_lits.size() > 0);
      break;
  }

  if(unsat_lits.size() == 0) //no unsatified clause found
    return dec_heur_largest_range(v, itv, true);
  
  //we need to chose one of the unsat lits
  //choose randomly for now
  std::cout << "Berkmin-heuristic: chooses literal from clause nr " << i 
            << " of " << clauses.size() << std::endl;
  
  const literalt& chosen_lit = unsat_lits[rand() % unsat_lits.size()];
  
  v = chosen_lit.first;
  itv = chosen_lit.second;
  
  return true;
}


/*******************************************************************\

Function: abstr_dpll_searcht::get_scores

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::get_scores(std::vector<double>& scores, bool relative)
{
  for(unsigned i = 0; i < values.size(); i++)
  {
    const itvt& itv = values[i];

    if(itv.is_singleton())
    {
      scores.push_back(-1);
      continue;
    }
    
    if(relative)
      scores.push_back(get_ratio(values[i], initial_values[i]));
    else
      scores.push_back(get_ratio(values[i], var_val_trail[i][0]));
  }

}

/*******************************************************************\

Function: abstr_dpll_searcht::get_avg_score
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

double abstr_dpll_searcht::get_avg_score(bool relative)
{
  std::vector<double> scores;
  get_scores(scores, relative);

  assert(scores.size() == values.size());

  double sum=0;
  unsigned count=0;

  for(unsigned i = 0; i < scores.size(); i++)
    if(scores[i] >= 0)
    {
      sum+=scores[i];
      ++count;
    }

  assert(count > 0);
  assert(sum >= 0);
  double avg = sum/count;

  return avg;
}

/*******************************************************************\

Function: abstr_dpll_searcht::decide

  Inputs: 

 Outputs:

 Purpose: Ask decision heuristic for next assignment, push on
          appropriate stacks

\*******************************************************************/

bool abstr_dpll_searcht::decide(abstr_elementt& elem)
{
  assert(control_trail.size() == last_backtrack.size());
  control_trail.push_back(val_trail.size());
  last_backtrack.push_back(backtracks);
  assert(control_trail.size() == last_backtrack.size());

  just_backtracked = false;

  ++dlevel;
  std::cout << "new dlevel: " << dlevel << std::endl;

  itvt val;
  int var;

  bool result = decision_heuristic(var, val);

  //if no more decisions can be made, return false
  if(!result)
    return false;

  if(found_bmc_counterexample)
  {
    std::cout << "FOUND COUNTEREXAMPLE WITH BMC" << std::endl;
    return false;
  }

  assign(var, val);

  check_consistency();

  return true;
}

/*******************************************************************\

Function: abstr_dpll_searcht::assign

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::assign(int var, const itvt& value, int reason)
{
  std::cout << "ASSIGN " << to_symbol_expr(numbering[var]).get_identifier() 
            << " to " << value.to_string() << std::endl 
            << " because of " << reason  << std::endl 
            << std::endl;
  
  
  //adjust current decision variable's value
  val_trail.push_back(value);
  var_trail.push_back(var);
  reason_trail.push_back(reason);

  values[var] =
    value;

  //change decision level
  dlevels[var].push_back(dlevel);
  reasons[var].push_back(reason);

  //push value on per-variable stack
  var_val_trail[var].push_back(value);


  //adjust abstract element
  itv_array_domain.set_abstr_val(
    current_element, numbering[var],
    itv_array_domain.get_itv_var_domain().from_internal(value));
    
  check_consistency();
}

/*******************************************************************\

Function: abstr_dpll_searcht::init

  Inputs: 

 Outputs:

 Purpose: Initialize stacks

\*******************************************************************/

void abstr_dpll_searcht::init(abstr_elementt& elem)
{
  srand(1808);
  dlevel = 0;
  conflicting_clause = -1;
  found_bmc_counterexample = false;
  backtracks = 0;
  
  std::string heur = options.get_option("dec-heur");
  if(heur == "berkmin") 
    dec_heur = BERKMIN;
  else if(heur == "range")
    dec_heur = RANGE;
  else if(heur == "range-rel")
    dec_heur = RANGE_REL;
  else 
    dec_heur = RANGE_REL;

  rel_bmc = options.get_bool_option("bmc-thresh-rel");

  cubet ranges;
  get_var_ranges(ranges);

  for(symbol_sett::const_iterator it = decision_variables.begin();
      it != decision_variables.end(); it++)
  {
    //initialize value array for each of those variables
    values.push_back(
      itvt(
        it->type(), 
        itv_array_domain.get_itv_var_domain().get_rounding_mode()));

    //number all expressions
    numbering.number(to_symbol_expr(*it));

    //if type is float, set to [NINF, PINF] (can not be NaN)
    //this is unsound, but necessary for the approach, since our domain cannot
    //handle NaN
    if(values.back().type == itvt::FLOAT)
      values.back().f().set_non_nan();

    var_trail.push_back(numbering.number(to_symbol_expr(*it)));
    reason_trail.push_back(-1);
    val_trail.push_back(values.back());

    //initialize decision per variable stack
    var_val_trail.push_back(val_stackt());
    var_val_trail.back().push_back(values.back());

    pos_occ.push_back(clause_indicest());
    neg_occ.push_back(clause_indicest());

    //initialize decision level stacks
    dlevels.push_back(std::vector<unsigned>());
    dlevels.back().push_back(0);
    //initialize reason stacks
    reasons.push_back(std::vector<int>());
    reasons.back().push_back(-1); //no reason
  }

  for(cubet::const_iterator it = ranges.begin();
      it != ranges.end(); ++it)
  {
    assign(it->first, it->second);
  }

  elem = 
    itv_array_domain.from_itv_assignments(numbering, values);

  check_consistency();

  //we don't need to propagate these initial assignments
  bcp_queue_top = var_trail.size();
  
  //set initial var ranges
  initial_values = values;

  get_bmc_thresh();

  just_backtracked = false;
}


/*******************************************************************\

Function: abstr_dpll_searcht::learn_and_backtrack

  Inputs: 

 Outputs:

 Purpose: Chronological backtrack, no learning

\*******************************************************************/

bool abstr_dpll_searcht::learn_and_backtrack(abstr_elementt& elem)
{

  clauset confl_clause;
  int blevel;
  get_conflict_clause(confl_clause, blevel);

  if(blevel < 0) //no further backtrack possible
    return false;

  const clauset& added_clause = add_clause(confl_clause);
  
  dump_trail(added_clause, blevel);

  //backtrack 
  cancel_until(blevel);
  std::cout << "backtrack to dlevel: " << dlevel << std::endl;
  
  backtracks++;

  //assign asserting literal
  assert(&added_clause == &clauses.back());
  int result = unit_rule(clauses.size()-1);

  assert(var_trail.size() - control_trail.size() >= 2);

  elem = 
    itv_array_domain.from_itv_assignments(numbering, values);
  
  assert(result == UNIT);

  check_consistency();
  
  just_backtracked = true;

  return true;
} 

/*******************************************************************\

Function: abstr_dpll_searcht::generalize_proof
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::generalize_proof(abstr_elementt& elem) 
{
  //std::cout << "*** Generalizing proof *********************" << std::endl;
  //search_generalizationt sg(*this, itv_array_domain, ns);
  //sg.ignore_symbols(ignored_symbols);
  //sg.generalize();

  if(last_proof == ABSINT)
  {  
    assert(conflicting_clause == -1);
    //only generalize if there is no conflict clause
    global_search_generalizationt 
      gg(*this, 
          itv_array_domain, 
          itv_array_domain.get_itv_var_domain(),
          elem);

    gg.generalize();
  } else if(last_proof == BMC)
  {
    exprt generalized = bmc->generalize();
    elem = domain.from_expr(generalized);
  }

  //std::cout << "*** Done Generalizing proof ****************" << std::endl;
}

/*******************************************************************\

Function: abstr_dpll_searcht::cancel_until

  Inputs: 

 Outputs:

 Purpose: Cancel stacks up to the specified level

\*******************************************************************/

void abstr_dpll_searcht::cancel_until(unsigned lvl)
{
  while(dlevel > lvl)
    cancel_once();
}

/*******************************************************************\

Function: abstr_dpll_searcht::cancel_once

  Inputs: 

 Outputs: Stores most recently deleted assignment in 

 Purpose: Cancel one decision level

\*******************************************************************/

void abstr_dpll_searcht::cancel_once()
{
  while(val_trail.size() > control_trail.back())
  {
    unsigned var_nr = var_trail.back();

    assert(var_val_trail[var_nr].size() == dlevels[var_nr].size());
    assert(dlevels[var_nr].size() == reasons[var_nr].size());
    assert(var_val_trail[var_nr].size() >= 2);

    var_val_trail[var_nr].pop_back();
    dlevels[var_nr].pop_back();
    reasons[var_nr].pop_back();
    
    values[var_nr] = var_val_trail[var_nr].back();

    var_trail.pop_back();
    reason_trail.pop_back();
    val_trail.pop_back();
  }

  control_trail.pop_back();
  last_backtrack.pop_back();
  assert(control_trail.size() == last_backtrack.size());
  dlevel--;
  bcp_queue_top = var_trail.size();
}


/*******************************************************************\

Function: abstr_dpll_searcht::flip

  Inputs: 

 Outputs:

 Purpose: Flip decision in context, e.g., dec ==[0,5], context==[0,10],
          then dec := [6,10]

\*******************************************************************/

void abstr_dpll_searcht::flip(itvt& decision, const itvt& context)
{
  decision.complement(context);
}


/*******************************************************************\

Function: abstr_dpll_searcht::check_consistency
 
  Inputs:

 Outputs:

 Purpose: Debug function

\*******************************************************************/

void abstr_dpll_searcht::check_consistency()
{
  /*for(unsigned i = 0; i < dlevels.size(); i++)
  {
    assert(dlevels[i].size() <= (dlevel + 1));
  }*/
  
}

/*******************************************************************\

Function: abstr_dpll_searcht::get_conflict_clause
 
  Inputs:

 Outputs:

 Purpose: Find the conflict clause, get blevel

\*******************************************************************/

void abstr_dpll_searcht::get_conflict_clause(clauset& cl, int &blevel)
{
  //get reason from abstr int proof
  cubet reason;
  
  if(last_proof == PROPOSITIONAL)
  {
    //conflict is caused purely by clauses
    cl = clauses[conflicting_clause];
    std::cout << "CONFLICT IS PURELY PROPOSITIONAL" << std::endl;
    std::cout << "CONFLICT CLAUSE = " << to_string(cl) << std::endl;
  } 
  else if(last_proof == ABSINT) 
  {
    //conflict is caused by AI proof
    get_ai_reason(reason);

    for(cubet::const_iterator it = reason.begin();
        it != reason.end(); it++)
    {
      negate(*it, cl);
    }
    std::cout << "CONFLICT CLAUSE = " << to_string(cl) << std::endl;
  } 
  else if(last_proof == BMC)
  {
    get_bmc_reason(reason);
    for(cubet::const_iterator it = reason.begin();
        it != reason.end(); it++)
    {
      negate(*it, cl);
    }
    std::cout << "CONFLICT CLAUSE = " << to_string(cl) << std::endl;
  }
  else assert(0);
  
  //resolve_with_antecedents(cl, blevel);

  if(cl.size() == 0)
    blevel = -1;
  else 
    find_uip(cl, dlevel, blevel);
}

/*******************************************************************\

Function: abstr_dpll_searcht::resolve_with_antecedents
 
  Inputs:

 Outputs:

 Purpose: Resolve a clause with antecedents, until all literals
          are contradicted by decisions or are contradicted by assignments
          made on previous levels.

\*******************************************************************/

void abstr_dpll_searcht::resolve_with_antecedents(clauset& c, int& blevel)
{
  unsigned max_dlevel = 0;
  
  std::cout << "RESOLVING WITH ANTECEDENTS" << std::endl;

  bool done; 

  do
  {
    done = true;
    
    std::cout << "iterating through literals " << std::endl;
    for(int counter = 0; counter < int(c.size()); ++counter)
    {
      const literalt& l = c[counter];

      unsigned contr = get_earliest_contradiction(l);
      unsigned d = dlevels[l.first][contr];

      if(dlevel != d && d > max_dlevel)
        max_dlevel = d;

      assert(reasons[l.first].size() == dlevels[l.first].size());
      int r = reasons[l.first][contr];

      std::cout << "literal " << to_string(l) << " "; 
      
      //get reason 
      if(d == dlevel && r != -1)
      {
        //if this is on the same dlevel and has a reason, 
        //resolve with that reason
        const clauset& antecedent = clauses[r];

        //resolve with antecedent into the same clause
        std::cout << " - earliest contradiction on same dlevel" << std::endl;
        resolve_into(c, counter, antecedent);
        std::cout << std::endl;
        done = false;
        break;
      } else if(d == 0) {
        //remove stuff that's contradicted at level 0
        if(counter != int(c.size()) - 1)
          std::swap(c[counter], c.back());
        c.pop_back();
        --counter;
        continue;
      }
      if(d != dlevel)
        std::cout << " different dlevel" << std::endl;
      else 
        std::cout << " is decision literal" << std::endl;
    }

  } while(!done);
  
  if(c.size() == 1)
    blevel = 0;
  else 
    blevel = int(max_dlevel);
}

void abstr_dpll_searcht::find_uip(
  clauset& result_clause, 
  unsigned dl,
  int& blevel)
{
  assert(result_clause.size() != 0);
  std::cout << "searching for uip" << std::endl;

  if(dl == 0)
  { //trying to resolve a conflict a dlevel 0
    blevel = -1; //UNSAT
    return;
  }

  /* PREPARATION
   *   Move those literals from reason into working set which are contradicted
   *   at decision level dl.
   */ 
  clauset target_level_lits;
  int max_reason_dl = -1;
  {
    clauset new_result_clause;
    for(clauset::const_iterator it = result_clause.begin(); 
        it != result_clause.end(); ++it)
    {
      unsigned contr = get_earliest_contradiction(*it);
      assert(contr < dlevels[it->first].size());
      unsigned contr_dl = dlevels[it->first][contr];

      assert(contr_dl <= dl);

      if(contr_dl == dl)
        target_level_lits.push_back(*it);
      else
      {
        if(int(contr_dl) > max_reason_dl)
          max_reason_dl = int(contr_dl);

        new_result_clause.push_back(*it);
      }
    }
    new_result_clause.swap(result_clause);
  }


  /* If the working set is empty, then we have chosen the wrong dlevel */
  if(target_level_lits.size() == 0)
  {
    assert(max_reason_dl >= 0);
    //go to that earlier dlevel, and try learning again from there
    std::cout << "restarting search for UIP at level " << max_reason_dl << std::endl;
    find_uip(result_clause, unsigned(max_reason_dl), blevel);
    return;
  }


  /* Set the backtracking level */
  assert(max_reason_dl != -1 || result_clause.size() == 0);
  if(max_reason_dl == -1)
  {
    //unit clause
    assert(result_clause.size() == 0);
    blevel = 0;
  }
  else blevel = max_reason_dl;
  

  /* If there is only one lit on current dlevel, use the current, 
     generalized one */
  if(target_level_lits.size() == 1)
  {
    result_clause.push_back(target_level_lits.front());
    std::cout << "using generalized lit as negated uip: " 
              << to_string(result_clause.front())
              << std::endl;
    return;
  }

  /* find dl section of trail, set up helpers */
  assert(dl > 0);
  int trail_start = control_trail[dl-1];
  int trail_end = 
      dl < control_trail.size() ? 
          control_trail[dl] - 1 : val_trail.size()-1;

  unsigned trail_size = (trail_end+1) - trail_start;

  std::vector<bool> marked;
  marked.resize(trail_size, false);

  unsigned open_paths = target_level_lits.size();


  /* set initial marking for trail */
  for(int ws_i = 0; unsigned(ws_i) < target_level_lits.size(); ws_i++)
  {
    const literalt& lit = target_level_lits[ws_i];
    int index = first_contradiction_on_trail(lit, trail_start, trail_end);
    marked[index - trail_start] = true;
  }


  /* START OF UIP DETECTION
   */  
  int uip = -1;

  for(int i = trail_end; i >= trail_start; i--)
  {
    if(!marked[i-trail_start]) //skip unmarked ones
      continue;

    //found uip
    if(open_paths == 1)
    {
      uip = i;
      break;
    }

    int r = reason_trail[i]; assert(r != -1);
    literalt l = lit_from_trail(i); 
    
    std::cout << "analyzing trail literal " << to_string(l) << std::endl;
    std::cout << "stepping through predecessor clause " << std::endl;

    //get predecessor clause, must be non-unit
    const clauset& predec_clause = clauses[r];
    assert(predec_clause.size() > 1);
    
    bool found_asserting_lit = false;
    
    for(clauset::const_iterator it = predec_clause.begin();
        it != predec_clause.end(); ++it)
    {
      const literalt& predec_lit = *it;
      if(predec_lit.first == l.first &&
         predec_lit.second.eq(l.second))
      {
        found_asserting_lit = true;
        continue;
      }
      
      unsigned contr = get_earliest_contradiction(*it);
      assert(contr < dlevels[it->first].size());
      unsigned contr_dl = dlevels[it->first][contr];
      
      assert(contr_dl <= dl);
      if(contr_dl < dl)
      {
        //contradiction on earlier decision level
        std::cout << "contradiction on earlier level, adding " 
                  << to_string(*it) << " to result" << std::endl;
        result_clause.push_back(*it);

        if(int(contr_dl) > blevel)
          blevel = contr_dl;
      } 
      else
      {
        //contradiction on this dlevel, find first contradiction on trail, mark it
        std::cout << "contradiction on same level, marking on trail"  
                  << std::endl;
        int contr_index = 
          first_contradiction_on_trail(
            predec_lit, 
            trail_start, 
            trail_end);

        if(!marked[contr_index - trail_start])
          open_paths++;

        marked[contr_index - trail_start] = true;
      }

    }

    open_paths--;
    assert(found_asserting_lit);
  }
  
  //add the uip to the conflict clause
  assert(uip != -1);

  literalt uip_lit = lit_from_trail(uip);
  std::cout << "found UIP " << to_string(uip_lit) << std::endl;
  negate(uip_lit, result_clause);

}

abstr_dpll_searcht::literalt abstr_dpll_searcht::lit_from_trail(int index)
{
  assert(index > 0 && var_trail.size() > unsigned(index));
  int var = var_trail[index];
  const itvt& val = val_trail[index];
  
  int i;
  for(i = var_val_trail[var].size()-1; i >= 1; --i)
  {
    if(var_val_trail[var][i].eq(val))
      break;
  }
  assert(i > 0);
  
  const itvt& prev_val = var_val_trail[var][i-1];

  switch(prev_val.type)
  {
    case itvt::INTBV:
    {
      const intbv_intervalt& prev = prev_val.i();
      const intbv_intervalt& cur = val.i();
      literalt result(var, val);
      
      if(prev.lower() == cur.lower())
        result.second.i().set(prev.get_min(), cur.upper());
      else if(prev.upper() == cur.upper())
        result.second.i().set(cur.lower(), prev.get_max());
      else assert(0);
        
      return result;
    }
      break;
    case itvt::FLOAT:
    {
      const float_intervalt& prev = prev_val.f();
      const float_intervalt& cur = val.f();
      literalt result(var, val);

      //set -infty, +infty
      result.second.f().set_non_nan();
      
      if(prev.lower() == cur.lower())
      {
        result.second.f().set(
          result.second.f().lower(),
          cur.upper());
      }
      else if(prev.upper() == cur.upper())
      {
        result.second.f().set(
          cur.lower(),
          result.second.f().upper());
      }

      else assert(0);
        
      return result;
    }
      break;
    default:
      assert(0);
  }
} 

int abstr_dpll_searcht::first_contradiction_on_trail(
    const literalt& l, 
    int trail_start, 
    int trail_end)
{
  for(int i = trail_start; i <= trail_end; i++)
  {
    if(var_trail[i] == l.first && val_trail[i].disjunct(l.second))
    {
      return i;
    }
  }

  assert(0);
}


/*******************************************************************\

Function: abstr_dpll_searcht::get_earliest_contradiction
 
  Inputs:

 Outputs:

 Purpose: Return the index to the earliest assignment to the variable that 
          contradicts the literal.

\*******************************************************************/

unsigned abstr_dpll_searcht::get_earliest_contradiction(const literalt& l)
{
  static int counter = 0;
  counter++;
  const int& var = l.first;
  const itvt& itv = l.second;
  
  int c;
  for(c = var_val_trail[var].size()-1; c >= 0; c--)
  {
    if(!itv.disjunct(var_val_trail[var][c]))
      break;
  }
  c++;

  std::cout << to_string(l) << " is incompatible with " 
            << var_val_trail[var][c].to_string() << " at level " <<
            dlevels[var][c] << std::endl;

  assert(c > 0 && unsigned(c) < var_val_trail[var].size());
  return c;
}

/*******************************************************************\

Function: abstr_dpll_searcht::resolve
 
  Inputs: Assumes that a clause contains no redundant literals

 Outputs:

 Purpose: Resolve two clauses at pivot c1[p]

\*******************************************************************/

void abstr_dpll_searcht::resolve_into(
    clauset& c1, 
    int p,
    const clauset& c2)
{
  literalt pivot = c1[p];
  bool pivot_phase = lit_phase(pivot);

  std::cout << "RESOLVING: " << std::endl;
  std::cout << to_string(c1) << std::endl;
  std::cout << "With " << std::endl << to_string(c2) << std::endl;
  
  //remove pivot from c1
  if(p != int(c1.size())-1)
    std::swap(c1[p], c1.back());
  c1.pop_back();

  bool found_pivot = false;
  for(unsigned i = 0; i < c2.size(); i++)
  {
    const literalt& lit = c2[i];

    bool is_pivot = 
      (lit.first == pivot.first) && (lit_phase(lit) != pivot_phase);
    
    assert(!is_pivot || !found_pivot); //can't find a second pivot

    found_pivot |= is_pivot;
    if(!is_pivot)
      c1.push_back(lit);
  }

  compress_clause(c1);

  std::cout << "RESULT: " << std::endl; 
  std::cout << to_string(c1) << std::endl;

  assert(found_pivot);
}

void abstr_dpll_searcht::compress_clause(clauset& c1)
{
  typedef hash_map_cont<int, itvt> lit_mapt;
  lit_mapt pos_lits,neg_lits;
  for(clauset::const_iterator it = c1.begin(); it != c1.end(); it++)
  {
    const literalt& l = *it;
    bool phase = lit_phase(*it);
    lit_mapt& lit_map = phase ? pos_lits : neg_lits;

    int lit_var = l.first;

    lit_mapt::iterator find_it = lit_map.find(lit_var);
    if(find_it == lit_map.end())
      lit_map.insert(literalt(lit_var, l.second));
    else
      find_it->second.join(it->second); //join existing and new lit
  }

  c1.clear();
  
  for(lit_mapt::const_iterator it = pos_lits.begin(); 
      it != pos_lits.end(); ++it)
  {
    c1.push_back(*it);
  }

  for(lit_mapt::const_iterator it = neg_lits.begin(); 
      it != neg_lits.end(); ++it)
  {
    c1.push_back(*it);
  }
}

/*******************************************************************\

Function: abstr_dpll_searcht::negate
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::negate(const literalt& l, clauset& c)
{
  const itvt& itv = l.second;
  int var = l.first;

  assert(!itv.is_bot() && !itv.is_top());

  itvt newitv(itv);

  switch(itv.type)
  {
    case itvt::FLOAT:
    {
      const float_intervalt& f = itv.f();
      ieee_floatt inf(f.lower());
      inf.make_plus_infinity();
      if(!f.contains_max())
      { //insert interval greater than current interval
        newitv.f().set(f.upper(), inf);
        newitv.f().inc_lower();
        c.push_back(literalt(var, newitv));
        assert(!newitv.is_bot());
      }
      inf.negate();
      if(!f.contains_min())
      { //insert interval smaller than current interval
        newitv.f().set(inf, f.lower());
        newitv.f().dec_upper();
        c.push_back(literalt(var, newitv));
        assert(!newitv.is_bot());
      } 
      break;
    }
    case itvt::INTBV:
    {
      const intbv_intervalt& i = itv.i();
      if(!i.contains_max())
      { //insert interval greater than current interval
        newitv.i().set(i.upper(), i.get_max());
        newitv.i().inc_lower();
        c.push_back(literalt(var, newitv));
        assert(!newitv.is_bot());
      }
      if(!i.contains_min())
      { //insert interval smaller than current interval
        newitv.i().set(i.get_min(), i.lower());
        newitv.i().dec_upper();
        c.push_back(literalt(var, newitv));
        assert(!newitv.is_bot());
      }
      break;
    }
    case itvt::OTHER:
      assert(0);
      break;
  }
}

/*******************************************************************\

Function: abstr_dpll_searcht::get_ai_reason
 
  Inputs:

 Outputs:

 Purpose: Extract reason from abstract interpretation proof

\*******************************************************************/

void abstr_dpll_searcht::get_ai_reason(cubet& c)
{
  const abstr_elementt& initial_element = current_element;
  interval_var_domaint& var_domain = itv_array_domain.get_itv_var_domain();

  //get the map variable -> value from the initial element
  const var_mapt& map = 
    itv_array_domain.get_var_map(initial_element);

  //iterate through entries of the variable map
  for(var_mapt::const_iterator it = map.begin();
      it != map.end(); ++it)
  {
    //if this variable is a decision variable
    if(decision_variables.find(it->first) != decision_variables.end())
    {
      //get its interval
      const itvt& itv = var_domain.read(it->second);
      if(!itv.is_top() && !(itv.type == itvt::FLOAT && itv.f().is_non_nan()))
      {
        //if the interval is not top, then add it to the result cube
        c.push_back(literalt(numbering.number(it->first), itv));
      }
      
    }
  }

  std::cout << "REASON: ";
  if(c.size() != 0)
    for(cubet::const_iterator it = c.begin(); it != c.end(); it++)
      std::cout << to_symbol_expr(numbering[it->first]).get_identifier() 
                << ' ' << (it->second.to_string()) << ", ";
  else std::cout << "TRUE" << std::endl;

  std::cout << std::endl;
}

/*******************************************************************\

Function: abstr_dpll_searcht::get_bmc_reason

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::get_bmc_reason(cubet& c)
{
  get_ai_reason(c);
}

/*******************************************************************\

Function: abstr_dpll_searcht::lit_phase
 
  Inputs:

 Outputs:

 Purpose: Return the phase of a literal

\*******************************************************************/

bool abstr_dpll_searcht::lit_phase(const literalt& l)
{
  const itvt& itv = l.second;
  bool ge = !itv.contains_min();
  bool le = !itv.contains_max();

  assert(ge != le); //shouldn't be in both phases at once
  return ge;
}

/*******************************************************************\

Function: abstr_dpll_searcht::add_clause
 
  Inputs:

 Outputs:

 Purpose: Clean the clause and add it to the database

\*******************************************************************/

abstr_dpll_searcht::clauset& abstr_dpll_searcht::add_clause(const clauset& c)
{
  clauses.push_back(clauset());
  clauset& added_clause = clauses.back();
  int cl_index = clauses.size()-1;
    
  typedef hash_map_cont<int, const itvt*> lit_mapt;
  lit_mapt poslits, neglits;

  for(clauset::const_iterator it = c.begin(); it != c.end(); it++)
  {
    const literalt& l = *it;
    bool phase = lit_phase(l); 
    lit_mapt& lits = phase ? poslits : neglits;
    
    lit_mapt::iterator find_it = lits.find(l.first);
    if(find_it == lits.end())
      lits[l.first] = &l.second;
    else 
    {
      //if "l" is more general, than put it in the map instead
      if(!l.second.leq(*find_it->second))
        lits[l.first] = &l.second;
    }
  }
    
  int size = poslits.size() + neglits.size();
  assert(size > 0);

  //add to occurrence lists
  for(lit_mapt::const_iterator it = poslits.begin(); 
      it != poslits.end(); it++)
  {
    if(size != 1) //unit clauses are not added to occ lists
      pos_occ[it->first].push_back(cl_index);
    added_clause.push_back(literalt(it->first, *it->second));
  }

  //add to occurrence lists
  for(lit_mapt::const_iterator it = neglits.begin(); 
      it != neglits.end(); it++)
  {
    if(size != 1) //unit clauses are not added to occ lists
      neg_occ[it->first].push_back(cl_index);
    added_clause.push_back(literalt(it->first, *it->second));
  }

  std::cout << "ADDED CLAUSE: ";
  for(clauset::const_iterator it = added_clause.begin(); 
      it != added_clause.end(); it++)
  {
    std::cout << '(' << to_symbol_expr(numbering[it->first]).get_identifier() 
              << ',' << it->second.to_string() << ") ";
  }
  std::cout << std::endl;
  return added_clause;
}

/*******************************************************************\

Function: abstr_dpll_searcht::deduce
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::deduce()
{
  conflicting_clause = -1;
  for(;bcp_queue_top < var_trail.size(); bcp_queue_top++)
  {
    if(!propagate(bcp_queue_top))
      return false;
  }
  return true;
}

/*******************************************************************\

Function: abstr_dpll_searcht::propagate
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::propagate(int idx)
{
  assert(idx != 0);
  const int& var = var_trail[idx];
  const itvt& val = val_trail[idx];
  
  //find previous assignment to same variable
  int prev_idx = idx-1;
  for(;prev_idx > 0; prev_idx--)
    if(var_trail[prev_idx] == var) break;
  
  //there must be a previous assignment
  assert(prev_idx >= 0);
  const itvt& prev_val = val_trail[prev_idx];

  bool gt,lt;
  //now check whether this assignment enforced a "<" or a ">" constraint
  switch(val.type) {
    case itvt::FLOAT: 
      gt = (val.f().lower() != prev_val.f().lower());
      lt = (val.f().upper() != prev_val.f().upper()); break;
    case itvt::INTBV:
      gt = (val.i().lower() != prev_val.i().lower());
      lt = (val.i().upper() != prev_val.i().upper()); break;
    default: assert(0);
  }
  assert(gt != lt);

  const clause_indicest& occ = 
    gt ? neg_occ[var] : pos_occ[var];

  //check all clauses in occurrence list
  for(clause_indicest::const_iterator c_it = occ.begin(); 
      c_it != occ.end(); ++c_it)
  {
    if(unit_rule(*c_it) == CONFLICT)
      return false; //if conflict return false
  }

  return true;
}


/*******************************************************************\

Function: propagate

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

abstr_dpll_searcht::clause_statet 
abstr_dpll_searcht::unit_rule(int clause_index)
{
  const clauset& c = clauses[clause_index];

  int unit_idx = -1;
  for(unsigned i = 0; i < c.size(); i++)
  {
    const literalt& l = c[i];
    const int& lvar = l.first;
    const itvt& lval = l.second;
    const itvt& val = values[lvar];

    if(val.leq(lval)) return SATISFIED; //clause satisfied
    if(!val.disjunct(lval)) 
    {
      //if its not contradicted
      if(unit_idx != -1)
        return UNKNOWN; //we have more than one uncontradicted literals
      unit_idx = i;
    }
  }

  if(unit_idx == -1)
  {
  std::cout << "CLAUSE IS UNIT" << std::endl;
    conflicting_clause = clause_index;
    return CONFLICT; // conflict
  }

  std::cout << "CLAUSE IS UNIT" << std::endl;
  //clause is unit
  const literalt& unit_lit = c[unit_idx];
  itvt new_val(unit_lit.second);
  new_val.meet(values[unit_lit.first]);
  assign(unit_lit.first, new_val, clause_index);
  return UNIT;
}

/*******************************************************************\

Function: abstr_dpll_searcht::to_string

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

std::string abstr_dpll_searcht::to_string(const clauset& cl)
{
  std::stringstream ss;
  ss << "{ ";
  for(clauset::const_iterator it = cl.begin();
      it != cl.end(); ++it)
  {
    ss << to_string(*it) << " ";
  }
  ss << "}";
  return ss.str();
}

/*******************************************************************\

Function: abstr_dpll_searcht::to_string

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

std::string abstr_dpll_searcht::to_string(const literalt& l)
{
  std::stringstream ss;
  ss << '(' << numbering[l.first].get_identifier().as_string() 
     << ',' << l.second.to_string() << ')';
  return ss.str();
}

/*******************************************************************\

Function: abstr_dpll_searcht::init_bmc
 
  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/

void abstr_dpll_searcht::init_bmc()
{
  bmc = std::auto_ptr<itv_invar_bmct>(
    new itv_invar_bmct(
      cfg, 
      get_message_handler(),
      options,
      decision_variables));
}


/*******************************************************************\

Function: abstr_dpll_searcht::prove_with_bmc
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::prove_with_bmc()
{
  std::cout << "calling bmc with " << current_element.to_string()
            << std::endl;

  if(bmc.get() == NULL)
    init_bmc();

  bmc->clear_constraints();
  
  exprt expr = current_element.to_expr();


  make_flat(expr, ID_and, typet(ID_bool));
  
  forall_operands(it, expr)
  {
    const exprt& e = *it;
    const irep_idt& id = e.id();
    exprt lower_bound = nil_exprt();
    exprt upper_bound = nil_exprt();
    exprt symbol;
    
    assert((e.op0().is_constant() && e.op1().id() == ID_symbol) ||
           (e.op1().is_constant() && e.op0().id() == ID_symbol));

    if(id == ID_ge) 
    {
      if(e.op0().is_constant())
      {
        upper_bound = e.op0();
        symbol = e.op1();
      } else
      {
        lower_bound = e.op1();
        symbol = e.op0();
      }
    } 
    else if(id == ID_le) 
    {
      if(e.op0().is_constant())
      {
        lower_bound = e.op0();
        symbol = e.op1();
      } else
      {
        upper_bound = e.op1();
        symbol = e.op0();
      }
    } 
    else if(id == ID_equal || id == ID_ieee_float_equal)
    {
      if(e.op0().is_constant())
      {
        lower_bound = upper_bound = e.op0();
        symbol = e.op1();
      } else {
        lower_bound = upper_bound = e.op1();
        symbol = e.op0();
      }

    } else assert(0); 

    if(lower_bound.is_not_nil())
    {
      bmc->set_lower_bound(
        to_symbol_expr(symbol), 
        to_constant_expr(lower_bound));
    } 
    if(upper_bound.is_not_nil())
    {
      bmc->set_upper_bound(
        to_symbol_expr(symbol), 
        to_constant_expr(upper_bound));
    }
  }

  return bmc->do_bmc();
}

/*******************************************************************\

Function: abstr_search_dpllt::conflict_or_proof
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::conflict_or_proof()
{
  bool conflict = !deduce();

  last_proof = PROPOSITIONAL;

  if(!conflict)
  {
    local_exprst v;
    abstr_fwd_analysist::perform_analysis();
    get_violated_assertions(v);

    //also a conflict if proof holds
    conflict |= (v.size() == 0);
    last_proof = ABSINT;
  }

  if(!conflict && use_bmc())
  {
    double avg_score = get_avg_score(rel_bmc);
  
    unsigned old_dlevel = dlevel;

    while(avg_score < bmc_bt_thresh && dlevel > 0)
    {
      cancel_once();
      avg_score = get_avg_score(rel_bmc);
    }
    current_element = 
      itv_array_domain.from_itv_assignments(numbering, values);
    
    if(old_dlevel != dlevel)
      std::cout << "backtracked from " << old_dlevel << " to "
                << dlevel << " before calling bmc" << std::endl;

    conflict = prove_with_bmc();
    found_bmc_counterexample = !conflict;
    last_proof = BMC;
  }


  return conflict;
}

/*******************************************************************\

Function: abstr_dpll_searcht::use_bmc

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

bool abstr_dpll_searcht::use_bmc()
{
  if(options.get_bool_option("bmc-on-backtrack") && !just_backtracked)
    return false;

  double avg = get_avg_score(rel_bmc);

  return avg <= bmc_thresh;
}

/*******************************************************************\

Function: abstr_dpll_searcht::dump_trail
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::dump_trail(
    const clauset& added_clause, 
    unsigned blevel)
{
  static unsigned counter = 0;
  std::stringstream filename;
  filename << "logout/trail_" << std::setw(5) << std::setfill('0') << counter++ 
           << ".out";
  std::ofstream file;
  file.open(filename.str().c_str());

  assert(control_trail.size() == last_backtrack.size());

  unsigned control = 0;
    
  assert(val_trail.size() == var_trail.size());
  for(unsigned i = 0; i < val_trail.size(); i++) 
  {
    if(control < control_trail.size() && i == control_trail[control])
    {
      control++;
      file << std::endl;
      file << "dlevel " << control;
      file << " ***************************************** ";
      file << last_backtrack[control-1];
      
      file << std::endl << std::endl;

    }
    
    file << val_trail[i].to_string() << "  " 
         << numbering[var_trail[i]].get_identifier() << std::endl;

  }
  
  file << std::endl << std::endl;
  file << "ADDED CLAUSE:" <<std::endl << to_string(added_clause) << std::endl;
  file << "blevel " << blevel << std::endl;

  file.close();
}


/*******************************************************************\

Function: abstr_dpll_searcht::get_var_ranges

  Inputs: 

 Outputs:

 Purpose:

\*******************************************************************/

void abstr_dpll_searcht::get_var_ranges(cubet& result)
{
  std::string var_ranges = options.get_option("set-var-range");
  std::vector<std::string> split;
  split_string(var_ranges, ',', split);

  if(split.size() % 3 != 0)
    throw "set-var-range has wrong length";

  //find the right decision var
  unsigned cur = 0;
  while(cur < split.size())
  {
    const std::string& ident_fragment = split[cur++];
    exprt sym = nil_exprt();

    for(symbol_sett::const_iterator it = decision_variables.begin();
        it != decision_variables.end(); it++)
    {
      const symbol_exprt& cur = to_symbol_expr(*it);
      const std::string& ident = cur.get_identifier().as_string();
      size_t pos = ident.find(ident_fragment);
      if(pos != std::string::npos) 
      {
        sym = cur;
        break;
      }
    }

    if(sym.is_nil())
      throw ident_fragment + " symbol not found while setting variable values";

    itvt itv(sym.type());
    literalt literal;

    if(sym.type().id() == ID_signedbv || sym.type().id() == ID_unsignedbv)
    {
      mp_integer l(split[cur++].c_str());
      mp_integer u(split[cur++].c_str());

      itv.i().set(l, u);
      literal = literalt(numbering.number(to_symbol_expr(sym)), itv);
    } 
    else if(sym.type().id() == ID_floatbv)
    {
      itvt itv(sym.type());
      bool fail = false;

      ieee_floatt ieee_l, ieee_u;

      if(itv.f().lower_or_infty().is_double())
      {
        double l, u;
        std::stringstream sl,su;

        sl << split[cur++];
        su << split[cur++];
        
        sl >> l;
        fail = fail || sl.fail();
        su >> u;
        fail = fail || su.fail();

        ieee_l.from_double(l);
        ieee_u.from_double(u);
      } 
      else if(itv.f().lower_or_infty().is_float()) 
      {
        float l, u;
        std::stringstream sl,su;

        sl << split[cur++];
        su << split[cur++];

        sl >> l;
        fail = fail || sl.fail();
        su >> u;
        fail = fail || su.fail();
        ieee_l.from_float(l);
        ieee_u.from_float(u);
      }
      itv.f().set(ieee_l, ieee_u);
      literal = literalt(numbering.number(to_symbol_expr(sym)), itv);

      if(fail)
        throw "illegal floating point bound in set-var-range";
      
    } else assert(0);


    std::cout << "ADDED VAR RANGE LIMIT: " 
              << numbering[literal.first].get_identifier() << " "
              << literal.second.to_string() << std::endl;
    result.push_back(literal);
  }
}


double abstr_dpll_searcht::get_ratio(const itvt& i1, const itvt& i2)
{
  assert(i1.type == i2.type);
  if(i1.type == itvt::INTBV)
  {
    mp_integer r1 = i1.i().upper() - i1.i().lower();
    mp_integer r2 = i2.i().upper() - i2.i().lower();

    unsigned long ur2;
    if(!r2.is_ulong())
      ur2 = ULONG_MAX;
    else
      ur2 = r2.to_ulong();

    unsigned long ur1;
    if(!r1.is_ulong())
      ur1 = ULONG_MAX;
    else
      ur1 = r1.to_ulong();

    double result = double(ur1)/ur2;
    assert(result >= 0 && result <= 1);
    return result;
  } 
  else if(i1.type == itvt::FLOAT)
  {

    ieee_floatt dist1 = i1.f().upper();
    dist1 -= i1.f().lower();

    ieee_floatt dist2 = i2.f().upper();
    dist2 -= i2.f().lower();

    assert(!dist1.get_sign() && !dist2.get_sign());

    if(dist1.is_infinity())
      dist1.make_fltmax();

    if(dist2.is_infinity())
      dist2.make_fltmax();

    assert(!dist2.is_zero());

    dist1 /= dist2;

    ieee_floatt dummy;
    dummy.from_double(0.0);

    dist1.change_spec(dummy.spec);

    double score = dist1.to_double();

    assert(score >= 0 && score <= 1);

    return score;
  } 
  
  assert(0);
  return 1;
}

void abstr_dpll_searcht::get_bmc_thresh()
{
  std::stringstream ss;
  ss << options.get_option("bmc-thresh");
  double thresh;
  ss >> thresh;
  if(ss.fail()) 
    throw "could not parse bmc-thresh value from options";

  bmc_thresh = thresh;

  ss.clear();
  ss << options.get_option("bmc-bt-thresh");
  ss >> thresh;
  if(ss.fail())
    throw "could not parse bmc-bt-thresh value from options";

  bmc_bt_thresh = thresh;
}

