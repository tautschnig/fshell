/*******************************************************************\

Module: Base class for loosely coupled product domains  

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef PRODUCT_DOMAIN_H
#define PRODUCT_DOMAIN_H

#include "abstr_domain_mem.h"

typedef std::pair<abstr_elementt, abstr_elementt> abstr_pairt; 

class product_domaint : public abstr_domain_memt<abstr_pairt>
{
public:
  product_domaint(abstr_domaint& _a1, abstr_domaint& _a2)
    : a1(_a1), a2(_a2) { }

  //called after an element is modified,
  //override to nontrivially combine information about the two domains
  virtual void reduce(abstr_pairt& a);

  virtual abstr_elementt top();
  virtual abstr_elementt bot();

  virtual bool is_top(const abstr_elementt& e);

  virtual bool is_bot(const abstr_elementt& e);

  virtual bool leq(const abstr_elementt& a1, const abstr_elementt& a2);

  virtual void meet_inplace(abstr_pairt&, const abstr_pairt& e);

  virtual void join_inplace(abstr_pairt&, const abstr_pairt& e);

  virtual void widen_inplace(
      abstr_pairt&, 
      const abstr_pairt& e, 
      const abstr_pairt& threshold);

  virtual void apply_assign_inplace(
      abstr_pairt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  virtual void apply_test_inplace(
      abstr_pairt& a, 
      const exprt& e, 
      bool result);


  virtual std::string to_string(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a);

  virtual abstr_elementt get_initial();
  
  virtual ~product_domaint() { }

protected:
  abstr_domaint& a1;
  abstr_domaint& a2;
};

#endif
