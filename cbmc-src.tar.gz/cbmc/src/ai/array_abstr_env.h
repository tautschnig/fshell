/*******************************************************************\

Module: Abstract environments with simple support for fixed size arrays,
        and structs.
        Arrays are represented explicitly and internally handled as 
        symbols.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ARRAY_ABSTR_ENV_H
#define ARRAY_ABSTR_ENV_H

#include "abstr_env.h"

#include "array_struct_emulator.h"


class array_abstr_envt : public abstr_env_domaint
{
public:
  typedef abstr_env_domaint sub;

  //arrays with nr elements > max_array_size are not handled
  array_abstr_envt(abstr_var_domaint& domain, array_struct_emulatort& emul)
    : abstr_env_domaint(domain), array_emul(emul)
  { }

  virtual ~array_abstr_envt() { }

  virtual void apply_assign_inplace(
      var_mapt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  virtual exprt to_expr(const abstr_elementt& a);

  virtual exprt to_expr(const abstr_elementt& a, std::vector<symbol_exprt>&);

  virtual exprt to_expr_omit_arrays(const abstr_elementt& a);

  virtual void get_used_symbols(
    const abstr_elementt& elem, 
    hash_set_cont<exprt, irep_hash>& symbols) const;

protected:
  array_struct_emulatort& array_emul;

  mp_integer to_integer(const exprt& e);
  mp_integer dim_size(const array_typet& t);

  //special handling of array values
  virtual var_elementt fwd_interpret_nocache(
      const exprt& e, 
      const var_mapt& context,
      fwd_mapt* cache);

  //special handling of array values
  virtual void bwd_interpret_arith(
      const exprt& e, 
      const var_mapt& context,
      const var_elementt& value, 
      var_mapt& result,
      fwd_mapt& cache);

  virtual var_mapt bwd_interpret_bool(
    const exprt& e, 
    const var_mapt& context,
    bool result,
    fwd_mapt& cache
  );

  virtual void apply_assign_inplace(
      const var_mapt& src, 
      const exprt& lhs, 
      const exprt& rhs,
      var_mapt& dest);

  bool get_possible_targets(
      const exprt& index,
      const var_mapt& context,
      std::vector<exprt>& o,
      fwd_mapt* cache);

  bool rec_get_possible_targets(
      const exprt& cur_expr_full,
      const var_mapt& context,
      exprt& cur_expr_sub,
      std::vector<exprt>& result,
      fwd_mapt* cache);

  void weak_update_variable_value(
      var_mapt& a,
      const symbol_exprt& s, 
      var_elementt& val);

};


#endif 
