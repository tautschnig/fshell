#include "proof_step_generalization.h"

#include <resolve_types.h>
#include <hash_cont.h>

#include <list>
#include <time.h>

#define forall_ordered_cfg_nodes(it, cfg) \
  for(CFGt::const_nodes_vectort::const_iterator it = (cfg).get_ordered_nodes().begin(); \
      it != (cfg).get_ordered_nodes().end(); it++)

/*******************************************************************\

Function: proof_step_generalizationt::proof_step_generalizationt
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

proof_step_generalizationt::proof_step_generalizationt(
    abstr_fwd_analysist& _analysis, 
    const namespacet& _ns ) : 
  proof_generalizationt(_analysis),
  cfg(_analysis.get_cfg()), 
  proof(_analysis.get_abstr_vec()), 
  ns(_ns)
{ 
  assert(cfg.size() == proof.size());
  new_proof.resize(cfg.size(), analysis.get_domain().top());
}

/*******************************************************************\

Function: void proof_step_generalizationt::generalize
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void proof_step_generalizationt::generalize()
{
  assert(proof.size() == cfg.size() && proof.size() != 0);

  typedef hash_set_cont<int> node_sett;
  typedef std::list<const CFG_nodet*> node_listt;
  
  node_sett on_queue;
  node_listt queue;

  abstr_elementt bot = proof.front().get_domain().bot();
  abstr_elementt top = proof.front().get_domain().top();

  //TODO: Use backwards iteration schedule here

  forall_ordered_cfg_nodes(it, cfg)
  {
    //cfg.output_node(*it, std::cout);

    queue.push_front(*it);
    on_queue.insert((*it)->id);
  }

  unsigned visited = 0;
  unsigned counter = 0;
  clock_t start_r, finish_r;
  clock_t start_g, finish_g;
  clock_t all_r = 0, all_g = 0;

  while(!queue.empty())
  {
    /*main loop*/
    
    ++visited;
    const CFG_nodet& cur = *queue.front();
    on_queue.erase(cur.id);
    queue.pop_front();

    abstr_elementt pre = get_invariant(new_proof, cur);

    if(valid_pre(cur, pre, new_proof))
    {
#ifdef PROOF_GEN_DEBUGINFO 
      std::cout << "****** Proof holds: " << std::endl;
      std::cout << "pre: " << pre.to_string() << std::endl;
      cfg.output_node(cur, std::cout); 
      if(cur.successor_next != NULL)
        std::cout << "post (next): " 
                  << get_invariant(new_proof, *cur.successor_next).to_string() 
                  << std::endl;
      if(cur.successor_jump != NULL)
        std::cout << "post (jump): " 
                  << get_invariant(new_proof, *cur.successor_jump).to_string() 
                  << std::endl;
      if(cur.successor_next == NULL && cur.successor_jump == NULL)
        std::cout << "post (no successor): top" << std::endl;
#endif
      continue;   //do nothing if proof holds
    }

    counter++;
    
#ifdef PROOF_GEN_DEBUGINFO
        //debug output
    std::cout << "****** Repairing node : " << std::endl;
    std::cout << "old pre: " << pre.to_string() << std::endl;
    cfg.output_node(cur, std::cout); 
    if(cur.successor_next != NULL)
      std::cout << "post (next): " 
                << get_invariant(new_proof, *cur.successor_next).to_string() 
                << std::endl;
    if(cur.successor_jump != NULL)
      std::cout << "post (jump): " 
                << get_invariant(new_proof, *cur.successor_jump).to_string() 
                << std::endl;
    if(cur.successor_next == NULL && cur.successor_jump == NULL)
      std::cout << "post (no successor): top" << std::endl;
#endif
    start_r = clock();
    repair_step(cur, pre, get_invariant(proof, cur), do_not_touch);
    finish_r = clock();
    //double rtime = (double(finish_r) - start_r) / CLOCKS_PER_SEC;
    //std::cout << "REPAIR TOOK OVERALL " << rtime << "s" << std::endl;
    //all_r += (finish_r - start_r);

#ifdef PROOF_GEN_DEBUGINFO
    std::cout << "repaired pre: " << pre.to_string() << std::endl;

    //assert that repaired element does not have ore information than the
    //current proof

    assert(valid_pre(cur, pre, new_proof));
#endif 
    start_g = clock();
    generalize_step(cur, pre, do_not_touch);
    finish_g = clock();
    all_g += (finish_g - start_g);
    //double gtime = (double(finish_g) - start_g) / CLOCKS_PER_SEC;
    //std::cout << "GENERALIZATION TOOK OVERALL " << gtime << "s" << std::endl;

#ifdef PROOF_GEN_DEBUGINFO
    std::cout << "generalized pre: " << pre.to_string() << std::endl;
    assert(valid_pre(cur, pre, new_proof));
#endif 

    set_invariant(new_proof, cur, pre);

    //enqueue predecessors
    const std::set<CFG_nodet*>& p = cur.predecessors;

    for(std::set<CFG_nodet*>::const_iterator it = p.begin();
        it != p.end(); it++)
    {
      if(on_queue.find((*it)->id) == on_queue.end())
      {
        queue.push_back(*it);
        on_queue.insert((*it)->id);
      }
    }

    /*main loop */
  }
  std::cout << "visited "<< visited << " nodes" << std::endl;
  std::cout << "repaired and generalized " << counter << " nodes" << std::endl;
  std::cout << "Time spent in generalization: " 
    << (double(all_g) / CLOCKS_PER_SEC) << std::endl;
  std::cout << "Time spent in repair: " 
    << (double(all_r) / CLOCKS_PER_SEC) << std::endl;
  //swap new and old proof
  new_proof.swap(proof);
}
/*******************************************************************\

Function: bool proof_step_generalizationt::valid_triple
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool proof_step_generalizationt::valid_triple(
    const CFG_nodet& n, const CFG_nodet& n2,
    const abstr_elementt& pre, 
    const abstr_elementt& post)
{
  abstr_elementt t = analysis.transfer(pre, n, n2);
  
  if(n.type == ASSERT)
  {
    if(!t.leq(post))
      return false;

    exprt assertion = n.reasoning_guard;
    
    resolve_types(assertion, ns);
    t.apply_test(assertion, false);

    return t.is_bot();
  }
  else
    return t.leq(post);
}

bool proof_step_generalizationt::valid_pre(
    const CFG_nodet& n, 
    const abstr_elementt& pre, 
    abstr_elementst& p)
{
  if(n.type == ASSERT) {

    if(n.successor_next != NULL)
    {
      if(!pre.leq(get_invariant(p, *n.successor_next)))
        return false;
    } 

    exprt assertion = n.reasoning_guard;
    resolve_types(assertion, ns);

    abstr_elementt fail = pre;
    fail.apply_test(assertion, false);

    return fail.is_bot();

  } else if(n.type == GOTO) {
    bool valid = true;

    if(n.successor_next != NULL)
      valid = valid && valid_triple(n, *n.successor_next, pre, get_invariant(p, *n.successor_next));

    if(n.successor_jump != NULL)
      valid = valid && valid_triple(n, *n.successor_jump, pre, get_invariant(p, *n.successor_jump));
    
    return valid;

  } else if(n.type == FUNCTION_CALL) {
    throw "Function calls not implemented"; 
  } else {
    if(n.successor_next == NULL)
      return true;
    else return valid_triple(n, *n.successor_next, pre, get_invariant(p, *n.successor_next));
  }
}

/*******************************************************************\

Function: bool proof_step_generalizationt::has_symbol
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool proof_step_generalizationt::has_symbol(const exprt& e, const id_sett& s)
{
  if(e.id() == ID_symbol)
  {
    const irep_idt& ident = to_symbol_expr(e).get_identifier();
    return s.find(ident) != s.end();
  } 
  
  forall_operands(it, e)
  {
    if(has_symbol(*it, s))
      return true;
  }

  return false;
}

