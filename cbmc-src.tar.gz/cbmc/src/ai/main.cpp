#include "ai_parseoptions.h"
#include <iostream>

int main(int argc, const char **argv)
{
  try { 
    ai_parseoptionst parseoptions(argc, argv);
    return parseoptions.main();
  } catch(const std::string s) {
    std::cout << s << std::endl;
    return 1;
  } catch(const char* s)
  {
    std::cout << s << std::endl;
    return 1;
  }
}
