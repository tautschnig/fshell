/*******************************************************************\

Module: Command Line Parsing

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef AI_PARSEOPTIONS_H
#define AI_PARSEOPTIONS_H

#include <langapi/language_ui.h>
#include <ui_message.h>
#include <parseoptions.h>
#include <options.h>
#include <goto-programs/goto_functions.h>
#include <ieee_float.h>

#include "abstr_fwd_analysis.h"
#include "domains/apron_domain.h" 

#include <memory>

#define AI_OPTIONS \
  "(help)(show-symbol-table)I:D:"\
  "(show-goto-functions)(function):(box)(polyhedra)"\
  "(octagon)(strict-polyhedra)(widening):(disequality)"\
  "(intervals)(proof-growing)(diseq-itv)(arr-diseq-itv)"\
  "(inline)(itv-arrays)(max-array-size):"\
  "(block-inv-output):(invariants)"\
  "(rounding-mode):(do-not-generalize):(const-prop)"\
  "(preprocess-const-prop)"\
  "(unwind):(preprocess-expr-prop)(expr-prop)"\
  "(count-paths)"\
  "(show-violations)(set-var-range):"\
  "(loop-modified)(remove-pointers)"\
  "(proof-search)"\
  "(bmc-thresh):(bmc-thresh-rel)(filter-dec-vars):(iteration-limit):"\
  "(dec-heur-berkmin)(dec-heur-range-rel)(dec-heur-range)"\
  "(bmc-on-backtrack)(bmc-bt-thresh):"

class ai_parseoptionst:
  public parseoptions_baset,
  public language_uit
{
public:
  virtual int doit();
  virtual void help();

  ai_parseoptionst(int argc, const char **argv);

  void register_languages();

protected:

  bool process_goto_program(goto_functionst &goto_functions, 
                            optionst& options);

  bool get_goto_program(goto_functionst &goto_functions, 
                        optionst& options);

  void get_command_line_options(optionst &options);

  //read declared variables into list
  void get_declarations(var_listt&, const CFGt&);

  //read function arguments into list
  void get_function_arguments(
      var_listt& l,
      const goto_functionst::goto_functiont& f);

  std::auto_ptr<abstr_domaint> get_domain(
      optionst &options, 
      CFGt& cfg,
      goto_functionst::goto_functiont &fun,
      const namespacet& ns);

  void print_result(abstr_fwd_analysist& analysis, const optionst& options);
  
  void parse_inv_block(const std::string&, std::set<irep_idt>&);

  bool prune_expr(const std::set<irep_idt>& block_set, exprt&);

  void simplify_with_const_prop(
      CFGt& cfg, 
      const loop_infot& loop_info,
      const namespacet& ns);

  void simplify_with_expr_prop(
      CFGt& cfg, 
      const loop_infot& loop_info,
      const namespacet& ns);

  void unwind_cfg(
      CFGt& cfg, 
      const optionst& optionst);

  void print_annotated_nodes(
    const optionst& options, 
    const namespacet& n,
    const CFGt& cfg, 
    const abstr_fwd_analysist& analysis);

  ieee_floatt::rounding_modet get_rounding_mode(
    const optionst& options);
                    
};

#endif
