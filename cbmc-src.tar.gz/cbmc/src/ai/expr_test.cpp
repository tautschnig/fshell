#include <expr.h>

#include <std_expr.h>

void append_ops(exprt& e, unsigned nr)
{
  if(nr == 0)
  {
    e.copy_to_operands(true_exprt());
    e.copy_to_operands(false_exprt());
    return;
  }

  e.copy_to_operands(and_exprt());
  append_ops(e.op0(), nr-1);
}

void remove_ops(exprt& e)
{
  while(e.operands().size() != 0)
  {
    e.swap(e.op0());
  }
}

int main(void)
{
  exprt e;
  
  append_ops(e,10000);
  remove_ops(e);

  return 0;
}
