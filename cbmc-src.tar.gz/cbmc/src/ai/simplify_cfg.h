/*******************************************************************\

Module: Simplify CFG using an invariant generator

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef SIMPLIFY_CFG_H
#define SIMPLIFY_CFG_H

#include "inv_generator.h"

void simplify_cfg(
    const inv_generatort& inv, 
    const namespacet& ns,
    CFGt& cfg);

void simplify_cfg_node(
   const inv_generatort& inv,
   const namespacet& ns,
   CFGt& cfg);

#endif
