/*******************************************************************\

Module: Abstract DPLL

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_DPLL_H
#define ABSTR_DPLL_H

#include "abstr_fwd_analysis.h"
#include "domains/interval_array_domain.h"

#include <solvers/sat/satcheck_minisat2.h>
#include <solvers/flattening/boolbv.h>

#include <options.h>
#include <message.h>

#define VERBOSE

class abstr_dpllt : public abstr_fwd_analysist, public messaget
{
public:
  typedef abstr_fwd_analysist sub;

public:
  abstr_dpllt(
      const CFGt& cfg, 
      const loop_infot& _loop_info,
      interval_array_domaint& dom,
      unsigned widening_limit,
      const namespacet& ns, 
      const optionst& _options)
    : sub(cfg, _loop_info, dom, widening_limit, ns),
      iteration_limit(-1), options(_options), itv_array_domain(dom), 
      current_element(dom.top()) { }

  virtual ~abstr_dpllt() { };

  //perform the analysis
  virtual void perform_analysis();
  
  void set_iteration_limit(int i) { iteration_limit = i; }

protected:
  typedef hash_set_cont<symbol_exprt, irep_hash> symbol_sett;

  int iteration_limit;
  const optionst& options;
  interval_array_domaint& itv_array_domain;

  //current abstr clipping for search
  abstr_elementt current_element;

  //symbols that are not generalized
  std::set<irep_idt> ignored_symbols;

  symbol_sett decision_variables;

  virtual void init_analysis();
  abstr_vect unnecessary_top_vec;

protected:
  //return decision, or bottom if none are left
  virtual bool decide(abstr_elementt& elem) = 0;

  //returns false when a conflict is detected
  virtual bool deduce() = 0;

  virtual bool conflict_or_proof();

  //return the initial element for one iteration of the analysis
  virtual abstr_elementt get_initial_element();

  virtual void init(abstr_elementt& elem) = 0;

  //generalize the invariants
  virtual void generalize_proof(abstr_elementt& elem) = 0;

  //returns false if no further backtrack possible
  virtual bool learn_and_backtrack(abstr_elementt& elem) = 0;

  void get_symbols(symbol_sett &);
  void get_symbols(const exprt& e, symbol_sett& s);
  void filter_symbols(symbol_sett &);
  void get_ignored_symbols(std::set<irep_idt>& ids, const optionst& opt);
};
#endif
