/*******************************************************************\

Module: Abstract domain template with simple memory management.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ABSTR_DOMAIN_MEM_H
#define ABSTR_DOMAIN_MEM_H

#include "abstr_domain.h"

//memory managed abstr_domain for infinite size or very large domains
template <class elemT>
class abstr_domain_memt : virtual public abstr_domaint 
{
public:
  //these functions are implemented here, and cannot be overwritten
  //in subclasses, they call the *_inplace functions
  abstr_elementt& meet(
      abstr_elementt&, 
      const abstr_elementt& e);

  abstr_elementt& join(
      abstr_elementt&, 
      const abstr_elementt& e);

  abstr_elementt& widen(
      abstr_elementt&, 
      const abstr_elementt& e, 
      const abstr_elementt& threshold);

  abstr_elementt& apply_assign(
      abstr_elementt& a, 
      const exprt& lhs, 
      const exprt& rhs);

  abstr_elementt& apply_test(
      abstr_elementt& a, 
      const exprt& e,
      bool result);

  //provide read access to internal elements
  virtual const elemT& read(const abstr_elementt& e) const
  {
    return *get_refmon(e).first;
  }

  //these functions require implementation in subclasses, 
  virtual void  meet_inplace(elemT&, const elemT& e) = 0;

  virtual void  join_inplace(elemT&, const elemT& e) = 0;

  virtual void widen_inplace(
      elemT&, 
      const elemT& e, 
      const elemT& threshold) = 0;

  //return result of applying transfer function for c expression
  virtual void apply_assign_inplace(
      elemT& a, 
      const exprt& lhs, 
      const exprt& rhs) = 0;

  //return result of applying test for c expression
  virtual void apply_test_inplace(
      elemT& a, 
      const exprt& e, 
      bool result) = 0;

  //create abstract element from internal representation
  virtual abstr_elementt from_internal(const elemT& e)
  { return new_elem(new elemT(e)); }

  //make sure you know what you're doing when accessing this
  elemT& get_internal(abstr_elementt& e)
  {
    return write(e);
  }
  
protected:

  //provide implementations for mem_mgt functions
  //count references
  virtual void register_abstr_elem(abstr_elementt& e) 
  { get_refmon(e).second++; }

  virtual void deregister_abstr_elem(abstr_elementt& e)
  { 
    refmont *r = &get_refmon(e);
    assert(r->second != 0);

    if(r->second == 1) 
    {
      delete r->first; 
      delete r;
    }
    else 
      r->second--;
  }

  //create new internal element and return its external representation 
  //create with "new elemT(...)" as parameter
  //memory is freed by abstr_domain_mem
  virtual abstr_elementt new_elem(elemT* e) 
  {
    refmont *r = new refmont(e, 0);
    return abstr_elementt(*this, (void*) r);
  }


  //provide write access to internal elements
  virtual elemT& write(abstr_elementt& e) 
  { 
    detatch(e);
    return get_elem(e);
  }

  //provide unsafe access to internal elements 
  //(may not change semantics of e, only representation)
  virtual elemT& read_unsafe(const abstr_elementt& e) const
  {
    return get_elem(e);
  }


private:
  //reference counting for abstract elements
  typedef std::pair<elemT*, unsigned> refmont;
  
  virtual void set_refmon(abstr_elementt& e, refmont* refmon) const
  {
    if(&e.get_domain() != this)
      throw "Element not associated with this domain";
    e.ptr() = refmon;
  }

  virtual const refmont& get_refmon(const abstr_elementt& e) const
  {
    if(&e.get_domain() != this)
      throw "Element not associated with this domain";
    return *reinterpret_cast<const refmont*>(e.ptr());
  }

  virtual refmont& get_refmon(abstr_elementt& e) const
  {
    if(&e.get_domain() != this)
      throw "Element not associated with this domain";
    return *reinterpret_cast<refmont*>(e.ptr());
  }

  //provide write access to internal elements UNSAFE
  virtual elemT& get_elem(abstr_elementt& e) const
  {
    return *get_refmon(e).first;
  }

  //provide write access to internal elements UNSAFE
  virtual elemT& get_elem(const abstr_elementt& e) const
  {
    return *get_refmon(e).first;
  }


  //create new element if current element has more than one reference
  virtual void detatch(abstr_elementt& a)
  {
    refmont& r = get_refmon(a);
    assert(r.second != 0);
    if(r.second != 1)
    {
      //create a new element
      r.second--;
      assert(r.second != 0);
      refmont *r_new = new refmont(new elemT(*r.first), 1);
      set_refmon(a, r_new);
    }
  }
};

template <class elemT> 
abstr_elementt& 
abstr_domain_memt<elemT>::
meet(abstr_elementt& a1, const abstr_elementt& a2)
{
  detatch(a1);
  meet_inplace(get_elem(a1), read(a2));
  return a1;
}

template <class elemT> 
abstr_elementt& 
abstr_domain_memt<elemT>::
join(abstr_elementt& a1, const abstr_elementt& a2)
{
  detatch(a1);
  join_inplace(get_elem(a1), read(a2));
  return a1;
}

template <class elemT> 
abstr_elementt& 
abstr_domain_memt<elemT>::
widen(
    abstr_elementt& a1, 
    const abstr_elementt& a2, 
    const abstr_elementt& threshold)
{
  detatch(a1);
  widen_inplace(get_elem(a1), read(a2), read(threshold));
  return a1;
}

template <class elemT> 
abstr_elementt& 
abstr_domain_memt<elemT>::
apply_assign(
    abstr_elementt& a, 
    const exprt& lhs, 
    const exprt& rhs)
{
  detatch(a);
  apply_assign_inplace(get_elem(a),lhs,rhs);
  return a;
}

template <class elemT> 
abstr_elementt& 
abstr_domain_memt<elemT>::
apply_test(abstr_elementt& a, const exprt& e, bool result)
{
  detatch(a);
  apply_test_inplace(get_elem(a), e, result);
  return a;
}

#endif 
