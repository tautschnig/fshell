/*******************************************************************\

Module: Proof generalization using UNSAT core

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "core_generalization.h"

#include "get_symbol_vals.h"

#include <resolve_types.h>

#include <replace_expr.h>

#include <flatten_expr.h>

#include <arith_tools.h>

#include <find_expr.h>

/*******************************************************************\

Function: core_generalizationt::core_generalizationt
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

core_generalizationt::core_generalizationt(
    abstr_fwd_analysist& _analysis, 
    const namespacet& ns) 
: sub(_analysis, ns)
{ 
  for(unsigned i = 0; i < _analysis.get_cfg().size(); i++)
  {
    solvers.push_back(new satcheck_minisatt);
    boolbvs.push_back(new boolbvt(ns, *solvers.back()));
    
    true_lit = solvers.back()->new_variable();
    bvt bv; bv.push_back(true_lit);
    solvers.back()->lcnf(bv);

    false_lit = true_lit.negation();
  }
} 

/*******************************************************************\

Function:  core_generalizationt::repair_step
 
  Inputs:

 Outputs:

 Purpose: Repair a broken proof using conjuncts from a working proof.

\*******************************************************************/

void core_generalizationt::repair_step(
    const CFG_nodet& n,
    abstr_elementt& broken_element,
    const abstr_elementt& proof_elem,
    const id_sett& must_include) 
{
  if(n.type != GOTO && n.type != ASSUME &&
     n.type != ASSIGN && n.type != ASSERT)
  {
    throw "cannot repair node";
  } 

  //get solver and boolbv corresponding to node
  satcheck_minisatt& solver = *solvers[n.id];
  boolbvt& boolbv = *boolbvs[n.id];

  assert(!broken_element.is_bot());
   
  exprt pre = proof_elem.to_expr();
  bvt pre_assumpts;
    
  convert_conjunct(pre, boolbv, pre_assumpts);

  bool pre_has_false = remove_false(pre_assumpts);

  literalt has_pref_assignment; // ignore
  literalt post_holds = convert_transfer(n, boolbv, new_proof, has_pref_assignment);

  bvt all_assumpts = pre_assumpts;
  
  all_assumpts.push_back(post_holds.negation());
  
  //assumptions cannot be constants T or F, replace these by
  //literals that must be T or F
  replace_constants_by_lits(all_assumpts);

  //solve !(pre => post)  (== pre && !post)
  solver.set_assumptions(all_assumpts);
  propt::resultt r = solver.prop_solve();

  //we expect pre => post to hold, except if we removed false from pre
  if(r == propt::P_UNSATISFIABLE)
  {
    //use proof_elem of (pre => post) to weaken pre
    exprt weakened_invar_expr = 
      weaken_with_unsat_proof(pre, boolbv, solver, must_include);

    broken_element = analysis.get_domain().from_expr(weakened_invar_expr); 
    return;
  } else {
    if(!(r == propt::P_SATISFIABLE && pre_has_false))
    {
      //print some debug, then die
      if(n.type == ASSIGN)
      {
        expr_sett list;
        codet assign = n.code;
        resolve_types(assign, ns); 
        find_expr(assign, ID_symbol, list);

        for(expr_sett::const_iterator it = list.begin(); 
            it != list.end(); it++)
        {
          const exprt& e = *it;
          std::cout << e.pretty() << std::endl << boolbv.get(e).pretty()
                    << std::endl;
          exprt next = e;
          prime_symbol(next);
          std::cout << next.pretty() << std::endl << boolbv.get(next).pretty()
                    << std::endl;
        }
      }
      
      assert(0);
    }
    //return full proof_elem (== BOTTOM)
    

    broken_element = proof_elem;
    return;
  }

}

void core_generalizationt::convert_conjunct(
    const exprt& expr,
    boolbvt& boolbv,
    bvt& assumpts)
{
  exprt e = expr;

  //make into a flat conjunction
  make_flat(e, ID_and, typet(ID_bool));

  forall_operands(it, e) 
    assumpts.push_back(boolbv.convert(*it));
}

//returns a literal indicating whether postconditions are true
literalt core_generalizationt::convert_transfer(
    const CFG_nodet& n,
    boolbvt& boolbv,
    abstr_elementst& p,
    literalt& has_pref_assignment)
{
  switch(n.type)
  {
    case GOTO:
      return convert_goto(n, boolbv, p, has_pref_assignment);
      break;
    case ASSUME:
      return convert_assume(n, boolbv, p, has_pref_assignment);
      break;
    case ASSERT:
      return convert_assert(n, boolbv, p, has_pref_assignment);
      break;
    case ASSIGN:
      has_pref_assignment.make_true();
      return convert_assign(n, boolbv, p);
      break;
    default:
      assert(0);
  }
}

literalt core_generalizationt::convert_goto(
    const CFG_nodet& n,
    boolbvt& boolbv,
    abstr_elementst& p, literalt& has_pref_assignment)
{
  literalt l; 

  exprt vac_true_expr;
  vac_true_expr.make_true();

  assert(n.successor_next != NULL ||
         n.successor_jump != NULL);
  
  exprt cond = n.jump_condition;
  resolve_types(cond, ns);

  exprt neg_cond = cond;
  neg_cond.make_not();

  // (cond => jump_inv) && (!cond => next_inv)

  exprt result_expr(ID_and, typet(ID_bool));

  // (!cond => next_inv)
  if(n.successor_next != NULL) 
  { 
    exprt post = get_invariant(p, *n.successor_next).to_expr();
    exprt impl(ID_implies, typet(ID_bool));
    impl.move_to_operands(neg_cond);
    impl.move_to_operands(post);
    
    vac_true_expr = impl.op1();

    result_expr.move_to_operands(impl);
  }

  // (cond => jump_inv)
  if(n.successor_jump != NULL)
  {
    exprt post = get_invariant(p, *n.successor_jump).to_expr();
    exprt impl(ID_implies, typet(ID_bool));
    impl.move_to_operands(cond);
    impl.move_to_operands(post);
    
    exprt vac_true_tmp(ID_and, typet(ID_bool));
    vac_true_tmp.move_to_operands(vac_true_expr);
    vac_true_tmp.copy_to_operands(impl.op1());
    vac_true_expr.swap(vac_true_tmp);

    result_expr.move_to_operands(impl);
  }

  if(result_expr.operands().size() == 1)
  {
    exprt tmp = result_expr.op0();
    result_expr.swap(tmp);
  }

  has_pref_assignment = boolbv.convert(vac_true_expr);

  return boolbv.convert(result_expr);
}

literalt core_generalizationt::convert_assume(
    const CFG_nodet& n,
    boolbvt& boolbv,
    abstr_elementst& p, 
    literalt& has_pref_assignment)
{
  assert(n.successor_jump == NULL);

  if(n.successor_next == NULL) {
    literalt l;
    l.make_true();
    has_pref_assignment.make_true();
    return l;
  }
  
  // guard => post
  exprt guard = n.reasoning_guard;
  resolve_types(guard, ns);

  exprt post = get_invariant(p, *n.successor_next).to_expr();
  exprt impl(ID_implies, typet(ID_bool));

  impl.move_to_operands(guard);
  impl.move_to_operands(post);

  has_pref_assignment = boolbv.convert(impl.op1());

  return boolbv.convert(impl);
}

literalt core_generalizationt::convert_assert(
    const CFG_nodet& n,
    boolbvt& boolbv,
    abstr_elementst& p,
    literalt& has_pref_assignment)
{
  assert(n.successor_jump == NULL);
  exprt guard = n.reasoning_guard;
  resolve_types(guard, ns);

  if(n.successor_next == NULL) {
    return boolbv.convert(guard);
  } 

  //prefer assignments that are within array bounds
  exprt in_bounds = all_indices_in_bounds(guard);
  has_pref_assignment = boolbv.convert(in_bounds);

  // guard && post
  exprt post = get_invariant(p, *n.successor_next).to_expr();
  exprt and_expr(ID_and, typet(ID_bool));
  and_expr.move_to_operands(guard);
  and_expr.move_to_operands(post);

  return boolbv.convert(and_expr);
}

literalt core_generalizationt::convert_assign(
    const CFG_nodet& n,
    boolbvt& boolbv,
    abstr_elementst& p)
{
  if(n.successor_next == NULL) {
    literalt l;
    l.make_true();
    return l;
  }
  const code_assignt& assignment = to_code_assign(n.code);

  exprt lhs = assignment.lhs();
  exprt rhs = assignment.rhs();

  resolve_types(lhs, ns);
  resolve_types(rhs, ns);

  exprt assigned_symbol, primed_symbol;

  exprt eq =
    prime_assignment(lhs, rhs, assigned_symbol, primed_symbol);
  
  boolbv.set_to_true(eq);

  exprt post = get_invariant(p, *n.successor_next).to_expr();
  replace_expr(assigned_symbol, primed_symbol, post);

  //make sure lhs symbols are converted
  bvt dummy;
  boolbv.convert_bv(lhs, dummy);

  return boolbv.convert(post);
}

//eliminates conjuncts from e that were not necessary for the proof
exprt core_generalizationt::weaken_with_unsat_proof(
    const exprt& expr,
    const boolbvt& boolbv,
    const satcheck_minisatt& solver,
    const id_sett& must_include)
{
  exprt result(ID_and, typet(ID_bool));

  exprt e = expr;
  make_flat(e, ID_and, typet(ID_bool));

  //check whether operands were in proof
  Forall_operands(it, e)
  {
    assert(it->type().id() == ID_bool);
    literalt l = lit_from_cache(*it, boolbv);
    
    //if conjunct contributes to conflict, move to result
    if(solver.is_in_conflict(l) || has_symbol(*it, must_include))
      result.move_to_operands(*it);
  }

  if(result.operands().size() == 1)
  {
    exprt tmp = result.op0();
    result.swap(tmp);
  }
  else if(result.operands().size() == 0)
    result.make_true();
  
  return result;
}

literalt core_generalizationt::lit_from_cache(const exprt& e, const boolbvt& boolbv)
{
  const boolbvt::cachet& cache = boolbv.get_cache();

  if(e.is_true())
    return true_lit;

  if(e.is_false())
    return false_lit;

  boolbvt::cachet::const_iterator it = cache.find(e);
  assert(it != cache.end());

  return it->second;
}

core_generalizationt::~core_generalizationt()
{
  for(unsigned i = 0; i < solvers.size(); i++)
    delete solvers[i];
  for(unsigned i = 0; i < boolbvs.size(); i++)
    delete boolbvs[i];
}


void core_generalizationt::replace_constants_by_lits(bvt& bv)
{
  for(bvt::iterator it = bv.begin(); it != bv.end(); it++)
  {
    if(it->is_true())
      *it = true_lit;
    else if(it->is_false())
      *it = false_lit;
  }
}

bool core_generalizationt::remove_false(bvt& bv)
{
  bool has_false = false;
  for(bvt::const_iterator it = bv.begin();
      it != bv.end(); it++)
    if(it->is_false())
      has_false = true;

  return has_false;
}

void core_generalizationt::generalize_step(
    const CFG_nodet& n,
    abstr_elementt& elem,
    const id_sett& leave_untouched)
{ 
  /* This function uses the SAT solver to find some generalization of pre.
    If pre is not BOT, this does nothing. If it is BOT, then the SAT solver
    is used to identify a variable assignment that makes pre => post, where
    pre >= BOT. */

  abstr_elementt e = elem;

  if(!e.is_bot()) //only attempt to generalize if element is bot
    return;

  if(n.type != GOTO && n.type != ASSUME &&
      n.type != ASSIGN && n.type != ASSERT)
  {
    assert(n.successor_next != NULL);

    //simply return the next invariant (treat command as skip)
    elem = get_invariant(new_proof, *n.successor_next);
    return;
  } 
  else if(n.type == FUNCTION_CALL) 
  {
    throw "function calls not supported";
  }
  
  //bitblast statement and get a satisfying precondition from SAT solver

  satcheck_minisatt& solver = *solvers[n.id];
  boolbvt& boolbv = *boolbvs[n.id];

  literalt has_pref_assignment;
  literalt post_holds = convert_transfer(n, boolbv, new_proof, has_pref_assignment);
  bvt assumpts;
  assumpts.push_back(post_holds);
  
  //first try to make it true non vacuously
  assumpts.push_back(has_pref_assignment);
  replace_constants_by_lits(assumpts);
  //assume transfer + post holds
  solver.set_assumptions(assumpts);
  propt::resultt r = solver.prop_solve();

  if(r == propt::P_UNSATISFIABLE)
  {
    //if it cannot be made true non-vacuously, try to make it true in some way
    assumpts.pop_back();
    solver.set_assumptions(assumpts);
    r = solver.prop_solve();
  }

  if(r == propt::P_SATISFIABLE)
  { 
    expr_sett symbols;
    get_symbols(n, symbols, new_proof);//get all symbols relevant to n in proof
    exprt pre_expr = get_symbol_vals(boolbv, symbols);

    resolve_types(pre_expr, ns);
    abstr_elementt result = analysis.get_domain().from_expr(pre_expr);
  
    //only return if the abstract domain can actually prove it
    if(valid_pre(n, result, new_proof))
    {
      elem = result;
      return;
    }
    else return;

  } else if(r == propt::P_UNSATISFIABLE)
  {
    return; //return bot (== elem)
  } else assert(0);

} 

void core_generalizationt::get_symbols(
    const CFG_nodet& n, 
    expr_sett& dest,
    abstr_elementst& p)
{
  if(n.type == ASSERT || n.type == ASSUME)
  {
    find_expr(n.reasoning_guard, ID_symbol, dest);
  } 
  else if(n.type == ASSIGN) 
  {
    const code_assignt& assign = to_code_assign(n.code);
    find_expr(assign.lhs(), ID_symbol, dest);
    find_expr(assign.rhs(), ID_symbol, dest);
  } 
  else if(n.type == GOTO) 
  {
    find_expr(n.jump_condition, ID_symbol, dest);
  } else 
  {
    assert(0);
  }

  //get symbols occurring in post conditions
  if(n.successor_next != NULL) {
    exprt post_next = get_invariant(p, *n.successor_next).to_expr();
    find_expr(post_next, ID_symbol, dest);
  } 
  if(n.successor_jump != NULL) {
    exprt post_jump = get_invariant(p, *n.successor_jump).to_expr();
    find_expr(post_jump, ID_symbol, dest);
  } 
}


exprt core_generalizationt::all_indices_in_bounds(const exprt& e)
{
  if(e.operands().size() == 0)
  {
    exprt t; t.make_true(); return t;
  } 
    
  exprt and_expr(ID_and, typet(ID_bool));
  
  forall_operands(it, e)
  {
    exprt in_bounds = all_indices_in_bounds(*it);
    if(!in_bounds.is_true())
      and_expr.copy_to_operands(in_bounds);
  }

  if(e.id() == ID_index)
  {
    const index_exprt &index = to_index_expr(e);
    const exprt& size = to_array_type(index.array().type()).size();
    exprt zero = from_integer(mp_integer(0), size.type());
    assert(zero.is_not_nil());
    
    exprt ge_zero(ID_ge, typet(ID_bool));
    ge_zero.copy_to_operands(index.index(), zero);

    exprt lt_size(ID_lt, typet(ID_bool));
    lt_size.copy_to_operands(index.index(), size);
    assert(index.index().type() == size.type());

    and_exprt index_valid(ge_zero, lt_size);
    and_expr.move_to_operands(index_valid);
  }

  if(and_expr.operands().size() == 0)
    and_expr.make_true();
  else if(and_expr.operands().size() == 1)
  {
    exprt tmp = and_expr.op0();
    and_expr.swap(tmp);
  }

  return and_expr;
}

/*******************************************************************\

Function: core_generalizationt::prime_assignment

  Inputs: lhs, rhs

 Outputs: symbol of the assignnment and its primed variant,
          warning. Return value is the equality generated for the 
          assignment.

 Purpose:

\*******************************************************************/

exprt core_generalizationt::prime_assignment(
  const exprt& lhs, 
  const exprt& rhs,
  exprt& symbol, 
  exprt& primed_symbol)
{
  if(lhs.id() == ID_symbol)
  {
    symbol = lhs;
    primed_symbol = lhs;
    prime_symbol(primed_symbol);

    return equality_exprt(primed_symbol, rhs);
  } 
  else if(lhs.id() == ID_member)
  {
    const member_exprt& m = 
      to_member_expr(lhs);
    
    const exprt& component_name = m.find_expr(ID_component_name);
    assert(component_name.is_not_nil());
    
    with_exprt w(m.struct_op(), exprt(ID_member_name), rhs);
    w.where().set(ID_component_name, component_name);
    return prime_assignment(m.struct_op(), w, symbol, primed_symbol);
  }
  else if(lhs.id() == ID_index)
  {
    const index_exprt& i = 
      to_index_expr(lhs);
    
    with_exprt w(i.array(), i.index(), rhs);
    return prime_assignment(i.array(), w, symbol, primed_symbol);

  } else assert(0);

  return nil_exprt();
}


void core_generalizationt::prime_symbol(exprt& s)
{
  assert(s.id() == ID_symbol);
  symbol_exprt& sym = to_symbol_expr(s);

  sym.set_identifier(sym.get_identifier().as_string() + "###next_symbol###");
}

