/*******************************************************************\

Module: Proof generalization using UNSAT core

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef CORE_GENERALIZATION_H
#define CORE_GENERALIZATION_H

#include "proof_step_generalization.h"

#include <find_expr.h>

#include <solvers/flattening/boolbv.h>
#include <solvers/sat/satcheck_minisat2.h>

class core_generalizationt : virtual public proof_step_generalizationt
{
public:
  typedef proof_step_generalizationt sub;

public:
  core_generalizationt(
      abstr_fwd_analysist& _analysis, 
      const namespacet& ns);

  virtual ~core_generalizationt();

  virtual void generalize_step(
    const CFG_nodet&, 
    abstr_elementt& elem,
    const id_sett& do_not_generalize);

  //locally repair broken proof step
  virtual void repair_step(
    const CFG_nodet&, 
    abstr_elementt& broken_pre,
    const abstr_elementt& proof,
    const id_sett& must_include);

protected:
  typedef std::vector<satcheck_minisatt*> satcheck_minisatst;
  typedef std::vector<boolbvt*> boolbvst;

  satcheck_minisatst solvers;
  boolbvst boolbvs;

  literalt true_lit;
  literalt false_lit;

protected:
  //returns a set of literals, one for each conjunct in e
  virtual void convert_conjunct(
      const exprt& e,
      boolbvt& boolbv,
      bvt& assumptions);

  //returns a literal indicating whether postcondition holds
  virtual literalt convert_transfer(
      const CFG_nodet& n,
      boolbvt& boolbv,
      abstr_elementst &p, 
      literalt& has_pref_assignment);

  virtual literalt convert_goto(
      const CFG_nodet& n,
      boolbvt& boolbv,
      abstr_elementst &p,
      literalt& has_pref_assignment);

  virtual literalt convert_assume(
      const CFG_nodet& n,
      boolbvt& boolbv,
      abstr_elementst &p, 
      literalt& has_pref_assignment);

  virtual literalt convert_assert(
      const CFG_nodet& n,
      boolbvt& boolbv,
      abstr_elementst &p,
      literalt& has_pref_assignment);

  virtual literalt convert_assign(
      const CFG_nodet& n,
      boolbvt& boolbv,
      abstr_elementst &p);

  //eliminates conjuncts from e that were not necessary for the proof
  virtual exprt weaken_with_unsat_proof(
      const exprt& e,
      const boolbvt& bv,
      const satcheck_minisatt& solver,
      const id_sett& must_include);

  //transform a = a + b into a' = a + b, return the changed lhs,
  //the assigned symbol, and its primed variant
  exprt prime_assignment(
      const exprt& lhs, 
      const exprt& rhs, 
      exprt& symbol, 
      exprt& primed_symbol);

  exprt all_indices_in_bounds(const exprt& e);
  
  void replace_constants_by_lits(bvt& bv);

  bool remove_false(bvt& bv);

  literalt lit_from_cache(const exprt& e, const boolbvt& boolbv);

  void get_symbols(
      const CFG_nodet& n, 
      expr_sett& dest, 
      abstr_elementst& proof);
  
  void prime_symbol(exprt& symbol);

};


#endif


