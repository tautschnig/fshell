/*******************************************************************\

Module: BMC with additional interval invariant constraints.
        All assigned variables are constrained to value ranges
        given by invariants.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef ITV_INVAR_BMC
#define ITV_INVAR_BMC

#include <goto-programs/control_flow_graph.h>

#include <hash_cont.h>
#include <solvers/prop/literal.h>
#include <cbmc/bmc.h>
#include <cbmc/bv_cbmc.h>
#include <solvers/sat/satcheck.h>

class itv_invar_bmct : protected bmct 
{
public:
  typedef hash_set_cont<symbol_exprt, irep_hash> symbol_sett;

  itv_invar_bmct(const CFGt& cfg, 
                 message_handlert& mh,
                 const optionst& options,
                 const symbol_sett& constrain_vars);

  
  void set_lower_bound(const symbol_exprt& sym, const constant_exprt& val)
  { lower_bound_vals[sym] = val; }

  void set_upper_bound(const symbol_exprt& sym, const constant_exprt& val)
  { upper_bound_vals[sym] = val; }

  void clear_constraints() { assumptions.clear(); }

  bool do_bmc();
  
  //return generalized restriction
  exprt generalize();

  constant_exprt generalize_constant(
      const symbol_exprt& sym, 
      bool lb, 
      const constant_exprt& c);

protected:
  bvt assumptions;
  const symbol_sett& constrain_vars;

  typedef hash_map_cont<symbol_exprt, symbol_exprt, irep_hash> sym_sym_mapt;
  typedef hash_map_cont<symbol_exprt, constant_exprt, irep_hash> sym_const_mapt;

  typedef hash_map_cont<exprt, exprt, irep_hash> debug_mapt;
  debug_mapt upper_bound_exprs;
  debug_mapt lower_bound_exprs;


  void set_bound_assumptions();

  void set_bound_assumptions(
      const symbol_exprt& sym, 
      const std::string& val, 
      bool lower);


  sym_sym_mapt lower_bounds, upper_bounds;
  sym_sym_mapt enable_upper, enable_lower;

  sym_const_mapt lower_bound_vals;
  sym_const_mapt upper_bound_vals;

  const CFGt& cfg;
  goto_functionst goto_functions;
  unsigned aux_symbol_counter;
  
  satcheckt satcheck;
  bv_cbmct bv_cbmc;

  symbol_exprt new_aux_symbol(const std::string& s, const typet& t);

  symbol_exprt to_first_ssa(const symbol_exprt&);

  void assume_symbol(const symbol_exprt& sym, const std::string& val);

  bool check_converted(const exprt& s);
  
};

#endif
