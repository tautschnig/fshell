#include <iostream>
#include <cmath>
#include <cstdlib>

#include "domains/float_interval_element.h"
#include <std_types.h>

#define PINF (1.0f/0.0f)
#define NINF (-1.0f/0.0f)

floatbv_typet float_type;

float random_float()
{
  union
  {
    float f;
    unsigned i;
  } u;

  unsigned r = ((unsigned) random()) % 20;

  switch(r)
  {
    case 0:
      return PINF;
    case 1:
      return NINF;
    case 2:
      return PINF+NINF;
    case 3:
      return 0.0f;
    case 4:
      return -0.0f;
    case 5:
      //subnormal number
      u.i=std::rand();
      u.i=(u.i<<16)^std::rand();
      u.i &= 2155872255u;//mask out exponent
      return u.f;
    default: 
      u.i=std::rand();
      u.i=(u.i<<16)^std::rand();
      return u.f;
  }
}

int bin_search(const float_intervalt& f, 
               const ieee_floatt& target, 
               unsigned depth, bool median)
{
  assert(f.contains(target));
  assert(!median || depth < 100);

  if(f.is_singleton())
  {
    return depth;
  } else {
    float_intervalt half(f);
    half.halve_lower(median);
    if(!half.contains(target))
      half.complement(f);
    return bin_search(half, target, depth+1, median);
  }
}

int main(void)
{
  float_type.set_width(32);
  float_type.set_f(23);

  srand(0);
  ieee_floatt fl;
  float f = 0.0f;
  fl.from_float(f);

  unsigned long depth_sum = 0;
    
  for(int i = 0; i < 1000; i++)
  {
    bool median = false;

    f = random_float();
    fl.from_float(f);
    if(fl.is_NaN())
    {
      i--;
      continue;
    }

    float_intervalt f_itv(float_type);
    f_itv.set_non_nan();

    unsigned depth = bin_search(f_itv, fl, 0, median);
    depth_sum += depth;

    if(i%100 == 0 && i)
    {
      std::cerr << i << " found, average depth " 
                << ( ((float) depth_sum) / i) << std::endl;
    }
  
    median = !median;

    assert(depth);
  }

  return 0;
}
  
