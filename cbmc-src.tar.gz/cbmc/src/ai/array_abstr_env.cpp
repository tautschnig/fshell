/*******************************************************************\

Module: Abstract environments with simple support for fixed size arrays.
        Arrays are represented explicitly and internally handled as 
        symbols.

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#include "array_abstr_env.h"

#include <find_expr.h>

#include <arith_tools.h>
#include <std_types.h>

#include <sstream>


/*******************************************************************\

Function: array_abstr_envt::get_possible_targets

  Inputs: 

 Outputs: Returns false if the expression cannot be handled 
          (e.g., potential overflow, array type not supported)

 Purpose: Return all symbols representing array values that this 
          index expression could apply to in context.

\*******************************************************************/

bool array_abstr_envt::get_possible_targets(
    const exprt& index,
    const var_mapt& context,
    std::vector<exprt>& o,
    fwd_mapt* cache)
{
  //std::cout << "get possible targets called " << std::endl;
  assert( index.id() == ID_member || index.id() == ID_index);
  assert( array_emul.supported(index) );
  
  exprt index_cp = index;
  return rec_get_possible_targets(index_cp, context, index_cp, o, cache);
}
/*******************************************************************\

Function: array_abstr_envt::dim_size
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

mp_integer array_abstr_envt::dim_size(const array_typet& t)
{
  mp_integer result;
  return to_integer(t.size());
}
/*******************************************************************\

Function: array_abstr_envt::to_integer
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

mp_integer array_abstr_envt::to_integer(const exprt& e)
{
  mp_integer result;
  bool failed = ::to_integer(e, result);
  assert(!failed);
  return result;
}

/*******************************************************************\

Function: array_abstr_envt::rec_get_possible_targets

  Inputs: 

 Outputs:

 Purpose: Recursive helper function for get_possible_targets

\*******************************************************************/

bool array_abstr_envt::rec_get_possible_targets(
    const exprt& cur_expr_full,
    const var_mapt& context,
    exprt& cur_expr_sub,
    std::vector<exprt>& result,
    fwd_mapt* cache)
{
  if(cur_expr_sub.id() != ID_index && cur_expr_sub.id() != ID_member)
  {
    exprt emulated = array_emul.emulate(cur_expr_full);
    result.push_back(
      emulated 
    );
    return true;
  }

  if(cur_expr_sub.id() == ID_member)
    return rec_get_possible_targets(
              cur_expr_full, 
              context, 
              cur_expr_sub.op0(), 
              result, cache); 

  //leave constants in index expression untouched, replace all other
  //expressions by all their forward interpretations
  index_exprt& cur_index = to_index_expr(cur_expr_sub);

  if(cur_index.index().is_constant())
  {
    //CASE 1: index expression is already constant
    //--> check for safety, else do nothing
    mp_integer idx = to_integer(cur_index.index());

    if(idx < 0 || idx >= dim_size(to_array_type(cur_index.array().type())))
      return false;

    return rec_get_possible_targets(
              cur_expr_full, context, cur_index.array(), result, cache);

  } else {

    var_elementt index_val = fwd_interpret(cur_index.index(), context, cache);

    if(var_domain.is_singleton(index_val))
    {
      //CASE 2: index expression is non-constant, but fwd interpretation 
      //        yields a single possible constant value
      //--> replace index expression by this constant

      exprt indexing_constant = index_val.to_expr();

      //check for legal index
      mp_integer c_index = to_integer(indexing_constant);

      if(c_index < 0 || 
         c_index >= dim_size(to_array_type(cur_index.array().type())))
        return false;
      
      cur_index.index().swap(indexing_constant);

      return rec_get_possible_targets(
              cur_expr_full, context, cur_index.array(),result, cache);

    } else {
      //CASE 3: index expression is non-constant and fwd interpretation 
      //        yields more than one possible concrete value
      //--> replace index expression by each possible constant in turn

      const exprt& array_size = 
        to_array_type(cur_index.array().type()).size();
      assert(array_size.is_constant());

      mp_integer size = to_integer(array_size);
        
      //Check whether index element is guaranteed to describe a valid index

      //Create "INDEX IS INVALID" expression
      //1) too small?
      exprt too_small(ID_lt, typet(ID_bool));
      too_small.copy_to_operands(cur_index.index());
      too_small.copy_to_operands(
        from_integer(
          mp_integer(0), 
          cur_index.index().type()));
      
      //2) too large
      exprt too_large(ID_ge, typet(ID_bool));
      too_large.copy_to_operands(cur_index.index());
      too_large.copy_to_operands(array_size);

      //  invalid = too small or too large
      exprt index_invalid(ID_or, typet(ID_bool));
      index_invalid.move_to_operands(too_small);
      index_invalid.move_to_operands(too_large);

      //  check if invalid is possible
      var_mapt invalid_possible;
      if(cache != NULL) 
        invalid_possible = bwd_interpret_bool(index_invalid, context, true, *cache);
      else
      {
        fwd_mapt m;
        invalid_possible = bwd_interpret_bool(index_invalid, context, true, m);
      }

      if(!invalid_possible.is_bot())
        return false; 
        //if it is possible to violate array bounds, we return false

      //1) Generate all possible index constants i, for 0 <= i < array_size
      //2) Tests if index constant is consistent with abstract element
      //3) If consistent instantiate recursively

      bool valid = true; 
      for(mp_integer i = 0; i < size; i=i+1)
      {
        //TODO: consider better handling if this is inefficient
        exprt i_expr = from_integer(i, cur_index.index().type());
        var_elementt i_val = fwd_interpret(i_expr, context, cache);
        i_val.meet(index_val);
        if(!i_val.is_bot())
        {
          cur_index.index().swap(i_expr); 
          valid = valid && rec_get_possible_targets(
                  cur_expr_full, context, cur_index.array(),result, cache);
        }

      }
      
      return valid;

    } //endif CASE 3
  } //endif CASE 1 || CASE 3

}


/*******************************************************************\

Function: array_abstr_envt::apply_assign_inplace

  Inputs: 

 Outputs:

 Purpose: Provide special handling for index expressions

\*******************************************************************/

void array_abstr_envt::apply_assign_inplace(
    var_mapt& a, 
    const exprt& lhs, 
    const exprt& rhs)
{
  apply_assign_inplace(a, lhs, rhs, a); //src == dest
}

/*******************************************************************\

Function: array_abstr_envt::apply_assign_inplace

  Inputs: 

 Outputs:

 Purpose: Provide special handling for index expressions

\*******************************************************************/

void array_abstr_envt::apply_assign_inplace(
    const var_mapt& src, 
    const exprt& lhs, 
    const exprt& rhs,
    var_mapt& dest)
{
  if(lhs.id() == ID_index || lhs.id() == ID_member)
  {
    if( ! array_emul.supported(lhs) )
      return; //Do not want!

    std::vector<exprt> possible_targets;
    bool valid = get_possible_targets(lhs, src, possible_targets, NULL); 

    if(!valid)
    {
      dest.set_top();
      return;
    }

    if(possible_targets.size() == 0)
    {
      //failing indexing expression, make bottom
      dest.set_bot();
      return;

    } else if(possible_targets.size() == 1)
    {

      //strong update
      sub::apply_assign_inplace(dest, possible_targets.front(), rhs);

    } else {

      var_elementt val = fwd_interpret(rhs, src, NULL);

      //weak update
      for(std::vector<exprt>::iterator it = possible_targets.begin();
          it != possible_targets.end(); it++)
      {
        weak_update_variable_value(dest, to_symbol_expr(*it), val);
      }

    }
  } else if(lhs.type().id() == ID_array || 
            lhs.type().id() == ID_struct) {
    //array or struct intialization

    if( ! array_emul.supported(lhs.type()) )
      return; //do not want

    std::vector<exprt> lhs_assignables, rhs_assignables;
    array_emul.get_all_assignables(lhs, lhs_assignables); 
    array_emul.get_all_assignables(rhs, rhs_assignables); 

    array_emul.emulate(lhs_assignables);
    array_emul.emulate(rhs_assignables);
    
    apply_parallel_assign_inplace(dest, lhs_assignables, rhs_assignables);

  } else sub::apply_assign_inplace(src, lhs, rhs, dest);
} 

/*******************************************************************\

Function: array_abstr_envt::weak_update_variable_value

  Inputs: 

 Outputs:

 Purpose: Perform a weak update of the value of a variable.

\*******************************************************************/

void array_abstr_envt::weak_update_variable_value(
    var_mapt& var_map,
    const symbol_exprt& s, 
    var_elementt& val)
{
  if(var_map.is_bot() && val.is_bot())
  {
    return;
  }

  if(var_map.is_bot())
  { 
    //clear map first to enable assignment to val
    var_map.set_top();
  }

  if(val.is_bot())
  {
    //just retain the old map, nothing changes
    return;
  }

  var_mapt::iterator it = var_map.find(s);

  if(it != var_map.end())
    it->second.join(val);

}


/*******************************************************************\

Function: array_abstr_envt::fwd_interpret

  Inputs: 

 Outputs:

 Purpose: Forward interpretation with special handling of symbols
          representing array values

\*******************************************************************/

abstr_env_domaint::var_elementt array_abstr_envt::fwd_interpret_nocache(
  const exprt& e, 
  const var_mapt& context,
  fwd_mapt* cache)
{
  if(e.id() == ID_index || e.id() == ID_member)
  {
    if( ! array_emul.supported(e) )
      return var_domain.top(e.type()) ;

    std::vector<exprt> possible_targets;

    bool valid = get_possible_targets(e, context, possible_targets, cache); 

    if(!valid)
      return var_domain.top(e.type());

    assert(possible_targets.size() > 0);

    var_elementt result = 
      sub::fwd_interpret_nocache(possible_targets.front(), context, cache);
    
    //return the join of all possible targets
    for(std::vector<exprt>::iterator it = ++possible_targets.begin();
        it != possible_targets.end(); it++)
    {
      if(result.is_top())
        break;
      result.join(sub::fwd_interpret(*it, context, cache));
    }
    
    return result;
  } else return sub::fwd_interpret_nocache(e, context, cache);


}
/*******************************************************************\

Function: array_abstr_envt::bwd_interpret_bool
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

var_mapt array_abstr_envt::bwd_interpret_bool(
  const exprt& e, 
  const var_mapt& context,
  bool result,
  fwd_mapt& cache)
{
  if((e.id() == ID_equal || e.id() == ID_notequal) &&
        (e.op0().type().id() == ID_array ||
         e.op0().type().id() == ID_struct))
  {
    exprt and_expr(ID_and, typet(ID_bool));
    std::vector<exprt> lhs_assignables, rhs_assignables;
    array_emul.get_all_assignables(e.op0(), lhs_assignables); 
    array_emul.get_all_assignables(e.op1(), rhs_assignables); 
    assert(lhs_assignables.size() == rhs_assignables.size());
    assert(lhs_assignables.size() > 0);
    
    std::vector<exprt>::const_iterator it1, it2;
    for(it1 = lhs_assignables.begin(), it2 = rhs_assignables.begin();
        it1 != lhs_assignables.end(); it1++, it2++)
    {
      exprt eq_expr(e.id(), typet(ID_bool));
      eq_expr.copy_to_operands(*it1);
      eq_expr.copy_to_operands(*it2);
      and_expr.move_to_operands(eq_expr);
    }
    
    return bwd_interpret_bool(and_expr, context, result, cache); 
  } 
  else 
  {
    return sub::bwd_interpret_bool(e, context, result, cache);
  }

}

//special handling of array values
void array_abstr_envt::bwd_interpret_arith(
    const exprt& e, 
    const var_mapt& context,
    const var_elementt& value, 
    var_mapt& result,
    fwd_mapt& cache
)
{
  if(e.id() == ID_index || e.id() == ID_member)
  {
    std::vector<exprt> possible_targets;

    if( ! array_emul.supported(e) )
      return; //do not want

    bool valid = get_possible_targets(e, context, possible_targets, &cache); 

    if(!valid)
      return;

    assert(possible_targets.size() >= 1);
    
    if(possible_targets.size() == 1)
    {
      //get fwd value of array symbol representing array 
      var_elementt fwd_value = 
        fwd_interpret(possible_targets.front(), context, &cache);

      //meet fwd value with value imposed by bwd interpretation
      fwd_value.meet(value);

      if(fwd_value.is_bot())
      {
        result.set_bot();
        return;
      }
      
      if(possible_targets.front().id() == ID_symbol)
      {
        //set symbol corresponding to array index to result
        set_variable_value(
            result, to_symbol_expr(possible_targets.front()), fwd_value);
      }

    } else
    {
      //restrict by (a[i1] == value) || (a[i2] == value) || ...
      //in this domain we can only check whether such an assignment is
      //possible

      for(std::vector<exprt>::iterator it = possible_targets.begin();
          it != possible_targets.end(); it++)
      {
        var_elementt fwd_value = 
          fwd_interpret(*it, context, &cache);

        if(!fwd_value.meet(value).is_bot())
          return; //bwd value is consistent, return the result unchanged
      }
      
      //bwd value is inconsistent, return bot
      result.set_bot();
    }

    return;
  } 
  else 
    sub::bwd_interpret_arith(e, context, value, result, cache);
}


/*******************************************************************\

Function: array_abstr_envt::to_expr

  Inputs: 

 Outputs:

 Purpose: Special handling of symbols representing array index expressions

\*******************************************************************/

exprt array_abstr_envt::to_expr(const abstr_elementt& a)
{
  exprt result = sub::to_expr(a);
  array_emul.replace_symbols_by_orig(result);
  return result;
}


/*******************************************************************\

Function: array_abstr_envt::to_expr

  Inputs: 

 Outputs:

 Purpose: Special handling of symbols representing array index expressions

\*******************************************************************/

exprt array_abstr_envt::to_expr(
    const abstr_elementt& a, 
    std::vector<symbol_exprt>& symbols)
{
  exprt result = sub::to_expr(a, symbols);
  array_emul.replace_symbols_by_orig(result);
  return result;
}

/*******************************************************************\

Function: array_abstr_envt::to_expr_omit_arrays

  Inputs: 

 Outputs:

 Purpose: Do not translate non-array symbols

\*******************************************************************/

exprt array_abstr_envt::to_expr_omit_arrays(const abstr_elementt& a)
{
  const var_mapt& v = read(a);
  
  std::vector<symbol_exprt> primitive_symbols;
  for(var_mapt::const_iterator it = v.begin(); it != v.end(); it++)
  {
    if(!array_emul.is_aux_symbol(it->first))
      primitive_symbols.push_back(it->first);
  }

  exprt result = sub::to_expr(a, primitive_symbols);

  return result;
}

/*******************************************************************\

Function: array_abstr_envt::get_used_symbols
 
  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void array_abstr_envt::get_used_symbols(
    const abstr_elementt& elem, 
    hash_set_cont<exprt, irep_hash>& symbols) const
{
  if(elem.is_top() || elem.is_bot())
    return;

  const var_mapt& m = read(elem);

  for(var_mapt::const_iterator it = m.begin(); it != m.end(); ++it)
  {
    if(it->second.is_top())
      continue;

    if(!array_emul.is_aux_symbol(it->first))
      symbols.insert(it->first);
    else 
    {
      //first translate symbol
      exprt e = it->first;
      array_emul.replace_symbols_by_orig(e);
      find_expr(e, ID_symbol, symbols);
    }
  }
}
