#include "widening_strategy.h"

#include <iostream>

bool 
simple_widening_strategyt::apply_widening()
{
  bool result = schedule.is_loop_header() && 
                schedule.iterations_in_loop() >= iterations_to_widening;

  return result;
}
