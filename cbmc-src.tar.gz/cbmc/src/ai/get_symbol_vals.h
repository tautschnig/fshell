/*******************************************************************\

Module: Extract conjunction of equalities from SAT assignment

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef GET_SYMBOL_VALS_H
#define GET_SYMBOL_VALS_H

#include <solvers/flattening/boolbv.h>
#include <hash_cont.h>

typedef hash_set_cont<symbol_exprt, irep_hash> symbol_sett;
typedef hash_set_cont<exprt, irep_hash> expr_sett;

exprt get_symbol_vals(const boolbvt& p, const symbol_sett&);
exprt get_symbol_vals(const boolbvt& p, const expr_sett&);

#endif
