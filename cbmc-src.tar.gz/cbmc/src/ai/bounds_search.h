/*******************************************************************\

Module: Proof generalization using search on constants

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef BOUNDS_SEARCH_H
#define BOUNDS_SEARCH_H

#include "bound_search.h"
#include "abstr_env.h"
#include "domains/interval_var_domain.h"

struct search_entryt {
  search_entryt() : itv(NULL), s(NULL) {} 
  search_entryt(itvt* _itv, const_bound_searcht* _s) : itv(_itv), s(_s) { }

  itvt* itv;
  const_bound_searcht* s; 
};
typedef std::vector<search_entryt> search_entriest;


class bounds_searcht : public bound_searcht
{
public:
  bounds_searcht(
    abstr_elementt& _elem,
    abstr_env_domaint& _abstr_env,
    interval_var_domaint& _itv_var);

  virtual bool has_next() {return !done; }
  void next(bool widen); 

  virtual ~bounds_searcht();

protected:  
  abstr_elementt& elem;
  abstr_env_domaint& abstr_env;
  interval_var_domaint& itv_var;

  search_entriest search_entries;
  int cur;
  bool done;
  bool drop_mode;
  bool all_bounds_done;
};

#endif
