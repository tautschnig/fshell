/*******************************************************************\

Module: Proof generalization using search on constants at the 
        granularity of single statements

Author: Leopold Haller, leopoldhaller@gmail.com

\*******************************************************************/

#ifndef SEARCH_GENERALIZATION_H
#define SEARCH_GENERALIZATION_H

#include "proof_step_generalization.h"

#include "domains/interval_array_domain.h"

class search_generalizationt : virtual public proof_step_generalizationt
{
public:
  typedef proof_step_generalizationt sub;

public:
  search_generalizationt(
      abstr_fwd_analysist& _analysis, 
      interval_array_domaint& _itv_dom, 
      const namespacet& ns);

  //locally generalize elem at node
  virtual void generalize_step(
    const CFG_nodet&, 
    abstr_elementt& elem,
    const id_sett& do_not_generalize);

  //locally repair broken proof step
  virtual void repair_step(
    const CFG_nodet&, 
    abstr_elementt& pre,
    const abstr_elementt& proof,
    const id_sett& must_include);

 protected:
   interval_array_domaint& itv_dom;

  void get_transition_symbols(
    const CFG_nodet& n, 
    hash_set_cont<exprt,irep_hash>&);

  void get_post_symbols(
    const CFG_nodet& n,
    hash_set_cont<exprt, irep_hash>&);

  void get_post_subexpr(
    const CFG_nodet& n,
    hash_set_cont<exprt, irep_hash>&);

  void get_all_symbols(
    const abstr_elementt& n,
    hash_set_cont<exprt, irep_hash>&);
  
};

#endif
