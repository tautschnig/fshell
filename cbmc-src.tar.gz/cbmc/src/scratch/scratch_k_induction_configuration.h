/*
 * scratch_k_induction_configuration.h
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#ifndef SCRATCH_K_INDUCTION_CONFIGURATION_H_
#define SCRATCH_K_INDUCTION_CONFIGURATION_H_

#include <goto-programs/goto_program.h>

#include <k-induction/k_induction_configuration.h>

#include <util/namespace.h>


class scratch_k_induction_configurationt: public k_induction_configurationt {
public:
	scratch_k_induction_configurationt() { }
	virtual ~scratch_k_induction_configurationt() { }
	virtual void havoc_globals(goto_programt& method, const namespacet ns);
	virtual void add_loop_invariants(goto_programt& loop_body, const namespacet ns);
};

#endif /* SCRATCH_K_INDUCTION_CONFIGURATION_H_ */
