/*
 * dma_simple_tracking_analyser.cpp
 *
 *  Created on: May 7, 2010
 *      Author: alad
 */

#include <ansi-c/c_types.h>
#include <util/arith_tools.h>
#include <util/expr_util.h>
#include <util/pointer_offset_size.h>

#include <ansi-c/expr2c.h>

#include <goto-programs/goto_functions.h>
#include <goto-programs/show_claims.h>

#include <langapi/language_ui.h>

#include <loopfrog/pointer_expr.h>

#include <k-induction/k_induction.h>

#include "dma_simple_tracking_analyser.h"

#include "tracker_variables.h"

#define DMA_FREE_REGION "dma_free_region"

static bool function_name_is_dma_free_region(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");
	return expr2c(operand, ns) == DMA_FREE_REGION;
}


static bool is_dma_free_region(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_dma_free_region(inst.code.op1(), ns);
}


void dma_simple_tracking_analysert::instrument_program(goto_functionst& all_functions)
{
	check_for_barriers(all_functions);
	check_for_fences(all_functions);

	// 1. Declare variables, __valid, __is_get, __ls, __size, __tag
	// 2. Set __valid[i] = 0
	// 3. Declare tag mask variable
	// 3. Replace each write_tag_mask with write to tag mask variable
	// 3. Replace each wait with __valid = __valid && (IS_0 (tag_mask, __tag))
	// 4. Replace each put/get with check against the logged operation, if valid.  Then, nondeterministic
    //    choose whether to log the new operation

	if(NUM_TRACKED_DMAS > 0)
	{
		/***** Declare variable to log the tags that are in use */
		add_global_declaration(TAGS_IN_USE, tags_in_use_symbol, uint_type());
		add_static_initialiser(tags_in_use_symbol, from_integer(0, uint_type()), all_functions);

		/***** Declare variable to log the number of operations in progress */
		add_global_declaration(OPS_IN_PROGRESS, ops_in_progress_symbol, uint_type());
		add_static_initialiser(ops_in_progress_symbol, from_integer(0, uint_type()), all_functions);
	}

	/***** Declare temporary 'track_this_dma' variable, used to make nondeterministic choice */
	add_global_declaration(TRACK_THIS_DMA, track_this_dma_symbol, bool_typet());

	/***** Declare 'tag_mask' variable */
	add_global_declaration(TAG_MASK, tag_mask_symbol, uint_type());

	/***** Declare 'valid' variable */
	add_global_declaration(VALID, valid_symbol, bool_typet());
	add_static_initialiser(valid_symbol, false_exprt(), all_functions);

	/***** Declare 'is_get' variable */
	add_global_declaration(IS_GET, is_get_symbol, bool_typet());

	/***** Declare 'ls' variable */
	pointer_typet char_ptr(char_type());
	add_global_declaration(LS, ls_symbol, char_ptr);

	/***** Declare 'size' variable */
	add_global_declaration(SIZE, size_symbol, uint_type());

	/***** Declare 'tag' variable */
	if((0 == NUM_TRACKED_DMAS) || program_involves_barriers || program_involves_fences)
	{
		add_global_declaration(TAG, tag_symbol, uint_type());
	}

	/***** Declare 'protected_by_barrier' variable if the program uses barriers */
	if(program_involves_barriers)
	{
		add_global_declaration(PROTECTED_BY_BARRIER, protected_by_barrier_symbol, bool_typet());
	}

	if(max_age > 0)
	{
		/***** Declare 'age' variable */
		add_global_declaration(AGE, age_symbol, uint_type());
	}

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			if(is_dma_free_region(*it, ns)) {

				goto_programt assertion_instructions;

				exprt assertion_condition = not_exprt(symbol_expr(valid_symbol));

				binary_exprt  ls_plus_size(symbol_expr(ls_symbol), "+", symbol_expr(size_symbol));
				ls_plus_size.type() = ls_plus_size.op0().type();

				typecast_exprt current_ls_expr(char_ptr);
				current_ls_expr.op() = it->code.op2().op0();

				exprt current_size_expr = it->code.op2().op1();

				binary_exprt current_ls_plus_size(
						current_ls_expr,
						"+",
						current_size_expr
				);
				current_ls_plus_size.type() = current_ls_plus_size.op0().type();

				or_exprt intersection_empty(
						binary_relation_exprt( ls_plus_size , "<=", current_ls_expr ),
						binary_relation_exprt( current_ls_plus_size , "<=", symbol_expr(ls_symbol))
						);

				assertion_condition = or_exprt(assertion_condition, intersection_empty);

				goto_programt::targett race_assertion = assertion_instructions.add_instruction(ASSERT);

				race_assertion->make_assertion(assertion_condition);

				copy_location_info(race_assertion, it);

				race_assertion->location.set_comment("DMA-free region assertion `" + expr2c(it->code, ns) + "' failed");
				race_assertion->location.set_property("DMA-free region check");

				method.instructions.splice(it, assertion_instructions.instructions);

				it->make_skip();

			}

			// Assignment statement - find memory locations it accesses
			if(it->type == ASSIGN || it->type == FUNCTION_CALL) {

				// This is a preliminary, proof-of-concept implementation.  Right now, I
				// add assertions to check DMAs against writes to arrays, or pointers.

				exprt lhs = it->code.op0();

				if((lhs.id()==ID_dereference) || (lhs.id()==ID_index))
				{

					goto_programt assertion_instructions;

					exprt assertion_condition = not_exprt(symbol_expr(valid_symbol));

					binary_exprt  ls_plus_size(symbol_expr(ls_symbol), "+", symbol_expr(size_symbol));
					ls_plus_size.type() = ls_plus_size.op0().type();

					typecast_exprt current_ls_expr(char_ptr);

					if(lhs.id() == ID_dereference)
					{
						current_ls_expr.op() = lhs.op0();
					} else {
						assert(lhs.id() == ID_index);
						current_ls_expr.op() = address_of_exprt(lhs);
					}

					exprt current_size_expr = from_integer(pointer_offset_size(ns, lhs.type()), uint_type());

					binary_exprt current_ls_plus_size(
							current_ls_expr,
							"+",
							current_size_expr
					);
					current_ls_plus_size.type() = current_ls_plus_size.op0().type();



					or_exprt intersection_empty(
							binary_relation_exprt( ls_plus_size , "<=", current_ls_expr ),
							binary_relation_exprt( current_ls_plus_size , "<=", symbol_expr(ls_symbol))
							);

					assertion_condition = or_exprt(assertion_condition, intersection_empty);

					goto_programt::targett race_assertion = assertion_instructions.add_instruction(ASSERT);

					race_assertion->make_assertion(assertion_condition);

					copy_location_info(race_assertion, it);

					race_assertion->location.set_comment("Assignment `" + expr2c(it->code, ns) + "' races with prior DMA");
					race_assertion->location.set_property("DMA race check");

					method.instructions.splice(it, assertion_instructions.instructions);

				}

			}



			// write tag mask
			if(is_write_tag_mask(*it, ns))
			{
				/* Here we just change the statement, so no re-arrangement of targets is necessary */

				// Add an assignment of 'tag_mask' to the given parameter expression
				code_assignt assignment(symbol_expr(tag_mask_symbol), it->code.op2().op0());
				it->code.swap(assignment);
				it->type = ASSIGN;
			}

			// wait
			if(is_wait_operation(*it, ns))
			{
				// Philipp's super-clever encoding of wait operations

				goto_programt invalidation_instructions;

				if(0 == NUM_TRACKED_DMAS)
				{
					goto_programt::targett assume_tag_is_not_part_of_mask = invalidation_instructions.add_instruction(ASSUME);

					assume_tag_is_not_part_of_mask->make_assumption(
							or_exprt(not_exprt(symbol_expr(valid_symbol)),
							equality_exprt(binary_exprt(
									binary_exprt(from_integer(1, uint_type()), "shl", symbol_expr(tag_symbol)),
									"bitand", symbol_expr(tag_mask_symbol)), from_integer(0, uint_type()))));

					copy_location_info(assume_tag_is_not_part_of_mask, it);

					redirect_targets(it, assume_tag_is_not_part_of_mask, method);

				} else {

					goto_programt::targett assume_tags_in_use_not_part_of_mask = invalidation_instructions.add_instruction(ASSUME);
					assume_tags_in_use_not_part_of_mask->make_assumption(
							equality_exprt(binary_exprt(symbol_expr(tags_in_use_symbol), "bitand", symbol_expr(tag_mask_symbol)), from_integer(0, uint_type())));
					copy_location_info(assume_tags_in_use_not_part_of_mask, it);

					goto_programt::targett assume_zero_mask_implies_not_valid = invalidation_instructions.add_instruction(ASSUME);
					copy_location_info(assume_zero_mask_implies_not_valid, it);

					assume_zero_mask_implies_not_valid->make_assumption(
							or_exprt(not_exprt(symbol_expr(valid_symbol)),
							not_exprt(equality_exprt(symbol_expr(tags_in_use_symbol), from_integer(0, uint_type())))));

					redirect_targets(it, assume_tags_in_use_not_part_of_mask, method);

				}

				method.instructions.splice(it, invalidation_instructions.instructions);
				it->make_skip();
			}

			// dma operation
			if(is_dma_operation(*it, ns))
			{
				goto_programt assertion_instructions;

				goto_programt::targett size_lte_max_assertion = assertion_instructions.add_instruction();
				exprt size_assertion_condition = binary_relation_exprt(get_size_expr_from_dma(it, ns), "<=", from_integer(MAX_SIZE_FOR_DMA, uint_type()));
				if(is_assume_dma_operation(*it, ns))
				{
					size_lte_max_assertion->make_assumption(size_assertion_condition);
				} else {
					size_lte_max_assertion->make_assertion(size_assertion_condition);
				}
				copy_location_info(size_lte_max_assertion, it);

				size_lte_max_assertion->location.set_comment("Max. DMA size exceeded by operation `" + expr2c(it->code.op1(), ns)
						+ "(" + expr2c(it->code.op2().op0(), ns) +
						+ ", " + expr2c(it->code.op2().op1(), ns) +
						+ ", " + expr2c(it->code.op2().op2(), ns) +
						+ ", " + expr2c(it->code.op2().op3(), ns) +
						+ ", " + expr2c(it->code.op2().operands()[4], ns) +
						+ ", " + expr2c(it->code.op2().operands()[5], ns) +
						")'");
				size_lte_max_assertion->location.set_property("DMA size check");

				redirect_targets(it, size_lte_max_assertion, method);

				goto_programt::targett tag_lt_max_assertion = assertion_instructions.add_instruction();
				exprt tag_assertion_condition = binary_relation_exprt(get_tag_expr_from_dma(it, ns), "<", from_integer(MAX_TAG, uint_type()));
				if(is_assume_dma_operation(*it, ns))
				{
					tag_lt_max_assertion->make_assumption(tag_assertion_condition);
				} else {
					tag_lt_max_assertion->make_assertion(tag_assertion_condition);
				}
				copy_location_info(tag_lt_max_assertion, it);

				tag_lt_max_assertion->location.set_comment("Max. DMA tag exceeded by operation `" + expr2c(it->code.op1(), ns)
						+ "(" + expr2c(it->code.op2().op0(), ns) +
						+ ", " + expr2c(it->code.op2().op1(), ns) +
						+ ", " + expr2c(it->code.op2().op2(), ns) +
						+ ", " + expr2c(it->code.op2().op3(), ns) +
						+ ", " + expr2c(it->code.op2().operands()[4], ns) +
						+ ", " + expr2c(it->code.op2().operands()[5], ns) +
						")'");
				tag_lt_max_assertion->location.set_property("DMA size check");


				/* Note that we do not check whether the above are greater than or equal to zero, as they are unsigned. */

				if(is_barrier_dma_operation(*it, ns) && !is_assert_dma_operation(*it, ns) && !is_assume_dma_operation(*it, ns))
				{
					assert(program_involves_barriers);

					/* If the new DMA is a barrier then we need to protect the pending
					 * DMA operation if it uses the same tag.  We do this *before*
					 * we check interference against the new operation
					 */

					goto_programt::targett assign_instruction = add_assign_instruction(
							symbol_expr(protected_by_barrier_symbol),
							equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it, ns)),
							assertion_instructions, it); // A bit dodgy adding this to "assertion_instructions" as it is not an assertion
				}

				exprt assertion_condition = not_exprt(symbol_expr(valid_symbol));

				if(is_dma_put_operation(*it, ns))
				{
					assertion_condition = or_exprt(assertion_condition, not_exprt(symbol_expr(is_get_symbol)));
				}

				binary_exprt  ls_plus_size(symbol_expr(ls_symbol), "+", symbol_expr(size_symbol));
				ls_plus_size.type() = ls_plus_size.op0().type();

				typecast_exprt current_ls_expr(char_ptr);
				current_ls_expr.op() = get_ls_expr_from_dma(it, ns);

				typecast_exprt current_size_expr(uint_type());
				current_size_expr.op() = get_size_expr_from_dma(it, ns);

				binary_exprt current_ls_plus_size(
						current_ls_expr,
						"+",
						current_size_expr
				);
				current_ls_plus_size.type() = current_ls_plus_size.op0().type();

				or_exprt intersection_empty(
						binary_relation_exprt( ls_plus_size , "<=", current_ls_expr ),
						binary_relation_exprt( current_ls_plus_size , "<=", symbol_expr(ls_symbol))
						);

				assertion_condition = or_exprt(assertion_condition, intersection_empty);

				if(is_fence_dma_operation(*it, ns))
				{
					/* If it's a fence operation then it is OK for the intersection
					 * with the pending operation to be non-empty, as long as the new operation
					 * has the same tag as the pending operation.
					 */
					assert(program_involves_fences);
					assertion_condition = or_exprt(assertion_condition, equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it, ns)));
				}

				else if(program_involves_barriers) {

					/* If pending operation is protected by a barrier then it's OK for this operation to
					 * intersect with it, as long as the new operation has the same tag as the
					 * pending operation.  We only need to check this if the new operation
					 * is not itself a fence operation.
					 *
					 * Also, we do not bother checking this if we know that the program contains no barriers
					 */

					assertion_condition = or_exprt(assertion_condition, and_exprt(symbol_expr(protected_by_barrier_symbol),
							equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it, ns))));

				}

				 if (is_barrier_dma_operation(*it, ns) && (is_assert_dma_operation(*it, ns) || is_assume_dma_operation(*it, ns))) {
					/* Special case for a ghost barrier operation.  This is because, with the operation
					 * being a ghost op, we did not set the 'protected' flag above.  However, from the point of view
					 * of the assertions we need to generate, it's OK just to ignore operations on the same tag.
					 */
					 assertion_condition = or_exprt(assertion_condition, equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it, ns)));
				 }

				goto_programt::targett assertion = assertion_instructions.add_instruction();

				if(is_assume_dma_operation(*it, ns))
				{
					assertion->make_assumption(assertion_condition);
				} else {
					assertion->make_assertion(assertion_condition);
				}

				copy_location_info(assertion, it);

				assertion->location.set_comment("DMA race caused by `" + expr2c(it->code.op1(), ns)
						+ "(" + expr2c(it->code.op2().op0(), ns) +
						+ ", " + expr2c(it->code.op2().op1(), ns) +
						+ ", " + expr2c(it->code.op2().op2(), ns) +
						+ ", " + expr2c(it->code.op2().op3(), ns) +
						+ ", " + expr2c(it->code.op2().operands()[4], ns) +
						+ ", " + expr2c(it->code.op2().operands()[5], ns) +
						")'");
				assertion->location.set_property("DMA race check");

				if(NUM_TRACKED_DMAS > 0)
				{
					goto_programt::targett assert_max_operations_not_reached = assertion_instructions.add_instruction();
					assert_max_operations_not_reached->make_assertion(binary_relation_exprt(symbol_expr(ops_in_progress_symbol), "<", from_integer(NUM_TRACKED_DMAS, uint_type())));
					assert_max_operations_not_reached->location.set_comment("Maximum number of DMA operations exceeded by `" + expr2c(it->code.op1(), ns)
							+ "(" + expr2c(it->code.op2().op0(), ns) +
							+ ", " + expr2c(it->code.op2().op1(), ns) +
							+ ", " + expr2c(it->code.op2().op2(), ns) +
							+ ", " + expr2c(it->code.op2().op3(), ns) +
							+ ", " + expr2c(it->code.op2().operands()[4], ns) +
							+ ", " + expr2c(it->code.op2().operands()[5], ns) +
							")'");
					assert_max_operations_not_reached->location.set_property("Max DMAs reached check");
				}

				goto_programt update_instructions;

				goto_programt::targett nondeterministic_assignment = update_instructions.add_instruction(ASSIGN);
				nondeterministic_assignment->make_assignment();
				nondeterministic_assignment->code = code_assignt(symbol_expr(track_this_dma_symbol), nondet_exprt(bool_typet()));
				copy_location_info(nondeterministic_assignment, it);

				goto_programt::targett choose_whether_to_track = update_instructions.add_instruction(GOTO);
				copy_location_info(choose_whether_to_track, it);

				goto_programt::targett start_of_tracking_code = add_assign_instruction(symbol_expr(valid_symbol), true_exprt(), update_instructions, it);
				copy_location_info(start_of_tracking_code, it);

				if(is_dma_get_operation(*it, ns))
				{
					add_assign_instruction(symbol_expr(is_get_symbol), true_exprt(), update_instructions, it);
				} else {
					add_assign_instruction(symbol_expr(is_get_symbol), false_exprt(), update_instructions, it);
				}

				typecast_exprt ls_expr_as_char_ptr(char_ptr);
				ls_expr_as_char_ptr.op0() = get_ls_expr_from_dma(it, ns);

				add_assign_instruction(symbol_expr(ls_symbol), ls_expr_as_char_ptr, update_instructions, it);
				add_assign_instruction(symbol_expr(size_symbol), get_size_expr_from_dma(it, ns), update_instructions, it);

				if((0 == NUM_TRACKED_DMAS) || program_involves_barriers || program_involves_fences)
				{
					add_assign_instruction(symbol_expr(tag_symbol), get_tag_expr_from_dma(it, ns), update_instructions, it);
				}

				if(max_age > 0)
				{
					add_assign_instruction(symbol_expr(age_symbol), from_integer(0, uint_type()), update_instructions, it);
				}

				if(program_involves_barriers)
				{
					/* The new operation is *not* protected by a barrier, even if it is itself a barrier */
					add_assign_instruction(symbol_expr(protected_by_barrier_symbol), false_exprt(), update_instructions, it);
				}

				if(NUM_TRACKED_DMAS > 0)
				{
					// Philipp's extra-cool encoding again
					add_assign_instruction(symbol_expr(ops_in_progress_symbol), binary_exprt(symbol_expr(ops_in_progress_symbol), "+", from_integer(1, uint_type())), update_instructions, it);
					add_assign_instruction(symbol_expr(tags_in_use_symbol), binary_exprt(symbol_expr(tags_in_use_symbol), "bitor",
							binary_exprt(from_integer(1, uint_type()), "shl", get_tag_expr_from_dma(it, ns))), update_instructions, it);
				}

				goto_programt::targett join_for_nondeterministic_choice = update_instructions.add_instruction(SKIP);
				join_for_nondeterministic_choice->make_skip();
				copy_location_info(join_for_nondeterministic_choice, it);
				choose_whether_to_track->make_goto(join_for_nondeterministic_choice, not_exprt(symbol_expr(track_this_dma_symbol)));

				method.instructions.splice(it, assertion_instructions.instructions);

				if(!is_assert_dma_operation(*it, ns) && !is_assume_dma_operation(*it, ns))
				{
					method.instructions.splice(it, update_instructions.instructions);
				}

				it->make_skip();

			}

		}

	}

    all_functions.update();
    all_functions.compute_loop_numbers();

}



static void set_havoc_refinement_location(goto_programt::targett inst)
{
	inst->location = locationt();
	inst->location.set_file("<havoc refinement>");
	inst->location.set_line("<no line>");
	inst->location.set_function("<no function>");
	inst->location.set_comment("Havoc refinement statement");
	inst->location.set_property("Havoc refinement statement");
}


void dma_simple_tracking_analysert::havoc_globals(CFGt& method, const namespacet ns) {

	this->k_induction_configurationt::havoc_globals(method, ns); // Havoc all globals

	// Now refine this havocking where possible

	if(NUM_TRACKED_DMAS > 0)
	{
		goto_programt temp_program;
		goto_programt::targett assume_no_tags_in_use_implies_not_valid_instruction = temp_program.add_instruction(ASSUME);
		assume_no_tags_in_use_implies_not_valid_instruction->make_assumption(
				or_exprt(not_exprt(symbol_expr(valid_symbol)),
				not_exprt(equality_exprt(symbol_expr(tags_in_use_symbol), from_integer(0, uint_type())))));
		set_havoc_refinement_location(assume_no_tags_in_use_implies_not_valid_instruction);
		method.append_node(CFG_nodet(*assume_no_tags_in_use_implies_not_valid_instruction));
	}

	add_havoc_instruction(size_symbol, method);
	{
		goto_programt temp_program;
		goto_programt::targett assume_size_in_range_instruction = temp_program.add_instruction(ASSUME);
		assume_size_in_range_instruction->make_assumption(binary_relation_exprt(symbol_expr(size_symbol), "<",
				from_integer(MAX_SIZE_FOR_DMA, uint_type())));
		set_havoc_refinement_location(assume_size_in_range_instruction);
		method.append_node(CFG_nodet(*assume_size_in_range_instruction));
	}

	if(program_involves_barriers || program_involves_fences || 0 == NUM_TRACKED_DMAS) {
		goto_programt temp_program;
		goto_programt::targett assume_tag_in_range_instruction = temp_program.add_instruction(ASSUME);
		assume_tag_in_range_instruction->make_assumption(binary_relation_exprt(symbol_expr(tag_symbol), "<",
				from_integer(MAX_TAG, uint_type())));
		set_havoc_refinement_location(assume_tag_in_range_instruction);
		method.append_node(CFG_nodet(*assume_tag_in_range_instruction));
	}

}


void dma_simple_tracking_analysert::make_instructions_for_invariant(goto_programt& temp_program)
{
	temp_program.instructions.clear();

	if(free_dmas > 0)
	{
		assert(free_dmas <= NUM_TRACKED_DMAS);
		// We would like to assert that the number of operations in progress never exceeds (max-free_dmas)
		goto_programt::targett assert_sufficient_free_slots = temp_program.add_instruction(ASSERT);
		// TODO Add message
		assert_sufficient_free_slots->make_assertion(binary_relation_exprt(symbol_expr(ops_in_progress_symbol), "<", from_integer(NUM_TRACKED_DMAS-free_dmas, uint_type())));
	}

	if(max_age > 0)
	{
		goto_programt::targett assert_op_not_too_old = temp_program.add_instruction(ASSERT);
		assert_op_not_too_old->make_assertion(or_exprt(not_exprt(symbol_expr(valid_symbol)),
				binary_relation_exprt(symbol_expr(age_symbol), "<=", from_integer(max_age, uint_type()))));
		// TODO Add message
		goto_programt::targett increment_age = temp_program.add_instruction(ASSIGN);
		increment_age->make_assignment();
		increment_age->code = code_assignt(symbol_expr(age_symbol), binary_exprt(symbol_expr(age_symbol), "+", from_integer(1, uint_type())));
	}

}



void dma_simple_tracking_analysert::check_for_fences(goto_functionst& all_functions)
{

	/* We need to determine whether or not the given program uses fence operations,
	 * so that when we do DMA instrumentation we know whether or not we need to add
	 * additional checks for this scenario
	 */
	program_involves_fences = false;

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			if(is_dma_operation(*it, ns) && is_fence_dma_operation(*it, ns))
			{
				program_involves_fences = true;
				return;
			}

		}

	}


 }
