/*
 * dma_simple_tracking_analyser.cpp
 *
 *  Created on: May 7, 2010
 *      Author: alad
 */

#include <ansi-c/c_types.h>
#include <util/arith_tools.h>
#include <util/expr_util.h>

#include <ansi-c/expr2c.h>

#include <goto-programs/goto_functions.h>
#include <goto-programs/show_claims.h>

#include <langapi/language_ui.h>

#include <loopfrog/pointer_expr.h>

#include <goto-symex/k_induction.h>

#include "dma_simple_tracking_analyser.h"

#include "tracker_variables.h"

static void add_havoc_instruction(symbolt& sym, CFGt& method)
{
    add_havoc_instruction(symbol_expr(sym), method, sym.type);
}


void dma_simple_tracking_analysert::instrument_program(goto_functionst& all_functions)
{
	check_for_barriers(all_functions);
	check_for_fences(all_functions);

	// 1. Declare variables, __valid, __is_get, __ls, __size, __tag
	// 2. Set __valid[i] = 0
	// 3. Declare tag mask variable
	// 3. Replace each write_tag_mask with write to tag mask variable
	// 3. Replace each wait with __valid = __valid && (IS_0 (tag_mask, __tag))
	// 4. Replace each put/get with check against the logged operation, if valid.  Then, nondeterministic
    //    choose whether to log the new operation

	if(NUM_TRACKED_DMAS > 0)
	{
		/***** Declare variable to log the tags that are in use */
		add_global_declaration(TAGS_IN_USE, tags_in_use_symbol, uint_type());
		add_static_initialiser(tags_in_use_symbol, from_integer(0, uint_type()), all_functions);

		/***** Declare variable to log the number of operations in progress */
		add_global_declaration(OPS_IN_PROGRESS, ops_in_progress_symbol, uint_type());
		add_static_initialiser(ops_in_progress_symbol, from_integer(0, uint_type()), all_functions);
	}

	/***** Declare temporary 'track_this_dma' variable, used to make nondeterministic choice */
	add_global_declaration(TRACK_THIS_DMA, track_this_dma_symbol, bool_typet());

	/***** Declare 'tag_mask' variable */
	add_global_declaration(TAG_MASK, tag_mask_symbol, uint_type());

	/***** Declare 'valid' variable */
	add_global_declaration(VALID, valid_symbol, bool_typet());
	add_static_initialiser(valid_symbol, false_exprt(), all_functions);

	/***** Declare 'is_get' variable */
	add_global_declaration(IS_GET, is_get_symbol, bool_typet());

	/***** Declare 'ls' variable */
	pointer_typet char_ptr(char_type());
	add_global_declaration(LS, ls_symbol, char_ptr);

	/***** Declare 'size' variable */
	add_global_declaration(SIZE, size_symbol, uint_type());

	/***** Declare 'tag' variable */
	if((0 == NUM_TRACKED_DMAS) || program_involves_barriers || program_involves_fences)
	{
		add_global_declaration(TAG, tag_symbol, uint_type());
	}

	/***** Declare 'protected_by_barrier' variable if the program uses barriers */
	if(program_involves_barriers)
	{
		add_global_declaration(PROTECTED_BY_BARRIER, protected_by_barrier_symbol, bool_typet());
	}

	if(max_age > 0)
	{
		/***** Declare 'age' array */
		add_global_declaration(AGE, age_symbol, uint_type());
	}

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			// write tag mask
			if(is_write_tag_mask(*it, ns))
			{
				/* Here we just change the statement, so no re-arrangement of targets is necessary */

				// Add an assignment of 'tag_mask' to the given parameter expression
				code_assignt assignment(symbol_expr(tag_mask_symbol), it->code.op2().op0());
				it->code.swap(assignment);
				it->type = ASSIGN;
			}

			// wait
			if(is_wait_operation(*it, ns))
			{
				// Philipp's super-clever encoding of wait operations

				goto_programt invalidation_instructions;

				if(0 == NUM_TRACKED_DMAS)
				{
					goto_programt::targett assume_tag_is_not_part_of_mask = invalidation_instructions.add_instruction(ASSUME);

					assume_tag_is_not_part_of_mask->make_assumption(
							or_exprt(not_exprt(symbol_expr(valid_symbol)),
							equality_exprt(binary_exprt(
									binary_exprt(from_integer(1, uint_type()), "shl", symbol_expr(tag_symbol)),
									"bitand", symbol_expr(tag_mask_symbol)), from_integer(0, uint_type()))));
				} else {

					goto_programt::targett assume_tags_in_use_not_part_of_mask = invalidation_instructions.add_instruction(ASSUME);
					assume_tags_in_use_not_part_of_mask->make_assumption(
							equality_exprt(binary_exprt(symbol_expr(tags_in_use_symbol), "bitand", symbol_expr(tag_mask_symbol)), from_integer(0, uint_type())));
					redirect_targets(it, assume_tags_in_use_not_part_of_mask, method);

				}

				method.instructions.splice(it, invalidation_instructions.instructions);
				it->make_skip();
			}

			// dma operation
			if(is_dma_operation(*it, ns))
			{
				goto_programt assertion_instructions;

				goto_programt::targett size_lte_max_assertion = assertion_instructions.add_instruction();
				size_lte_max_assertion->make_assertion(binary_relation_exprt(get_size_expr_from_dma(it), "<=", from_integer(MAX_SIZE_FOR_DMA, uint_type())));
				copy_location_info(size_lte_max_assertion, it);

				redirect_targets(it, size_lte_max_assertion, method);

				goto_programt::targett tag_lt_max_assertion = assertion_instructions.add_instruction();
				tag_lt_max_assertion->make_assertion(binary_relation_exprt(get_tag_expr_from_dma(it), "<", from_integer(MAX_TAG, uint_type())));
				copy_location_info(tag_lt_max_assertion, it);

				/* Note that we do not check whether the above are greater than or equal to zero, as they are unsigned. */

				if(is_barrier_dma_operation(*it, ns))
				{
					assert(program_involves_barriers);

					/* If the new DMA is a barrier then we need to protect the pending
					 * DMA operation if it uses the same tag.  We do this *before*
					 * we check interference against the new operation
					 */

					goto_programt::targett assign_instruction = add_assign_instruction(
							symbol_expr(protected_by_barrier_symbol),
							equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it)),
							assertion_instructions, it); // A bit dodgy adding this to "assertion_instructions" as it is not an assertion
				}

				exprt assertion_condition = not_exprt(symbol_expr(valid_symbol));

				if(is_dma_put_operation(*it, ns))
				{
					assertion_condition = or_exprt(assertion_condition, not_exprt(symbol_expr(is_get_symbol)));
				}

				binary_exprt  ls_plus_size(symbol_expr(ls_symbol), "+", symbol_expr(size_symbol));
				ls_plus_size.type() = ls_plus_size.op0().type();

				typecast_exprt current_ls_expr(char_ptr);
				current_ls_expr.op() = get_ls_expr_from_dma(it);

				typecast_exprt current_size_expr(uint_type());
				current_size_expr.op() = get_size_expr_from_dma(it);

				binary_exprt current_ls_plus_size(
						current_ls_expr,
						"+",
						current_size_expr
				);
				current_ls_plus_size.type() = current_ls_plus_size.op0().type();

				or_exprt intersection_empty(
						binary_relation_exprt( ls_plus_size , "<=", current_ls_expr ),
						binary_relation_exprt( current_ls_plus_size , "<=", symbol_expr(ls_symbol))
						);

				assertion_condition = or_exprt(assertion_condition, intersection_empty);

				if(is_fence_dma_operation(*it, ns))
				{
					/* If it's a fence operation then it is OK for the intersection
					 * with the pending operation to be non-empty, as long as the new operation
					 * has the same tag as the pending operation.
					 */
					assert(program_involves_fences);
					assertion_condition = or_exprt(assertion_condition, equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it)));
				}

				else if(program_involves_barriers) {

					/* If pending operation is protected by a barrier then it's OK for this operation to
					 * intersect with it, as long as the new operation has the same tag as the
					 * pending operation.  We only need to check this if the new operation
					 * is not itself a fence operation.
					 *
					 * Also, we do not bother checking this if we know that the program contains no barriers
					 */

					assertion_condition = or_exprt(assertion_condition, and_exprt(symbol_expr(protected_by_barrier_symbol),
							equality_exprt(symbol_expr(tag_symbol), get_tag_expr_from_dma(it))));

				}

				goto_programt::targett assertion = assertion_instructions.add_instruction();
				assertion->make_assertion(assertion_condition);
				copy_location_info(assertion, it);

				assertion->location.set_comment("DMA race caused by `" + expr2c(it->code.op1(), ns)
						+ "(" + expr2c(it->code.op2().op0(), ns) +
						+ ", " + expr2c(it->code.op2().op1(), ns) +
						+ ", " + expr2c(it->code.op2().op2(), ns) +
						+ ", " + expr2c(it->code.op2().op3(), ns) +
						+ ", " + expr2c(it->code.op2().operands()[4], ns) +
						+ ", " + expr2c(it->code.op2().operands()[5], ns) +
						")'");
				assertion->location.set_property("DMA race check");

				if(NUM_TRACKED_DMAS > 0)
				{
					goto_programt::targett assert_max_operations_not_reached = assertion_instructions.add_instruction();
					assert_max_operations_not_reached->make_assertion(binary_relation_exprt(symbol_expr(ops_in_progress_symbol), "<", from_integer(NUM_TRACKED_DMAS, uint_type())));
					assert_max_operations_not_reached->location.set_comment("Maximum number of DMA operations exceeded by `" + expr2c(it->code.op1(), ns)
							+ "(" + expr2c(it->code.op2().op0(), ns) +
							+ ", " + expr2c(it->code.op2().op1(), ns) +
							+ ", " + expr2c(it->code.op2().op2(), ns) +
							+ ", " + expr2c(it->code.op2().op3(), ns) +
							+ ", " + expr2c(it->code.op2().operands()[4], ns) +
							+ ", " + expr2c(it->code.op2().operands()[5], ns) +
							")'");
					assert_max_operations_not_reached->location.set_property("Max DMAs reached check");
				}

				goto_programt update_instructions;

				goto_programt::targett nondeterministic_assignment = update_instructions.add_instruction(ASSIGN);
				nondeterministic_assignment->make_assignment();
				nondeterministic_assignment->code = code_assignt(symbol_expr(track_this_dma_symbol), nondet_exprt(bool_typet()));

				goto_programt::targett choose_whether_to_track = update_instructions.add_instruction(GOTO);

				add_assign_instruction(symbol_expr(valid_symbol), true_exprt(), update_instructions, it);
				if(is_dma_get_operation(*it, ns))
				{
					add_assign_instruction(symbol_expr(is_get_symbol), true_exprt(), update_instructions, it);
				} else {
					add_assign_instruction(symbol_expr(is_get_symbol), false_exprt(), update_instructions, it);
				}

				typecast_exprt ls_expr_as_char_ptr(char_ptr);
				ls_expr_as_char_ptr.op0() = get_ls_expr_from_dma(it);

				add_assign_instruction(symbol_expr(ls_symbol), ls_expr_as_char_ptr, update_instructions, it);
				add_assign_instruction(symbol_expr(size_symbol), get_size_expr_from_dma(it), update_instructions, it);

				if((0 == NUM_TRACKED_DMAS) || program_involves_barriers || program_involves_fences)
				{
					add_assign_instruction(symbol_expr(tag_symbol), get_tag_expr_from_dma(it), update_instructions, it);
				}

				if(max_age > 0)
				{
					add_assign_instruction(symbol_expr(age_symbol), from_integer(0, uint_type()), update_instructions, it);
				}

				if(program_involves_barriers)
				{
					/* The new operation is *not* protected by a barrier, even if it is itself a barrier */
					add_assign_instruction(symbol_expr(protected_by_barrier_symbol), false_exprt(), update_instructions, it);
				}

				if(NUM_TRACKED_DMAS > 0)
				{
					// Philipp's extra-cool encoding again
					add_assign_instruction(symbol_expr(ops_in_progress_symbol), binary_exprt(symbol_expr(ops_in_progress_symbol), "+", from_integer(1, uint_type())), update_instructions, it);
					add_assign_instruction(symbol_expr(tags_in_use_symbol), binary_exprt(symbol_expr(tags_in_use_symbol), "bitor",
							binary_exprt(from_integer(1, uint_type()), "shl", get_tag_expr_from_dma(it))), update_instructions, it);
				}

				goto_programt::targett join_for_nondeterministic_choice = update_instructions.add_instruction(SKIP);
				join_for_nondeterministic_choice->make_skip();
				choose_whether_to_track->make_goto(join_for_nondeterministic_choice, not_exprt(symbol_expr(track_this_dma_symbol)));

				method.instructions.splice(it, assertion_instructions.instructions);
				method.instructions.splice(it, update_instructions.instructions);

				it->make_skip();

			}

		}

	}

    all_functions.update();
    all_functions.compute_loop_numbers();

}

void dma_simple_tracking_analysert::havoc_globals(CFGt& method, const namespacet ns) {

	add_havoc_instruction(ops_in_progress_symbol, method);
	add_havoc_instruction(valid_symbol, method);
	add_havoc_instruction(tags_in_use_symbol, method);
	add_havoc_instruction(track_this_dma_symbol, method);
	add_havoc_instruction(tag_mask_symbol, method);
	add_havoc_instruction(is_get_symbol, method);
	add_havoc_instruction(ls_symbol, method);
	add_havoc_instruction(size_symbol, method);

	if(program_involves_barriers || program_involves_fences) {
		add_havoc_instruction(tag_symbol, method);
	}

	if(program_involves_barriers) {
		add_havoc_instruction(protected_by_barrier_symbol, method);
	}

	if(max_age > 0)
	{
		add_havoc_instruction(age_symbol, method);
	}

}


void dma_simple_tracking_analysert::make_instructions_for_invariant(goto_programt& temp_program)
{
	temp_program.instructions.clear();

	if(free_dmas > 0)
	{
		assert(free_dmas <= NUM_TRACKED_DMAS);
		// We would like to assert that the number of operations in progress never exceeds (max-free_dmas)
		goto_programt::targett assert_sufficient_free_slots = temp_program.add_instruction(ASSERT);
		assert_sufficient_free_slots->make_assertion(binary_relation_exprt(symbol_expr(ops_in_progress_symbol), "<", from_integer(NUM_TRACKED_DMAS-free_dmas, uint_type())));
	}

	if(max_age > 0)
	{
		goto_programt::targett assert_op_not_too_old = temp_program.add_instruction(ASSERT);
		assert_op_not_too_old->make_assertion(or_exprt(not_exprt(symbol_expr(valid_symbol)),
				binary_relation_exprt(symbol_expr(age_symbol), "<=", from_integer(max_age, uint_type()))));
		goto_programt::targett increment_age = temp_program.add_instruction(ASSIGN);
		increment_age->make_assignment();
		increment_age->code = code_assignt(symbol_expr(age_symbol), binary_exprt(symbol_expr(age_symbol), "+", from_integer(1, uint_type())));
	}

}



void dma_simple_tracking_analysert::check_for_fences(goto_functionst& all_functions)
{

	/* We need to determine whether or not the given program uses fence operations,
	 * so that when we do DMA instrumentation we know whether or not we need to add
	 * additional checks for this scenario
	 */
	program_involves_fences = false;

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			if(is_dma_operation(*it, ns) && is_fence_dma_operation(*it, ns))
			{
				program_involves_fences = true;
				return;
			}

		}

	}


 }
