/*******************************************************************\

Module: Parsing of options

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk

\*******************************************************************/

#include <fstream>
#include <memory>


#include <cbmc/bmc.h>

#include <config.h>
#include <expr_util.h>

#include <ansi-c/ansi_c_language.h>

#include <goto-programs/goto_convert_functions.h>
#include <goto-programs/goto_check.h>
#include <goto-programs/goto_inline.h>
#include <goto-programs/show_claims.h>
#include <goto-programs/set_claims.h>
#include <goto-programs/read_goto_binary.h>
#include <goto-programs/interpreter.h>
#include <goto-programs/string_abstraction.h>
#include <goto-programs/string_instrumentation.h>
#include <goto-programs/loop_numbers.h>
#include <goto-programs/write_goto_binary.h>

#include <k-induction/k_induction.h>

#include <langapi/mode.h>

#include <loop-analysis/dominator_info.h>
#include <loop-analysis/find_loops.h>

#include "parseoptions.h"
#include "dma_bug_analysis.h"

#include "scratch_k_induction_configuration.h"

#include "version.h"


#include "scratch_bmc.h"

unsigned int NUM_TRACKED_DMAS;
static unsigned int K_INDUCTION_DEPTH;

bool DEBUG_INSTRUMENTATION = false;

/*******************************************************************\

Function: scratch_parseoptionst::process_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool scratch_parseoptionst::process_goto_program(
  bmc_baset &bmc,
  goto_functionst &goto_functions)
{
    namespacet ns(context);


    // do partial inlining
    goto_partial_inline(goto_functions, ns, ui_message_handler);

#if DEBUG_INSTRUMENTATION
    std::cout << "Before instrumentation:\n";
    goto_functions.output(ns, std::cout);
#endif

    dma_bug_analysert dma_analyser(goto_functions, ns, context, *this);

    dma_analyser.instrument_program();

#if DEBUG_INSTRUMENTATION
    std::cout << "After instrumentation:\n";
    goto_functions.output(ns, std::cout);
#endif

    if(cmdline.isset("write-binary"))
    {
    	std::cout << "Writing goto functions to binary file " << cmdline.getval("write-binary") << "\n";


		std::ofstream f(cmdline.getval("write-binary"), std::ios::binary);
		if (!f.is_open())
		{
			error("Error opening file");
			return true;
		}

		if(write_goto_binary(f, context, goto_functions))
		{
			return true;
		}

		f.close();

		exit(0);

    }


	return false;
}



/*******************************************************************\

Function: scratch_parseoptionst::do_bmc

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

#define LOOP_TOO_COMPLEX 12

int scratch_parseoptionst::do_bmc(
  bmc_baset &bmc,
  const goto_functionst &goto_functions)
{
	if(cmdline.isset("bug-finding"))
	{
		std::cout << "*** In bug finding mode ***\n";
		return cbmc_parseoptionst::do_bmc(bmc, goto_functions);
	}

	scratch_k_induction_configurationt k_induction_configuration;

	k_induction_enginet engine(context, k_induction_configuration);

	if(engine.analyse_main_loop(goto_functions))
	{
		return LOOP_TOO_COMPLEX;
	}

	if(!engine.program_has_loops())
	{
    	std::cout << "The program does not have any loops, so standard bmc will be applied.\n";
    	return cbmc_parseoptionst::do_bmc(bmc, goto_functions);
	}

	if(cmdline.isset("base-case-bug-finding"))
	{
		int k = atoi(cmdline.getval("base-case-bug-finding"));

		std::cout << "Just checking base case for k = " << k << ".\n";

		goto_functionst base_case_functions;

		scratch_bmct new_bmc(context, bmc.get_message_handler(), false);
		new_bmc.options = bmc.options;

		engine.assemble_pure_base_case(base_case_functions, goto_functions, k);
		return cbmc_parseoptionst::do_bmc(new_bmc, base_case_functions);

	}


	std::cout << "\n*** Starting k-induction analysis.  Maximum k set to " << K_INDUCTION_DEPTH << " ***\n\n";


	{
		goto_functionst base_case_functions;

		scratch_bmct new_bmc(context, bmc.get_message_handler(), false);
		new_bmc.options = bmc.options;

		std::cout << "\nChecking base case where loop is not entered (i.e. k=0).\n\n";

		engine.assemble_base_case(base_case_functions, goto_functions, 0);
		int base_case_result = cbmc_parseoptionst::do_bmc(new_bmc, base_case_functions);
		if(base_case_result != 0)
		{
			std::cout << "\nBase case failed (k = 0).\n\n";
			return base_case_result;
		}
	}

	std::cout << "\nStarting k-induction.\n\n";

	for(unsigned int k=1; k <= K_INDUCTION_DEPTH; k++)
	{
		std::cout << "Depth: k = " << k << ".\n\n";

		{
			goto_functionst base_case_functions;

			engine.assemble_base_case(base_case_functions, goto_functions, k);

			scratch_bmct new_bmc(context, bmc.get_message_handler(), false);
			new_bmc.options = bmc.options;
			int base_case_result = cbmc_parseoptionst::do_bmc(new_bmc, base_case_functions);

			if(base_case_result != 0)
			{
				std::cout << "\nBase case failed (k = " << k << ").\n\n";
				return base_case_result;
			}

		}

		std::cout << "\nBase case succeeded (k = " << k << ").  Moving on to inductive step.\n\n";

		{
			goto_functionst inductive_step_functions;

			scratch_bmct new_bmc(context, bmc.get_message_handler(), !cmdline.isset("show-step-case-fails"));
			new_bmc.options = bmc.options;

			engine.assemble_inductive_step(inductive_step_functions, goto_functions, k);

			int inductive_step_result = cbmc_parseoptionst::do_bmc(new_bmc, inductive_step_functions);

			if(inductive_step_result == 0 )
			{
				std::cout << "\nInductive step succeeded (k = " << k << ") - verification successful!\n\n";
				return 0;
			} else {

				std::cout << "\nInductive step failed (k = " << k << ")\n\n";

			}

		}

	}

	std::cout << "Could not prove within depth " << K_INDUCTION_DEPTH << "\n";

	return 14;

}


void scratch_parseoptionst::get_command_line_options(optionst &options)
{
  cbmc_parseoptionst::get_command_line_options(options);

  if(cmdline.isset("tracked-dmas"))
  {
	  NUM_TRACKED_DMAS = atoi(cmdline.getval("tracked-dmas"));

	  if(NUM_TRACKED_DMAS == 0)
	  {
		  std::cout << "Error, cannot track zero DMA operations!\n";
		  exit(1);
	  }

	  if(NUM_TRACKED_DMAS >= MAX_DMAS)
	  {
		  std::cout << "Warning: tracking " << NUM_TRACKED_DMAS << " DMA operations; should never have more than " << MAX_DMAS << " in practice.\n";
	  }

	  std::cout << "Tracking " << NUM_TRACKED_DMAS << " DMA operations.\n";

  } else {

	  const unsigned int DEFAULT_DMAS_TO_TRACK = 5;

	  std::cout << "Number of DMA operations to track not specified, using " << DEFAULT_DMAS_TO_TRACK << ".\n";

	  NUM_TRACKED_DMAS = DEFAULT_DMAS_TO_TRACK;

  }



  if(cmdline.isset("k-induction-depth"))
  {
	  K_INDUCTION_DEPTH = atoi(cmdline.getval("k-induction-depth"));

	  if(K_INDUCTION_DEPTH == 0)
	  {
		  std::cout << "Error, cannot set max k-induction depth to zero!\n";
		  exit(1);
	  }

	  std::cout << "Max depth for k-induction is " << K_INDUCTION_DEPTH << ".\n";

  } else {

	  const unsigned int DEFAULT_K_INDUCTION_DEPTH = 10;

	  std::cout << "Max depth for k-induction not specified, using " << DEFAULT_K_INDUCTION_DEPTH << ".\n";

	  K_INDUCTION_DEPTH = DEFAULT_K_INDUCTION_DEPTH;

  }


  if(cmdline.isset("free-dmas"))
  {
	  FREE_DMAS = atoi(cmdline.getval("free-dmas"));
	  std::cout << "Assertion will be added to ensure that at least " << FREE_DMAS << " DMA slots are always free.\n";
  } else {
	  FREE_DMAS = 0;
  }


  if(cmdline.isset("max-age"))
  {
	  MAX_AGE = atoi(cmdline.getval("max-age"));
	  std::cout << "DMA operations will not be allowed to live for more than " << MAX_AGE << " loop iterations.";
  } else {
	  MAX_AGE = 0;
  }

  if(cmdline.isset("debug-instrumentation"))
  {
	  DEBUG_INSTRUMENTATION = true;
  }


}


bmct& scratch_parseoptionst::get_bmc(const contextt & context, message_handlert & message_handler) {
	return *(new scratch_bmct(context, message_handler, false));
}


void scratch_parseoptionst::help()
{
  std::cout <<
    "\n"
    "* *             SCRATCH " SCRATCH_VERSION " - Copyright (C) 2009                 * *\n"
    "* *           Alastair F. Donaldson, Daniel Kroening             * *\n"
    "* *        University of Oxford Computing Laboratory             * *\n"
    "* *           alastair.donaldson@comlab.ox.ac.uk                 * *\n"
    "\n"
    "Usage:                       Purpose:\n"
    "\n"
    " scratch [-?] [-h] [--help]   show help\n"
    " scratch file.c ...           source file names\n"
    "\n"
    "Additonal options:\n"
    " -I path                      set include path (C/C++)\n"
    " -D macro                     define preprocessor macro (C/C++)\n"
    " --bug-finding                run in bug finding mode\n"
    " --function name              set main function name\n"
    " --k-induction-depth k        set depth for k-induction to k\n"
    " --tracked-dmas nr            track nr dmas\n"
    " --no-unwinding-assertions    do not generate unwinding assertions\n"
    " --unwind nr                  unwind nr times\n"
    " --unwindset nr               unwind given loop nr times\n"
    " --write-binary name          instead of model checking, write goto program to file 'name'\n"
    " --binary name                run scratch on ready-made goto program in file 'name'\n"
    " --free-dmas n                when using k-induction, add assertion that n DMA slots are free at start of loop\n"
    " --show-step-case-fails       display counterexamples for step-case failure.\n"
    " --debug-instrumentation      show instrumentation\n"
    " --max-age n                  do not let DMA operations live for longer than n iterations\n"
    " --base-case-bug-finding n    generate pure base case for length n, to be used for bug-finding\n"
    "\n";
}
