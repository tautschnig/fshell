/*
 * scratch_k_induction_configuration.cpp
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#include <ansi-c/c_types.h>

#include <k-induction/k_induction.h>

#include <util/arith_tools.h>
#include <util/expr_util.h>
#include <util/std_expr.h>

#include "dma_analysis.h"

#include "tracker_variables.h"

#include "scratch_k_induction_configuration.h"

unsigned int FREE_DMAS;

static void add_havoc_instruction(irep_idt variable_name, goto_programt& method, const namespacet ns)
{
    const symbolt sym = ns.lookup(SCRATCH_NAME_PREFIX + variable_name.as_string());
    add_havoc_instruction(symbol_expr(sym), method, sym.type);
}


static void add_instructions_to_havoc_tracker_array(irep_idt array_name, goto_programt& method, const namespacet ns)
{
	add_instructions_to_havoc_array(symbol_expr(ns.lookup(SCRATCH_NAME_PREFIX + array_name.as_string())), method, ns);
}


void scratch_k_induction_configurationt::havoc_globals(goto_programt& method, const namespacet ns) {
	// Havoc 'tag_mask' variable
	add_havoc_instruction(TAG_MASK, method, ns);

	// Havoc 'new_position' variable (probably not necessary)
	add_havoc_instruction(NEW_POSITION, method, ns);

	// Havoc 'valid' array
	add_instructions_to_havoc_tracker_array(VALID, method, ns);

	// Havoc 'is_get' array
	add_instructions_to_havoc_tracker_array(IS_GET, method, ns);

	// Havoc 'ls' array
	add_instructions_to_havoc_tracker_array(LS, method, ns);

	// Havoc 'size' array
	add_instructions_to_havoc_tracker_array(SIZE, method, ns);

	// Havoc 'tag' array
	add_instructions_to_havoc_tracker_array(TAG, method, ns);

	// Havoc 'protected_by_barrier' array
	add_instructions_to_havoc_tracker_array(PROTECTED_BY_BARRIER, method, ns);

	if(MAX_AGE > 0)
	{
		// Havoc 'age' array
		add_instructions_to_havoc_tracker_array(AGE, method, ns);
	}

}


void scratch_k_induction_configurationt::add_loop_invariants(goto_programt& loop_body, const namespacet ns)
{

	if(FREE_DMAS != 0)
	{

		index_exprt valid_0;
		symbolt valid_symbol = ns.lookup(SCRATCH_NAME_PREFIX VALID);
		valid_0.array() = symbol_expr(valid_symbol);
		valid_0.index() = from_integer(0, index_type());
		valid_0.type() = valid_0.array().type().subtype();
		exprt num_free("if", uint_type());
		num_free.copy_to_operands(valid_0, from_integer(0, uint_type()), from_integer(1, uint_type()));

		for(unsigned int i=1; i<NUM_TRACKED_DMAS; i++)
		{
			index_exprt valid_i;
			valid_i.array() = symbol_expr(valid_symbol);
			valid_i.index() = from_integer(i, index_type());
			valid_i.type() = valid_i.array().type().subtype();
			exprt one_or_zero("if", uint_type());
			one_or_zero.copy_to_operands(valid_i, from_integer(0, uint_type()), from_integer(1, uint_type()));
			num_free = binary_exprt(num_free, "+", one_or_zero);
			num_free.type() = num_free.op0().type();
		}

		goto_programt::targett assert_enough_free = loop_body.add_instruction();
		assert_enough_free->make_assertion(binary_relation_exprt(num_free, ">=", from_integer(FREE_DMAS, uint_type())));
	}

	if(MAX_AGE > 0)
	{
		for(unsigned int i=0; i<NUM_TRACKED_DMAS ; i++)
		{
			symbolt valid_symbol = ns.lookup(SCRATCH_NAME_PREFIX VALID);
			index_exprt valid_i;
			valid_i.array() = symbol_expr(valid_symbol);
			valid_i.index() = from_integer(i, index_type());
			valid_i.type() = valid_i.array().type().subtype();

			symbolt age_symbol = ns.lookup(SCRATCH_NAME_PREFIX AGE);
			index_exprt age_i;
			age_i.array() = symbol_expr(age_symbol);
			age_i.index() = from_integer(i, index_type());
			age_i.type() = age_i.array().type().subtype();

			goto_programt::targett assert_not_too_old = loop_body.add_instruction();
			assert_not_too_old->make_assertion(or_exprt(not_exprt(valid_i), binary_relation_exprt(age_i, "<=", from_integer(MAX_AGE, uint_type()))));

			goto_programt::targett increment_by_one = loop_body.add_instruction();
			increment_by_one->type=ASSIGN;
			increment_by_one->targets.clear();
			increment_by_one->guard.make_true();
			increment_by_one->event="";
			increment_by_one->code.make_nil();

			increment_by_one->code = code_assignt(age_i, binary_exprt(age_i, "+", from_integer(1, uint_type())));
		}

	}

}
