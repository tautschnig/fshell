/*******************************************************************\

Module: Command Line Parsing

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk (based on analogous file in CBMC)

\*******************************************************************/

#ifndef CPROVER_SCRATCH_PARSEOPTIONS_H
#define CPROVER_SCRATCH_PARSEOPTIONS_H


/* DEFINEs for debugging */

extern bool DEBUG_INSTRUMENTATION;

/* end of DEFINEs */

#define MAX_DMAS 32

extern unsigned int NUM_TRACKED_DMAS;

#include <langapi/language_ui.h>
#include <ui_message.h>
#include <cbmc/parseoptions.h>

#include <cbmc/bmc.h>

#define SCRATCH_OPTIONS \
  "(bug-finding)(tracked-dmas):(k-induction-depth):(write-binary):(free-dmas):(show-step-case-fails)(max-age):(base-case-bug-finding):"

class scratch_parseoptionst:
  public cbmc_parseoptionst
{
public:

  virtual void help();

  scratch_parseoptionst(int argc, const char **argv):
    cbmc_parseoptionst(argc, argv, SCRATCH_OPTIONS)
  {
  }

  scratch_parseoptionst(
    int argc,
    const char **argv,
    const std::string &extra_options):
    cbmc_parseoptionst(argc, argv, SCRATCH_OPTIONS+extra_options)
  {
  }

protected:

  virtual void get_command_line_options(optionst &options);

  virtual int do_bmc(bmc_baset &bmc, const goto_functionst &goto_functions);

  virtual bool process_goto_program(
    bmc_baset &bmc,
    goto_functionst &goto_functions);

  virtual bmct& get_bmc(const contextt & context, message_handlert & message_handler);

};

#endif
