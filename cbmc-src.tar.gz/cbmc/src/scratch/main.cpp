/*******************************************************************\

Module: Main Module

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk

\*******************************************************************/

/*

  SCRATCH
  Automatic verification of code using scratchpad memory
  Copyright (C) 2009 Alastair Donaldson <alastair.donaldson@comlab.ox.ac.uk> and Daniel Kroening <kroening@kroening.com>

*/

#include "parseoptions.h"

/*******************************************************************\

Function: main

  Inputs: Number of arguments (argc), list of arguments (argv)

 Outputs: Error status code returned

 Purpose: Kicks off the SCRATCH tool

\*******************************************************************/

int main(int argc, const char **argv)
{
  scratch_parseoptionst parseoptions(argc, argv);
  return parseoptions.main();
}
