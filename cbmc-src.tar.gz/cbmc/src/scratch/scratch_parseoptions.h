/*******************************************************************\

Module: Command Line Parsing

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk (based on analogous file in CBMC)

\*******************************************************************/

#ifndef CPROVER_SCRATCH_PARSEOPTIONS_H
#define CPROVER_SCRATCH_PARSEOPTIONS_H

extern unsigned int NUM_TRACKED_DMAS;

#include <memory>

#include <langapi/language_ui.h>
#include <ui_message.h>

#include <k-induction/kcbmc_parseoptions.h>

#include "dma_analyser.h"

#include <cbmc/bmc.h>

#define SCRATCH_OPTIONS \
  "(bug-finding)(tracked-dmas):(free-dmas):(max-age):(track-history)(write-binary):"

class scratch_parseoptionst:
  public kcbmc_parseoptionst
{
public:

  virtual void help();

  scratch_parseoptionst(int argc, const char **argv):
    kcbmc_parseoptionst(argc, argv, SCRATCH_OPTIONS)
  {
  }

  scratch_parseoptionst(
    int argc,
    const char **argv,
    const std::string &extra_options):
    kcbmc_parseoptionst(argc, argv, SCRATCH_OPTIONS+extra_options)
  {
  }

protected:

  virtual void get_command_line_options(optionst &options);

  virtual int do_bmc(bmc_baset &bmc, const goto_functionst &goto_functions);

  virtual bool process_goto_program(
    bmc_baset &bmc,
    goto_functionst &goto_functions);


  std::auto_ptr<dma_analysert> dma_analyser;

};

#endif
