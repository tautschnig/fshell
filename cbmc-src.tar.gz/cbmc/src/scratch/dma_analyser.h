/*
 * dma_analysis.h
 *
 *  Created on: Jul 16, 2009
 *      Author: Alastair F. Donaldson
 */

#ifndef DMA_ANALYSER_H_
#define DMA_ANALYSER_H_

#include <goto-programs/goto_functions.h>

#include <goto-programs/find_loops.h>

#include <cbmc/bmc.h>

#include <cbmc/parseoptions.h>

#include <goto-symex/k_induction_configuration.h>

#define DMA_PUT "mfc_put"
#define DMA_PUTF "mfc_putf"
#define DMA_PUTB "mfc_putb"
#define DMA_GET "mfc_get"
#define DMA_GETF "mfc_getf"
#define DMA_GETB "mfc_getb"
#define DMA_WAIT "mfc_read_tag_status_all"
#define WRITE_TAG_MASK "mfc_write_tag_mask"


class dma_analysert : public k_induction_configurationt
{
protected:
	contextt& context;
	const namespacet ns;

	bool program_involves_barriers;

    static bool function_name_is_dma_put_operation_name(const exprt& operand, const namespacet& ns);

    static bool function_name_is_dma_get_operation_name(const exprt& operand, const namespacet& ns);

    static bool function_name_is_wait_operation_name(const exprt& operand, const namespacet& ns);

    static bool function_name_is_write_tag_mask(const exprt& operand, const namespacet& ns);

    static bool function_name_is_fence_dma_operation_name(const exprt& operand, const namespacet& ns);

    static bool function_name_is_barrier_dma_operation_name(const exprt& operand, const namespacet& ns);

    static bool is_fence_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_barrier_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_dma_put_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_dma_get_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_wait_operation(const goto_programt::instructiont & inst, const namespacet& ns);

    static bool is_write_tag_mask(const goto_programt::instructiont & inst, const namespacet& ns);

    goto_programt::targett add_array_shift_instruction(const int i, const symbolt& array_symbol, goto_programt& program, goto_programt::targett instruction_to_take_values_from);

    goto_programt::targett add_array_assign_index_instruction(const symbolt& array_symbol, const exprt& index_value, goto_programt& program, goto_programt::targett instruction_to_take_values_from, const exprt& new_value);

    goto_programt::targett add_array_assign_0_instruction(const symbolt& array_symbol, goto_programt& program, goto_programt::targett instruction_to_take_values_from, const exprt& new_value);

    goto_programt::targett add_declaration_instruction(irep_idt base_name, symbolt& symbol, typet type, goto_programt& program, goto_programt& existing_program, std::set<symbolt*>& new_local_variables);

    void add_global_declaration(irep_idt base_name, symbolt& symbol, typet type);

    goto_programt::targett add_assign_instruction(const exprt& lhs, const exprt& rhs, goto_programt& program, goto_programt::targett instruction_to_take_values_from);

    void add_static_initialiser(symbolt& var, const exprt& value, goto_functionst& all_functions);

    void add_static_array_initialiser(symbolt& array, const exprt& element_value, array_typet type, goto_functionst& all_functions);

    exprt& get_ls_expr_from_dma(goto_programt::targett inst);

    exprt& get_size_expr_from_dma(goto_programt::targett inst);

    exprt& get_tag_expr_from_dma(goto_programt::targett inst);

	void redirect_targets(goto_programt::targett previous_target, goto_programt::targett new_target, goto_programt& method);

	index_exprt make_array_index(symbolt& symbol, exprt& index);

	index_exprt make_array_index(symbolt& symbol, int i);

	void check_for_barriers(goto_functionst& all_functions);

public:

    cbmc_parseoptionst& options;
	unsigned int free_dmas;
	unsigned int max_age;

	dma_analysert(
			contextt& context,
			cbmc_parseoptionst& options) : context(context), ns(context), options(options)
	{

	}

	virtual void havoc_globals(CFGt& method, const namespacet ns) = 0;
	virtual void make_instructions_for_invariant(goto_programt& temp_program) = 0;
	virtual void instrument_program(goto_functionst& all_functions) = 0;

};


void copy_location_info(goto_programt::targett dest, goto_programt::const_targett src);



#endif /* DMA_ANALYSER_H_ */
