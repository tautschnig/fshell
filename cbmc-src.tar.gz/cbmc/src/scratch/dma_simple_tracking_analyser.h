/*
 * dma_simple_tracking_analyser.h
 *
 *  Created on: May 7, 2010
 *      Author: alad
 */

#ifndef DMA_SIMPLE_TRACKING_ANALYSER_H_
#define DMA_SIMPLE_TRACKING_ANALYSER_H_

#include <goto-programs/goto_functions.h>

#include <goto-programs/find_loops.h>

#include <cbmc/bmc.h>

#include <scratch/parseoptions.h>

#include "dma_analyser.h"

class dma_simple_tracking_analysert : public dma_analysert
{

public:

	dma_simple_tracking_analysert(
			contextt& context,
			scratch_parseoptionst& options) : dma_analysert(context, options)
			{ }

	virtual void havoc_globals(CFGt& method, const namespacet ns);
	virtual void make_instructions_for_invariant(goto_programt& temp_program);
	virtual void instrument_program(goto_functionst& all_functions);

protected:

	void check_for_fences(goto_functionst& all_functions);

	bool program_involves_fences;

	symbolt ops_in_progress_symbol;
	symbolt valid_symbol;
	symbolt age_symbol;
	symbolt tags_in_use_symbol;
	symbolt track_this_dma_symbol;
	symbolt tag_mask_symbol;
	symbolt is_get_symbol;
	symbolt ls_symbol;
	symbolt size_symbol;
	symbolt tag_symbol;
	symbolt protected_by_barrier_symbol;

};

#endif /* DMA_SIMPLE_TRACKING_ANALYSER_H_ */
