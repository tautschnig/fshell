/*******************************************************************\

Module: Command Line Parsing

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk (based on analogous file in CBMC)

\*******************************************************************/

#ifndef CPROVER_KCBMC_PARSEOPTIONS_H
#define CPROVER_KCBMC_PARSEOPTIONS_H

#include <langapi/language_ui.h>
#include <ui_message.h>
#include <cbmc/parseoptions.h>

#include <cbmc/bmc.h>

#define KCBMC_OPTIONS \
  "(k-induction-depth):(show-step-case-fails)(monolithic)(starting-k):(loop-free-restriction)"

class kcbmc_parseoptionst:
  public cbmc_parseoptionst
{
public:

  virtual void help();

  kcbmc_parseoptionst(int argc, const char **argv):
    cbmc_parseoptionst(argc, argv, KCBMC_OPTIONS)
  {
  }

  kcbmc_parseoptionst(
    int argc,
    const char **argv,
    const std::string &extra_options):
    cbmc_parseoptionst(argc, argv, KCBMC_OPTIONS+extra_options)
  {
  }

protected:

  virtual void get_command_line_options(optionst &options);

  virtual int do_bmc(bmc_baset &bmc, const goto_functionst &goto_functions);

  virtual int doit();

  virtual bool process_goto_program(
    bmc_baset &bmc,
    goto_functionst &goto_functions);

};

#endif
