/*
 * dma_analysis.cpp
 *
 *  Created on: Jul 16, 2009
 *      Author: Alastair F. Donaldson
 */

#include "dma_analyser.h"

#include "tracker_variables.h"

#include <config.h>

#include <expr_util.h>
#include <std_expr.h>

#include <ansi-c/c_types.h>
#include <ansi-c/expr2c.h>

#include <goto-programs/goto_functions.h>
#include <goto-programs/show_claims.h>

#include <langapi/language_ui.h>

#include <pointer-analysis/value_set_analysis.h>

#include <util/arith_tools.h>

#include <sstream>


bool dma_analysert::function_name_is_dma_put_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == DMA_PUT) || (expr2c(operand, ns) == DMA_PUTF) || (expr2c(operand, ns) == DMA_PUTB) || (expr2c(operand, ns) == DMA_PUTL)
			|| (expr2c(operand, ns) == ASSERT_DMA_PUT) || (expr2c(operand, ns) == ASSERT_DMA_PUTF) || (expr2c(operand, ns) == ASSERT_DMA_PUTB) || (expr2c(operand, ns) == ASSERT_DMA_PUTL)
			|| (expr2c(operand, ns) == ASSUME_DMA_PUT) || (expr2c(operand, ns) == ASSUME_DMA_PUTF) || (expr2c(operand, ns) == ASSUME_DMA_PUTB) || (expr2c(operand, ns) == ASSUME_DMA_PUTL)
			|| (expr2c(operand, ns) == EFFECT_DMA_PUT) || (expr2c(operand, ns) == EFFECT_DMA_PUTF) || (expr2c(operand, ns) == EFFECT_DMA_PUTB) || (expr2c(operand, ns) == EFFECT_DMA_PUTL);
}

bool dma_analysert::function_name_is_dma_get_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == DMA_GET) || (expr2c(operand, ns) == DMA_GETF) || (expr2c(operand, ns) == DMA_GETB) || (expr2c(operand, ns) == DMA_GETL)
			|| (expr2c(operand, ns) == ASSERT_DMA_GET) || (expr2c(operand, ns) == ASSERT_DMA_GETF) || (expr2c(operand, ns) == ASSERT_DMA_GETB) || (expr2c(operand, ns) == ASSERT_DMA_GETL)
			|| (expr2c(operand, ns) == ASSUME_DMA_GET) || (expr2c(operand, ns) == ASSUME_DMA_GETF) || (expr2c(operand, ns) == ASSUME_DMA_GETB) || (expr2c(operand, ns) == ASSUME_DMA_GETL)
			|| (expr2c(operand, ns) == EFFECT_DMA_GET) || (expr2c(operand, ns) == EFFECT_DMA_GETF) || (expr2c(operand, ns) == EFFECT_DMA_GETB) || (expr2c(operand, ns) == EFFECT_DMA_GETL);
}

bool dma_analysert::function_name_is_fence_dma_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == DMA_GETF) || (expr2c(operand, ns) == DMA_PUTF) ||
			(expr2c(operand, ns) == ASSERT_DMA_GETF) || (expr2c(operand, ns) == ASSERT_DMA_PUTF) ||
			(expr2c(operand, ns) == ASSUME_DMA_GETF) || (expr2c(operand, ns) == ASSUME_DMA_PUTF) ||
			(expr2c(operand, ns) == EFFECT_DMA_GETF) || (expr2c(operand, ns) == EFFECT_DMA_PUTF);
}


bool dma_analysert::function_name_is_barrier_dma_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == DMA_GETB) || (expr2c(operand, ns) == DMA_PUTB) ||
			(expr2c(operand, ns) == ASSERT_DMA_GETB) || (expr2c(operand, ns) == ASSERT_DMA_PUTB) ||
			(expr2c(operand, ns) == ASSUME_DMA_GETB) || (expr2c(operand, ns) == ASSUME_DMA_PUTB) ||
			(expr2c(operand, ns) == EFFECT_DMA_GETB) || (expr2c(operand, ns) == EFFECT_DMA_PUTB);
}

bool dma_analysert::function_name_is_assert_dma_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == ASSERT_DMA_GET) || (expr2c(operand, ns) == ASSERT_DMA_GETF) || (expr2c(operand, ns) == ASSERT_DMA_GETB) || (expr2c(operand, ns) == ASSERT_DMA_GETL) ||
			(expr2c(operand, ns) == ASSERT_DMA_PUT) || (expr2c(operand, ns) == ASSERT_DMA_PUTF) || (expr2c(operand, ns) == ASSERT_DMA_PUTB) || (expr2c(operand, ns) == ASSERT_DMA_PUTL);
}

bool dma_analysert::function_name_is_assume_dma_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == ASSUME_DMA_GET) || (expr2c(operand, ns) == ASSUME_DMA_GETF) || (expr2c(operand, ns) == ASSUME_DMA_GETB) || (expr2c(operand, ns) == ASSUME_DMA_GETL) ||
			(expr2c(operand, ns) == ASSUME_DMA_PUT) || (expr2c(operand, ns) == ASSUME_DMA_PUTF) || (expr2c(operand, ns) == ASSUME_DMA_PUTB) || (expr2c(operand, ns) == ASSUME_DMA_PUTL);
}

bool dma_analysert::function_name_is_effect_dma_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return (expr2c(operand, ns) == EFFECT_DMA_GET) || (expr2c(operand, ns) == EFFECT_DMA_GETF) || (expr2c(operand, ns) == EFFECT_DMA_GETB) || (expr2c(operand, ns) == EFFECT_DMA_GETL) ||
			(expr2c(operand, ns) == EFFECT_DMA_PUT) || (expr2c(operand, ns) == EFFECT_DMA_PUTF) || (expr2c(operand, ns) == EFFECT_DMA_PUTB) || (expr2c(operand, ns) == EFFECT_DMA_PUTL);
}


bool dma_analysert::function_name_is_wait_operation_name(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return expr2c(operand, ns) == DMA_WAIT;
}

bool dma_analysert::function_name_is_write_tag_mask(const exprt& operand, const namespacet& ns)
{
	// Assert that 'operand' really is a function
	assert(operand.type().id()=="code");

	return expr2c(operand, ns) == WRITE_TAG_MASK;
}


bool dma_analysert::is_fence_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	assert(inst.is_function_call());
	return function_name_is_fence_dma_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_barrier_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	assert(inst.is_function_call());
	return function_name_is_barrier_dma_operation_name(inst.code.op1(), ns);
}


bool dma_analysert::is_dma_put_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	// TODO It's not really enough just to say that an operation is a DMA if it has simply the correct name.
	// we should also check the correct number of arguments, and maybe do something "deeper".  Having said
	// this, C doesn't have overloading so it may not be such an issue.  Also, let's be pragmatic.
	return inst.is_function_call() && function_name_is_dma_put_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_dma_get_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_dma_get_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return is_dma_put_operation(inst, ns) || is_dma_get_operation(inst, ns);
}

bool dma_analysert::is_dma_list_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() &&
		(
				(expr2c(inst.code.op1(), ns) == DMA_PUTL) || (expr2c(inst.code.op1(), ns) == DMA_GETL) ||
				(expr2c(inst.code.op1(), ns) == ASSERT_DMA_PUTL) || (expr2c(inst.code.op1(), ns) == ASSERT_DMA_GETL) ||
				(expr2c(inst.code.op1(), ns) == ASSUME_DMA_PUTL) || (expr2c(inst.code.op1(), ns) == ASSUME_DMA_GETL) ||
				(expr2c(inst.code.op1(), ns) == EFFECT_DMA_PUTL) || (expr2c(inst.code.op1(), ns) == EFFECT_DMA_GETL)
		);
}


bool dma_analysert::is_wait_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_wait_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_assert_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_assert_dma_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_assume_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_assume_dma_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_effect_dma_operation(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_effect_dma_operation_name(inst.code.op1(), ns);
}

bool dma_analysert::is_write_tag_mask(const goto_programt::instructiont & inst, const namespacet& ns)
{
	return inst.is_function_call() && function_name_is_write_tag_mask(inst.code.op1(), ns);
}

goto_programt::targett dma_analysert::add_array_shift_instruction(const int i, const symbolt& array_symbol, goto_programt& program, goto_programt::targett instruction_to_take_values_from)
{

    index_exprt lhs;
    lhs.array() = symbol_expr(array_symbol);
    lhs.index() = from_integer(i, index_type());

    index_exprt rhs;
    rhs.array() = symbol_expr(array_symbol);
    rhs.index() = from_integer(i-1, index_type());

    return add_assign_instruction(lhs, rhs, program, instruction_to_take_values_from);

}

goto_programt::targett dma_analysert::add_array_assign_index_instruction(const symbolt& array_symbol, const exprt& index_value, goto_programt& program, goto_programt::targett instruction_to_take_values_from, const exprt& new_value)
{
	index_exprt lhs;
	lhs.array() = symbol_expr(array_symbol);
	lhs.index() = index_value;
	return add_assign_instruction(lhs, new_value, program, instruction_to_take_values_from);
}



goto_programt::targett dma_analysert::add_array_assign_0_instruction(const symbolt& array_symbol, goto_programt& program, goto_programt::targett instruction_to_take_values_from, const exprt& new_value)
{
	return add_array_assign_index_instruction(array_symbol, from_integer(0, index_type()), program, instruction_to_take_values_from, new_value);
}


goto_programt::targett dma_analysert::add_assign_instruction(const exprt& lhs, const exprt& rhs, goto_programt& program, goto_programt::targett instruction_to_take_values_from)
{

	goto_programt::targett inst;

	inst = program.add_instruction();
	inst->type=ASSIGN;
	inst->targets.clear();
	inst->guard.make_true();
	inst->code.make_nil();

	inst->code = code_assignt( lhs, rhs);
	inst->code.location()=instruction_to_take_values_from->code.location();
	inst->location=instruction_to_take_values_from->code.location();
	inst->function=instruction_to_take_values_from->code.location().get_function();
	inst->location_number = -1;
	return inst;

}




goto_programt::targett dma_analysert::add_declaration_instruction(irep_idt base_name, symbolt& symbol, typet type, goto_programt& program, goto_programt& existing_program, std::set<symbolt*>& new_local_variables)
{
    goto_programt::targett decl = program.add_instruction();
    decl->make_other();
    symbol.base_name = base_name;
    symbol.name = SCRATCH_NAME_PREFIX + base_name.as_string();
    symbol.type = type;
    context.add(symbol);

    decl->code=code_declt(symbol_expr(symbol));
    decl->code.location()=existing_program.instructions.begin()->code.location();
    decl->location=existing_program.instructions.begin()->location;
    decl->function=existing_program.instructions.begin()->function;
    decl->location_number = -1;
    new_local_variables.insert(&symbol);
    return decl;

}


void dma_analysert::add_global_declaration(irep_idt base_name, symbolt& symbol, typet type)
{
	/* Confusingly, this seems to be far more simple than adding a declaration instruction -
	 * there's basically no need for the declaration to actually appear anywhere - it is simply
	 * put into the context.
	 */
    symbol.base_name = base_name;
    symbol.name = SCRATCH_NAME_PREFIX + base_name.as_string();
    symbol.type = type;
    symbol.static_lifetime = true; // Not sure exactly what this means, but use it to make sure globals are havocked
    symbol.lvalue = true;
    context.add(symbol);
}


void dma_analysert::add_static_initialiser(symbolt& var, const exprt& value, goto_functionst& all_functions)
{
	/* Inserts "var = value" to static initialisers */

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			;
			f_it++)
	{

    	if(f_it == all_functions.function_map.end())
    	{
    	    throw "main symbol not found; please set an entry point";
    	}

		if(ns.lookup(f_it->first).display_name() == "main")
		{
			assert(f_it->second.body_available);

			goto_programt& pre_main_method = f_it->second.body;
			goto_programt::targett start_of_pre_main_method = pre_main_method.instructions.begin();

			goto_programt program_for_new_instruction;
			goto_programt::targett inst = program_for_new_instruction.add_instruction();
			inst->type=ASSIGN;
			inst->targets.clear();
			inst->guard.make_true();
			inst->code.make_nil();
			inst->code = code_assignt(symbol_expr(var), value);

			pre_main_method.instructions.splice(start_of_pre_main_method, program_for_new_instruction.instructions);

			return;
		}
	}
	assert(false);

}


void dma_analysert::add_static_array_initialiser(symbolt& array, const exprt& element_value, array_typet type, goto_functionst& all_functions)
{
	/* Inserts "lhs = rhs" to static initialisers */

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			;
			f_it++)
	{
		assert(f_it != all_functions.function_map.end());
		if(ns.lookup(f_it->first).display_name() == "main")
		{
			assert(f_it->second.body_available);

			goto_programt& pre_main_method = f_it->second.body;
			goto_programt::targett start_of_pre_main_method = pre_main_method.instructions.begin();

			goto_programt program_for_new_instruction;
			goto_programt::targett inst = program_for_new_instruction.add_instruction();
			inst->type=ASSIGN;
			inst->targets.clear();
			inst->guard.make_true();
			inst->code.make_nil();
		    exprt initialiser("array_of", type);
		    initialiser.copy_to_operands(element_value);
			inst->code = code_assignt(symbol_expr(array), initialiser);

			pre_main_method.instructions.splice(start_of_pre_main_method, program_for_new_instruction.instructions);

			return;
		}
	}
	assert(false);

}



exprt dma_analysert::get_ls_expr_from_dma(const goto_programt::targett inst, const namespacet& ns)
{
	return inst->code.op2().op0();
}

exprt dma_analysert::get_size_expr_from_dma(const goto_programt::targett inst, const namespacet& ns)
{

	if(is_dma_list_operation(*inst, ns))
	{
		return inst->code.op2().op3();
	} else {
		return inst->code.op2().op2();
	}
}

exprt dma_analysert::get_tag_expr_from_dma(const goto_programt::targett inst, const namespacet& ns)
{
	if(is_dma_list_operation(*inst, ns))
	{
		return inst->code.op2().operands()[4];
	} else {
		return inst->code.op2().op3();
	}
}


void dma_analysert::redirect_targets(goto_programt::targett previous_target, goto_programt::targett new_target, goto_programt& method)
{
	for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
	{
		for(goto_programt::targetst::iterator g_it = it->targets.begin(); g_it != it->targets.end(); g_it++)
		{
			if((*g_it)==previous_target)
			{
				*g_it = new_target;
			}
		}
	}
}


index_exprt dma_analysert::make_array_index(symbolt& symbol, exprt& index)
{
	index_exprt result;
	result.array() = symbol_expr(symbol);
	result.index() = index;
	result.type()  = result.array().type().subtype();
	return result;
}


index_exprt dma_analysert::make_array_index(symbolt& symbol, int i)
{
	exprt index = from_integer(i, index_type());
	return make_array_index(symbol, index);
}

void copy_location_info(goto_programt::targett dest, goto_programt::const_targett src)
{
	dest->code.location()=src->code.location();
	dest->location=src->location;
	dest->function=src->function;
	dest->location_number = -1;
}


void dma_analysert::check_for_barriers(goto_functionst& all_functions)
{

	/* We need to determine whether or not the given program uses barrier operations,
	 * so that when we do DMA instrumentation we know whether or not we need to add
	 * additional checks for this scenario
	 */
	program_involves_barriers = false;

    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			if(is_dma_operation(*it, ns) && is_barrier_dma_operation(*it, ns))
			{
				program_involves_barriers = true;
				return;
			}

		}

	}


 }
