/*
 * scratch_bmc.cpp
 *
 *  Created on: Sep 29, 2009
 *      Author: ally
 */

#include <goto-symex/build_goto_trace.h>

#include <solvers/prop/prop_conv.h>

#include <ansi-c/expr2c.h>

#include "scratch_bmc.h"


void show_dma_goto_trace(
  std::ostream &out,
  const namespacet &ns,
/*  const pretty_namest &pretty_names,*/
  const goto_tracet &goto_trace)
{
  unsigned prev_step_nr=0;
  bool first_step=true;

  std::cout << "BLAAAH\n";

  for(goto_tracet::stepst::const_iterator
      it=goto_trace.steps.begin();
      it!=goto_trace.steps.end();
      it++)
  {
	  it->output(ns, std::cout);
	  std::cout << "\n";

	  switch(it->type)
    {
/*    case goto_trace_stept::ASSERT:
      if(!it->cond_value)
      {
        out << std::endl;
        out << "Violated property:" << std::endl;
        if(!it->pc->location.is_nil())
          out << "  " << it->pc->location << std::endl;
        out << "  " << it->comment << std::endl;

        if(it->pc->is_assert())
          out << "  " << from_expr(ns, "", it->pc->guard) << std::endl;

        out << std::endl;
      }
      break;

    case goto_trace_stept::ASSUME:
      break;

    case goto_trace_stept::LOCATION:
      if(it->pc->is_sync())
      {
        show_state_header(out, *it, it->pc->location, it->step_nr);

        out << "SYNC " << it->pc->event << std::endl;
      }
      break;*/

    case goto_trace_stept::ASSIGNMENT:
      if(it->pc->is_assign() ||
         (it->pc->is_other() && it->lhs.is_not_nil()))
      {
    	  std::cout << expr2c(it->original_lhs, ns) << "\n";

    	  if(expr2c(it->original_lhs.op0(), ns) == "valid") {

    	  }
/*        if(prev_step_nr!=it->step_nr || first_step)
        {
          first_step=false;
          prev_step_nr=it->step_nr;
          show_state_header(out, *it, it->pc->location, it->step_nr);
        }

        counterexample_value(out, ns, it->original_lhs,
                             it->value, pretty_names);*/
      }
      break;

/*    case goto_trace_stept::OUTPUT:
      {
        printf_formattert printf_formatter(ns);
        printf_formatter(it->format_string, it->output_args);
        printf_formatter.print(out);
        out << std::endl;
      }
      break;*/

    default:
		break;
//      assert(false);
    }
  }
}



void scratch_bmct::error_trace(const prop_convt &prop_conv)
{

/*	goto_tracet goto_trace;

	build_goto_trace(equation, prop_conv, goto_trace);

	show_dma_goto_trace(
			std::cout,
			ns,
			goto_trace);*/

	if(!silent)
	{
		bmct::error_trace(prop_conv);
	}


}
