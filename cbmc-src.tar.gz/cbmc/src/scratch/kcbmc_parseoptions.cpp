/*******************************************************************\

Module: Parsing of options

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk

\*******************************************************************/

#include <fstream>
#include <memory>


#include <cbmc/bmc.h>

#include <config.h>
#include <expr_util.h>

#include <ansi-c/ansi_c_language.h>

#include <goto-programs/goto_convert_functions.h>
#include <goto-programs/goto_check.h>
#include <goto-programs/goto_inline.h>
#include <goto-programs/show_claims.h>
#include <goto-programs/set_claims.h>
#include <goto-programs/read_goto_binary.h>
#include <goto-programs/interpreter.h>
#include <goto-programs/string_abstraction.h>
#include <goto-programs/string_instrumentation.h>
#include <goto-programs/loop_numbers.h>
#include <goto-programs/write_goto_binary.h>
#include <goto-programs/find_loops.h>

#include <goto-symex/k_induction.h>

#include <langapi/mode.h>

#include <loopfrog/transform_loops.h>

#include "kcbmc_parseoptions.h"

#include "kcbmc_k_induction_configuration.h"

#include "kcbmc_version.h"

class k_induction_message_handlert : public ui_message_handlert
{
	std::ostream output_stream;

public:
	k_induction_message_handlert(ui_message_handlert::uit __ui, const std::string& program) : ui_message_handlert(__ui, program),
		output_stream(std::cout.rdbuf())
	{

	}

	virtual void print(unsigned level, const std::string &message)
	{
		if(level>1)
		{
			output_stream << message << std::endl;
		}
		else
		{
			output_stream << message << std::endl;
		}
	}


};


/*******************************************************************\

Function: kcbmc_parseoptionst::process_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool kcbmc_parseoptionst::process_goto_program(
  bmc_baset &bmc,
  goto_functionst &goto_functions)
{
    namespacet ns(context);

    k_induction_message_handlert my_message_handler(ui_message_handlert::PLAIN, "");

    // do partial inlining
    goto_partial_inline(goto_functions, ns, my_message_handler);

	return false;
}


/*******************************************************************\

Function: kcbmc_parseoptionst::doit

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int kcbmc_parseoptionst::doit()
{
  if(cmdline.isset("version"))
  {
    std::cout << KCBMC_VERSION << std::endl;
    return 0;
  }

  register_languages();

  k_induction_message_handlert my_message_handler(ui_message_handlert::PLAIN, "");

  bmct bmc(context, my_message_handler);

  //
  // command line options
  //

  get_command_line_options(bmc.options);
  set_verbosity(bmc);
  set_verbosity(*this);

  if(cmdline.isset("preprocess"))
  {
    preprocessing();
    return 0;
  }

  goto_functionst goto_functions;

  if(get_goto_program(bmc, goto_functions))
    return 6;

  if(cmdline.isset("show-claims"))
  {
    const namespacet ns(context);
    show_claims(ns, get_ui(), goto_functions);
    return 0;
  }

  if(set_claims(goto_functions))
    return 7;

  // do actual BMC
  return do_bmc(bmc, goto_functions);
}



/*******************************************************************\

Function: kcbmc_parseoptionst::do_bmc

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int kcbmc_parseoptionst::do_bmc(
  bmc_baset &bmc,
  const goto_functionst &goto_functions)
{

	if(config.main == "")
	{
		config.main = "main";
	}

	try
	{
		kcbmc_k_induction_configurationt k_induction_configuration;
		CFGt control_flow_graph(context, find_main(const_cast<goto_functionst&>(goto_functions), context));

		k_induction_enginet engine(context, k_induction_configuration, *this, goto_functions, bmc.get_message_handler());

		return engine.try_k_induction(bmc, control_flow_graph);

	}

	catch(char *e)
	{
		error(e);
		return 10;
	}


}


void kcbmc_parseoptionst::get_command_line_options(optionst &options)
{
  cbmc_parseoptionst::get_command_line_options(options);

  if(cmdline.isset("k-induction-depth"))
  {
	  K_INDUCTION_DEPTH = atoi(cmdline.getval("k-induction-depth"));

	  if(K_INDUCTION_DEPTH == 0)
	  {
		  std::cout << "Error, cannot set max k-induction depth to zero!\n";
		  exit(1);
	  }

	  std::cout << "Max depth for k-induction is " << K_INDUCTION_DEPTH << ".\n";

  } else {

	  const unsigned int DEFAULT_K_INDUCTION_DEPTH = 10;

	  std::cout << "Max depth for k-induction not specified, using " << DEFAULT_K_INDUCTION_DEPTH << ".\n";

	  K_INDUCTION_DEPTH = DEFAULT_K_INDUCTION_DEPTH;

  }


  if(cmdline.isset("starting-k"))
  {
	  STARTING_K = atoi(cmdline.getval("starting-k"));

	  std::cout << "Starting value for k-induction set to " << STARTING_K << ".\n";

  }

}


void kcbmc_parseoptionst::help()
{
  std::cout <<
    "\n"
    "* *             KCBMC " KCBMC_VERSION " - Copyright (C) 2010                 * *\n"
    "* *           Alastair F. Donaldson, Daniel Kroening             * *\n"
    "* *        University of Oxford Computing Laboratory             * *\n"
    "* *           alastair.donaldson@comlab.ox.ac.uk                 * *\n"
    "\n"
    "Usage:                       Purpose:\n"
    "\n"
    " kcbmc [-?] [-h] [--help]    show help\n"
    " kcbmc file.c ...            source file names\n"
    "\n"
    "Some relevant CBMC options (other CBMC options may have undesirable interactions with k-induction):\n"
    " -I path                      set include path (C/C++)\n"
    " -D macro                     define preprocessor macro (C/C++)\n"
    " --function name              set main function name\n"
    " --binary name                run kcbmc on ready-made goto program in file 'name'\n\n"

    "k-induction options:\n"
    " --show-step-case-fails       display counterexamples for step-case failures\n"
    " --monolithic                 transform loop nest to a single, monolithic loop and apply k-induction to that\n"
    " --starting-k n               set minimum k for which k-induction will be attempted to n (default is 0)\n"
    " --k-induction-depth n        set maximum depth for k-induction to n (default is 10)\n"
    " --loop-free-restriction      restrict step case to consider only loop-free paths\n"


    "\n";
}
