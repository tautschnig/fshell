/*
 * dma_analysis.h
 *
 *  Created on: Jul 16, 2009
 *      Author: Alastair F. Donaldson
 */

#ifndef DMA_BUG_ANALYSIS_H_
#define DMA_BUG_ANALYSIS_H_

#include <goto-programs/goto_functions.h>

#include <loop-analysis/find_loops.h>

#include <cbmc/bmc.h>

#include <scratch/parseoptions.h>

#include "dma_analysis.h"

class dma_bug_analysert : dma_analysert
{

public:

	void instrument_program();

	dma_bug_analysert(
			goto_functionst& all_functions,
			namespacet& ns,
			contextt& context,
			scratch_parseoptionst& options) : dma_analysert(all_functions, ns, context, options)
			{ }

};

#endif /* DMA_BUG_ANALYSIS_H_ */
