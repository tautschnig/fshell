/*
 * k_induction_bmc.h
 *
 *  Created on: May 13, 2010
 *      Author: ally
 */

#ifndef K_INDUCTION_BMC_H_
#define K_INDUCTION_BMC_H_

#include <cbmc/bmc.h>

#include <scratch/k_induction_symex.h>

class k_induction_bmc_baset:public bmc_baset
{
public:
  k_induction_bmc_baset(
    const namespacet &_ns,
    symex_bmct &_symex,
    symex_target_equationt &_equation,
    message_handlert &_message_handler):
    	bmc_baset(_ns, _symex, _equation, _message_handler)
  {
  }

protected:

};

class k_induction_bmct:public k_induction_bmc_baset
{
public:
  k_induction_bmct(
    const contextt &_context,
    message_handlert &_message_handler,
    std::set<goto_programt::const_targett>& loop_header_instruction_points,
    bool loop_free_restriction):
    k_induction_bmc_baset(_ns, _symex, _equation, _message_handler),
    _ns(_context, new_context),
    _equation(ns),
    _symex(ns, new_context, _equation, loop_header_instruction_points, loop_free_restriction)
  {
  }

protected:
  contextt new_context;
  namespacet _ns;
  symex_target_equationt _equation;
  k_induction_symex_bmct _symex;
};



#endif /* K_INDUCTION_BMC_H_ */
