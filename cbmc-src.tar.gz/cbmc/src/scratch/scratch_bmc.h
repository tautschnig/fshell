/*
 * scratch_bmc.h
 *
 *  Created on: Sep 29, 2009
 *      Author: ally
 */

#include <cbmc/bmc.h>

#ifndef SCRATCH_BMC_H_
#define SCRATCH_BMC_H_

class scratch_bmct:public bmct
{
	bool silent;

public:
	scratch_bmct(
		const contextt &_context,
		message_handlert &_message_handler, bool _silent):
			bmct(_context, _message_handler),
					silent(_silent)

	{
	}

protected:

	virtual void error_trace(const prop_convt &prop_conv);

};

#endif /* SCRATCH_BMC_H_ */
