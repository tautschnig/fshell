/*
 * dma_analysis.cpp
 *
 *  Created on: Jul 16, 2009
 *      Author: Alastair F. Donaldson
 */

#include "dma_bug_analysis.h"

#include "tracker_variables.h"

#include <config.h>

#include <expr_util.h>
#include <std_expr.h>

#include <ansi-c/c_types.h>
#include <ansi-c/expr2c.h>

#include <goto-programs/goto_functions.h>
#include <goto-programs/show_claims.h>

#include <langapi/language_ui.h>

#include <k-induction/k_induction_util.h>

#include <loopfrog/pointer_expr.h>

#include <pointer-analysis/value_set_analysis.h>

#include <util/arith_tools.h>

#include <sstream>


unsigned int MAX_AGE;

static void redirect_targets(goto_programt::targett previous_target, goto_programt::targett new_target, goto_programt& method)
{
	for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
	{
		for(goto_programt::targetst::iterator g_it = it->targets.begin(); g_it != it->targets.end(); g_it++)
		{
			if((*g_it)==previous_target)
			{
				*g_it = new_target;
			}
		}
	}
}


void dma_bug_analysert::instrument_program()
{
	// 1. Declare arrays, __valid, __is_get, __ls, __size, __tag
	// 2. Set __valid[i] = 0 for all i
	// 3. Declare tag mask variable
	// 3. Replace each write_tag_mask with write to tag mask variable
	// 3. Replace each wait with __valid[i] = __valid[i] && (IS_0 (tag_mask, __tag[i]))
	// 4. Replace each get with check for every valid operation, then shift of ops
	// 5. Replace each put with get for every valid get operation, then shift of ops

	bool_typet bool_type;

	/***** Declare 'tag_mask' variable */
	symbolt tag_mask_symbol;
	add_global_declaration(TAG_MASK, tag_mask_symbol, uint_type());

	/***** Declare 'new_position' variable */
	symbolt new_position_symbol;
	add_global_declaration(NEW_POSITION, new_position_symbol, index_type());

	array_typet array_of_HISTORY_DEPTH_uint; // Type for tracker arrays
	array_of_HISTORY_DEPTH_uint.size() = from_integer(NUM_TRACKED_DMAS, uint_type()); // Size is NUM_TRACKED_DMAS
	array_of_HISTORY_DEPTH_uint.subtype() = uint_type(); // Element type is unsigned

	array_typet array_of_HISTORY_DEPTH_bool; // Type for tracker arrays
	array_of_HISTORY_DEPTH_bool.size() = from_integer(NUM_TRACKED_DMAS, uint_type()); // Size is NUM_TRACKED_DMAS
	array_of_HISTORY_DEPTH_bool.subtype() = bool_type; // Element type is bool

	/***** Declare 'valid' array */
	symbolt valid_symbol;
	add_global_declaration(VALID, valid_symbol, array_of_HISTORY_DEPTH_bool);
	add_static_array_initialiser(valid_symbol, false_exprt(), array_of_HISTORY_DEPTH_bool);

	/***** Declare 'is_get' array */
	symbolt is_get_symbol;
	add_global_declaration(IS_GET, is_get_symbol, array_of_HISTORY_DEPTH_bool);
	add_static_array_initialiser(is_get_symbol, false_exprt(), array_of_HISTORY_DEPTH_bool);

	/***** Declare 'ls' array */
	symbolt ls_symbol;
	add_global_declaration(LS, ls_symbol, array_of_HISTORY_DEPTH_uint);
	add_static_array_initialiser(ls_symbol, from_integer(0, uint_type()), array_of_HISTORY_DEPTH_uint);

	/***** Declare 'size' array */
	symbolt size_symbol;
	add_global_declaration(SIZE, size_symbol, array_of_HISTORY_DEPTH_uint);
	add_static_array_initialiser(size_symbol, from_integer(0, uint_type()), array_of_HISTORY_DEPTH_uint);

	/***** Declare 'tag' array */
	symbolt tag_symbol;
	add_global_declaration(TAG, tag_symbol, array_of_HISTORY_DEPTH_uint);
	add_static_array_initialiser(tag_symbol, from_integer(0, uint_type()), array_of_HISTORY_DEPTH_uint);

	/***** Declare 'protected_by_barrier' array */
	symbolt protected_by_barrier_symbol;
	add_global_declaration(PROTECTED_BY_BARRIER, protected_by_barrier_symbol, array_of_HISTORY_DEPTH_bool);
	add_static_array_initialiser(protected_by_barrier_symbol, false_exprt(), array_of_HISTORY_DEPTH_bool);

	symbolt age_symbol;
	if(MAX_AGE > 0)
	{
		/***** Declare 'age' array */
		add_global_declaration(AGE, age_symbol, array_of_HISTORY_DEPTH_uint);
		add_static_array_initialiser(age_symbol, from_integer(0, uint_type()), array_of_HISTORY_DEPTH_uint);
	}



    for(goto_functionst::function_mapt::iterator
			f_it = all_functions.function_map.begin();
			f_it != all_functions.function_map.end();
			f_it++)
	{
    	if(!(f_it->second.body_available))
    	{
    		continue;
    	}

    	goto_programt& method = f_it->second.body;

		for(goto_programt::targett it = method.instructions.begin(); it != method.instructions.end(); it++)
		{

			// write tag mask
			if(is_write_tag_mask(*it, ns))
			{
				/* Here we just change the statement, so no re-arrangement of targets is necessary */

				// Add an assignment of 'tag_mask' to the given parameter expression
				code_assignt assignment(symbol_expr(tag_mask_symbol), it->code.op2().op0());
				it->code.swap(assignment);
				it->type = ASSIGN;
			}

			// wait
			if(is_wait_operation(*it, ns))
			{
				goto_programt invalidation_instructions;

				for(unsigned int i=0; i<NUM_TRACKED_DMAS; i++)
				{
					index_exprt valid_i;
					valid_i.array() = symbol_expr(valid_symbol);
					valid_i.index() = from_integer(i, index_type());
					valid_i.type() = valid_i.array().type().subtype();

					index_exprt tag_i;
					tag_i.array() = symbol_expr(tag_symbol);
					tag_i.index() = from_integer(i, index_type());
					tag_i.type() = tag_i.array().type().subtype();

					binary_exprt lshr_expression(
							symbol_expr(tag_mask_symbol),
							"lshr",
							tag_i
					);
					lshr_expression.type() = lshr_expression.op0().type();

					binary_exprt shifted_tag_mask_and_1(
						lshr_expression,
						"bitand",
						from_integer(1, uint_type())
					);
					shifted_tag_mask_and_1.type() = shifted_tag_mask_and_1.op0().type();

					typecast_exprt shifted_tag_mask_and_1_as_bool(bool_type);
					shifted_tag_mask_and_1_as_bool.op0() = shifted_tag_mask_and_1;

					not_exprt not_shifted_tag_mask_and_1(shifted_tag_mask_and_1_as_bool);

					binary_exprt new_value_for_valid_i(valid_i, "and", not_shifted_tag_mask_and_1);
					new_value_for_valid_i.type() = new_value_for_valid_i.op0().type();

					goto_programt::targett assign_instruction = add_assign_instruction(valid_i, new_value_for_valid_i, invalidation_instructions, it);

					if(0 == i)
					{
						redirect_targets(it, assign_instruction, method);
					}

				}

				method.instructions.splice(it, invalidation_instructions.instructions);

				it->make_skip();

			}

			// dma operation
			if(is_dma_operation(*it, ns))
			{
				goto_programt assertion_instructions;

				goto_programt::targett size_lte_max_assertion = assertion_instructions.add_instruction();
				size_lte_max_assertion->make_assertion(binary_relation_exprt(get_size_expr_from_dma(it), "<=", from_integer(MAX_DMA, uint_type())));
				copy_location_info(size_lte_max_assertion, it);

				redirect_targets(it, size_lte_max_assertion, method);

				goto_programt::targett tag_lt_max_assertion = assertion_instructions.add_instruction();
				tag_lt_max_assertion->make_assertion(binary_relation_exprt(get_tag_expr_from_dma(it), "<", from_integer(MAX_TAG, uint_type())));
				copy_location_info(tag_lt_max_assertion, it);

				/* Note that we do not check whether the above are greater than or equal to zero, as they are unsigned. */

				for(unsigned int i=0; i<NUM_TRACKED_DMAS; i++)
				{
					index_exprt valid_i;
					valid_i.array() = symbol_expr(valid_symbol);
					valid_i.index() = from_integer(i, index_type());
					valid_i.type() = valid_i.array().type().subtype();

					exprt assertion_condition = not_exprt(valid_i);

					if(is_dma_put_operation(*it, ns))
					{
						index_exprt is_get_i;
						is_get_i.array() = symbol_expr(is_get_symbol);
						is_get_i.index() = from_integer(i, index_type());
						is_get_i.type() = is_get_i.array().type().subtype();

						assertion_condition = or_exprt(assertion_condition, not_exprt(is_get_i));
					}

					index_exprt ls_i;
					ls_i.array() = symbol_expr(ls_symbol);
					ls_i.index() = from_integer(i, index_type());
					ls_i.type() = ls_i.array().type().subtype();

					index_exprt size_i;
					size_i.array() = symbol_expr(size_symbol);
					size_i.index() = from_integer(i, index_type());
					size_i.type() = size_i.array().type().subtype();

					binary_exprt  ls_plus_size_i(
							ls_i,
							"+",
							size_i
					);
					ls_plus_size_i.type() = ls_plus_size_i.op0().type();

					typecast_exprt current_ls_expr(uint_type());
					current_ls_expr.op() = get_ls_expr_from_dma(it);

					typecast_exprt current_size_expr(uint_type());
					current_size_expr.op() = get_size_expr_from_dma(it);

					binary_exprt ls_plus_size(
							current_ls_expr,
							"+",
							current_size_expr
					);
					ls_plus_size.type() = ls_plus_size.op0().type();

					or_exprt intersection_empty(
							binary_relation_exprt( ls_plus_size_i , "<=", current_ls_expr ),
							binary_relation_exprt( ls_plus_size , "<=", ls_i)
							);

					assertion_condition = or_exprt(assertion_condition, intersection_empty);

					if(is_fence_dma_operation(*it, ns) || is_barrier_dma_operation(*it, ns))
					{
						/* If it's a fence or barrier operation then it is OK for the intersection
						 * with pending operation i to be non-empty, as long as the new operation
						 * has the same tag as pending operation i.
						 */

						index_exprt tag_i;
						tag_i.array() = symbol_expr(tag_symbol);
						tag_i.index() = from_integer(i, index_type());
						tag_i.type() = tag_i.array().type().subtype();
						assertion_condition = or_exprt(assertion_condition, equality_exprt(tag_i, get_tag_expr_from_dma(it)));
					}

					else {

						/* If pending operation is a barrier then it's OK for this operation to
						 * intersect with it, as long as the new operation has the same tag as
						 * pending operation i.  We only need to check this if the new operation
						 * is not itself a fence or barrier operation.
						 */

						index_exprt protected_by_barrier_i;
						protected_by_barrier_i.array() = symbol_expr(protected_by_barrier_symbol);
						protected_by_barrier_i.index() = from_integer(i, index_type());
						protected_by_barrier_i.type() = protected_by_barrier_i.array().type().subtype();

						index_exprt tag_i;
						tag_i.array() = symbol_expr(tag_symbol);
						tag_i.index() = from_integer(i, index_type());
						tag_i.type() = tag_i.array().type().subtype();

						assertion_condition = or_exprt(assertion_condition, and_exprt(protected_by_barrier_i, equality_exprt(tag_i, get_tag_expr_from_dma(it))));

					}

					goto_programt::targett assertion = assertion_instructions.add_instruction();
					assertion->make_assertion(assertion_condition);
					copy_location_info(assertion, it);
					assertion->location.set_comment("DMA race caused by `" + expr2c(it->code.op1(), ns) + "'");
					assertion->location.set_property("DMA race check");

				}

				exprt assert_there_is_some_slot_for_operation;
				for(unsigned int i=0; i<NUM_TRACKED_DMAS; i++)
				{
					index_exprt valid_i;
					valid_i.array() = symbol_expr(valid_symbol);
					valid_i.index() = from_integer(i, index_type());
					valid_i.type() = valid_i.array().type().subtype();
					exprt not_valid_i = not_exprt(valid_i);

					if(i==0)
					{
						assert_there_is_some_slot_for_operation = not_valid_i;
					} else {
						assert_there_is_some_slot_for_operation = or_exprt(assert_there_is_some_slot_for_operation, not_valid_i);
					}
				}

				goto_programt::targett instruction_to_assert_there_is_some_slot_for_operation = assertion_instructions.add_instruction();
				instruction_to_assert_there_is_some_slot_for_operation->make_assertion(assert_there_is_some_slot_for_operation);
				copy_location_info(instruction_to_assert_there_is_some_slot_for_operation, it);
				instruction_to_assert_there_is_some_slot_for_operation->location.set_comment("DMA operation `" + expr2c(it->code.op1(), ns) + "' cannot be issued, as max. number of DMA operations has been reached");
				instruction_to_assert_there_is_some_slot_for_operation->location.set_property("Max DMAs check");

				goto_programt update_instructions;

				/* new position := 0 */
				goto_programt::targett pick_new_position = update_instructions.add_instruction(ASSIGN);

				exprt assign_rhs = from_integer(NUM_TRACKED_DMAS, index_type());
				for(int i=NUM_TRACKED_DMAS-1; i>=0; i--)
				{

					index_exprt valid_position;
					valid_position.array() = symbol_expr(valid_symbol);
					valid_position.index() = from_integer(i, index_type());
					valid_position.type() = valid_position.array().type().subtype();

					exprt new_op1 = not_exprt(valid_position);
					exprt new_op2 = from_integer(i, index_type());
					exprt new_op3 = assign_rhs;

					exprt new_expr("if", index_type());
					new_expr.copy_to_operands(new_op1, new_op2, new_op3);
					assign_rhs = new_expr;


				}

				code_assignt assignment(symbol_expr(new_position_symbol), assign_rhs);
				pick_new_position->code.swap(assignment);
				copy_location_info(pick_new_position, it);

				add_array_assign_index_instruction(valid_symbol, symbol_expr(new_position_symbol), update_instructions, it, true_exprt());

				if(is_dma_get_operation(*it, ns))
				{
					add_array_assign_index_instruction(is_get_symbol, symbol_expr(new_position_symbol), update_instructions, it, true_exprt());
				} else {
					add_array_assign_index_instruction(is_get_symbol, symbol_expr(new_position_symbol), update_instructions, it, false_exprt());
				}

				typecast_exprt ls_expr_as_uint(uint_type());
				ls_expr_as_uint.op0() = get_ls_expr_from_dma(it);

				add_array_assign_index_instruction(ls_symbol, symbol_expr(new_position_symbol), update_instructions, it, ls_expr_as_uint);
				add_array_assign_index_instruction(size_symbol, symbol_expr(new_position_symbol), update_instructions, it, get_size_expr_from_dma(it));
				add_array_assign_index_instruction(tag_symbol, symbol_expr(new_position_symbol), update_instructions, it, get_tag_expr_from_dma(it));


				if(MAX_AGE > 0)
				{
					add_array_assign_index_instruction(age_symbol, symbol_expr(new_position_symbol), update_instructions, it, from_integer(0, uint_type()));
				}


				if(is_barrier_dma_operation(*it, ns))
				{
					// Set any valid operation with same tag to be protected by barrier
					for(unsigned int i=0; i<NUM_TRACKED_DMAS; i++)
					{

						index_exprt tag_i;
						tag_i.array() = symbol_expr(tag_symbol);
						tag_i.index() = from_integer(i, index_type());
						tag_i.type() = tag_i.array().type().subtype();

						index_exprt protected_by_barrier_i;
						protected_by_barrier_i.array() = symbol_expr(protected_by_barrier_symbol);
						protected_by_barrier_i.index() = from_integer(i, index_type());
						protected_by_barrier_i.type() = protected_by_barrier_i.array().type().subtype();


						goto_programt::targett assign_instruction = add_assign_instruction(
								protected_by_barrier_i,
								equality_exprt(tag_i, get_tag_expr_from_dma(it)),
								update_instructions, it);
					}
				} else {
					add_array_assign_index_instruction(protected_by_barrier_symbol, symbol_expr(new_position_symbol), update_instructions, it, false_exprt());
				}

				method.instructions.splice(it, assertion_instructions.instructions);
				method.instructions.splice(it, update_instructions.instructions);

				it->make_skip();

			}





		}

	}

    all_functions.update();
    all_functions.compute_loop_numbers();



}
