/*
 * dma_analysis.h
 *
 *  Created on: Jul 16, 2009
 *      Author: Alastair F. Donaldson
 */

#ifndef DMA_BUG_ANALYSIS_H_
#define DMA_BUG_ANALYSIS_H_

#include <goto-programs/goto_functions.h>

#include <goto-programs/find_loops.h>

#include <cbmc/bmc.h>

#include <scratch/parseoptions.h>

#include "dma_analyser.h"

class dma_history_tracking_analysert : public dma_analysert
{

public:

	dma_history_tracking_analysert(
			contextt& context,
			scratch_parseoptionst& options) : dma_analysert(context, options)
			{ }

	virtual void havoc_globals(CFGt& method, const namespacet ns);
	virtual void make_instructions_for_invariant(goto_programt& temp_program);
	virtual void instrument_program(goto_functionst& all_functions);

protected:
	symbolt valid_symbol;
	symbolt age_symbol;

};

#endif /* DMA_BUG_ANALYSIS_H_ */
