/*
 * scratch_k_induction_configuration.h
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#ifndef KCBMC_K_INDUCTION_CONFIGURATION_H_
#define KCBMC_K_INDUCTION_CONFIGURATION_H_

#include <goto-programs/goto_program.h>

#include <goto-symex/k_induction_configuration.h>

#include <util/namespace.h>


class kcbmc_k_induction_configurationt: public k_induction_configurationt {
public:
	kcbmc_k_induction_configurationt() { }
	virtual ~kcbmc_k_induction_configurationt() { }
	virtual void havoc_globals(CFGt& method, const namespacet ns);
	virtual void make_instructions_for_invariant(goto_programt& temp_program);

};

#endif /* KCBMC_K_INDUCTION_CONFIGURATION_H_ */
