/*
 * version.h
 *
 *  Created on: Jul 13, 2009
 *      Author: Alastair Donaldson
 */

#ifndef VERSION_H_
#define VERSION_H_

#define KCBMC_VERSION "0.1"

#endif /* VERSION_H_ */
