/*
 * tracker_variables.h
 *
 *  Created on: Sep 21, 2009
 *      Author: alad
 */

#ifndef TRACKER_VARIABLES_H_
#define TRACKER_VARIABLES_H_

#define SCRATCH_NAME_PREFIX "__scratch__::"

#define TAG_MASK "tag_mask"
#define NEW_POSITION "new_position"
#define VALID "valid"
#define IS_GET "is_get"
#define LS "ls"
#define SIZE "size"
#define TAG "tag"
#define PROTECTED_BY_BARRIER "protected_by_barrier"
#define AGE "age"
#define TRACK_THIS_DMA "track_this_dma"
#define TAGS_IN_USE "tags_in_use"
#define OPS_IN_PROGRESS "operations_in_progress"

#define MAX_SIZE_FOR_DMA 16384
#define MAX_TAG 32

#endif /* TRACKER_VARIABLES_H_ */
