/*******************************************************************\

Module: Parsing of options

Author: Alastair Donaldson, alastair.donaldson@comlab.ox.ac.uk

\*******************************************************************/

#include <fstream>
#include <memory>


#include <cbmc/bmc.h>

#include <config.h>
#include <expr_util.h>

#include <ansi-c/ansi_c_language.h>

#include <goto-programs/goto_convert_functions.h>
#include <goto-programs/goto_check.h>
#include <goto-programs/goto_inline.h>
#include <goto-programs/show_claims.h>
#include <goto-programs/set_claims.h>
#include <goto-programs/read_goto_binary.h>
#include <goto-programs/interpreter.h>
#include <goto-programs/string_abstraction.h>
#include <goto-programs/string_instrumentation.h>
#include <goto-programs/loop_numbers.h>
#include <goto-programs/write_goto_binary.h>

#include <k-induction/k_induction.h>

#include <langapi/mode.h>

#include <loopfrog/transform_loops.h>

#include "scratch_parseoptions.h"
#include "dma_history_tracking_analyser.h"
#include "dma_simple_tracking_analyser.h"

#include "version.h"



unsigned int NUM_TRACKED_DMAS;

/*******************************************************************\

Function: scratch_parseoptionst::process_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool scratch_parseoptionst::process_goto_program(
  bmc_baset &bmc,
  goto_functionst &goto_functions)
{
    namespacet ns(context);

    if(cmdline.isset("debug-mode"))
    {
    	std::cout << "Before instrumentation:\n";
    	goto_functions.output(ns, std::cout);
    }

	dma_analyser->instrument_program(goto_functions);

    if(cmdline.isset("debug-mode"))
    {
    	std::cout << "After instrumentation:\n";
		goto_functions.output(ns, std::cout);
	}

    if(cmdline.isset("write-binary"))
    {
    	std::cout << "Writing goto functions to binary file " << cmdline.getval("write-binary") << "\n";


		std::ofstream f(cmdline.getval("write-binary"), std::ios::binary);
		if (!f.is_open())
		{
			error("Error opening file");
			return true;
		}

		if(write_goto_binary(f, context, goto_functions))
		{
			return true;
		}

		f.close();

		exit(0);

    }

    return kcbmc_parseoptionst::process_goto_program(bmc, goto_functions);

}



/*******************************************************************\

Function: scratch_parseoptionst::do_bmc

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int scratch_parseoptionst::do_bmc(
  bmc_baset &bmc,
  const goto_functionst &goto_functions)
{
	if(cmdline.isset("bug-finding"))
	{
		std::cout << "*** In bug finding mode ***\n";
		return cbmc_parseoptionst::do_bmc(bmc, goto_functions);
	}

	if(config.main == "")
	{
		config.main = "main";
	}

	try
	{
		CFGt control_flow_graph(context, find_enclosing_main(const_cast<goto_functionst&>(goto_functions), context));
		k_induction_enginet engine(context, *dma_analyser, *this, goto_functions, bmc.get_message_handler());
		return engine.try_k_induction(bmc, control_flow_graph);
	}

	catch(char *e)
	{
		error(e);
		return 10;
	}

}


void scratch_parseoptionst::get_command_line_options(optionst &options)
{

  kcbmc_parseoptionst::get_command_line_options(options);

  if(cmdline.isset("track-history"))
  {
  	dma_analyser = std::auto_ptr<dma_analysert>(new dma_history_tracking_analysert(context, *this));
  } else {
  	dma_analyser = std::auto_ptr<dma_analysert>(new dma_simple_tracking_analysert(context, *this));
  }

  if(cmdline.isset("tracked-dmas"))
  {
	  NUM_TRACKED_DMAS = atoi(cmdline.getval("tracked-dmas"));

	  if(NUM_TRACKED_DMAS == 0)
	  {
		  std::cout << "Error, cannot track zero DMA operations!\n";
		  exit(1);
	  }

	  std::cout << "Tracking " << NUM_TRACKED_DMAS << " DMA operations.\n";

  } else {

	  if(cmdline.isset("track-history"))
	  {
		  const unsigned int DEFAULT_DMAS_TO_TRACK = 16;

		  std::cout << "Number of DMA operations to track not specified, using " << DEFAULT_DMAS_TO_TRACK << ".\n";

		  NUM_TRACKED_DMAS = DEFAULT_DMAS_TO_TRACK;
	  } else {
		  NUM_TRACKED_DMAS = 0;
	  }

  }

  if(cmdline.isset("free-dmas"))
  {
	  dma_analyser->free_dmas = atoi(cmdline.getval("free-dmas"));
	  std::cout << "Assertion will be added to ensure that at least " << (dma_analyser->free_dmas) << " DMA slots are always free.\n";
  } else {
	  dma_analyser->free_dmas = 0;
  }


  if(cmdline.isset("max-age"))
  {
	  dma_analyser->max_age = atoi(cmdline.getval("max-age"));
	  std::cout << "DMA operations will not be allowed to live for more than " << (dma_analyser->max_age) << " loop iterations.";
  } else {
	  dma_analyser->max_age = 0;
  }

}


void scratch_parseoptionst::help()
{
  std::cout <<
    "\n"
    "* *             SCRATCH " SCRATCH_VERSION " - Copyright (C) 2009                 * *\n"
    "* *           Alastair F. Donaldson, Daniel Kroening             * *\n"
    "* *        University of Oxford Computing Laboratory             * *\n"
    "* *           alastair.donaldson@comlab.ox.ac.uk                 * *\n"
    "\n"
    "Usage:                       Purpose:\n"
    "\n"
    " scratch [-?] [-h] [--help]   show help\n"
    " scratch file.c ...           source file names\n"
    "\n"
    "Additonal options:\n"
    " -I path                      set include path (C/C++)\n"
    " -D macro                     define preprocessor macro (C/C++)\n"
    " --bug-finding                run in bug finding mode\n"
    " --function name              set main function name\n"
    " --k-induction-depth k        set depth for k-induction to k\n"
    " --tracked-dmas nr            track nr dmas\n"
    " --no-unwinding-assertions    do not generate unwinding assertions\n"
    " --unwind nr                  unwind nr times\n"
    " --unwindset nr               unwind given loop nr times\n"
    " --write-binary name          instead of model checking, write goto program to file 'name'\n"
    " --binary name                run scratch on ready-made goto program in file 'name'\n"
    " --free-dmas n                when using k-induction, add assertion that n DMA slots are free at start of loop\n"
    " --show-step-case-fails       display counterexamples for step-case failure.\n"
    " --max-age n                  do not let DMA operations live for longer than n iterations\n"
    " --base-case-bug-finding n    generate pure base case for length n, to be used for bug-finding\n"
    " --no-monolithic              handle multiple loops by recursive application of k-induction\n"
    "\n";
}
