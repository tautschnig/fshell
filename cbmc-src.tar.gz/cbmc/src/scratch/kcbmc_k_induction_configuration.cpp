/*
 * kcbmc_k_induction_configuration.cpp
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#include "kcbmc_k_induction_configuration.h"


void kcbmc_k_induction_configurationt::havoc_globals(CFGt& method, const namespacet ns) {


}

void kcbmc_k_induction_configurationt::make_instructions_for_invariant(goto_programt& temp_program)
{
	temp_program.instructions.clear();
}
