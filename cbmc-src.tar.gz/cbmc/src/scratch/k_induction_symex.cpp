/*
 * k_induction_symex.cpp
 *
 *  Created on: May 13, 2010
 *      Author: ally
 */

#include <iostream>
#include <sstream>

#include <cbmc/symex_bmc.h>

#include <util/expr_util.h>

#include <ansi-c/expr2c.h>

#include "k_induction_symex.h"

std::set<goto_programt::const_targett> current_loop_header_instruction_points;

k_induction_symex_bmct::k_induction_symex_bmct(
    const namespacet &_ns,
    contextt &_new_context,
    symex_targett &_target,
    std::set<goto_programt::const_targett>& loop_header_instruction_points,
    bool loop_free_restriction) : symex_bmct(_ns, _new_context, _target), _loop_header_instruction_points(loop_header_instruction_points), loop_free_restriction(loop_free_restriction)
{
	_symex_states_at_loop_headers.clear();
}


void k_induction_symex_bmct::symex_step(
  const goto_functionst &goto_functions,
  statet &state)
{
	if(loop_free_restriction && (_loop_header_instruction_points.end() != _loop_header_instruction_points.find(state.source.pc)))
	{
		exprt assume_guard;
		bool guard_exists = false; // We need to check whether we actually build up any guard

		for(unsigned int i=0; i < _symex_states_at_loop_headers.size(); i++)
		{

			bool is_first = true;

			exprt clause;

			for(goto_symex_statet::level1t::current_namest::const_iterator
					it=state.top().level1.current_names.begin();
					it!=state.top().level1.current_names.end();
					it++)
			{
				if(it->first == "goto_symex::\\guard")
				{
					// Not really sure where this comes from
					continue;
				}

				goto_symex_statet::level1t::current_namest::const_iterator other_it =
					_symex_states_at_loop_headers[i].top().level1.current_names.find(it->first);
				assert(_symex_states_at_loop_headers[i].top().level1.current_names.end() != other_it);

				irep_idt LHS_name = it->first;
				irep_idt RHS_name = other_it->first;
				irep_idt LHS_level1_name = state.top().level1(LHS_name);
				irep_idt RHS_level1_name = _symex_states_at_loop_headers[i].top().level1(RHS_name);
				int LHS_number = state.level2.current_number(LHS_level1_name);
				int RHS_number = _symex_states_at_loop_headers[i].level2.current_number(RHS_level1_name);

				assert(LHS_name == RHS_name);

				if(LHS_level1_name != RHS_level1_name)
				{
					std::ostringstream stream;
					stream << "Error during restriction to loop-free paths: names " << LHS_level1_name << " and " << RHS_level1_name
							<< " found to be not equal. This is likely a known bug in KCBMC with temporary variables declared in loops.  As a work-around, try hoisting all declarations to the start of your main function.";
					throw stream.str();
				}


				if(LHS_number != RHS_number)
				{
					guard_exists = true; /* We now know that we should definitely add an assume */

					symbolt varname = ns.lookup(LHS_name);

					exprt lhs = symbol_expr(varname);
					dereference(lhs, state, false);
					state.rename(lhs, ns);
					do_simplify(lhs);

					exprt rhs = symbol_expr(varname);
					dereference(rhs, _symex_states_at_loop_headers[i], false);
					_symex_states_at_loop_headers[i].rename(rhs, ns);
					do_simplify(rhs);

					exprt atom = not_exprt(equality_exprt(lhs, rhs));

					std::ostringstream stream;

					if(!is_first)
					{
						clause = or_exprt(clause, atom);
					} else {
						clause = atom;
						is_first = false;
					}

				}

			}

			if(0 == i)
			{
				assume_guard = clause;
			} else {
				assume_guard = and_exprt(assume_guard, clause);
			}

		}

		if(guard_exists)
		{
			state.guard.guard_expr(assume_guard);
			target.assumption(state.guard, assume_guard, state.source);
		}

		_symex_states_at_loop_headers.push_back(state);

		_loop_header_instruction_points.erase(state.source.pc);

	} else {
		symex_bmct::symex_step(goto_functions, state);
	}
}
