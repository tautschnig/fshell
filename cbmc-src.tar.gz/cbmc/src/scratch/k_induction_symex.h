/*
 * k_induction_symex.h
 *
 *  Created on: May 13, 2010
 *      Author: ally
 */

#ifndef K_INDUCTION_SYMEX_H_
#define K_INDUCTION_SYMEX_H_

#include <cbmc/symex_bmc.h>

class k_induction_symex_bmct: public symex_bmct
{
public:
	k_induction_symex_bmct(
    const namespacet &_ns,
    contextt &_new_context,
    symex_targett &_target,
    std::set<goto_programt::const_targett>& loop_header_instruction_points,
    bool loop_free_restriction);

protected:

  virtual void symex_step(
    const goto_functionst &goto_functions,
    statet &state);

  // Could override get_unwinding to assert false

  std::vector<goto_symext::statet> _symex_states_at_loop_headers;

  std::set<goto_programt::const_targett>& _loop_header_instruction_points;

  bool loop_free_restriction;

};

#endif /* K_INDUCTION_SYMEX_H_ */
