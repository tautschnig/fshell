/*******************************************************************\

Module: A termination checking module

Author: CM Wintersteiger

\*******************************************************************/

#include <ansi-c/expr2c.h>

#include <util/std_expr.h>
#include <util/expr_util.h>
#include <util/i2string.h>
#include <util/rename.h>

#include "termination.h"

/*******************************************************************\

Function: termination_instrumentert::termination_instrumentert

  Inputs:

 Outputs:

 Purpose: Constructor

\*******************************************************************/

termination_instrumentert::termination_instrumentert(
  contextt &_ct,
  message_handlert &_mh) :
    messaget(_mh),
    context(_ct),
    ns(_ct)
{
}

/*******************************************************************\

Function: termination_instrumentert::~termination_instrumentert

  Inputs:

 Outputs:

 Purpose: Destructor

\*******************************************************************/

termination_instrumentert::~termination_instrumentert()
{
}

/*******************************************************************\

Function: termination_instrumentert::instrument

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::instrument(goto_programt &program)
{
  // remove all assertions from the program
  Forall_goto_program_instructions(it, program)
    if(it->is_assert())
      it->type=SKIP;

  // find loops
  for(goto_programt::targett
      it=program.instructions.begin();
      it!=program.instructions.end();
      ) // no it++
  {
    // do this now, the program changes!
    goto_programt::targett next=it;
    next++;

    if(it->is_goto())
    {
      if(it->is_backwards_goto())
      {
        assert(it->targets.size()==1);
        loop.begin=it->targets.front();
        loop.end=it;
        instrument_loop(program);
      }
    }

    it=next;
  }
}

/*******************************************************************\

Function: termination_instrumentert::instrument

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::instrument(goto_functionst &goto_functions)
{
  Forall_goto_functions(it, goto_functions)
  {
    if(it->second.body_available)
      instrument(it->second.body);
  }
}

/*******************************************************************\

 Function: termination_instrumentert::get_variant

 Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::get_variant()
{
  variant.clear();

  for(goto_programt::const_targett
      it=loop.begin;
      it!=loop.end;
      it++)
  {
    switch(it->type)
    {
    case FUNCTION_CALL:
      {
        const code_function_callt &call=to_code_function_call(it->code);
        if(call.lhs().is_not_nil())
          variant.insert(call.lhs());
        // we currently don't look at variables changed inside
        // the function
      }
      break;

    case ASSIGN:
    {
      const code_assignt &code=to_code_assign(it->code);

      variant.insert(code.lhs());
      break;
    }

    case OTHER:
      break;

    default: break; /* Nothing */
    }
  }
}

/*******************************************************************\

 Function: termination_instrumentert::add_copied_flag

 Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::add_copied_flag()
{
  unsigned loop_id=loop.end->loop_number;

  // add a flag
  std::string flag_ident=
    "termination::copied_"+i2string(loop_id);

  symbolt flag_symbol;

  flag_symbol.name=flag_ident;
  flag_symbol.base_name=flag_ident.substr(flag_ident.find("::")+2);
  flag_symbol.type=bool_typet();
  flag_symbol.lvalue=true;
  copied_flag=symbol_expr(flag_symbol);
  context.move(flag_symbol);
}

/*******************************************************************\

 Function: termination_instrumentert::instrument_loop

 Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::instrument_loop(goto_programt &program)
{
  get_variant();

  #if 0
  std::cout << "Loop #" << loop_counter << ": ";
  for(std::set<exprt>::const_iterator vit=variant.begin();
      vit!=variant.end();
      vit++)
    std::cout << expr2c(*vit, ns) << ", ";
  std::cout << std::endl;
  #endif

  // create old/new variables
  if(make_old_variables())
  {
    goto_programt::targett a=program.insert(loop.begin);
    a->type=ASSERT;
    a->guard=false_exprt(); // give up on loops over pointers
    a->local_variables=loop.begin->local_variables;
    a->location=loop.begin->location;
    a->location.set("comment", "loop termination");
    a->location.set("property", "termination");
  }
  else
  {
    // add the looping flag
    add_copied_flag();

    // set looping flag to false before entering
    goto_programt::targett set_flag=program.insert(loop.begin);
    set_flag->type=ASSIGN;
    set_flag->code=code_assignt(copied_flag, false_exprt());
    set_flag->local_variables=loop.begin->local_variables;
    set_flag->location=loop.begin->location;

    // add termination assertion
    insert_assertion(program);

    // all forwards-incoming edges of the loop head have to hit set_flag,
    // while all backwards-incoming edges have to hit the assertion!
    program.compute_incoming_edges();

    goto_programt::targett next=set_flag; next++;

    for(std::set<goto_programt::targett>::iterator it=
          next->incoming_edges.begin();
        it!=next->incoming_edges.end();
        it++)
    {
      if((*it)!=loop.end && (*it)->is_goto())
      {
        assert((*it)->targets.size()==1);

        if((*it)->targets.front()==next)
        {
          (*it)->targets.clear();
          (*it)->targets.push_back(set_flag);
        }
      }
    }
  }
}

/*******************************************************************\

 Function: termination_instrumentert::make_old_variables

 Inputs:

 Outputs:

 Purpose: create old/new variables

\*******************************************************************/

bool termination_instrumentert::make_old_variables()
{
//  unsigned loop_id=loop.end->loop_number;

  var_map.clear();

  for(std::set<exprt>::const_iterator
      vit=variant.begin();
      vit!=variant.end();
      vit++)
  {
    if(vit->id()!="symbol")
      return true;

    const irep_idt &ident=vit->get("identifier");

    const symbolt &old_symbol=ns.lookup(ident);
    symbolt new_symbol=old_symbol;
    std::string suffix="$pre"; //+i2string(loop_id);
    new_symbol.name="termination::"+id2string(new_symbol.name)+suffix;
    new_symbol.base_name=id2string(new_symbol.name);
    new_symbol.pretty_name=(new_symbol.pretty_name=="")?"":
                           id2string(new_symbol.name);
    get_new_name(new_symbol, ns);
    var_map[*vit]=symbol_expr(new_symbol);
    context.move(new_symbol);
  }

  return false;
}

/*******************************************************************\

 Function: termination_instrumentert::generate_termination_assertion

 Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt termination_instrumentert::generate_termination_assertion() const
{
  exprt::operandst op;

  // The most basic solution: start with `false'
  op.push_back(false_exprt());

#if 0
  // Let's keep it simple for now: one of the variables must decrease.
  for(std::map<exprt, exprt>::const_iterator
      it=var_map.begin();
      it!=var_map.end();
      it++)
  {
    binary_relation_exprt bin(it->first, "<", it->second);
    op.push_back(bin);
  }
#endif

  return implies_exprt(copied_flag, or_exprt(op));
}

/*******************************************************************\

 Function: termination_instrumentert::insert_assertion

 Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void termination_instrumentert::insert_assertion(goto_programt &program)
{
  for(std::map<exprt,exprt>::const_iterator
      vit=var_map.begin();
      vit!=var_map.end();
      vit++)
  {
    if(vit->second.id()!="symbol")
      throw "Non-symbol variant!";

    const irep_idt &ident=
      to_symbol_expr(vit->second).get_identifier();

    loop.begin->local_variables.insert(ident);
  }

  goto_programt dest;

  // build assertion
  goto_programt::targett a=dest.add_instruction(ASSERT);
  a->guard=generate_termination_assertion();

  // build branch
  exprt guard=and_exprt(
    not_exprt(copied_flag),
    side_effect_expr_nondett(bool_typet()));

  goto_programt::targett goto_statement=
    dest.add_instruction(GOTO);
  goto_statement->guard=guard;

  goto_programt::targett assign_copied=dest.add_instruction(ASSIGN);
  assign_copied->code=code_assignt(copied_flag, true_exprt());

  // copy the variables
  for(std::map<exprt,exprt>::const_iterator
      mit=var_map.begin();
      mit!=var_map.end();
      mit++)
  {
    goto_programt::targett v_assign=dest.add_instruction(ASSIGN);
    v_assign->code=code_assignt(mit->second, mit->first);
  }

  goto_programt::targett skip=dest.add_instruction(SKIP);
  goto_statement->targets.push_back(skip);

  // set locations/local_variables
  Forall_goto_program_instructions(it, dest)
  {
    it->location=loop.begin->location;
    it->local_variables=loop.begin->local_variables;
  }

  // set comments for assertion
  a->location.set("comment", "loop termination");
  a->location.set("property", "termination");

  program.insert_swap(loop.begin, dest);
}
