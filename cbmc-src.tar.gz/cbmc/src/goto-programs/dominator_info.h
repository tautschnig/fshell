/*
 * dominator_info.h
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */

#ifndef DOMINATOR_INFO_H_
#define DOMINATOR_INFO_H_

#include <goto-programs/goto_program.h>


class dominator_infot {

public:
	dominator_infot(const goto_programt& program);

	/* Determines whether instruction a dominates instruction b */
	bool dominates(const unsigned a, const unsigned b);

	friend std::ostream& operator<<(std::ostream& os, const dominator_infot& dom);

private:

	void initialise_with_all_location_numbers(std::set<unsigned> & S, const goto_programt& program);

	std::map<unsigned, std::set<unsigned> > D;

};



#endif /* DOMINATOR_INFO_H_ */
