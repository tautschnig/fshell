/*******************************************************************\

Module: Safety Checker Interface

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "safety_checker.h"

/*******************************************************************\

Function: safety_checkert::safety_checkert

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

safety_checkert::safety_checkert(const namespacet &_ns):
  ns(_ns)
{
}

