/*******************************************************************\

Module: Weakest Preconditions

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <std_expr.h>
#include <std_code.h>
#include <base_type.h>

#include "wp.h"

/*******************************************************************\

Function: replace_sideeffects_rec

  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/

void replace_sideeffects_rec(exprt &dest, unsigned &counter)
{
  Forall_operands(it, dest)
    replace_sideeffects_rec(*it, counter);

  if(dest.id()==ID_sideeffect)
  {
    const side_effect_exprt &side_effect_expr=to_side_effect_expr(dest);
    const irep_idt &statement=side_effect_expr.get_statement();
    
    if(statement==ID_nondet)
    {
      
    }
  }
}

/*******************************************************************\

Function: substitute_rec

  Inputs:

 Outputs:

 Purpose: replace 'what' by 'by' in 'dest',
          considering possible aliasing

\*******************************************************************/

void substitute_rec(
  exprt &dest,
  const exprt &what,
  const exprt &by,
  const namespacet &ns)
{
  if(dest.id()!=ID_address_of)
    Forall_operands(it, dest)
      substitute_rec(*it, what, by, ns);

  // possibly substitute?
  if(dest.id()==ID_member ||
     dest.id()==ID_index ||
     dest.id()==ID_dereference ||
     dest.id()==ID_symbol)
  {
    // could these be possible the same?
  
    if(base_type_eq(what.type(), dest.type(), ns))
    {
      // the trivial case first
      if(dest.id()==ID_symbol && what.id()==ID_symbol)
      {
        if(to_symbol_expr(dest).get_identifier()==
           to_symbol_expr(what).get_identifier())
          dest=by;
          
        return;
      }
      
      // consider possible aliasing between 'what' and 'dest'
      exprt what_address=address_of_exprt(what);
      exprt dest_address=address_of_exprt(dest);

      equality_exprt alias_cond=equality_exprt(what_address, dest_address);
    
      if_exprt if_expr;

      if_expr.cond()=alias_cond;
      if_expr.type()=dest.type();
      if_expr.true_case()=by;
      if_expr.false_case()=dest;

      dest=if_expr;
      return;
    }
  }
}

/*******************************************************************\

Function: rewrite_assignment

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void rewrite_assignment(exprt &lhs, exprt &rhs)
{
  if(lhs.id()==ID_member) // turn s.x:=e into s:=(s with .x=e)
  {
    const member_exprt member_expr=to_member_expr(lhs);
    irep_idt component_name=member_expr.get_component_name();
    exprt new_lhs=member_expr.struct_op();

    with_exprt new_rhs;
    new_rhs.type()=new_lhs.type();
    new_rhs.old()=new_lhs;
    new_rhs.where().id(ID_member_name);
    new_rhs.where().set(ID_component_name, component_name);
    new_rhs.new_value()=rhs;
    
    lhs=new_lhs;
    rhs=new_rhs;
    
    rewrite_assignment(lhs, rhs); // rec. call
  }
  else if(lhs.id()==ID_index) // turn s[i]:=e into s:=(s with [i]=e)
  {
    const index_exprt index_expr=to_index_expr(lhs);
    exprt new_lhs=index_expr.array();

    with_exprt new_rhs;
    new_rhs.type()=new_lhs.type();
    new_rhs.old()=new_lhs;
    new_rhs.where()=index_expr.index();
    new_rhs.new_value()=rhs;
    
    lhs=new_lhs;
    rhs=new_rhs;
    
    rewrite_assignment(lhs, rhs); // rec. call
  }
}

/*******************************************************************\

Function: wp_assign

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt wp_assign(
  const code_assignt &code,
  const exprt &post,
  const namespacet &ns)
{
  exprt pre=post;
  
  exprt lhs=code.lhs(),
        rhs=code.rhs();
        
  rewrite_assignment(lhs, rhs);

  // replace lhs by rhs in pre
  substitute_rec(pre, lhs, rhs, ns);
  
  return pre;
}

/*******************************************************************\

Function: wp_assume

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt wp_assume(
  const code_assumet &code,
  const exprt &post,
  const namespacet &ns)
{
  return implies_exprt(code.assumption(), post);
}

/*******************************************************************\

Function: wp

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt wp(
  const codet &code,
  const exprt &post,
  const namespacet &ns)
{
  const irep_idt &statement=code.get_statement();
  
  if(statement==ID_assign)
    return wp_assign(to_code_assign(code), post, ns);
  else if(statement==ID_assume)
    return wp_assume(to_code_assume(code), post, ns);
  else if(statement==ID_skip)
    return post;
  else if(statement==ID_decl)
    return post;
  else if(statement==ID_assert)
    return post;   
  else if(statement==ID_expression)
    return post;
  else if(statement==ID_printf)
    return post;
  else if(statement==ID_free)
    return post;
  else
    throw "sorry, wp("+id2string(statement)+"...) not implemented";
}
