/*******************************************************************\

Module: Weakest Preconditions

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "wp.h"

/*******************************************************************\

Function: wp_assign

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt wp_assign(
  const code_assignt &code,
  const exprt &post,
  const namespacet &ns)
{
  
}

/*******************************************************************\

Function: wp

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt wp(
  const codet &code,
  const exprt &post,
  const namespacet &ns)
{
  const irep_idt &statement=code.get_statement();
  
  if(statement=="assign")
    return wp_assign(to_code_assign(code), post, ns);
  else
    throw "sorry, wp("+id2string(statement)+"...) not implemented";
}
