/*
 * find_loops.cpp
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */

#include "find_loops.h"

#include <util/std_expr.h>

#include <ansi-c/c_types.h>
#include <ansi-c/expr2c.h>

#include <util/expr_util.h>
#include <util/arith_tools.h>
#include <util/config.h>

/* Control flow graphs */

CFG_nodet::CFG_nodet(goto_programt::instructiont& goto_program_instruction)
{
	this->code = goto_program_instruction.code;
	this->function = goto_program_instruction.function;
	this->location = goto_program_instruction.location;
	this->type = goto_program_instruction.type;

	if(this->type == ASSERT || this->type == ASSUME) {
		this->reasoning_guard = goto_program_instruction.guard;
	} else {
		this->reasoning_guard = true_exprt();
	}

	if(this->type == GOTO) {
		contextt ctx;
		/* We only deal with deterministic gotos */
		assert(goto_program_instruction.targets.size() == 1);
		this->jump_condition = goto_program_instruction.guard;
	} else {
		this->jump_condition = false_exprt();
	}

	this->successor_next = NULL;
	this->successor_jump = NULL;
}


static goto_programt::targett get_following_instruction(goto_programt::targett current) {
	goto_programt::targett result = current;
	result++;
	return result;
}

CFGt::CFGt(contextt& context, goto_programt& program) : context(context) {

	nodes.clear();

	namespacet ns(context);

	/* First, for every instruction in the function,
	 * add a node to the CFG.  Keep a mapping from instructions
	 * to nodes, so that later we can add edges to the CFG
	 */
	std::map<goto_programt::instructiont*, CFG_nodet*> instructions_to_nodes;
	for(goto_programt::targett
			it = program.instructions.begin();
			it != program.instructions.end();
			it++)
	{
		if(it->type == END_FUNCTION)
		{
			CFG_nodet return_node(code_returnt(), nodes.back().function, nodes.back().location, RETURN);
			nodes.push_back(return_node);
			instructions_to_nodes[&(*it)] = &(nodes.back());
		} else {
			CFG_nodet node(*it);
			nodes.push_back(node);
			instructions_to_nodes[&(*it)] = &(nodes.back());
		}

	}

	/* Now go through the CFG nodes and the function instructions
	 * in-step.  Add edges to the CFG nodes according to the
	 * successor relationships between instructions
	 */
	nodest::iterator nodes_it = nodes.begin();
	for(goto_programt::targett
			instructions_it = program.instructions.begin();
			instructions_it != program.instructions.end();
			instructions_it++, nodes_it++)
	{
		if((instructions_it->type == END_FUNCTION) || (instructions_it->type == RETURN))
		{
			/* A RETURN instruction has no CFG successors */
			continue;
		}

		assert(nodes_it != nodes.end());

		/* Get the next instruction */
		goto_programt::targett next_instruction = get_following_instruction(instructions_it);
		assert(next_instruction != program.instructions.end());

		if(!(((nodes_it->type) == GOTO) && ((nodes_it->jump_condition) == true_exprt())))
		{
			/* We populate the "successor_next" field, unless the node is an unconditional jump */
			nodes_it->successor_next = instructions_to_nodes[&(*next_instruction)];
		}

		if((instructions_it->type == GOTO) && (nodes_it->jump_condition != false_exprt())) {
			/* We add a 'jump' successor to the current CFG node provided that the node
			 * is a GOTO, and the guard for the GOTO is not false
			 */
			assert(1 == instructions_it->targets.size());

			goto_programt::targett instruction_to_jump_to = instructions_it->targets.front();

			nodes_it->successor_jump = instructions_to_nodes[&*(instructions_it->targets.front())];
		}

	}

	/* Remove unreachable parts of the CFG, and add predecessor information */
	update();

}

static int index_of_node(const CFGt::nodest& nodes, const CFG_nodet& n)
{
	int j = 0;

	for(CFGt::nodest::const_iterator nodes_it = nodes.begin(); nodes_it != nodes.end(); nodes_it++)
	{
		if(&n == &(*nodes_it)) {
			return j;
		}
		j++;
	}

	assert(false);
	return -1;
}

static void output_single_node(const CFG_nodet& node, const CFGt::nodest& nodes,
			std::ostream& out, const namespacet& ns, bool show_predecessors)
{
	out << index_of_node(nodes, node) << ": " << node.type << "  ";

	if(node.type == ASSERT || node.type == ASSUME)
	{
		out << from_expr(ns, "", node.reasoning_guard) << std::endl;
	} else if(node.type != GOTO && node.type != SKIP && node.type != END_FUNCTION) {
		out << from_expr(ns, "", node.code);
	} else {
		out << std::endl;
	}

	out << "    ";

	if(NULL != node.successor_jump)
	{
		out << "if(" << from_expr(ns, "", node.jump_condition) << ") GOTO " << index_of_node(nodes, *(node.successor_jump)) << " ELSE ";
	}

	if(NULL == node.successor_next) {
		out << "EXIT";
	} else {
		out << "GOTO " << index_of_node(nodes, *(node.successor_next));
	}

	out << std::endl;

	if(show_predecessors)
	{
		out << "Predecessors:";
		for(std::set<CFG_nodet*>::const_iterator
				predecessor_it = node.predecessors.begin();
				predecessor_it != node.predecessors.end();
				predecessor_it++)
		{
			output_single_node(**predecessor_it, nodes, out, ns, false);
		}
		out << std::endl;
	}
}

void CFGt::output_node(
		const CFG_nodet& node,
		std::ostream& out, bool show_predecessors) const
{
	namespacet ns(context);
	output_single_node(node, nodes, out, ns, show_predecessors);
}


static void output_nodes(const CFGt::nodest& nodes,
				const class namespacet &ns,
				const irep_idt &identifier,
				std::ostream& out, bool show_predecessors, CFGt::nodes_const_sett* loop_header_points = NULL)
{
	for(CFGt::nodest::const_iterator it = nodes.begin(); it != nodes.end(); it++)
	{
		if(NULL != loop_header_points)
		{
			if(loop_header_points->end() != loop_header_points->find(&(*it)))
			{
				out << "LOOP HEADER POINT:" << std::endl;
			}
		}

		output_single_node(*it, nodes, out, ns, show_predecessors);
	}

}


void CFGt::output(
		const class namespacet &ns,
		const irep_idt &identifier,
		std::ostream& out, bool show_predecessors, CFGt::nodes_const_sett* loop_header_points) const
{
	output_nodes(nodes, ns, identifier, out, show_predecessors, loop_header_points);
}


void CFGt::to_goto_program(goto_programt& program, CFGt::nodes_const_sett* loop_header_CFG_points, std::set<goto_programt::const_targett>* loop_header_instruction_points)
{
	program.instructions.clear();

	if(NULL != loop_header_instruction_points)
	{
		loop_header_instruction_points->clear();
	}

	std::map<goto_programt::targett, CFG_nodet*> instructions_to_nodes;
	std::map<CFG_nodet*, goto_programt::targett> nodes_to_instructions;

	for(nodest::iterator nodes_it = nodes.begin(); nodes_it != nodes.end(); nodes_it++)
	{

		goto_programt::targett inst = program.add_instruction();

		if(NULL != loop_header_CFG_points)
		{
			assert(NULL != loop_header_instruction_points);
			if(loop_header_CFG_points->end() != loop_header_CFG_points->find(&(*nodes_it)))
			{
				loop_header_instruction_points->insert(inst);
			}
		}

		instructions_to_nodes[inst] = &(*nodes_it);
		nodes_to_instructions[&(*nodes_it)] = inst;

		inst->code = nodes_it->code;
		inst->function = nodes_it->function;
		inst->location = nodes_it->location;
		inst->type = nodes_it->type;

		if(inst->type == ASSERT || inst->type == ASSUME)
		{
			inst->guard = nodes_it->reasoning_guard;
		}

		if(inst->type == GOTO)
		{
			inst->guard = nodes_it->jump_condition;
		}

		// If we find a CFG node that has no successor, it had better be a return node
		if((NULL == nodes_it->successor_next) && (NULL == nodes_it->successor_jump))
		{
			assert(RETURN == nodes_it->type);
		}

	}


	for(nodest::iterator nodes_it = nodes.begin(); nodes_it != nodes.end(); nodes_it++)
	{
		CFG_nodet* node = &(*nodes_it);
		goto_programt::targett inst = nodes_to_instructions[node];

		if(node->type == GOTO) {
			assert(inst->targets.empty());
			inst->targets.push_back( nodes_to_instructions[node->successor_jump] );
		}

		goto_programt::targett next_inst = inst;
		next_inst++;

		if(next_inst == program.instructions.end() && NULL != node->successor_next) {
			goto_programt::targett goto_instruction = program.add_instruction();
			goto_instruction->make_goto();
			goto_instruction->targets.push_back(nodes_to_instructions[node->successor_next]);
		} else if(next_inst != program.instructions.end() && instructions_to_nodes[next_inst] != node->successor_next
				&& NULL != node->successor_next) {
			goto_programt temp_program;
			temp_program.instructions.clear();
			goto_programt::targett goto_instruction = temp_program.add_instruction();
			goto_instruction->make_goto();
			goto_instruction->targets.push_back(nodes_to_instructions[node->successor_next]);
			program.instructions.splice(next_inst, temp_program.instructions);
		}

	}

	program.add_instruction(END_FUNCTION);

	program.update();


}


void CFGt::append_node(CFG_nodet node)
{
	CFG_nodet* prev = NULL;
	if(!nodes.empty())
	{
		prev = &(nodes.back());
	}
	nodes.push_back(node);
	if(prev)
	{
		prev->successor_next = &(nodes.back());
	}
}


static void redirect_pointer(CFG_nodet*& pointer_to_redirect, std::map<const CFG_nodet*, CFG_nodet*>& original_to_cloned)
{
	if(NULL != pointer_to_redirect)
	{
		if(original_to_cloned.find(pointer_to_redirect) != original_to_cloned.end())
		{
			pointer_to_redirect = original_to_cloned[pointer_to_redirect];
		}
	}

}

static void patchup_pointers_in_nodes(CFGt::nodest& nodes, std::map<const CFG_nodet*, CFG_nodet*>& patchup_map)
{
	/* Go through the base-case so far, patching up pointers */
	for(CFGt::nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		redirect_pointer(it->successor_next, patchup_map);
		redirect_pointer(it->successor_jump, patchup_map);
	}
}

void CFGt::patchup_pointers(std::map<const CFG_nodet*, CFG_nodet*>& patchup_map)
{
	patchup_pointers_in_nodes(nodes, patchup_map);
}


CFGt::nodes_const_sett apply_patchup_map_to_set(CFGt::nodes_const_sett* source, std::map<const CFG_nodet*, CFG_nodet*> map)
{
	CFGt::nodes_const_sett result;
	result.clear();
	for(CFGt::nodes_const_sett::const_iterator it = source->begin(); it != source->end(); it++)
	{
		if(NULL != map[*it]) {
			result.insert(map[*it]);
		}
	}
	return result;
}



void CFGt::collect_garbage(CFGt::nodes_const_sett* loop_header_points)
{
	std::set<CFG_nodet*> reachable;
	reachable.insert(&(nodes.front()));

	bool changed = true;

	while(changed)
	{
		changed = false;
		for(nodest::iterator
				it = nodes.begin();
				it != nodes.end();
				it++)
		{
			if(reachable.find(&(*it)) != reachable.end())
			{
				if(NULL != it->successor_next && reachable.find(it->successor_next) == reachable.end())
				{
					changed = true;
					reachable.insert(it->successor_next);
				}

				if(NULL != it->successor_jump && reachable.find(it->successor_jump) == reachable.end())
				{
					changed = true;
					reachable.insert(it->successor_jump);
				}

			}

		}

	}

	nodest new_nodes;
	std::map<const CFG_nodet*, CFG_nodet*> old_to_new;

	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		if(reachable.find(&(*it)) != reachable.end())
		{
			new_nodes.push_back(*it);
			old_to_new[&(*it)] = &(new_nodes.back());
		}
	}

	patchup_pointers_in_nodes(new_nodes, old_to_new);
	if(NULL != loop_header_points)
	{
		*loop_header_points = apply_patchup_map_to_set(loop_header_points, old_to_new);
	}

	nodes.clear();

	std::map<const CFG_nodet*, CFG_nodet*> new_to_final;
	for(nodest::iterator
			it = new_nodes.begin();
			it != new_nodes.end();
			it++)
	{
		nodes.push_back(*it);
		new_to_final[&(*it)] = &nodes.back();
	}

	patchup_pointers_in_nodes(nodes, new_to_final);
	if(NULL != loop_header_points)
	{
		*loop_header_points = apply_patchup_map_to_set(loop_header_points, new_to_final);
	}

}


void CFGt::remove_self_loops()
{
	/* Loop analysis techniques can be made simpler if we are able to assume no
	 * self-looping CFG nodes.  These can be removed by adding intermediate "SKIP"
	 * nodes -- this method does such removal
	 */

	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++) {
		if(it->successor_next == &(*it)) {
			CFG_nodet skip_node(code_skipt(), it->function, it->location, SKIP);
			skip_node.successor_next = &(*it);
			nodes.push_back(skip_node);
			it->successor_next = &nodes.back();
		}
		if(it->successor_jump == &(*it)) {
			CFG_nodet skip_node(code_skipt(), it->function, it->location, SKIP);
			skip_node.successor_next = &(*it);
			nodes.push_back(skip_node);
			it->successor_jump = &nodes.back();
		}
	}
}

static bool all_non_back_edge_predecessors_mapped(
		const CFG_nodet& dest,
		std::map<const CFG_nodet*, CFG_nodet*>& old_to_new,
		const dominator_infot& dominator_info) {
	for(std::set<CFG_nodet*>::const_iterator source = dest.predecessors.begin(); source != dest.predecessors.end(); source++)
	{
		if(dominator_info.is_back_edge(**source, dest))
		{
			continue;
		}

		if(NULL == old_to_new[*source])
		{
			return false;
		}

	}
	return true;
}

void CFGt::compute_ordered_nodes(std::map<const CFG_nodet*, CFG_nodet*>& old_to_new, const CFG_nodet* current_node, CFGt::nodest& new_nodes, const dominator_infot& dominator_info)
{
	assert(old_to_new[current_node] == NULL);

	CFG_nodet new_node = *current_node;
	new_nodes.push_back(new_node);
	old_to_new[current_node] = &new_nodes.back();

	const CFG_nodet* successor_next = current_node->successor_next;
	if(NULL != successor_next) {
		if((NULL == old_to_new[successor_next]) && all_non_back_edge_predecessors_mapped(*successor_next, old_to_new, dominator_info)) {
			compute_ordered_nodes(old_to_new, successor_next, new_nodes, dominator_info);
		}
	}

	const CFG_nodet* successor_jump = current_node->successor_jump;
	if(NULL != successor_jump) {
		if((NULL == old_to_new[successor_jump]) && all_non_back_edge_predecessors_mapped(*successor_jump, old_to_new, dominator_info)) {
			compute_ordered_nodes(old_to_new, successor_jump, new_nodes, dominator_info);
		}
	}
}

void CFGt::order_nodes(CFGt::nodes_const_sett* loop_header_CFG_points)
{
	update(loop_header_CFG_points);
	nodest new_nodes;
	std::map<const CFG_nodet*, CFG_nodet*> old_to_new;
	compute_ordered_nodes(old_to_new, &nodes.front(), new_nodes, dominator_infot(*this));
	patchup_pointers_in_nodes(new_nodes, old_to_new);

	if(NULL != loop_header_CFG_points)
	{
		*loop_header_CFG_points = apply_patchup_map_to_set(loop_header_CFG_points, old_to_new);
	}

	nodes.clear();
	std::map<const CFG_nodet*, CFG_nodet*> new_to_final;
	for(nodest::iterator
			it = new_nodes.begin();
			it != new_nodes.end();
			it++)
	{
		nodes.push_back(*it);
		new_to_final[&(*it)] = &nodes.back();
	}

	patchup_pointers_in_nodes(nodes, new_to_final);

	if(NULL != loop_header_CFG_points)
	{
		*loop_header_CFG_points = apply_patchup_map_to_set(loop_header_CFG_points, new_to_final);
	}

	update(loop_header_CFG_points);

}



void CFGt::calculate_prececessors()
{
	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		it->predecessors.clear();
	}

	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		if(NULL != it->successor_next)
		{
			it->successor_next->predecessors.insert(&(*it));
		}

		if(NULL != it->successor_jump)
		{
			it->successor_jump->predecessors.insert(&(*it));
		}

	}

}


void CFGt::assign_ids()
{
	int next_id = 0;
	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		it->id = next_id;
		next_id++;
	}
}


void CFGt::update(CFGt::nodes_const_sett* loop_header_points) {
	remove_self_loops();
	collect_garbage(loop_header_points);
	calculate_prececessors();
	assign_ids();
}


int index_in_vector(std::vector<const CFG_nodet*> v, CFG_nodet* x)
{
	for(unsigned int i=0; i<v.size(); i++)
	{
		if(v[i] == x)
		{
			return i;
		}
	}
	return -1;
}


void CFGt::transform_to_monolithic_loop()
{
	loop_infot existing_loops(*this);

	if(existing_loops.num_loops() <= 1)
	{
		// No need to do transformation if there is only one, or even zero, loops
		return;
	}

	CFGt new_cfg(context);

	std::vector<const CFG_nodet*> headers;
	for(unsigned int i=0; i < existing_loops.num_loops(); i++) {
		headers.push_back(&(existing_loops.loops[i]->header));
	}

	// Add new declaration for variable
	symbolt loop_to_jump_to;
	loop_to_jump_to.base_name = "loop_to_jump_to";
	loop_to_jump_to.name = "__k_induction::" + loop_to_jump_to.base_name.as_string();
	loop_to_jump_to.type = uint_type();
    context.add(loop_to_jump_to);
    exprt loop_to_jump_to_expr = symbol_expr(loop_to_jump_to);
    CFG_nodet loop_to_jump_to_decl(code_declt(loop_to_jump_to_expr),
    		nodes.front().function,
    		nodes.front().location,
    		DECL);

    new_cfg.nodes.push_back(loop_to_jump_to_decl);

    CFG_nodet* ptr_to_loop_to_jump_to_decl = &(new_cfg.nodes.back());
    CFG_nodet* ptr_to_assign_loop_to_jump_to = NULL;

    // If the first statement in the program is in the loop then we need to
    // handle it specially
    for(unsigned int i=0; i<headers.size(); i++) {
    	if(headers[i] == &nodes.front())
    	{
    		code_assignt assigment_to_loop_to_jump_to(symbol_expr(loop_to_jump_to), from_integer(i, uint_type()));
    		CFG_nodet assign_node(assigment_to_loop_to_jump_to, nodes.front().function, nodes.front().location, ASSIGN);
    		new_cfg.nodes.push_back(assign_node);
    		ptr_to_loop_to_jump_to_decl->successor_next = &(new_cfg.nodes.back());
    		ptr_to_loop_to_jump_to_decl = NULL;
    	    ptr_to_assign_loop_to_jump_to = &new_cfg.nodes.back();
    		break;
    	}
    }

	// Add new header node, checking and jumping to each loop header
	CFG_nodet* ptr_to_new_header = NULL;
	{
		CFG_nodet* prev = NULL;

		for(unsigned int i=0; i<headers.size(); i++)
		{
			CFG_nodet new_header(
					code_ifthenelset(),
					existing_loops.outer_loops[0]->header.function,
					existing_loops.outer_loops[0]->header.location,
					GOTO);
			new_header.jump_condition = equality_exprt( loop_to_jump_to_expr, from_integer(i, uint_type()) ); // if loop_to_jump_to == i
			new_header.successor_jump = (CFG_nodet*)(headers[i]);
			new_cfg.nodes.push_back(new_header);

			if(i==0) {
				assert(NULL == prev);
				assert(NULL == ptr_to_new_header);
				ptr_to_new_header = &(new_cfg.nodes.back());
			} else {
				assert(NULL != prev);
				assert(NULL != ptr_to_new_header);
				prev->successor_next = &(new_cfg.nodes.back());
			}

			prev = &(new_cfg.nodes.back());

		}

		CFG_nodet assert_false(code_assertt(), existing_loops.outer_loops[0]->header.function,
					existing_loops.outer_loops[0]->header.location,
					ASSERT);
		assert_false.reasoning_guard = false_exprt();
		new_cfg.nodes.push_back(assert_false);
		assert(NULL != prev);
		prev->successor_next = &(new_cfg.nodes.back());

		CFG_nodet return_node(code_returnt(), existing_loops.outer_loops[0]->header.function,
					existing_loops.outer_loops[0]->header.location,
					RETURN);
		new_cfg.append_node(return_node);


	}

	assert(NULL != ptr_to_new_header);
	if(NULL != ptr_to_assign_loop_to_jump_to) {
		ptr_to_assign_loop_to_jump_to->successor_next = ptr_to_new_header;
	}

	// Add all nodes in the program, keeping patch-up map
	std::map<const CFG_nodet*, CFG_nodet*> patchup_map;

	for(nodest::iterator
			it = nodes.begin();
			it != nodes.end();
			it++)
	{
		new_cfg.nodes.push_back(*it);

		if((it == nodes.begin()) && (NULL != ptr_to_loop_to_jump_to_decl))
		{
			ptr_to_loop_to_jump_to_decl->successor_next = &(new_cfg.nodes.back());
		}

		patchup_map[&(*it)] = &(new_cfg.nodes.back());

		CFG_nodet* pointer_to_new_node = &(new_cfg.nodes.back());

		// next may go to a header, so instead make it simulate this and jump to new header
		if(NULL != pointer_to_new_node->successor_next)
		{
			int header_index = index_in_vector(headers, pointer_to_new_node->successor_next);
			if(-1 != header_index)
			{
				CFG_nodet assignment(code_assignt(loop_to_jump_to_expr, from_integer(header_index, uint_type())), pointer_to_new_node->successor_next->function,
						pointer_to_new_node->successor_next->location, ASSIGN);
				assignment.successor_next = ptr_to_new_header;
				new_cfg.nodes.push_back(assignment);
				pointer_to_new_node->successor_next = &(new_cfg.nodes.back());
			}
		}

		// jump may go to a header, so instead make it simulate this and jump to new header
		if(NULL != pointer_to_new_node->successor_jump)
		{
			int header_index = index_in_vector(headers, pointer_to_new_node->successor_jump);
			if(-1 != header_index)
			{
				CFG_nodet assignment(code_assignt(loop_to_jump_to_expr, from_integer(header_index, uint_type())), pointer_to_new_node->successor_jump->function,
						pointer_to_new_node->successor_jump->location, ASSIGN);
				assignment.successor_next = ptr_to_new_header;
				new_cfg.nodes.push_back(assignment);
				pointer_to_new_node->successor_jump = &(new_cfg.nodes.back());
			}
		}




	}


	new_cfg.patchup_pointers(patchup_map);

	nodes.clear();

	std::map<const CFG_nodet*, CFG_nodet*> new_to_final;
	for(nodest::iterator
			it = new_cfg.nodes.begin();
			it != new_cfg.nodes.end();
			it++)
	{
		nodes.push_back(*it);
		new_to_final[&(*it)] = &(nodes.back());
	}

	patchup_pointers(new_to_final);

	update();

	// Sanity check
	loop_infot monolithic_loops(*this);
	assert(1 == monolithic_loops.num_loops());

}





/* Depth-first spanning trees */

void DFST_numberingt::search(const CFG_nodet* n, CFGt::nodes_const_sett& visited)
{
	static int c = -1;

	if(n == &the_cfg.nodes.front()) {
		/* On visiting the first node, set c to be the number of CFG nodes */
		assert(-1 == c);
		c = the_cfg.nodes.size();
	}

	/* c must have been initialised to a sensible value */
	assert((-1 != c) && (c <= (int)the_cfg.nodes.size()));

	/* The node should not yet have been visited */
	assert(visited.end() == visited.find(n));

	visited.insert(n);

	if((NULL != n->successor_next) && (visited.end() == visited.find(n->successor_next)))
	{
		search(n->successor_next, visited);
	}

	if((NULL != n->successor_jump) && (visited.end() == visited.find(n->successor_jump)))
	{
		search(n->successor_jump, visited);
	}

	dfn[n] = c;
	c--;

	/* c should remain non-negative, and should be zero only on leaving
	 * the root node
	 */
	if(n == &the_cfg.nodes.front()) {
		assert(0 == c);
		c = -1; // Reset c for the next top-level call to 'search'
	} else {
		assert(c > 0);
	}

}

DFST_numberingt::DFST_numberingt(const CFGt& cfg) : the_cfg(cfg)
{
	CFGt::nodes_const_sett visited;
	search(&the_cfg.nodes.front(), visited);
}

std::ostream& operator<<(std::ostream& os, const DFST_numberingt& dfst)
{
	for(CFGt::nodest::const_iterator it = dfst.the_cfg.nodes.begin(); it != dfst.the_cfg.nodes.end(); it++)
	{
		dfst.the_cfg.output_node(*it, os, false);
		os << "  DFST number: " << ((DFST_numberingt&)dfst).dfn[&(*it)]<< "\n";
	}

	return os;

}

bool DFST_numberingt::is_retreating(const CFG_nodet& d, const CFG_nodet& n) const
{
	std::map<const CFG_nodet*, int>::const_iterator it_n = dfn.find(&n);
	assert(it_n != dfn.end());

	std::map<const CFG_nodet*, int>::const_iterator it_d = dfn.find(&d);
	assert(it_d != dfn.end());

	return it_n->second <= it_d->second;
}





/* Dominators */

void dominator_infot::initialise_with_all_cfg_nodes(CFGt::nodes_const_sett & S, const CFGt& cfg)
{
	S = CFGt::nodes_const_sett();

	for(CFGt::nodest::const_iterator
			it = cfg.nodes.begin();
			it != cfg.nodes.end();
			it++)
	{
		S.insert(&(*it));
	}

}



/* This is the algorithm in Fig. 10.52 of the Dragon book.
 *
 */
dominator_infot::dominator_infot(const CFGt& cfg) : the_cfg(cfg)
{

	const CFG_nodet& n_0 = cfg.nodes.front();

	CFGt::nodes_const_sett N;
	initialise_with_all_cfg_nodes(N, cfg);

	dominators_of[&n_0] = CFGt::nodes_const_sett();
	dominators_of[&n_0].insert(&n_0);

	for(CFGt::nodest::const_iterator
	  it = cfg.nodes.begin();
	  it != cfg.nodes.end();
	  it++)
	{

		if(&n_0 != &(*it))
		{
			dominators_of[&(*it)] = N;
		}
	}

	bool changed = true;
	while(changed)
	{
		changed = false;

		for(CFGt::nodest::const_iterator
		  it = cfg.nodes.begin();
		  it != cfg.nodes.end();
		  it++)
		{
			if(&n_0 != &(*it))
			{

				CFGt::nodes_const_sett intersection_of_incoming_dominators = N;

				for(std::set<CFG_nodet*>::const_iterator
					it2 = it->predecessors.begin();
					it2 != it->predecessors.end();
					it2++)
				{

			    	CFGt::nodes_const_sett intersection;

		    	    set_intersection(
		    	    		intersection_of_incoming_dominators.begin(),
			    	    	intersection_of_incoming_dominators.end(),
			    	    	dominators_of[*it2].begin(),
			    	    	dominators_of[*it2].end(),
			    	    	std::insert_iterator<CFGt::nodes_const_sett >(intersection, intersection.begin()));

		    	    intersection_of_incoming_dominators = intersection;

				}

				intersection_of_incoming_dominators.insert(&(*it));

				if(dominators_of[&(*it)] != intersection_of_incoming_dominators) {
					dominators_of[&(*it)] = intersection_of_incoming_dominators;
					changed = true;
				}

			}

		}
	}

}


std::ostream& operator<<(std::ostream& os, const dominator_infot& dom)
{
	for(std::map<const CFG_nodet*, CFGt::nodes_const_sett >::const_iterator i = dom.dominators_of.begin(); i != dom.dominators_of.end(); i++)
	{
		dom.the_cfg.output_node(*(i->first), os);

		os << " dominated by {\n  ";
		for(CFGt::nodes_const_sett::const_iterator j = i->second.begin(); j != i->second.end(); j++)
		{
			if(j != i->second.begin()) {
				os << ", ";
			}

			dom.the_cfg.output_node(**j, os);

		}

		os << " }\n\n";

	}


	return os;
}

bool dominator_infot::is_back_edge(const CFG_nodet& source, const CFG_nodet& dest) const
{
	// Return true if and only if dest dominates source

	dominator_mapt::const_iterator dominators_of_source = dominators_of.find(&source);
	assert(dominators_of_source != dominators_of.end());

	return dominators_of_source->second.find(&dest) != dominators_of_source->second.end();
}

bool dominator_infot::cfg_is_reducible(const DFST_numberingt& dfst)
{
	for(CFGt::nodest::const_iterator cfg_it = the_cfg.nodes.begin(); cfg_it != the_cfg.nodes.end(); cfg_it++)
	{
		const CFG_nodet& d = *cfg_it;

	    for(std::set<CFG_nodet*>::const_iterator
		    predecessor_it = d.predecessors.begin();
    		predecessor_it != d.predecessors.end();
    		predecessor_it++)
	    {
	    	const CFG_nodet& n = **predecessor_it;

			/* We have an edge of the form n -> d
			 * Need to check whether the edge is retreating
			 */

	    	if(dfst.is_retreating(n, d))
	    	{
	    		if(!is_back_edge(n, d))
	    		{
	    			return false;
	    		}
	    	}
		}

	}
	return true;
}








/* LOOPS */

static void insert_on_stack(const CFG_nodet& m, CFGt::nodes_const_sett & loop,
		std::vector<const CFG_nodet*> & stack)
{

	if(loop.end() != loop.find(&m))
	{
		return;
	}

	loop.insert(&m);

	stack.push_back(&m);

}

/* This is the algorithm of Fig. 10.15 of the Dragon book */
void loop_infot::compute_loop_nodes_for_back_edge(
		const CFG_nodet& n,
		const CFG_nodet& d,
		CFGt::nodes_const_sett & loop)
{

	std::vector<const CFG_nodet*> stack;

	loop.insert(&d);

	insert_on_stack(n, loop, stack);

	while(!stack.empty())
	{

		const CFG_nodet& m = *(stack.back());
		stack.pop_back();

		for(std::set<CFG_nodet*>::iterator
			it = m.predecessors.begin();
			it != m.predecessors.end();
			it++)
		{
			insert_on_stack(**it, loop, stack);
		}
	}

}


loop_infot::loop_infot(const CFGt& cfg)
{
	dominator_infot dominator_info(cfg);

	/* Our loop analysis infrastructure is only designed for reducible control-flow graphs,
	 * so check that we have one
	 */
	{
		DFST_numberingt dfst_numbering(cfg);
		assert(dominator_info.cfg_is_reducible(dfst_numbering));
	}

	for(CFGt::nodest::const_iterator cfg_it = cfg.nodes.begin(); cfg_it != cfg.nodes.end(); cfg_it++)
	{
		const CFG_nodet& d = *cfg_it;

		loopt* loop_headed_at_current_node = NULL;

	    for(std::set<CFG_nodet*>::const_iterator
		    predecessor_it = d.predecessors.begin();
    		predecessor_it != d.predecessors.end();
    		predecessor_it++)
	    {
	    	/* Getting into notation of Dragon book: */

	    	const CFG_nodet& n = **predecessor_it;

			/* We have an edge of the form n -> d
			 *
			 * Need to check whether d dominates n
			 */

	    	if(dominator_info.is_back_edge(n, d))
	    	{
	    		CFGt::nodes_const_sett loop_nodes = CFGt::nodes_const_sett();

	    		compute_loop_nodes_for_back_edge(n, d, loop_nodes);

	    		if(NULL == loop_headed_at_current_node)
	    		{
	    			// This is the first loop detected for this header
	    			loop_headed_at_current_node = new loopt(d, loop_nodes, cfg);
	    			loops.push_back(loop_headed_at_current_node);

	    		} else {
	    			// There are already loops at this header: merge the new loop with these loops
	    			loop_headed_at_current_node->add_nodes(loop_nodes);
	    		}


		    }

		}

	}

	organize_loops(cfg);

}


loop_infot::loopt* loop_infot::get_closest_containing_loop(const CFG_nodet* n) const
{
	std::map<const CFG_nodet*, loopt*>::const_iterator it = closest_containing_loop.find(n);

	if(it == closest_containing_loop.end())
	{
		return NULL;
	}

	return it->second;

}


void loop_infot::organize_loops(const CFGt& cfg)
{
	if(loops.empty())
	{
		return;
	}

	/* First, give each loop a parent if it has one */
	for(std::vector<loop_infot::loopt *>::iterator
			it1 = loops.begin();
			it1 != loops.end() - 1;
			it1++)
	{

		for(std::vector<loop_infot::loopt *>::iterator
			it2 = it1+1;
			it2 != loops.end();
			it2++)
		{
			loop_infot::loopt & loop1 = **it1;
			loop_infot::loopt & loop2 = **it2;

			if( loop1.contains(loop2) )
			{
				loop2.candidate_parent(loop1);
			} else if( loop2.contains(loop1) ) {
				loop1.candidate_parent(loop2);
			} else {
				assert ( loop_infot::loopt::disjoint (loop1, loop2 ) );
			}

		}

	}


	/* Next, assign immediate children to every loop, and work out the outer and inner loops */
	for(std::vector<loop_infot::loopt *>::iterator
			it1 = loops.begin();
			it1 != loops.end(); // Note that we don't use end() - 1 here as we need to consider all loops when working out inner and outer loops
			it1++)
	{
		loop_infot::loopt & loop1 = **it1;

		if(NULL == loop1.parent)
		{
			outer_loops.push_back(&loop1);
		}

		for(std::vector<loop_infot::loopt *>::iterator
			it2 = it1+1;
			it2 != loops.end();
			it2++)
		{
			loop_infot::loopt & loop2 = **it2;

			if( loop2.parent == &loop1 )
			{
				loop1.children.push_back(&loop2);
			}
		}

		if(loop1.children.empty())
		{
			inner_loops.push_back(&loop1);
		}

	}


	/* Finally, compute mapping which assigns each instruction to its nearest loop */
	for(CFGt::nodest::const_iterator it = cfg.nodes.begin(); it != cfg.nodes.end(); it++)
	{
		closest_containing_loop[&(*it)] = NULL;

		for(std::vector<loop_infot::loopt *>::iterator
				inner_loop_it = inner_loops.begin();
				inner_loop_it != inner_loops.end();
				inner_loop_it++)
		{
			loop_infot::loopt * current_loop = *inner_loop_it;

			bool found = false;

			while(NULL != current_loop)
			{
				if(current_loop->contains(*it))
				{
					closest_containing_loop[&(*it)] = current_loop;
					found = true;
					break;
				}

				current_loop = current_loop->parent;
			}


			if(found)
			{
				break;
			}

		}

	}

}


void loop_infot::loopt::candidate_parent( loopt& other )
{
	/* Set 'other' as parent if we don't have one.  Otherwise,
	 * we'd like 'other' as parent if our parent contains other,
	 * i.e. we have this <= other <= parent.
	 */
	if((NULL == parent) || (parent->contains(other)))
	{
		parent = &other;
	}
}


bool loop_infot::loopt::contains( const loopt& other) const
{
	for(CFGt::nodes_const_sett::iterator
			it = other.nodes.begin();
			it != other.nodes.end();
			it++)
	{
		bool found = false;
		for(CFGt::nodes_const_sett::iterator
				it2 = this->nodes.begin();
				it2 != this->nodes.end();
				it2++)
		{
			if( (*it) == (*it2) )
			{
				found = true;
				break;
			}
		}

		if(!found)
		{
			return false;
		}

	}

	return true;
}

bool loop_infot::loopt::contains( const CFG_nodet& inst) const
{
	return nodes.end() != nodes.find(&inst);
}

bool loop_infot::loopt::disjoint ( loopt& loop1, loopt& loop2 )
{
	for(CFGt::nodes_const_sett::iterator
			it = loop1.nodes.begin();
			it != loop1.nodes.end();
			it++)
	{
		for(CFGt::nodes_const_sett::iterator
				it2 = loop2.nodes.begin();
				it2 != loop2.nodes.end();
				it2++)
		{
			if( (*it) == (*it2) )
			{
				return false;
			}
		}

	}

	return true;

}



void loop_infot::loopt::add_nodes(CFGt::nodes_const_sett nodes)
{
	for(CFGt::nodes_const_sett::iterator it = nodes.begin(); it != nodes.end(); it++)
	{
		this->nodes.insert(*it);
	}
}

loop_infot::loopt::loopt(const CFG_nodet& header, CFGt::nodes_const_sett nodes, const CFGt& cfg) : header(header), cfg(cfg)
{
	this->add_nodes(nodes);
	this->parent = NULL;

}


std::ostream& operator<<(std::ostream& os, const loop_infot& loop_info)
{

	for(std::vector<loop_infot::loopt *>::const_iterator
			outer_loop_it = loop_info.outer_loops.begin();
			outer_loop_it != loop_info.outer_loops.end();
			outer_loop_it++)
	{
		os << (**outer_loop_it);
	}

	return os;

}



static void blanks(std::ostream& os, const int num)
{
	for(int i=0; i<num; ++i)
	{
		os << " ";
	}

}


std::ostream& operator<<(std::ostream& os, const loop_infot::loopt& loop)
{
	static unsigned indent = 0;
	const int indent_size = 4;

	blanks(os, indent);
	os << "[" << std::endl;
	blanks(os, indent);
	os << "    header:\n";
	loop.cfg.output_node(loop.header, os);
	os << std::endl;
	blanks(os, indent);
	os << "    nodes:\n";

	for(CFGt::nodes_const_sett::const_iterator
			it = loop.nodes.begin();
			it != loop.nodes.end();
			it++)
	{
		os << " ";
		loop.cfg.output_node(**it, os);
	}
	os << std::endl;

	if(!loop.children.empty())
	{
		blanks(os, indent);
		os << "    children:" << std::endl;

		indent += indent_size;

		for(std::vector<loop_infot::loopt *>::const_iterator
				it = loop.children.begin();
				it != loop.children.end();
				it++)
		{
			os << (**it) << std::endl;
		}

		indent -= indent_size;

	}

	blanks(os, indent);
	os << "]" << std::endl;

	return os;

}


unsigned int loop_infot::num_loops() const
{
	return this->loops.size();
}


bool loop_infot::is_inner_loop(const loopt* loop) const
{
	if(NULL == loop)
	{
		return false;
	}

	for(std::vector<loop_infot::loopt*>::const_iterator
			it = inner_loops.begin();
			it != inner_loops.end();
			it++)
	{
		if((*it) == loop)
		{
			return true;
		}

	}

	return false;

}

CFG_nodet& CFGt::get_initial()
{
  if(nodes.size() == 0)
    throw "get_initial called on empty CFG";
  return nodes.front();
}

const CFG_nodet& CFGt::get_initial() const
{
  if(nodes.size() == 0)
    throw "get_initial called on empty CFG";
  return nodes.front();
}


goto_programt& find_main(goto_functionst& goto_functions, contextt& context)
{
	namespacet ns(context);

    for(goto_functionst::function_mapt::iterator
    		f_it = goto_functions.function_map.begin();
			;
			f_it++)
    {
    	if(f_it == goto_functions.function_map.end())
    	{
    	    throw "main symbol not found; please set an entry point";
    	}

    	/* It seems that the scheme for naming functions
    	 * internally has recently changed within CPROVER,
    	 * this this code may no longer be the most suitable
    	 */
		if(ns.lookup(f_it->first).base_name == config.main)
		{
			assert(f_it->second.body_available);
			return f_it->second.body;
		}
    }
    assert(false);

}
