/*
 * find_loops.cpp
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */

#include "find_loops.h"

static void insert_on_stack(const goto_programt::const_targett m, std::set<unsigned> & loop,
		std::vector<goto_programt::const_targett> & stack)
{

	if(loop.end() != loop.find(m->location_number))
	{
		return;
	}

	loop.insert(m->location_number);

	stack.push_back(m);

}

/* This is the algorithm of Fig. 10.15 of the Dragon book */
void loop_infot::compute_loop_nodes_for_back_edge(const goto_programt::const_targett n,
		const goto_programt::const_targett d,
		std::set<unsigned> & loop)
{

	std::vector<goto_programt::const_targett> stack;

	loop.insert(d->location_number);

	insert_on_stack(n, loop, stack);

	while(!stack.empty())
	{

		const goto_programt::const_targett m = stack.back();
		stack.pop_back();

		for(std::set<goto_programt::targett>::iterator
			it = m->incoming_edges.begin();
			it != m->incoming_edges.end();
			it++)
		{
			insert_on_stack(*it, loop, stack);
		}
	}

}


void loop_infot::find_loops(dominator_infot& dominator_info, const goto_programt& goto_program)
{

	forall_goto_program_instructions(d, goto_program)
	{
		loopt* loop_headed_at_current_node = NULL;

		if(d->is_target())
		{
		    for(std::set<goto_programt::targett>::iterator
		    	target_it = d->incoming_edges.begin();
				target_it != d->incoming_edges.end();
		        target_it++)
		    {

		    	/* Getting into notation of Dragon book: */

		    	// This looks a bit dodgy, & and * don't seem to cancel with iterators
		    	const goto_programt::targett n = *target_it;

		    	/* We have an edge of the form n -> d
		    	 *
		    	 * Need to check whether d dominates n
		    	 */

		    	if(dominator_info.dominates( d->location_number, n->location_number ))
		    	{

		    		std::set<unsigned> loop_nodes = std::set<unsigned>();

		    		compute_loop_nodes_for_back_edge(n, d, loop_nodes);

		    		if(NULL == loop_headed_at_current_node)
		    		{
		    			// This is the first loop detected for this header
		    			loop_headed_at_current_node = new loopt(d->location_number, loop_nodes);
		    			loops.push_back(loop_headed_at_current_node);

		    		} else {
		    			// There are already loops at this header: merge the new loop with these loops
		    			loop_headed_at_current_node->add_nodes(loop_nodes);
		    		}

		    	}

		    }

		}

	}

}

void loop_infot::organize_loops(const goto_programt& goto_program)
{
	if(loops.empty())
	{
		return;
	}

	/* First, give each loop a parent if it has one */
	for(std::vector<loop_infot::loopt *>::iterator
			it1 = loops.begin();
			it1 != loops.end() - 1;
			it1++)
	{

		for(std::vector<loop_infot::loopt *>::iterator
			it2 = it1+1;
			it2 != loops.end();
			it2++)
		{
			loop_infot::loopt & loop1 = **it1;
			loop_infot::loopt & loop2 = **it2;

			if( loop1.contains(loop2) )
			{
				loop2.candidate_parent(loop1);
			} else if( loop2.contains(loop1) ) {
				loop1.candidate_parent(loop2);
			} else {
				assert ( loop_infot::loopt::disjoint (loop1, loop2 ) );
			}

		}

	}


	/* Next, assign immediate children to every loop, and work out the outer and inner loops */
	for(std::vector<loop_infot::loopt *>::iterator
			it1 = loops.begin();
			it1 != loops.end(); // Note that we don't use end() - 1 here as we need to consider all loops when working out inner and outer loops
			it1++)
	{
		loop_infot::loopt & loop1 = **it1;

		if(NULL == loop1.parent)
		{
			outer_loops.push_back(&loop1);
		}

		for(std::vector<loop_infot::loopt *>::iterator
			it2 = it1+1;
			it2 != loops.end();
			it2++)
		{
			loop_infot::loopt & loop2 = **it2;

			if( loop2.parent == &loop1 )
			{
				loop1.children.push_back(&loop2);
			}
		}

		if(loop1.children.empty())
		{
			inner_loops.push_back(&loop1);
		}

	}


	/* Finally, compute mapping which assigns each instruction to its nearest loop */
	forall_goto_program_instructions(it, goto_program)
	{

		containing_loop[it->location_number] = NULL;

		for(std::vector<loop_infot::loopt *>::iterator
				inner_loop_it = inner_loops.begin();
				inner_loop_it != inner_loops.end();
				inner_loop_it++)
		{
			loop_infot::loopt * current_loop = *inner_loop_it;

			bool found = false;

			while(NULL != current_loop)
			{
				if(current_loop->contains(it->location_number))
				{
					containing_loop[it->location_number] = current_loop;
					found = true;
					break;
				}

				current_loop = current_loop->parent;
			}


			if(found)
			{
				break;
			}

		}

	}

}


void loop_infot::loopt::candidate_parent( loopt& other )
{
	/* Set 'other' as parent if we don't have one.  Otherwise,
	 * we'd like 'other' as parent if our parent contains other,
	 * i.e. we have this <= other <= parent.
	 */
	if((NULL == parent) || (parent->contains(other)))
	{
		parent = &other;
	}
}


bool loop_infot::loopt::contains( const loopt& other) const
{
	for(std::set<unsigned>::iterator
			it = other.nodes.begin();
			it != other.nodes.end();
			it++)
	{
		bool found = false;
		for(std::set<unsigned>::iterator
				it2 = this->nodes.begin();
				it2 != this->nodes.end();
				it2++)
		{
			if( (*it) == (*it2) )
			{
				found = true;
				break;
			}
		}

		if(!found)
		{
			return false;
		}

	}

	return true;
}

bool loop_infot::loopt::contains( const unsigned inst) const
{
	return nodes.end() != nodes.find(inst);
}

bool loop_infot::loopt::disjoint ( loopt& loop1, loopt& loop2 )
{
	for(std::set<unsigned>::iterator
			it = loop1.nodes.begin();
			it != loop1.nodes.end();
			it++)
	{
		for(std::set<unsigned>::iterator
				it2 = loop2.nodes.begin();
				it2 != loop2.nodes.end();
				it2++)
		{
			if( (*it) == (*it2) )
			{
				return false;
			}
		}

	}

	return true;

}



void loop_infot::loopt::add_nodes(std::set<unsigned> nodes)
{
	for(std::set<unsigned>::iterator it = nodes.begin(); it != nodes.end(); it++)
	{
		this->nodes.insert(*it);
	}
}

loop_infot::loopt::loopt(unsigned header, std::set<unsigned> nodes) : header(header)
{
	static unsigned next_id = 0;
	this->id = next_id++;
	this->add_nodes(nodes);
	this->parent = NULL;

}


std::ostream& operator<<(std::ostream& os, const loop_infot& loop_info)
{

	for(std::vector<loop_infot::loopt *>::const_iterator
			outer_loop_it = loop_info.outer_loops.begin();
			outer_loop_it != loop_info.outer_loops.end();
			outer_loop_it++)
	{
		os << (**outer_loop_it);
	}

	return os;

}

std::ostream& loop_infot::show_closest_loop_info(std::ostream& os, const goto_programt& goto_program)
{
	os << "Closest loop info:\n";

	forall_goto_program_instructions(it, goto_program)
	{
		os << "  " << it->location_number << "(" << it->location.get_line() << ")" << " - ";

		if(NULL == containing_loop[it->location_number])
		{
			os << "no loop";
		} else {
			os << containing_loop[it->location_number]->get_id();
		}

		os << std::endl;
	}

	return os;
}


static void blanks(std::ostream& os, const int num)
{
	for(int i=0; i<num; ++i)
	{
		os << " ";
	}

}


std::ostream& operator<<(std::ostream& os, const loop_infot::loopt& loop)
{
	static unsigned indent = 0;
	const int indent_size = 4;

	blanks(os, indent);
	os << "[" << std::endl;
	blanks(os, indent);
	os << "    loop id: " << loop.id << std::endl;
	blanks(os, indent);
	os << "    header: " << loop.header << std::endl;
	blanks(os, indent);
	os << "    nodes:";

	for(std::set<unsigned>::const_iterator
			it = loop.nodes.begin();
			it != loop.nodes.end();
			it++)
	{
		os << " " << (*it);
	}
	os << std::endl;

	if(!loop.children.empty())
	{
		blanks(os, indent);
		os << "    children:" << std::endl;

		indent += indent_size;

		for(std::vector<loop_infot::loopt *>::const_iterator
				it = loop.children.begin();
				it != loop.children.end();
				it++)
		{
			os << (**it) << std::endl;
		}

		indent -= indent_size;

	}

	blanks(os, indent);
	os << "]" << std::endl;

	return os;

}


int loop_infot::num_loops()
{
	return this->loops.size();
}

unsigned loop_infot::loopt::get_id() const
{
	return id;
}


bool loop_infot::is_inner_loop(const loopt* loop) const
{
	if(NULL == loop)
	{
		return false;
	}

	for(std::vector<loop_infot::loopt*>::const_iterator
			it = inner_loops.begin();
			it != inner_loops.end();
			it++)
	{
		if((*it) == loop)
		{
			return true;
		}

	}

	return false;

}


goto_programt::targett get_iterator_for_loop_header(const loop_infot::loopt& loop, goto_programt& body)
{
	// First, get an iterator pointing to the loop header from the program
	goto_programt::targett result = body.instructions.begin();
	while((result->location_number) != loop.header)
	{
		/* We should never reach the end -- this would indicate that we've used a 'loop' which is not part of 'body' */
		assert(result != body.instructions.end());
		result++;
	}
	return result;
}


goto_programt::targett get_first_node_after_header(goto_programt::targett header, const loop_infot::loopt& loop, goto_programt& body)
{
	goto_programt::targett result;
	goto_programt::targetst successors;
	body.get_successors(header, successors);

	bool first_successor_inside_loop = loop.contains(successors.front()->location_number);
	goto_programt::targetst::iterator next_it = successors.begin();

	if(1 == successors.size()) {
		assert(first_successor_inside_loop);
		return *next_it;
	}

	assert(successors.size() == 2);

	if(first_successor_inside_loop)
	{
		return *next_it;
	}

	next_it++;

	assert(!first_successor_inside_loop);

	return *next_it;

}
