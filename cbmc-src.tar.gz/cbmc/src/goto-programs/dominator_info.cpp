/*
 * dominator_info.cpp
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */


#include "dominator_info.h"

#include <set>
#include <algorithm>
#include <iterator>

void dominator_infot::initialise_with_all_location_numbers(std::set<unsigned> & S, const goto_programt& program)
{
	S = std::set<unsigned>();

	for(goto_programt::instructionst::const_iterator
	  it=program.instructions.begin();
	  it!=program.instructions.end();
	  it++)
	{
		S.insert(it->location_number);
	}

}



/* This is the algorithm in Fig. 10.52 of the Dragon book.
 *
 */
dominator_infot::dominator_infot(const goto_programt& program)
{
	/* AD: It looks like location_number spans multiple procedures, i.e. not reset to 0 each time.
	 * It could be that target_number would be more suitable, which shouldn't be a major change.
	 */

	const unsigned n_0 = program.instructions.front().location_number;

	std::set<unsigned> N;
	initialise_with_all_location_numbers(N, program);

	D[n_0] = std::set<unsigned>();
	D[n_0].insert(n_0);

	for(goto_programt::instructionst::const_iterator
	  it=program.instructions.begin();
	  it!=program.instructions.end();
	  it++)
	{
		if(n_0 != it->location_number)
		{
			D[it->location_number] = N;
		}
	}

	bool changed = true;
	while(changed)
	{
		changed = false;

		for(goto_programt::instructionst::const_iterator
		  it=program.instructions.begin();
		  it!=program.instructions.end();
		  it++)
		{
			if(n_0 != it->location_number)
			{

				std::set<unsigned> intersection_of_incoming_dominators = N;

				for(std::set<goto_programt::targett>::iterator
					it2 = it->incoming_edges.begin();
					it2 != it->incoming_edges.end();
					it2++)
				{

			    	std::set<unsigned> intersection;

		    	    set_intersection(
		    	    		intersection_of_incoming_dominators.begin(),
			    	    	intersection_of_incoming_dominators.end(),
			    	    	D[(*it2)->location_number].begin(),
			    	    	D[(*it2)->location_number].end(),
			    	    	std::insert_iterator<std::set<unsigned> >(intersection, intersection.begin()));

		    	    intersection_of_incoming_dominators = intersection;

				}

				intersection_of_incoming_dominators.insert(it->location_number);

				if(D[it->location_number] != intersection_of_incoming_dominators) {
					D[it->location_number] = intersection_of_incoming_dominators;
					changed = true;
				}

			}

		}
	}

}


std::ostream& operator<<(std::ostream& os, const dominator_infot& dom)
{
	for(std::map<unsigned, std::set<unsigned> >::const_iterator i = dom.D.begin(); i != dom.D.end(); i++)
	{
		os << i->first << " dominated by { ";
		for(std::set<unsigned>::const_iterator j = i->second.begin(); j != i->second.end(); j++)
		{
			if(j != i->second.begin()) {
				os << ", ";
			}

			os << *j;

		}

		os << " }\n";

	}


	return os;
}

bool dominator_infot::dominates(const unsigned a, const unsigned b)
{
	return D[b].end() != D[b].find(a);

}
