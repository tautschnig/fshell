/*******************************************************************\

Module: Program Transformation

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <i2string.h>
#include <replace_expr.h>
#include <expr_util.h>
#include <location.h>
#include <std_expr.h>
#include <config.h>
#include <std_expr.h>

#include <ansi-c/c_types.h>

#include "remove_skip.h"
#include "goto_function_pointers.h"

/*******************************************************************\

Function: remove_function_pointer

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void remove_function_pointer(
  goto_functionst &goto_functions,
  goto_programt &goto_program,
  goto_programt::targett target)
{
  const code_function_callt &code=
    to_code_function_call(target->code);

  const exprt &function=code.function();

  assert(function.id()=="dereference");  
  assert(function.operands().size()==1);

  const exprt &pointer=function.op0();
  
  typedef std::list<exprt> functionst;
  functionst functions;
  
  // get all type-compatible functions
  // that have a body
  for(goto_functionst::function_mapt::iterator f_it=
      goto_functions.function_map.begin();
      f_it!=goto_functions.function_map.end();
      f_it++)
  {
    if(!f_it->second.body_available) continue;
    if(f_it->second.type!=function.type()) continue;
    
    symbol_exprt expr;
    expr.type()=f_it->second.type;
    expr.set_identifier(f_it->first);
    functions.push_back(expr);
  }
  
  // the final target is a skip
  
  goto_programt final_skip;
  goto_programt::targett t_final=final_skip.add_instruction();
  t_final->make_skip();

  // build the calls and gotos

  goto_programt new_code_calls;
  goto_programt new_code_gotos;

  for(functionst::const_iterator
      it=functions.begin();
      it!=functions.end();
      it++)
  {
    // call
    goto_programt::targett t1=new_code_calls.add_instruction();
    t1->make_function_call(code);
    to_code_function_call(t1->code).function()=*it;
    goto_programt::targett t2=new_code_calls.add_instruction();
    t2->make_goto(t_final, true_exprt());
  
    // goto
    address_of_exprt address_of;
    address_of.object()=*it;
    address_of.type()=pointer_typet();
    address_of.type().subtype()=it->type();
    
    goto_programt::targett t3=new_code_gotos.add_instruction();
    t3->make_goto(t1, equality_exprt(pointer, address_of));
  }

  goto_programt new_code;
  
  // patch them all together
  new_code.destructive_append(new_code_gotos);
  new_code.destructive_append(new_code_calls);
  new_code.destructive_append(final_skip);
  
  // fix local variables and locations
  Forall_goto_program_instructions(it, new_code)
  {
    it->location=target->location;
    it->local_variables.insert(target->local_variables.begin(),
                               target->local_variables.end());
  }
  
  goto_programt::targett next_target=target;
  next_target++;

  goto_program.instructions.splice(next_target, new_code.instructions);

  // we preserve the dereferencing to catch pointer errors
  code_expressiont code_expression;
  code_expression.location()=function.location();
  code_expression.expression()=function;
  target->code.swap(code_expression);
  target->type=OTHER;
}

/*******************************************************************\

Function: remove_function_pointers

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool remove_function_pointers(
  goto_functionst &goto_functions,
  goto_programt &goto_program)
{
  bool did_something=false;

  Forall_goto_program_instructions(target, goto_program)
    if(target->is_function_call())
    {
      const code_function_callt &code=
        to_code_function_call(target->code);
    
      if(code.function().id()=="dereference")
      {
        remove_function_pointer(goto_functions, goto_program, target); 
        did_something=true;
      }
    }

  if(did_something)
  {
    remove_skip(goto_program);
    goto_program.update();
  }
  
  return did_something;
}

/*******************************************************************\

Function: remove_function_pointers

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void remove_function_pointers(goto_functionst &functions)
{
  bool did_something=false;

  for(goto_functionst::function_mapt::iterator f_it=
      functions.function_map.begin();
      f_it!=functions.function_map.end();
      f_it++)
  {
    goto_programt &goto_program=f_it->second.body;

    if(remove_function_pointers(functions, goto_program))
      did_something=true;
  }

  if(did_something)
    functions.compute_location_numbers();
}
