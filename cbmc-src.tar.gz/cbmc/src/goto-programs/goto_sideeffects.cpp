/*******************************************************************\

Module: Program Transformation

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <expr_util.h>
#include <std_expr.h>
#include <rename.h>
#include <cprover_prefix.h>
#include <i2string.h>

#include <ansi-c/c_types.h>

#include "goto_convert_class.h"

/*******************************************************************\

Function: goto_convertt::read

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::read(exprt &expr, goto_programt &dest)
{
  if(expr.is_constant())
    return;

  const locationt location=expr.find_location();
  
  symbolt &new_symbol=new_tmp_symbol(expr.type(), dest, location);

  code_assignt assignment;
  assignment.lhs()=symbol_expr(new_symbol);
  assignment.rhs()=expr;
  assignment.location()=location;

  goto_programt tmp_program;
  convert(assignment, tmp_program);
  dest.destructive_append(tmp_program);

  expr=symbol_expr(new_symbol);  
}

/*******************************************************************\

Function: goto_convertt::has_sideeffect

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool goto_convertt::has_sideeffect(const exprt &expr)
{
  forall_operands(it, expr)
    if(has_sideeffect(*it))
      return true;

  if(expr.id()=="sideeffect")
    return true;

  return false;
}

/*******************************************************************\

Function: goto_convertt::has_function_call

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool goto_convertt::has_function_call(const exprt &expr)
{
  forall_operands(it, expr)
    if(has_function_call(*it))
      return true;

  if(expr.id()=="sideeffect" &&
     expr.get("statement")=="function_call")
    return true;

  return false;
}

/*******************************************************************\

Function: goto_convertt::remove_sideeffects

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_sideeffects(
  exprt &expr,
  goto_programt &dest,
  bool result_is_used)
{
  guardt guard;
  remove_sideeffects(expr, guard, dest, result_is_used);
}

/*******************************************************************\

Function: goto_convertt::remove_sideeffects

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_sideeffects(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  if(!has_sideeffect(expr))
    return;

  if(expr.id()=="and")
  {
    if(!expr.is_boolean())
      throw "`and' must be Boolean, but got "+
            expr.pretty();

    // re-write into nested ...?...:0

    exprt tmp=true_exprt();
    exprt false_e = false_exprt();

    exprt::operandst &ops=expr.operands();

    for(int i = int(ops.size())-1; i >= 0; i--)
    {
      exprt &op=ops[i];

      if(!op.is_boolean())
       throw "`and' takes Boolean operands only, but got "+
         op.pretty();

      if_exprt if_e(op, tmp, false_e);
      tmp.swap(if_e);
    }

    expr.swap(tmp);
    remove_sideeffects(expr, guard, dest, result_is_used);
    return;    
  }
  else if(expr.id()=="or")
  {
    if(!expr.is_boolean())
      throw "`or' must be Boolean, but got "+
            expr.pretty();

    // re-write into nested ...?1:...

    exprt tmp=true_exprt();
    exprt true_e = true_exprt();

    exprt::operandst &ops=expr.operands();

    for(int i = int(ops.size())-1; i >= 0; i--)
    {
      exprt &op=ops[i];

      if(!op.is_boolean())
       throw "`or' takes Boolean operands only, but got "+
         op.pretty();

      if_exprt if_e(op, true_e, tmp);
      tmp.swap(if_e);
    }

    expr.swap(tmp);
    remove_sideeffects(expr, guard, dest, result_is_used);
    return;    
  }
  else if(expr.id()=="if")
  {
    if(expr.operands().size()!=3)
      throw "if takes three arguments";

    if(!expr.op0().is_boolean())
    {
      std::string msg=
        "first argument of if must be boolean, but got "
        +expr.op0().to_string();
      throw msg;
    }

    remove_sideeffects(expr.op0(), guard, dest);

    bool o1=has_sideeffect(expr.op1());
    bool o2=has_sideeffect(expr.op2());

    if(o1 || o2)
      read(expr.op0(), dest);

    if(o1)
    {
      unsigned old_guard=guard.size();
      guard.add(expr.op0());
      remove_sideeffects(expr.op1(), guard, dest);
      guard.resize(old_guard);
    }

    if(o2)
    {
      unsigned old_guard=guard.size();
      exprt tmp(expr.op0());
      tmp.make_not();
      guard.add(tmp);
      remove_sideeffects(expr.op2(), guard, dest);
      guard.resize(old_guard);
    }

    return;
  }
  else if(expr.id()=="comma")
  {
    exprt result;
  
    Forall_operands(it, expr)
    {
      bool last=(it==--expr.operands().end());
      
      if(last)
      {
        result.swap(*it);
        remove_sideeffects(result, guard, dest, result_is_used);
      }
      else
        remove_sideeffects(*it, guard, dest, false);
    }
    
    expr.swap(result);
    
    return;
  }
  else if(expr.id()=="typecast")
  {
    if(expr.operands().size()!=1)
      throw "typecast takes one argument";

    // preserve 'result_is_used'
    remove_sideeffects(expr.op0(), guard, dest, result_is_used);
    
    return;
  }
  else if(expr.id()=="sideeffect" &&
          expr.get("statement")=="gcc_conditional_expression")
  {
    remove_gcc_conditional_expression(expr, guard, dest);
    return;
  }

  // TODO: evaluation order

  Forall_operands(it, expr)
    remove_sideeffects(*it, guard, dest);

  if(expr.id()=="sideeffect")
  {
    const irep_idt &statement=expr.get("statement");

    if(statement=="function_call") // might do anything
      remove_function_call(expr, guard, dest, result_is_used);
    else if(statement=="assign" ||
            statement=="assign+" ||
            statement=="assign-" ||
            statement=="assign*" ||
            statement=="assign_div" ||
            statement=="assign_bitor" ||
            statement=="assign_bitxor" ||
            statement=="assign_bitand" ||
            statement=="assign_lshr" ||
            statement=="assign_ashr" ||
            statement=="assign_shl" ||
            statement=="assign_mod")
      remove_assignment(expr, guard, dest);
    else if(statement=="postincrement" ||
            statement=="postdecrement")
      remove_post(expr, guard, dest, result_is_used);
    else if(statement=="preincrement" ||
            statement=="predecrement")
      remove_pre(expr, guard, dest);
    else if(statement=="cpp_new" ||
            statement=="cpp_new[]")
      remove_cpp_new(expr, guard, dest, result_is_used);
    else if(statement=="temporary_object")
      remove_temporary_object(expr, guard, dest, result_is_used);
    else if(statement=="statement_expression")
      remove_statement_expression(expr, guard, dest, result_is_used);
    else if(statement=="nondet")
    {
      // these are fine
    }
    else
    {
      str << "cannot remove side effect (" << statement << ")";
      throw 0;
    }
  }
}

/*******************************************************************\

Function: goto_convertt::remove_assignment

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_assignment(
  exprt &expr,
  guardt &guard,
  goto_programt &dest)
{
  codet assignment_statement("expression");
  assignment_statement.copy_to_operands(expr);
  assignment_statement.location()=expr.location();

  if(expr.operands().size()!=2)
    throw "assignment must have two operands";

  exprt lhs;
  lhs.swap(expr.op0());
  expr.swap(lhs);

  goto_programt tmp_program;
  convert(assignment_statement, tmp_program);
  guard_program(guard, tmp_program);
  dest.destructive_append(tmp_program);
}

/*******************************************************************\

Function: goto_convertt::remove_pre

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_pre(
  exprt &expr,
  guardt &guard,
  goto_programt &dest)
{
  codet pre_statement("expression");
  pre_statement.copy_to_operands(expr);

  if(expr.operands().size()!=1)
    throw "preincrement/predecrement must have one operand";

  exprt op;
  op.swap(expr.op0());
  expr.swap(op);

  goto_programt tmp_program;
  convert(pre_statement, tmp_program);
  guard_program(guard, tmp_program);
  dest.destructive_append(tmp_program);
}

/*******************************************************************\

Function: goto_convertt::remove_post

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_post(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  // we have ...(op++)...
  codet post_statement("expression");
  post_statement.copy_to_operands(expr);

  if(expr.operands().size()!=1)
    throw "postincrement/postdecrement must have one operand";

  if(result_is_used)
  {
    exprt tmp;
    tmp.swap(expr.op0());
    read(tmp, dest);
    expr.swap(tmp);
  }
  else
  {
    expr.make_nil();
  }

  goto_programt tmp_program;
  convert(post_statement, tmp_program);
  guard_program(guard, tmp_program);
  dest.destructive_append(tmp_program);
}

/*******************************************************************\

Function: goto_convertt::remove_function_call

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_function_call(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  if(!result_is_used)
  {
    goto_programt tmp_program;
    code_expressiont call;
    call.expression()=expr;
    convert(call, tmp_program);
    guard_program(guard, tmp_program);
    dest.destructive_append(tmp_program);
    return;
  }

  symbolt new_symbol;

  new_symbol.base_name="return_value";
  new_symbol.lvalue=true;
  new_symbol.is_statevar=true;
  new_symbol.thread_local=true;
  new_symbol.type=expr.type();
  new_symbol.location=expr.find_location();

  // get name of function, if available

  if(expr.id()!="sideeffect" ||
     expr.get("statement")!="function_call")
    throw "expected function call";

  if(expr.operands().empty())
    throw "function_call expects at least one operand";

  if(expr.op0().id()=="symbol")
  {
    const irep_idt &identifier=expr.op0().get("identifier");
    const symbolt &symbol=lookup(identifier);
    
    std::string new_base_name=id2string(new_symbol.base_name);
    
    new_base_name+="_";
    new_base_name+=id2string(symbol.base_name);
    new_base_name+="$"+i2string(++temporary_counter);
    
    new_symbol.base_name=new_base_name;
    new_symbol.mode=symbol.mode;
  }

  new_symbol.name=tmp_symbol_prefix+id2string(new_symbol.base_name);

  new_name(new_symbol);
  
  tmp_symbols.push_back(new_symbol.name);
  
  {
    code_declt decl;
    decl.symbol()=symbol_expr(new_symbol);
    decl.location()=new_symbol.location;
    goto_programt tmp_program1;
    convert(decl, tmp_program1);
    dest.destructive_append(tmp_program1);  
  }

  {
    goto_programt tmp_program2;
    code_assignt assignment(symbol_expr(new_symbol), expr);
    assignment.location()=new_symbol.location;
    convert(assignment, tmp_program2);
    guard_program(guard, tmp_program2);
    dest.destructive_append(tmp_program2);
  }

  expr=symbol_expr(new_symbol);
}

/*******************************************************************\

Function: goto_convertt::replace_new_object

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::replace_new_object(
  const exprt &object,
  exprt &dest)
{
  if(dest.id()=="new_object")
    dest=object;
  else
    Forall_operands(it, dest)
      replace_new_object(object, *it);
}

/*******************************************************************\

Function: goto_convertt::remove_cpp_new

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_cpp_new(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  codet call;

  if(result_is_used)
  {
    symbolt new_symbol;

    new_symbol.base_name="new_value$"+i2string(++temporary_counter);
    new_symbol.lvalue=true;
    new_symbol.type=expr.type();
    new_symbol.name=tmp_symbol_prefix+id2string(new_symbol.base_name);

    new_name(new_symbol);
    tmp_symbols.push_back(new_symbol.name);

    call=code_assignt(symbol_expr(new_symbol), expr);

    expr=symbol_expr(new_symbol);
  }
  else
  {
    call=codet("expression");
    call.move_to_operands(expr);
  }

  goto_programt tmp_program;
  convert(call, tmp_program);
  guard_program(guard, tmp_program);
  dest.destructive_append(tmp_program);
}

/*******************************************************************\

Function: goto_convertt::remove_temporary_object

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_temporary_object(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  if(expr.operands().size()!=1 &&
     expr.operands().size()!=0)
    throw "temporary_object takes 0 or 1 operands";

  symbolt &new_symbol=new_tmp_symbol(expr.type(), dest, expr.find_location());

  new_symbol.mode=expr.get("mode");
  
  if(expr.operands().size()==1)
  {
    codet assignment("assign");
    assignment.reserve_operands(2);
    assignment.copy_to_operands(symbol_expr(new_symbol));
    assignment.move_to_operands(expr.op0());

    goto_programt tmp_program;
    convert(assignment, tmp_program);
    dest.destructive_append(tmp_program);
  }

  if(expr.find("initializer").is_not_nil())
  {
    assert(expr.operands().empty());
    exprt initializer=static_cast<const exprt &>(expr.find("initializer"));
    replace_new_object(symbol_expr(new_symbol), initializer);

    goto_programt tmp_program;
    convert(to_code(initializer), tmp_program);
    dest.destructive_append(tmp_program);
  }

  expr=symbol_expr(new_symbol);  
}

/*******************************************************************\

Function: goto_convertt::remove_statement_expression

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_statement_expression(
  exprt &expr,
  guardt &guard,
  goto_programt &dest,
  bool result_is_used)
{
  if(expr.operands().size()!=1)
    throw "statement_expression takes 1 operand";

  if(expr.op0().id()!="code")
    throw "statement_expression takes code as operand";

  codet &code=to_code(expr.op0());

  exprt last;
  last.make_nil();

  if(result_is_used)
  {
    // get last statement from block
    if(code.get_statement()!="block")
      throw "statement_expression expects block";

    if(code.operands().empty())
      throw "statement_expression expects non-empty block";

    last.swap(code.operands().back());
    code.operands().pop_back();
  }

  {
    goto_programt tmp;
    convert(code, tmp);
    guard_program(guard, tmp);

    dest.destructive_append(tmp);
  }

  if(result_is_used)
  {
    goto_programt tmp;
    remove_sideeffects(last, guard, tmp, true);

    if(last.get("statement")=="expression" &&
       last.operands().size()==1)
      expr=last.op0();
    else
      throw "statement_expression expects expression as last statement";
  }
}

/*******************************************************************\

Function: goto_convertt::remove_gcc_conditional_expression

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_convertt::remove_gcc_conditional_expression(
  exprt &expr,
  guardt &guard,
  goto_programt &dest)
{
  if(expr.operands().size()!=2)
    throw "conditional_expression takes two operands";

  // first remove side-effects from condition
  remove_sideeffects(expr.op0(), guard, dest);

  if_exprt if_expr;

  if_expr.cond()=expr.op0();
  if_expr.true_case()=expr.op0();
  if_expr.false_case()=expr.op1();
  if_expr.location()=expr.location();

  if(if_expr.cond().type()!=bool_typet())
    if_expr.cond().make_typecast(bool_typet());
  
  expr.swap(if_expr);

  // there might still be one in expr.op2()  
  remove_sideeffects(expr, guard, dest);
}
