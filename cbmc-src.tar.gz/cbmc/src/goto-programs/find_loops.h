/*
 * find_loops.h
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */

#ifndef FIND_LOOPS_H_
#define FIND_LOOPS_H_

#include "dominator_info.h"


class loop_infot
{
public:

	/* Uses Dragon book algorithm to compute all natural loops for goto program */
	void find_loops(dominator_infot&, const goto_programt&);

	/* Organizes loops into containment chains, and associates each instruction with the inner-most loop that contains it */
	void organize_loops(const goto_programt& goto_program);

	int num_loops();

	std::ostream& show_closest_loop_info(std::ostream& os, const goto_programt& goto_program);

	friend std::ostream& operator<<(std::ostream& os, const loop_infot& loop_info);

	class loopt
	{
	public:

		loopt(unsigned header, std::set<unsigned> nodes);

		void add_nodes(std::set<unsigned> nodes);

		bool contains( const loopt& other) const;

		bool contains( const unsigned inst) const;

		static bool disjoint ( loopt& loop1, loopt& loop2 );

		void candidate_parent( loopt& other );

		friend std::ostream& operator<<(std::ostream& os, const loopt& loop);

		loopt * parent; // Pointer to loop containing this one

		std::vector<loopt *> children; // Inner loops

		unsigned get_id() const;

		const unsigned header;

	private:

		std::set<unsigned> nodes;

		unsigned id;

	};

	bool is_inner_loop(const loopt* loop) const;

	std::map<unsigned, loopt*> containing_loop;

	std::vector<loopt*> loops;

	std::vector<loopt*> outer_loops;

	std::vector<loopt*> inner_loops;

private:

	void compute_loop_nodes_for_back_edge(const goto_programt::const_targett n,
			const goto_programt::const_targett d,
			std::set<unsigned> & loop);



};


goto_programt::targett get_iterator_for_loop_header(const loop_infot::loopt& loop, goto_programt& body);

goto_programt::targett get_first_node_after_header(goto_programt::targett header, const loop_infot::loopt& loop, goto_programt& body);

#endif /* FIND_LOOPS_H_ */
