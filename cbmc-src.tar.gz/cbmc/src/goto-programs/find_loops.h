/*
 * find_loops.h
 *
 *  Created on: Jul 14, 2009
 *      Author: Alastair Donaldson
 */

#ifndef FIND_LOOPS_H_
#define FIND_LOOPS_H_

#include <goto-programs/goto_functions.h>
#include <goto-programs/goto_program.h>


#include <util/std_expr.h>


/* Utility function to grab the main method */
goto_programt& find_main(goto_functionst& goto_functions, contextt& context);


/* Control Flow Graphs */

class CFG_nodet
{
public:

	/* code, function, location and type determine the instruction represented by the CFG node */
	codet code;
	irep_idt function;
	locationt location;
	goto_program_instruction_typet type;

	exprt reasoning_guard; /* Used if instruction is assert/assume, otherwise meaningless */
	exprt jump_condition; /* Used if successor_jump is not NULL.  In this case, if jump_condition is true then the successor is successor_jump */
	CFG_nodet* successor_next; /* Default successor, or successor if jump_condition is false */
	CFG_nodet* successor_jump; /* Successor if jump condition is true */

	std::set<CFG_nodet*> predecessors; /* Nodes that point to this node via successor_next or successor_jump fields.  Set when parent CFG is updated */
	int id; /* Id for node, which is set when the parent CFG is updated */


	CFG_nodet(goto_programt::instructiont& goto_program_instruction);

	CFG_nodet(codet code, irep_idt function, locationt location, goto_program_instruction_typet type)
		: code(code), function(function), location(location), type(type)
	{
		reasoning_guard = false_exprt();
		jump_condition = false_exprt();
		successor_next = NULL;
		successor_jump = NULL;
	}

};

class dominator_infot;

class CFGt
{

public:

	typedef std::list<CFG_nodet> nodest;

	typedef std::set<CFG_nodet*> nodes_sett;
	typedef std::set<const CFG_nodet*> nodes_const_sett;

	contextt& context;
	nodest nodes;

	CFGt(contextt& context, goto_programt& program);

	CFGt(contextt& context) : context(context)
	{
		nodes.clear();
	}

public:

	void output(
			const class namespacet &ns,
			const irep_idt &identifier,
			std::ostream& out, bool show_predecessors=false,
			CFGt::nodes_const_sett* loop_header_points = NULL) const;

	void output_node(
			const CFG_nodet& node,
			std::ostream& out, bool show_predecessors=false) const;


	void to_goto_program(goto_programt& program, CFGt::nodes_const_sett* loop_header_CFG_points = NULL, std::set<goto_programt::const_targett>* loop_header_instruction_points = NULL);

	void append_node(CFG_nodet node);

	void patchup_pointers(std::map<const CFG_nodet*, CFG_nodet*>& patchup_map);

	void update(CFGt::nodes_const_sett* loop_header_points = NULL);

	void transform_to_monolithic_loop();

  const CFG_nodet& get_initial() const;
  CFG_nodet& get_initial();

	void order_nodes(CFGt::nodes_const_sett* loop_header_CFG_points = NULL);

private:
	void remove_self_loops();
	void calculate_prececessors();
	void collect_garbage(CFGt::nodes_const_sett* loop_header_points = NULL);
	void assign_ids();
	void compute_ordered_nodes(std::map<const CFG_nodet*, CFG_nodet*>& old_to_new, const CFG_nodet* current_node, nodest& new_nodes, const dominator_infot& dominator_info);

};






/* Depth-first spanning trees */

class DFST_numberingt {

public:
	DFST_numberingt(const CFGt& cfg);

	bool is_retreating(const CFG_nodet& d, const CFG_nodet& n) const;

	friend std::ostream& operator<<(std::ostream& os, const DFST_numberingt& dom);

private:

	void search(const CFG_nodet* n, CFGt::nodes_const_sett& visited);

	std::map<const CFG_nodet*, int> dfn;

	const CFGt& the_cfg;

};







/* Dominators */

class dominator_infot {

public:
	dominator_infot(const CFGt& cfg);

	/* Determines whether instruction source dominates instruction dest */
	bool is_back_edge(const CFG_nodet& source, const CFG_nodet& dest) const;

	/* Determines whether the CFG is reducible */
	bool cfg_is_reducible(const DFST_numberingt& dfst);

	friend std::ostream& operator<<(std::ostream& os, const dominator_infot& dom);

private:

	void initialise_with_all_cfg_nodes(CFGt::nodes_const_sett & S, const CFGt& cfg);

	typedef std::map<const CFG_nodet*, CFGt::nodes_const_sett > dominator_mapt;

	/* dominators_of[n] is all the nodes that dominate n.  See page 670 of Dragon Book, first edition */
	dominator_mapt dominators_of;

	const CFGt& the_cfg;

};











/* Loops */



class loop_infot /* Represents a nest of loops */
{
public:

	/* Uses Dragon book algorithm to compute all natural loops for goto program */
	loop_infot(const CFGt&);

	/* Returns number of loops in the nest */
	unsigned int num_loops() const;

	/* Display information about the loop nest */
	friend std::ostream& operator<<(std::ostream& os, const loop_infot& loop_info);

	class loopt;
	typedef std::vector<loopt*> loopst;

	class loopt /* Represents a single loop */
	{
	public:

		loopt(const CFG_nodet& header, CFGt::nodes_const_sett nodes, const CFGt& cfg);

		void add_nodes(CFGt::nodes_const_sett nodes);

		bool contains( const loopt& other) const;

		bool contains( const CFG_nodet& inst) const;

		static bool disjoint ( loopt& loop1, loopt& loop2 );

		void candidate_parent( loopt& other );

		friend std::ostream& operator<<(std::ostream& os, const loopt& loop);

		loopt* parent; // Pointer to loop containing this one

		loopst children; // Inner loops

		const CFG_nodet& header;

		const CFGt& cfg;

	private:

		CFGt::nodes_const_sett nodes;

		unsigned id;

	};

	bool is_inner_loop(const loopt* loop) const;

	loopst loops; /* All loops */

 	loopst outer_loops; /* Just the outer loops */

	loopst inner_loops; /* Just the inner loops */

	loopt* get_closest_containing_loop(const CFG_nodet* n) const;  /* Returns the innermost loops that contains the given node, returns NULL if the node is not in any loop */

private:

	void compute_loop_nodes_for_back_edge(const CFG_nodet& n,
			const CFG_nodet& d,
			CFGt::nodes_const_sett & loop);

	/* Organizes loops into containment chains, and associates each instruction with the inner-most loop that contains it */
	void organize_loops(const CFGt& cfg);

	std::map<const CFG_nodet*, loopt*> closest_containing_loop;

};


#endif /* FIND_LOOPS_H_ */
