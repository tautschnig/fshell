/*******************************************************************\

Module: Write GOTO binaries

Author: CM Wintersteiger

\*******************************************************************/

#include <fstream>

#include <message.h>
#include <irep_serialization.h>
#include <symbol_serialization.h>

#include <goto-programs/goto_function_serialization.h>

#include "write_goto_binary.h"

/*******************************************************************\

Function: goto_programt::write_goto_binary_v1

  Inputs:

 Outputs:

 Purpose: Writes a goto program to disc, using goto binary format ver 1

\*******************************************************************/

bool write_goto_binary_v1(
  std::ostream &out,
  const contextt &context,
  goto_functionst &functions,
  irep_serializationt &irepconverter,
  symbol_serializationt &symbolconverter,
  goto_function_serializationt &gfconverter)
{
  write_long( out, context.symbols.size() );
  
  forall_symbols(it, context.symbols)
  {
    const symbolt &sym = it->second;
    symbolconverter.convert(sym, out);
  }

  unsigned cnt=0;
  forall_goto_functions(it, functions)  
    if (it->second.body_available)
      cnt++;

  write_long( out, cnt );

  for ( goto_functionst::function_mapt::iterator it=
          functions.function_map.begin();
        it != functions.function_map.end();
        it++)
  {
    if (it->second.body_available)
    {
      it->second.body.compute_location_numbers();
      write_string(out, it->first.as_string());
      gfconverter.convert(it->second, out);        
    }
  }

  //irepconverter.output_map(f);
  //irepconverter.output_string_map(f);  

  return false;
}

/*******************************************************************\

Function: goto_programt::write_goto_binary_v2

  Inputs:

 Outputs:

 Purpose: Writes a goto program to disc, using goto binary format ver 2

\*******************************************************************/

bool write_goto_binary_v2(
  std::ostream &out,
  const contextt &lcontext,
  goto_functionst &functions,
  irep_serializationt &irepconverter,  
  goto_function_serializationt &gfconverter)
{
  write_long( out, lcontext.symbols.size() );
  
  forall_symbols(it, lcontext.symbols)
  {
    // In version 2, symbols are not converted to ireps,
    // instead they are saved in a custom binary format
    
    const symbolt &sym = it->second;        
    
    irepconverter.reference_convert(sym.type, out);
    irepconverter.reference_convert(sym.value, out);
    irepconverter.reference_convert(sym.location, out);
    
    irepconverter.write_string_ref(out, sym.name);
    irepconverter.write_string_ref(out, sym.module);
    irepconverter.write_string_ref(out, sym.base_name);
    irepconverter.write_string_ref(out, sym.mode);
    irepconverter.write_string_ref(out, sym.pretty_name);
    
    write_long(out, sym.ordering);

    unsigned flags=0;    
    flags = (flags << 1) | sym.is_type; 
    flags = (flags << 1) | sym.theorem;
    flags = (flags << 1) | sym.is_macro;
    flags = (flags << 1) | sym.is_exported;
    flags = (flags << 1) | sym.is_input;
    flags = (flags << 1) | sym.is_output;
    flags = (flags << 1) | sym.is_statevar;
    flags = (flags << 1) | sym.is_actual;
    flags = (flags << 1) | sym.free_var;
    flags = (flags << 1) | sym.binding;
    flags = (flags << 1) | sym.lvalue;
    flags = (flags << 1) | sym.static_lifetime;
    flags = (flags << 1) | sym.thread_local;
    flags = (flags << 1) | sym.file_local;
    flags = (flags << 1) | sym.is_extern;
    flags = (flags << 1) | sym.is_volatile;
    
    write_long(out, flags);
  }

  unsigned cnt=0;
  forall_goto_functions(it, functions)  
    if (it->second.body_available)
      cnt++;

  write_long( out, cnt );

  for ( goto_functionst::function_mapt::iterator it=
          functions.function_map.begin();
        it != functions.function_map.end();
        it++)
  {
    if (it->second.body_available)
    {      
      // In version 2, goto functions are not converted to ireps,
      // instead they are saved in a custom binary format      
      
      write_string(out, it->first.as_string()); // name      
      write_long(out, it->second.body.instructions.size()); // # instructions
      
      forall_goto_program_instructions(iit, it->second.body)
      {
        const goto_programt::instructiont &instruction = *iit;
        
        irepconverter.reference_convert(instruction.code, out);
        irepconverter.write_string_ref(out, instruction.function);
        irepconverter.reference_convert(instruction.location, out);
        write_long(out, (long)instruction.type);
        irepconverter.reference_convert(instruction.guard, out);        
        irepconverter.write_string_ref(out, instruction.event);        
        write_long(out, instruction.target_number);
                
        write_long(out, instruction.targets.size());
        for(goto_programt::targetst::const_iterator tit=
              instruction.targets.begin();
            tit!=instruction.targets.end();
            tit++)
        {          
          write_long(out, (*tit)->target_number);
        }        
          
        write_long(out, instruction.labels.size());
        for(goto_programt::instructiont::labelst::const_iterator lit=
              instruction.labels.begin();
            lit!=instruction.labels.end();
            lit++)
        {
          irepconverter.write_string_ref(out, *lit);
        }
      }
    }
  }

  //irepconverter.output_map(f);
  //irepconverter.output_string_map(f);  

  return false;
}

/*******************************************************************\

Function: goto_programt::write_goto_binary

  Inputs:

 Outputs:

 Purpose: Writes a goto program to disc

\*******************************************************************/

bool write_goto_binary(
  std::ostream &out,
  const contextt &lcontext,
  goto_functionst &functions,
  int version)
{
  // header
  out << "GBF";
  write_long(out, version);

  irep_serializationt::ireps_containert irepc;
  irep_serializationt irepconverter(irepc);    
  goto_function_serializationt gfconverter(irepc);
    
  switch(version)
  {
    case 1: 
    {
      symbol_serializationt symbolconverter(irepc);
      return write_goto_binary_v1(out, lcontext, functions,
                                        irepconverter,
                                        symbolconverter,
                                        gfconverter); 
      break;
    }
    case 2:
    {
      return write_goto_binary_v2(out, lcontext, functions,
                                        irepconverter,
                                        gfconverter); 
      break;
    }
    default: 
      throw "Unknown goto binary version";
  }
  
  return false;
}
