/*******************************************************************\

Module: A termination checking module

Author: CM Wintersteiger

\*******************************************************************/

#ifndef CPROVER_GOTO_PROGRAMS_TERMINATION_H
#define CPROVER_GOTO_PROGRAMS_TERMINATION_H

#include <set>

#include <util/namespace.h>
#include <util/message.h>
#include <util/context.h>

#include "goto_program.h"
#include "goto_functions.h"

class termination_instrumentert:public messaget
{
public:
  termination_instrumentert(contextt &_context,
               message_handlert &_mh);
  ~termination_instrumentert();

  void instrument(goto_programt &program);
  void instrument(goto_functionst &goto_functions);

protected:
  struct loopt
  {
    goto_programt::targett begin, end;
  };

  contextt &context;
  namespacet ns;
  std::map<exprt, exprt> var_map;
  std::set<exprt> variant;
  loopt loop;
  exprt copied_flag;

  void get_variant();
  void instrument_loop(goto_programt &program);
  bool make_old_variables();
  exprt generate_termination_assertion() const;
  void add_copied_flag();
  void insert_assertion(goto_programt &program);
};

#endif
