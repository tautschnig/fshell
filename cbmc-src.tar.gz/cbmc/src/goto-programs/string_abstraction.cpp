/*******************************************************************\

Module: String Abstraction

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <string.h>

#include <std_expr.h>
#include <std_code.h>
#include <expr_util.h>
#include <message_stream.h>
#include <arith_tools.h>
#include <i2string.h>
#include <type_eq.h>

#include <ansi-c/c_types.h>

#include "pointer_arithmetic.h"
#include "string_abstraction.h"

/*******************************************************************\

Function: string_abstraction

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstraction(
  contextt &context,
  message_handlert &message_handler,
  goto_programt &dest)
{
  string_abstractiont string_abstraction(context, message_handler);
  string_abstraction(dest);
}

/*******************************************************************\

Function: string_abstraction

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstraction(
  contextt &context,
  message_handlert &message_handler,
  goto_functionst &dest)
{
  string_abstractiont string_abstraction(context, message_handler);
  string_abstraction(dest);
}

/*******************************************************************\

Function: string_abstractiont::string_abstractiont

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

string_abstractiont::string_abstractiont(
  contextt &_context,
  message_handlert &_message_handler):
  message_streamt(_message_handler),
  context(_context),
  ns(_context)
{
  struct_typet s;

  s.components().resize(3);

  s.components()[0].set_name("is_zero");
  s.components()[0].set_pretty_name("is_zero");
  s.components()[0].type()=build_type(IS_ZERO);

  s.components()[1].set_name("length");
  s.components()[1].set_pretty_name("length");
  s.components()[1].type()=build_type(LENGTH);

  s.components()[2].set_name("size");
  s.components()[2].set_pretty_name("size");
  s.components()[2].type()=build_type(SIZE);

  string_struct=s;
}

/*******************************************************************\

Function: string_abstractiont::member

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::member(const exprt &a, whatt what)
{
  if(a.is_nil()) return a;
  
  member_exprt result;
  result.type()=build_type(what);
  result.struct_op()=a;

  switch(what)
  {
  case IS_ZERO: result.set_component_name("is_zero"); break;
  case SIZE: result.set_component_name("size"); break;
  case LENGTH: result.set_component_name("length"); break;
  default: assert(false);
  }

  return result;
}

/*******************************************************************\

Function: string_abstractiont::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::operator()(goto_functionst &dest)
{
  for(goto_functionst::function_mapt::iterator
      it=dest.function_map.begin();
      it!=dest.function_map.end();
      it++) {
    add_str_arguments(it->first, it->second);
    abstract(it->second.body);
    current_args.clear();
  }

  // do we have a main?
  goto_functionst::function_mapt::iterator
    m_it=dest.function_map.find(dest.main_id());

  if(m_it!=dest.function_map.end())
  {
    goto_programt &main=m_it->second.body;

    // do initialization
    initialization.destructive_append(main);
    main.swap(initialization);
    initialization.clear();
  }
}

/*******************************************************************\

Function: string_abstractiont::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::operator()(goto_programt &dest)
{
  abstract(dest);

  // do initialization
  initialization.destructive_append(dest);
  dest.swap(initialization);
  initialization.clear();
}

/*******************************************************************\

Function: string_abstractiont::abstract

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::abstract(goto_programt &dest)
{
  locals.clear();

  Forall_goto_program_instructions(it, dest)
    it=abstract(dest, it);

  // go over it again for the newly added locals
  if(!locals.empty())
  {
    ::std::map< irep_idt, ::goto_programt::targett > available_decls;
    Forall_goto_program_instructions(it, dest)
    {
      if(it->is_decl())
      {
        assert(it->code.get("statement")=="decl");
        assert(it->code.operands().size()==1);
        assert(it->code.op0().id()=="symbol");
        available_decls.insert(::std::make_pair(
              to_symbol_expr(it->code.op0()).get_identifier(),
              it));
      }
    }

    // declare (and, if necessary, define) locals
    for(localst::const_iterator l_it=locals.begin();
        l_it!=locals.end();
        l_it++)
    {
      goto_programt::targett ref_instr=dest.instructions.begin();
      bool has_decl=false;
      ::std::map< irep_idt, goto_programt::targett >::const_iterator entry=
        available_decls.find(l_it->first);
      if(available_decls.end() != entry) {
        ref_instr=entry->second;
        has_decl=true;
      }
      
      goto_programt tmp;
      make_decl_and_def(tmp, ref_instr, l_it->second); 

      if(has_decl) {
        goto_programt::targett next(ref_instr);
        ++next;
        dest.destructive_insert(next, tmp);
      } else {
        dest.destructive_insert(ref_instr, tmp);
      }
    }
  }

  locals.clear();
}

/*******************************************************************\

Function: string_abstractiont::make_dummy_rec

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::make_dummy_rec(goto_programt &dest,
    goto_programt::targett ref_instr,
    const symbolt &symbol)
{
  std::string suffix="$strdummy";
  
  exprt result;
  result.make_nil();
  
  const typet &eff_type=ns.follow(symbol.type);

  if(eff_type.id()=="array" || eff_type.id()=="pointer")
  {
    irep_idt dummy_identifier=id2string(symbol.name)+suffix;
    symbolt new_symbol;
    new_symbol.name=dummy_identifier;
    new_symbol.mode=symbol.mode;
    new_symbol.is_statevar=true;
    new_symbol.lvalue=true;
    new_symbol.static_lifetime=false;
    new_symbol.pretty_name=id2string(symbol.pretty_name)+suffix;
    new_symbol.module=symbol.module;
    new_symbol.base_name=id2string(symbol.base_name)+suffix;
    new_symbol.type=eff_type.subtype();
  
    // make sure it is declared before the recursive call
    goto_programt::targett decl=dest.add_instruction();
    decl->make_other();
    decl->location=ref_instr->location;
    decl->function=ref_instr->function;
    decl->code=code_declt(symbol_expr(new_symbol));
    decl->code.location()=ref_instr->location;
    
    // set the value - may be nil
    new_symbol.value=make_dummy_rec(dest, ref_instr, new_symbol);
    
    if(new_symbol.value.is_not_nil())
    {
      goto_programt::targett assignment1=dest.add_instruction(ASSIGN);
      assignment1->location=ref_instr->location;
      assignment1->function=ref_instr->function;
      assignment1->code=code_assignt(symbol_expr(new_symbol), new_symbol.value);
      assignment1->code.location()=ref_instr->location;
    }
      
    if(eff_type.id()=="array")
      result=exprt("array_of", eff_type);
    else
      result=exprt("address_of", eff_type);
    result.copy_to_operands(symbol_expr(new_symbol));
    
    context.move(new_symbol);
  }
  else if(eff_type.id()=="struct" || eff_type.id()=="union")
  {
    const struct_union_typet &struct_union_type=to_struct_union_type(eff_type);
    const struct_union_typet::componentst &components=struct_union_type.components();

    struct_union_typet::componentst new_comp;
    for(struct_union_typet::componentst::const_iterator
        it=components.begin();
        it!=components.end();
        it++)
    {
      const typet &eff_sub_type=ns.follow(it->type());
      if(eff_sub_type.id() != "pointer" &&
          eff_sub_type.id() != "array" &&
          eff_sub_type.id() != "struct" &&
          eff_sub_type.id() != "union")
        continue;

      irep_idt dummy_identifier=id2string(symbol.name)+"#"+id2string(it->get_name())+suffix;
      symbolt new_symbol;
      new_symbol.name=dummy_identifier;
      new_symbol.mode=symbol.mode;
      new_symbol.is_statevar=true;
      new_symbol.lvalue=true;
      new_symbol.static_lifetime=false;
      new_symbol.pretty_name=id2string(symbol.pretty_name)+"#"+id2string(it->get_name())+suffix;
      new_symbol.module=symbol.module;
      new_symbol.base_name=id2string(symbol.base_name)+"#"+id2string(it->get_name())+suffix;
      new_symbol.type=it->type();
      
      // make sure it is declared before the recursive call
      goto_programt::targett decl=dest.add_instruction();
      decl->make_other();
      decl->location=ref_instr->location;
      decl->function=ref_instr->function;
      decl->code=code_declt(symbol_expr(new_symbol));
      decl->code.location()=ref_instr->location;
      
      // set the value - may be nil
      new_symbol.value=make_dummy_rec(dest, ref_instr, new_symbol);

      if(new_symbol.value.is_not_nil())
      {
        goto_programt::targett assignment1=dest.add_instruction(ASSIGN);
        assignment1->location=ref_instr->location;
        assignment1->function=ref_instr->function;
        assignment1->code=code_assignt(symbol_expr(new_symbol), new_symbol.value);
        assignment1->code.location()=ref_instr->location;
      }

      exprt member("member", it->type());
      member.set("component_name", it->get_name());
      member.copy_to_operands(symbol_expr(symbol));
        
      goto_programt::targett assignment1=dest.add_instruction(ASSIGN);
      assignment1->location=ref_instr->location;
      assignment1->function=ref_instr->function;
      assignment1->code=code_assignt(member, symbol_expr(new_symbol));
      assignment1->code.location()=ref_instr->location;
      
      context.move(new_symbol);
    }
  }

  return result;
}
      
/*******************************************************************\

Function: string_abstractiont::make_decl_and_def

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::make_decl_and_def(goto_programt &dest,
    goto_programt::targett ref_instr,
    const irep_idt &identifier)
{
  const symbolt &symbol=ns.lookup(identifier);

  goto_programt::targett decl1=dest.add_instruction();
  decl1->make_other();
  decl1->location=ref_instr->location;
  decl1->function=ref_instr->function;
  decl1->code=code_declt(symbol_expr(symbol));
  decl1->code.location()=ref_instr->location;

  exprt val=symbol.value;
  if(val.is_nil())
    val=make_dummy_rec(dest, ref_instr, symbol);

  // may still be nil (structs, then assignments have been done already)
  if(val.is_not_nil())
  {
    goto_programt::targett assignment1=dest.add_instruction(ASSIGN);
    assignment1->location=ref_instr->location;
    assignment1->function=ref_instr->function;
    assignment1->code=code_assignt(symbol_expr(symbol), val);
    assignment1->code.location()=ref_instr->location;
  }
}

/*******************************************************************\

Function: string_abstractiont::abstract

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

goto_programt::targett string_abstractiont::abstract(
  goto_programt &dest,
  goto_programt::targett it)
{
  switch(it->type)
  {
  case ASSIGN:
    it=abstract_assign(dest, it);
    break;
    
  case GOTO:
  case ASSERT:
  case ASSUME:
    if(has_string_macros(it->guard))
      replace_string_macros(it->guard, false, it->location);
    break;
    
  case FUNCTION_CALL:
    abstract_function_call(dest, it);
    break;
    
  case RETURN:
    it=abstract_return(dest, it);
    break;
    
  default:;  
  }

  return it;
}

/*******************************************************************\

Function: string_abstractiont::has_string_macros

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool string_abstractiont::has_string_macros(const exprt &expr)
{
  if(expr.id()=="is_zero_string" ||
     expr.id()=="zero_string_length" ||
     expr.id()=="buffer_size")
    return true;

  forall_operands(it, expr)
    if(has_string_macros(*it))
      return true;

  return false;
}

/*******************************************************************\

Function: string_abstractiont::replace_string_macros

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::replace_string_macros(
  exprt &expr,
  bool lhs,
  const locationt &location)
{
  if(expr.id()=="is_zero_string")
  {
    assert(expr.operands().size()==1);
    exprt tmp=is_zero_string(expr.op0(), lhs, location);
    expr.swap(tmp);
  }
  else if(expr.id()=="zero_string_length")
  {
    assert(expr.operands().size()==1);
    exprt tmp=zero_string_length(expr.op0(), lhs, location);
    expr.swap(tmp);
  }
  else if(expr.id()=="buffer_size")
  {
    assert(expr.operands().size()==1);
    exprt tmp=buffer_size(expr.op0(), location);
    expr.swap(tmp);
  }
  else
    Forall_operands(it, expr)
      replace_string_macros(*it, lhs, location);
}

/*******************************************************************\

Function: string_abstractiont::build_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

typet string_abstractiont::build_type(whatt what)
{
  typet type;

  switch(what)
  {
  case IS_ZERO: type=bool_typet(); break;
  case LENGTH:  type=uint_type(); break;
  case SIZE:    type=uint_type(); break;
  }

  return type;
}

/*******************************************************************\

Function: string_abstractiont::build_unknown

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::build_unknown(whatt what, bool write)
{
  typet type=build_type(what);

  if(write)
    return exprt("NULL-object", type);

  exprt result;

  switch(what)
  {
  case IS_ZERO:
    result=false_exprt();
    break;

  case LENGTH:
  case SIZE:
    result=exprt("sideeffect", type);
    result.set("statement", "nondet");
    break;
  }

  return result;
}

/*******************************************************************\

Function: string_abstractiont::build_unknown

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::build_unknown(const typet &type, bool write)
{
  if(write)
    return exprt("NULL-object", type);

  // create an uninitialized dummy symbol
  // because of a lack of contextual information we can't build a nice name
  // here, but moving that into locals should suffice for proper operation
  irep_idt identifier="$tmp::nondet_str#str$"+i2string(++temporary_counter);
  // ensure decl and initialization
  locals[identifier]=identifier;

  symbolt new_symbol;
  new_symbol.name=identifier;
  new_symbol.mode="C";
  new_symbol.type=type;
  new_symbol.is_statevar=true;
  new_symbol.lvalue=true;
  new_symbol.static_lifetime=false;
  new_symbol.pretty_name=identifier;
  new_symbol.module="$tmp";
  new_symbol.base_name=identifier;

  context.move(new_symbol);

  const symbolt &str_symbol=ns.lookup(identifier);

  return symbol_expr(str_symbol);
}

/*******************************************************************\

Function: string_abstractiont::build

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::build(
  const exprt &pointer,
  whatt what,
  bool write,
  const locationt &location)
{
  // take care of pointer typecasts now
  if(pointer.id()=="typecast")
  {
    // cast from another pointer type?
    assert(pointer.operands().size()==1);
    if(pointer.op0().type().id()!="pointer")
      return build_unknown(what, write);

    // recursive call
    return build(pointer.op0(), what, write, location);
  }

  exprt str_struct;
  if(build(pointer, str_struct, write)) assert(false);

  exprt result=member(str_struct, what);

  if(what==LENGTH || what==SIZE)
  {
    // adjust for offset
    exprt pointer_offset("pointer_offset", uint_type());
    pointer_offset.copy_to_operands(pointer);
    result=sub(result, pointer_offset);
  }

  return result;
}

/*******************************************************************\

Function: string_abstractiont::build_symbol

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool string_abstractiont::build_symbol(const exprt &object, exprt &dest)
{
  std::string suffix="#str";
  
  assert(object.id()=="symbol");

  const symbol_exprt &expr_symbol=to_symbol_expr(object);

  const symbolt &symbol=ns.lookup(expr_symbol.get_identifier());
  irep_idt identifier=id2string(symbol.name)+suffix;

  const typet &abstract_type=build_abstraction_type(symbol.type);
  assert(!abstract_type.is_nil());

  if(current_args.find(symbol.name)!=current_args.end())
  {
    irep_idt identifier=id2string(symbol.name)+"#strarg";
    const symbolt &str_symbol=ns.lookup(identifier);
    dest=symbol_expr(str_symbol);
    /*assert(str_symbol.type.id()=="pointer");
    dest=dereference_exprt(abstract_type);
    dest.op0()=symbol_expr(str_symbol);
    */

    return false;
  }
  else if(context.symbols.find(identifier)==
     context.symbols.end())
  {
    if(!symbol.static_lifetime)
      locals[symbol.name]=identifier;

    symbolt new_symbol;
    new_symbol.name=identifier;
    new_symbol.mode=symbol.mode;
    new_symbol.type=abstract_type;
    new_symbol.is_statevar=true;
    new_symbol.lvalue=true;
    new_symbol.static_lifetime=symbol.static_lifetime;
    new_symbol.thread_local=symbol.thread_local;
    new_symbol.pretty_name=id2string(symbol.pretty_name)+suffix;
    new_symbol.module=symbol.module;
    new_symbol.base_name=id2string(symbol.base_name)+suffix;
    new_symbol.value.make_nil();

    const typet &eff_t=ns.follow(symbol.type);
    if(eff_t.id()=="array" && is_char_type(eff_t.subtype()))
    {
      exprt value=exprt("struct", string_struct);
      value.operands().resize(3);
      value.op0()=build_unknown(IS_ZERO, false);
      value.op1()=build_unknown(LENGTH, false);
      value.op2()=to_array_type(eff_t).size();
      make_type(value.op2(), build_type(SIZE));

      new_symbol.value=value;

      if(symbol.static_lifetime)
      {
        // initialization
        goto_programt::targett assignment1=
          initialization.add_instruction(ASSIGN);
        assignment1->code=code_assignt(symbol_expr(new_symbol), new_symbol.value);
      }
    }

    context.move(new_symbol);
    
    if(symbol.static_lifetime) {
      goto_programt::targett dummy_loc=initialization.add_instruction(SKIP);
      dummy_loc->location=symbol.location;
      make_decl_and_def(initialization, dummy_loc, identifier);
      initialization.instructions.erase(dummy_loc);
    }
  }

  const symbolt &str_symbol=ns.lookup(identifier);
  dest=symbol_expr(str_symbol);

  return false;
}

/*******************************************************************\

Function: string_abstractiont::build

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool string_abstractiont::build(const exprt &object, exprt &dest, bool write)
{
  // take care of typecasts
  if(object.id()=="typecast")
  {
    // recursive call
    return build(object.op0(), dest, write);
  }
 
  const typet &abstract_type=build_abstraction_type(object.type());
  if(abstract_type.is_nil()) return true;

  // take care of if
  if(object.id()=="if")
  {
    dest=if_exprt();

    // recursive calls
    dest.op0()=object.op0();
    bool op1_err=build(object.op1(), dest.op1(), write);
    bool op2_err=build(object.op2(), dest.op2(), write);
    if(op1_err && op2_err) return true;
    // at least one of them gave proper results
    if(op1_err)
    {
      dest.type()=dest.op2().type();
      dest.op1()=build_unknown(dest.type(), write);
    }
    if(op2_err)
    {
      dest.type()=dest.op1().type();
      dest.op2()=build_unknown(dest.type(), write);
    }
      
    return false;
  }
  
  if(object.id()=="string-constant")
    return build_symbol_constant(object.get("value"), dest);

  // other constants aren't useful
  if(object.is_constant())
    return true;
 
  if(object.id()=="symbol")
    return build_symbol(object, dest);

  if(object.id()=="member")
  {
    const typet &member_type=build_abstraction_type(object.type());
    assert(!member_type.is_nil());
    dest=exprt("member", abstract_type);
    dest.set("component_name", object.get("component_name"));
    
    assert(object.operands().size()==1);
    exprt parent;
    if(build(object.op0(), parent, write)) return true;

    dest.copy_to_operands(parent);
    return false;
  }

  if(object.id()=="dereference")
  {
    assert(object.operands().size()==1);
    if(build(object.op0(), dest, write)) return true;

    exprt deref=dereference_exprt(abstract_type);
    deref.op0().swap(dest);
    dest=deref;
    return false;
  }

  if(object.id()=="index")
  {
    assert(object.operands().size()==2);

    index_exprt result;
    if(build(object.op0(), result.array(), write)) return true;

    result.index()=object.op1();
    result.type()=abstract_type;
    dest=result;

    return false;
  }

  // handle pointer stuff
  if(object.type().id()=="pointer")
  {
    pointer_arithmetict ptr(object);
    if(ptr.pointer.id()=="address_of")
    {
      // writing is invalid
      if(write) return true;

      if(ptr.pointer.op0().id()=="index" &&
          ptr.pointer.op0().op0().id()=="string-constant")
        return build_symbol_constant(ptr.pointer.op0().op0().get("value"), dest);
      else if(ptr.pointer.op0().id()=="index" &&
          is_char_type(ptr.pointer.op0().type()))
        return build_symbol(ptr.pointer.op0().op0(), dest);
  
      // recursive call
      if(build(ptr.pointer.op0(), dest, write)) return true;
      
      exprt addr_of=exprt("address_of", pointer_typet());
      addr_of.type().subtype()=dest.type();
      addr_of.copy_to_operands(dest);
      dest=addr_of;
      return false;
    }
    else if(ptr.pointer.id()=="symbol" &&
        is_char_type(object.type().subtype()))
    {
      // recursive call; offset will be handled by pointer_offset in SIZE/LENGTH
      // checks
      if(build(ptr.pointer, dest, write)) return true;

      return false;
    }
    else
    {
      // declaration
    }

    // we don't handle other pointer arithmetic
    return true;
  }

  return true;
}

/*******************************************************************\

Function: string_abstractiont::build_symbol_constant

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool string_abstractiont::build_symbol_constant(const irep_idt &str, exprt &dest)
{
  unsigned l=strlen(str.c_str());
  irep_idt base="string_constant_str_"+i2string(l);
  irep_idt identifier="string_abstraction::"+id2string(base);

  if(context.symbols.find(identifier)==
     context.symbols.end())
  {
    symbolt new_symbol;
    new_symbol.name=identifier;
    new_symbol.mode="C";
    new_symbol.type=string_struct;
    new_symbol.is_statevar=true;
    new_symbol.lvalue=true;
    new_symbol.static_lifetime=true;
    new_symbol.pretty_name=base;
    new_symbol.base_name=base;

    {
      exprt value=exprt("struct", string_struct);
      value.operands().resize(3);

      value.op0()=true_exprt();
      value.op1()=from_integer(l, build_type(LENGTH));
      value.op2()=from_integer(l+1, build_type(SIZE));

      // initialization
      goto_programt::targett assignment1=initialization.add_instruction(ASSIGN);
      assignment1->code=code_assignt(symbol_expr(new_symbol), value);
    }

    context.move(new_symbol);
  }

  symbol_exprt symbol_expr;
  symbol_expr.type()=string_struct;
  symbol_expr.set_identifier(identifier);
  dest=symbol_expr;

  return false;
}

/*******************************************************************\

Function: string_abstractiont::is_zero_string

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::is_zero_string(
  const exprt &object,
  bool write,
  const locationt &location)
{
  return build(object, IS_ZERO, write, location);
}

/*******************************************************************\

Function: string_abstractiont::zero_string_length

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::zero_string_length(
  const exprt &object,
  bool write,
  const locationt &location)
{
  return build(object, LENGTH, write, location);
}

/*******************************************************************\

Function: string_abstractiont::buffer_size

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt string_abstractiont::buffer_size(
  const exprt &object,
  const locationt &location)
{
  return build(object, SIZE, false, location);
}

/*******************************************************************\

Function: string_abstractiont::move_lhs_arithmetic

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::move_lhs_arithmetic(exprt &lhs, exprt &rhs)
{
  if(lhs.id()=="-")
  {
    // move op1 to rhs
    exprt rest=lhs.op0();
    exprt sum=exprt("+", lhs.type());
    sum.copy_to_operands(rhs, lhs.op1());
    // overwrite
    rhs=sum;
    lhs=rest;
  }
}

/*******************************************************************\

Function: string_abstractiont::abstract_assign

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

goto_programt::targett string_abstractiont::abstract_assign(
  goto_programt &dest,
  goto_programt::targett target)
{
  code_assignt &assign=to_code_assign(target->code);

  exprt &lhs=assign.lhs();
  exprt &rhs=assign.rhs();
  
  if(has_string_macros(lhs))
  {
    replace_string_macros(lhs, true, target->location);
    move_lhs_arithmetic(lhs, rhs);
  }

  if(has_string_macros(rhs))
    replace_string_macros(rhs, false, target->location);

  const typet &type=ns.follow(lhs.type());
  if(type.id()=="pointer" || type.id()=="array")
    return abstract_pointer_assign(dest, target);
  else if(is_char_type(type))
    abstract_char_assign(dest, target);

  return target;
}

/*******************************************************************\

Function: string_abstractiont::abstract_pointer_assign

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

goto_programt::targett string_abstractiont::abstract_pointer_assign(
  goto_programt &dest,
  goto_programt::targett target)
{
  code_assignt &assign=to_code_assign(target->code);

  exprt &lhs=assign.lhs();
  exprt rhs=assign.rhs();
  exprt *rhsp=&(assign.rhs());

  while(rhsp->id()=="typecast")
    rhsp=&(rhsp->op0());
  
  //// ::std::cerr << "Processing: " << ::std::endl;
  //// dest.output_instruction(ns, "", ::std::cerr, target);
 
  const typet& abstract_type=build_abstraction_type(lhs.type());
  if(abstract_type.is_nil()) return target;
 
  exprt new_lhs, new_rhs;
  if(build(lhs, new_lhs, true)) return target;

  if(abstract_type!=build_abstraction_type(rhsp->type()) ||
      build(rhs, new_rhs, false))
    new_rhs=build_unknown(abstract_type, false);
  
  return value_assignments(dest, target, new_lhs, new_rhs);
}

/*******************************************************************\

Function: string_abstractiont::abstract_char_assign

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::abstract_char_assign(
  goto_programt &dest,
  goto_programt::targett target)
{
  code_assignt &assign=to_code_assign(target->code);

  exprt &lhs=assign.lhs();
  exprt &rhs=assign.rhs();

  // we only care if the constant zero is assigned
  if(!rhs.is_zero())
    return;

  // index into a character array
  if(lhs.id()=="index")
  {
    assert(lhs.operands().size()==2);

    goto_programt tmp;

    exprt new_lhs;
    if(!build(lhs.op0(), new_lhs, true))
    {
      const exprt i1=member(new_lhs, IS_ZERO);
      assert(i1.is_not_nil());
      
      goto_programt::targett assignment1=tmp.add_instruction(ASSIGN);
      assignment1->code=code_assignt(i1, true_exprt());
      assignment1->code.location()=target->location;
      assignment1->function=target->function;
      assignment1->location=target->location;

      const exprt i2=member(new_lhs, LENGTH);
      assert(i2.is_not_nil());
      
      exprt new_length=lhs.op1();
      make_type(new_length, i2.type());

      if_exprt min_expr;
      min_expr.cond()=binary_relation_exprt(new_length, "<", i2);
      min_expr.true_case()=new_length;
      min_expr.false_case()=i2;
      min_expr.type()=i2.type();

      goto_programt::targett assignment2=tmp.add_instruction(ASSIGN);
      assignment2->code=code_assignt(i2, min_expr);
      assignment2->code.location()=target->location;
      assignment2->function=target->function;
      assignment2->location=target->location;

      move_lhs_arithmetic(
       assignment2->code.op0(),
       assignment2->code.op1());
    }

    target++;
    dest.destructive_insert(target, tmp);
  }
  else if(lhs.id()=="dereference")
  {
    assert(lhs.operands().size()==1);
    
    goto_programt tmp;

    pointer_arithmetict ptr(lhs.op0());
    exprt new_lhs;
    
    if(!build(ptr.pointer, new_lhs, true))
    {
      const exprt i1=member(new_lhs, IS_ZERO);
      assert(i1.is_not_nil());
      
      goto_programt::targett assignment1=tmp.add_instruction(ASSIGN);
      assignment1->code=code_assignt(i1, true_exprt());
      assignment1->code.location()=target->location;
      assignment1->function=target->function;
      assignment1->location=target->location;

      const exprt i2=member(new_lhs, LENGTH);
      assert(i2.is_not_nil());
      
      goto_programt::targett assignment2=tmp.add_instruction(ASSIGN);
      make_type(ptr.offset, build_type(LENGTH));
      assignment2->code=code_assignt(i2, ptr.offset.is_nil()?gen_zero(build_type(LENGTH)):ptr.offset);
      assignment2->code.location()=target->location;
      assignment2->function=target->function;
      assignment2->location=target->location;

      move_lhs_arithmetic(
       assignment2->code.op0(),
       assignment2->code.op1());
    }

    target++;
    dest.destructive_insert(target, tmp);
  }
}

/*******************************************************************\

Function: string_abstractiont::abstract_function_call

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::abstract_function_call(
  goto_programt &dest,
  goto_programt::targett target)
{
  code_function_callt &call=to_code_function_call(target->code);
  code_function_callt::argumentst &arguments=call.arguments();
  code_function_callt::argumentst str_args;
   
  const symbolt &fct_symbol=ns.lookup(call.function().get("identifier"));
  const code_typet::argumentst &formal_params=
    to_code_type(fct_symbol.type).arguments();
  
  exprt::operandst::const_iterator it1=arguments.begin();
  for(code_typet::argumentst::const_iterator it2=formal_params.begin();
      it2!=formal_params.end();
      it2++, it1++)
  {
    const typet &abstract_type=build_abstraction_type(it2->type());
    if(!abstract_type.is_nil())
    {
      if(it1==arguments.end())
      {
        err_location(target->location);
        throw "function call: not enough arguments";
      }
 
      exprt new_arg;
      // if function takes void*, build for *it1 will fail if actual parameter
      // is of some other pointer type; then just introduce an unknown
      if(build(*it1, new_arg, false))
        new_arg=build_unknown(abstract_type, false);
      str_args.push_back(new_arg);
      // array -> pointer translation
      if(str_args.back().type().id()=="array" &&
          abstract_type.id()=="pointer")
      {
          exprt index_expr("index", str_args.back().type().subtype());
          index_expr.copy_to_operands(str_args.back(), gen_zero(index_type()));

          // disable bounds check on that one
          index_expr.set("bounds_check", false);
    
          str_args.back()=exprt("address_of", abstract_type);
          str_args.back().move_to_operands(index_expr);
      }
      /*
      // make pointers
      exprt addr_of=exprt("address_of", pointer_typet());
      addr_of.type().subtype()=abstract_type;
      addr_of.copy_to_operands(str_args.back());
      str_args.back().swap(addr_of);
      */
    }
  }
  
  const typet &abstract_ret_type=build_abstraction_type(
      to_code_type(fct_symbol.type).return_type());
  if(!abstract_ret_type.is_nil())
  {
    const exprt &lhs = call.lhs();
    if(lhs.is_not_nil()) {
      assert(!build_abstraction_type(lhs.type()).is_nil());
      exprt addr_of=exprt("address_of", pointer_typet());
      addr_of.type().subtype()=abstract_ret_type;
      exprt new_lhs;
      if(build(lhs, new_lhs, false)) assert(false);
      addr_of.copy_to_operands(new_lhs);
      str_args.push_back(addr_of);
    } else {
      const symbolt &curr_fct_symbol=ns.lookup(target->function);
      irep_idt base_name="return_value_"+id2string(fct_symbol.base_name)+"$"+i2string(++temporary_counter);
      irep_idt str_base_name=id2string(base_name)+"#str";
      irep_idt identifier=id2string(curr_fct_symbol.name)+"::$tmp::"+id2string(base_name);
      irep_idt str_identifier=id2string(identifier)+"#str";
      if(context.symbols.find(str_identifier)==
         context.symbols.end())
      {
        locals[identifier]=str_identifier;
    
        symbolt new_symbol;
        new_symbol.name=str_identifier;
        new_symbol.mode=curr_fct_symbol.mode;
        new_symbol.type=abstract_ret_type;
        new_symbol.is_statevar=true;
        new_symbol.lvalue=true;
        new_symbol.static_lifetime=false;
        new_symbol.pretty_name=str_identifier;
        new_symbol.module=curr_fct_symbol.module;
        new_symbol.base_name=str_base_name;

        context.move(new_symbol);
      }
      const symbolt &str_symbol=ns.lookup(str_identifier);
      exprt addr_of=exprt("address_of", pointer_typet());
      addr_of.type().subtype()=abstract_ret_type;
      addr_of.copy_to_operands(symbol_expr(str_symbol));
      str_args.push_back(addr_of);
    }
  }

  arguments.insert(arguments.end(), str_args.begin(), str_args.end());
}

/*******************************************************************\

Function: string_abstractiont::abstract_return

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

goto_programt::targett string_abstractiont::abstract_return(
  goto_programt &dest,
  goto_programt::targett target)
{
  code_returnt &ret=to_code_return(target->code);
  
  if(!ret.has_return_value())
    return target;

  exprt &retval=ret.return_value();

  replace_string_macros(retval, false, target->location);
  
  const symbolt &fct_symbol=ns.lookup(target->function);
  const typet &abstract_ret_type=build_abstraction_type(
      to_code_type(fct_symbol.type).return_type());
  if(!abstract_ret_type.is_nil())
  {
    irep_idt identifier="c::"+id2string(fct_symbol.module)+"::"+id2string(fct_symbol.base_name)+"::"+"$return_value_str_abst#strarg";
    const symbolt &str_symbol=ns.lookup(identifier);
    exprt lhs_deref=dereference_exprt(str_symbol.type.subtype());
    lhs_deref.op0()=symbol_expr(str_symbol);
    lhs_deref.location()=target->location;
  
    exprt new_retval;
    // may fail if returning a constant like NULL
    if(build(retval, new_retval, false))
      new_retval=build_unknown(abstract_ret_type, false);

    target=value_assignments(dest, target, lhs_deref, new_retval);
  }

  return target;
}
  
/*******************************************************************\

Function: string_abstractiont::value_assignments

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

goto_programt::targett string_abstractiont::value_assignments(
    goto_programt &dest,
    goto_programt::targett target,
    const exprt& lhs, const exprt& rhs)
{
  if(rhs.id()=="if")
  {
    goto_programt tmp;

    goto_programt::targett goto_else=tmp.add_instruction(GOTO);
    goto_programt::targett goto_out=tmp.add_instruction(GOTO);
    goto_programt::targett else_target=tmp.add_instruction(SKIP);
    goto_programt::targett out_target=tmp.add_instruction(SKIP);
    
    goto_else->function=target->function;
    goto_else->location=target->location;
    goto_else->make_goto(else_target);
    goto_else->guard=rhs.op0();
    goto_else->guard.make_not();
    
    goto_out->function=target->function;
    goto_out->location=target->location;
    goto_out->make_goto(out_target);
    goto_out->guard.make_true();
    
    else_target->function=target->function;
    else_target->location=target->location;
    
    out_target->function=target->function;
    out_target->location=target->location;
      
    value_assignments(tmp, goto_out, lhs, rhs.op1());
    value_assignments(tmp, else_target, lhs, rhs.op2());
  
    goto_programt::targett skip=tmp.add_instruction(SKIP);
    skip->function=target->function;
    skip->location=target->location;
    skip->swap(*target);

    target++;
    dest.destructive_insert(target, tmp);
    target--;

    return target;
  }
  
  if(!type_eq(lhs.type(), rhs.type(), ns)) {
    //// dest.output_instruction(ns, "", ::std::cerr, target);
    //// ::std::cerr << "LHS-type: " << lhs.type().pretty() << ::std::endl;
    //// ::std::cerr << "RHS-type: " << rhs.type().pretty() << ::std::endl;
    //// ::std::cerr << "LHS: " << lhs.pretty() << ::std::endl;
    //// ::std::cerr << "RHS: " << rhs.pretty() << ::std::endl;
    assert(false);
  }
  
  if(lhs.type().id()=="array")
  {
    mp_integer size;
    // don't do anything, if we cannot determine the size
    if (to_integer(to_array_type(lhs.type()).size(), size)) return target;
    for(mp_integer i=0; i<size; ++i)
    {
      index_exprt lhs_idx;
      lhs_idx.array()=lhs;
      lhs_idx.index()=from_integer(i, to_array_type(lhs.type()).size().type());
      lhs_idx.type()=lhs.type().subtype();
      lhs_idx.location()=target->location;
      
      index_exprt rhs_idx;
      rhs_idx.array()=rhs;
      rhs_idx.index()=from_integer(i, to_array_type(lhs.type()).size().type());
      rhs_idx.type()=rhs.type().subtype();
      rhs_idx.location()=target->location;

      target=value_assignments(dest, target, lhs_idx, rhs_idx);
    }
    return target;
  }
  else if(lhs.type().id()=="pointer")
  {
    exprt lhs_deref=dereference_exprt(lhs.type().subtype());
    lhs_deref.op0()=lhs;
    lhs_deref.location()=target->location;

    exprt rhs_deref=dereference_exprt(rhs.type().subtype());
    rhs_deref.op0()=rhs;
    rhs_deref.location()=target->location;

    return value_assignments(dest, target, lhs_deref, rhs_deref);
  }
  else if(lhs.type()==string_struct)
  {
    // copy all the values
    goto_programt tmp;

    {
      goto_programt::targett assignment=tmp.add_instruction(ASSIGN);
      assignment->code=code_assignt(
          member(lhs, IS_ZERO),
          member(rhs, IS_ZERO));
      assignment->code.location()=target->location;
      assignment->function=target->function;
      assignment->location=target->location;
    }

    {
      goto_programt::targett assignment=tmp.add_instruction(ASSIGN);
      assignment->code=code_assignt(
          member(lhs, LENGTH),
          member(rhs, LENGTH));
      assignment->code.location()=target->location;
      assignment->function=target->function;
      assignment->location=target->location;
    }

    {
      goto_programt::targett assignment=tmp.add_instruction(ASSIGN);
      assignment->code=code_assignt(
          member(lhs, SIZE),
          member(rhs, SIZE));
      assignment->code.location()=target->location;
      assignment->function=target->function;
      assignment->location=target->location;
    }
    
    goto_programt::targett skip=tmp.add_instruction(SKIP);
    skip->function=target->function;
    skip->location=target->location;
    skip->swap(*target);

    target++;
    dest.destructive_insert(target, tmp);
    target--;

    return target;
  }
  else if(lhs.type().id()=="struct" || lhs.type().id()=="union")
  {
    const struct_union_typet &struct_union_type=to_struct_union_type(lhs.type());
    const struct_union_typet::componentst &components=struct_union_type.components();

    for(struct_union_typet::componentst::const_iterator
        it=components.begin();
        it!=components.end();
        it++)
    {
      assert(it->get_name()!="");
      
      exprt lhs_member("member", it->type());
      lhs_member.copy_to_operands(lhs);
      lhs_member.set("component_name", it->get_name());
      
      exprt rhs_member("member", it->type());
      rhs_member.copy_to_operands(rhs);
      rhs_member.set("component_name", it->get_name());

      target=value_assignments(dest, target, lhs_member, rhs_member);
    }

    return target;
  }

  return target;
}
  
/*******************************************************************\

Function: string_abstractiont::add_str_arguments

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void string_abstractiont::add_str_arguments(
    const irep_idt & name,
    goto_functionst::goto_functiont &fct)
{
  std::string suffix="#strarg";
   
  symbolst::iterator ctx_entry(context.symbols.find(name));
  if(context.symbols.end()==ctx_entry)
    throw "function symbol lookup failed";
  symbolt &fct_symbol=ctx_entry->second;
  
  code_typet::argumentst &arguments=
    to_code_type(fct.type).arguments();
  code_typet::argumentst str_args;

  for(code_typet::argumentst::iterator it=arguments.begin();
      it!=arguments.end();
      it++)
  {
    const typet &abstract_type=build_abstraction_type(it->type());
    if(!abstract_type.is_nil())
    {
      const irep_idt &identifier=it->get_identifier();
      
      if(identifier=="") continue; // ignore
      
      /*typet type=pointer_typet();
      type.subtype()=abstract_type;
      */
      typet type=abstract_type;

      str_args.push_back(code_typet::argumentt(type));
      str_args.back().location()=it->location();
      str_args.back().set_base_name(id2string(it->get_base_name())+suffix);
      str_args.back().set_identifier(id2string(identifier)+suffix);
      current_args.insert(identifier);
    
      symbolt new_symbol;
      new_symbol.name=str_args.back().get_identifier();
      new_symbol.mode=fct_symbol.mode;
      new_symbol.type=type;
      new_symbol.is_statevar=true;
      new_symbol.lvalue=true;
      new_symbol.static_lifetime=false;
      new_symbol.pretty_name=str_args.back().get_base_name();
      new_symbol.base_name=str_args.back().get_base_name();

      context.move(new_symbol);
    }
  }
 
  const typet &abstract_ret_type=build_abstraction_type(
      to_code_type(fct.type).return_type());
  if(!abstract_ret_type.is_nil())
  {
    typet type=pointer_typet();
    type.subtype()=abstract_ret_type;

    str_args.push_back(code_typet::argumentt(type));
    str_args.back().set_base_name("$return_value_str_abst"+suffix);
    str_args.back().set_identifier("c::" + id2string(fct_symbol.module)+"::"+id2string(fct_symbol.base_name)+"::"+"$return_value_str_abst"+suffix);
    
    symbolt new_symbol;
    new_symbol.name=str_args.back().get_identifier();
    new_symbol.mode=fct_symbol.mode;
    new_symbol.type=type;
    new_symbol.is_statevar=true;
    new_symbol.lvalue=true;
    new_symbol.static_lifetime=false;
    new_symbol.pretty_name=str_args.back().get_base_name();
    new_symbol.base_name=str_args.back().get_base_name();

    context.move(new_symbol);
  }

  arguments.insert(arguments.end(), str_args.begin(), str_args.end());
  code_typet::argumentst &symb_arguments=
    to_code_type(fct_symbol.type).arguments();
  symb_arguments.insert(symb_arguments.end(), str_args.begin(), str_args.end());
}

/*******************************************************************\

Function: string_abstractiont::build_abstraction_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

const typet& string_abstractiont::build_abstraction_type(const typet &type)
{
  const typet &eff_type=ns.follow(type);
  ::std::pair< abstraction_types_mapt::iterator, bool > map_entry(
      abstraction_types_map.insert(::std::make_pair(
          type, typet("nil"))));
  if(!map_entry.second) return map_entry.first->second;

  if(eff_type.id()=="array")
  {
    if(is_char_type(eff_type.subtype()))
    {
      map_entry.first->second=string_struct;
    }
    else
    {
      const typet& subt=build_abstraction_type(eff_type.subtype());
      if(!subt.is_nil())
      {
        array_typet new_type;
        new_type.size()=to_array_type(eff_type).size();
        new_type.subtype()=subt;
        map_entry.first->second=new_type;
      }
    }
  }
  else if(eff_type.id()=="pointer")
  {
    // char* or void*
    if(is_char_type(eff_type.subtype()) || eff_type.subtype().id() == "empty")
    {
      map_entry.first->second=string_struct;
    }
    else
    {
      const typet& subt=build_abstraction_type(eff_type.subtype());
      if(!subt.is_nil())
      {
        typet type=pointer_typet();
        type.subtype()=subt;
        map_entry.first->second=type;
      }
    }
  }
  else if(eff_type.id()=="struct" || eff_type.id()=="union")
  {
    const struct_union_typet &struct_union_type=to_struct_union_type(eff_type);
    const struct_union_typet::componentst &components=struct_union_type.components();

    struct_union_typet::componentst new_comp;
    for(struct_union_typet::componentst::const_iterator
        it=components.begin();
        it!=components.end();
        it++)
    {
      if(it->get_name()=="") continue; // ignore anonymous members
      typet subt=build_abstraction_type(it->type());
      if(subt.is_nil()) continue; // also precludes structs with pointers to the same datatype
      new_comp.push_back(struct_union_typet::componentt());
      new_comp.back().set_name(it->get_name());
      new_comp.back().set("pretty_name", it->get("pretty_name"));
      new_comp.back().type()=subt;
    }
    if(!new_comp.empty())
    {
      struct_union_typet new_type;
      new_type.id(eff_type.id());
      new_type.components().swap(new_comp);
      map_entry.first->second=new_type;
    }
  }
  
  return map_entry.first->second;
}
