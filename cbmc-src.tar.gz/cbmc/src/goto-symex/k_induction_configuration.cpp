/*
 * k_induction_configuration.cpp
 *
 *  Created on: May 20, 2010
 *      Author: alad
 */

#include "k_induction_configuration.h"

void k_induction_configurationt::add_loop_invariants(CFGt& method, const namespacet ns)
{
	loop_infot program_loops(method);

	goto_programt instructions_to_add_to_each_header;
	make_instructions_for_invariant(instructions_to_add_to_each_header);

	if(0 == instructions_to_add_to_each_header.instructions.size())
	{
		// Nothing to do.
		return;
	}

	for(loop_infot::loopst::iterator it = program_loops.loops.begin(); it != program_loops.loops.end(); it++)
	{

		CFG_nodet* pointer_to_first_new_node = NULL;

		for(goto_programt::instructionst::iterator instructions_it = instructions_to_add_to_each_header.instructions.begin();
				instructions_it != instructions_to_add_to_each_header.instructions.end(); instructions_it++)
		{
			CFG_nodet new_node(*instructions_it);
			new_node.location = (*it)->header.location;
			new_node.function = (*it)->header.function;

			if(instructions_it == instructions_to_add_to_each_header.instructions.begin())
			{
				method.nodes.push_back(new_node);
				pointer_to_first_new_node = &(method.nodes.back());
			} else {
				method.append_node(new_node);
			}
		}

		assert(NULL != pointer_to_first_new_node);

		const CFG_nodet& header = (*it)->header;

		CFG_nodet* ptr_to_header = NULL;
		for(CFGt::nodest::iterator nodes_it = method.nodes.begin(); nodes_it != method.nodes.end(); nodes_it++)
		{
			if(nodes_it->successor_next == (&header))
			{
				nodes_it->successor_next = pointer_to_first_new_node;
			}

			if(nodes_it->successor_jump == (&header))
			{
				nodes_it->successor_jump = pointer_to_first_new_node;
			}

			if(&header == &(*nodes_it))
			{
				ptr_to_header = &(*nodes_it);
			}
		}

		assert(NULL != ptr_to_header);

		// Now we link the last node we added, to the header
		method.nodes.back().successor_next = ptr_to_header;

	}

}
