/*
 * k_induction.h
 *
 *  Created on: Sep 17, 2009
 *      Author: alad
 */

#ifndef K_INDUCTION_H_
#define K_INDUCTION_H_


#include <goto-programs/goto_functions.h>

#include <goto-programs/find_loops.h>


#include <util/namespace.h>

#include <cbmc/bmc.h>
#include <cbmc/parseoptions.h>

#include "k_induction_configuration.h"

#include "goto_symex.h"

extern unsigned int K_INDUCTION_DEPTH;
extern unsigned int STARTING_K;

class k_induction_enginet : public messaget
{

	k_induction_configurationt& configuration;
	contextt& context;
	cbmc_parseoptionst& cbmc_options;
	const goto_functionst& goto_functions; /* This is the goto functions for the original program under analysis */

public:

	k_induction_enginet(contextt& ctx, k_induction_configurationt& config, cbmc_parseoptionst& cbmc_options, const goto_functionst& goto_functions, message_handlert &_message_handler);

	loop_infot::loopt* analyse_main_loop(CFGt& control_flow_graph);

	void assemble_base_case(CFGt& base_case_CFG, const CFGt& control_flow_graph, loop_infot::loopt* outer_loop, const unsigned int k);

	void assemble_inductive_step(CFGt& step_case_CFG, const CFGt& control_flow_graph, CFGt::nodes_const_sett& loop_header_points, loop_infot::loopt* outer_loop, const unsigned int k);

	int do_bmc(bmc_baset &bmc, const goto_functionst &goto_functions);

	int try_k_induction(bmc_baset &bmc, CFGt& control_flow_graph);

private:
	int try_k_induction_recursive(bmc_baset &bmc, CFGt& control_flow_graph, const unsigned int nesting_level, bool base_case, CFGt::nodes_const_sett* loop_header_instruction_points = NULL);

};


void add_havoc_instruction(exprt lhs, CFGt& method, typet type);

void add_instructions_to_havoc_array(exprt array_expression, CFGt& method, const namespacet ns);



#endif /* K_INDUCTION_H_ */
