/*
 * k_induction.h
 *
 *  Created on: Sep 17, 2009
 *      Author: alad
 */

#ifndef K_INDUCTION_H_
#define K_INDUCTION_H_


#include <goto-programs/goto_functions.h>

#include <goto-programs/find_loops.h>

#include <util/namespace.h>

#include "k_induction_configuration.h"

class k_induction_enginet
{

	k_induction_configurationt& configuration;

	goto_programt loop_prefix;
	exprt loop_exit_condition;
	goto_programt loop_body;
	goto_programt loop_postfix;
	goto_programt::const_targett loop_exit_condition_instruction; // used to take location information from


	void compute_prefix(goto_programt& main_method, loop_infot::loopt& loop);
	void compute_body(goto_programt& main_method, loop_infot::loopt& loop);
	void compute_postfix(goto_programt& main_method, loop_infot::loopt& loop);
	void compute_condition(goto_programt& main_method, loop_infot::loopt& loop);

	namespacet ns;

	bool has_loops;

public:

	k_induction_enginet(contextt& context, k_induction_configurationt& config) : configuration(config), ns(context)
	{

	}

	bool analyse_main_loop(const goto_functionst& functions);

	void assemble_base_case(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k);

	void assemble_pure_base_case(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k);

	void assemble_inductive_step(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k);

	bool program_has_loops();

};


void add_havoc_instruction(exprt lhs, goto_programt& method, typet type);

void add_instructions_to_havoc_array(exprt array_expression, goto_programt& method, const namespacet ns);


#endif /* K_INDUCTION_H_ */
