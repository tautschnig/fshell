/*
 * k_induction_contextt.h
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#ifndef K_INDUCTION_CONTEXTT_H_
#define K_INDUCTION_CONTEXTT_H_

#include <goto-programs/find_loops.h>

class k_induction_configurationt {
public:
	k_induction_configurationt() { }
	virtual ~k_induction_configurationt() { }

	virtual void havoc_globals(CFGt& method, const namespacet ns) = 0;

	void add_loop_invariants(CFGt& method, const namespacet ns);

	virtual void make_instructions_for_invariant(goto_programt& temp_program) = 0;

};

#endif /* K_INDUCTION_CONTEXTT_H_ */
