/*
 * k_induction_contextt.h
 *
 *  Created on: Jan 15, 2010
 *      Author: ally
 */

#ifndef K_INDUCTION_CONTEXTT_H_
#define K_INDUCTION_CONTEXTT_H_

class k_induction_configurationt {
public:
	k_induction_configurationt() { }
	virtual ~k_induction_configurationt() { }

	virtual void havoc_globals(goto_programt& method, const namespacet ns) = 0;
	virtual void add_loop_invariants(goto_programt& loop_body, const namespacet ns) = 0;

};

#endif /* K_INDUCTION_CONTEXTT_H_ */
