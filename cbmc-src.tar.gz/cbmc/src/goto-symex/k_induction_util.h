/*
 * k_induction_util.h
 *
 *  Created on: Jan 14, 2010
 *      Author: alad
 */

#ifndef K_INDUCTION_UTIL_H_
#define K_INDUCTION_UTIL_H_

static void copy_location_info(goto_programt::targett dest, goto_programt::const_targett src)
{
	dest->code.location()=src->code.location();
	dest->location=src->location;
	dest->function=src->function;
	dest->location_number = -1;
}

#endif /* K_INDUCTION_UTIL_H_ */
