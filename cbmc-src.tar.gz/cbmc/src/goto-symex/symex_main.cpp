/*******************************************************************\

Module: Symbolic Execution

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <std_expr.h>
#include <rename.h>

#include "goto_symex.h"

/*******************************************************************\

Function: goto_symext::new_name

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::new_name(symbolt &symbol)
{
  get_new_name(symbol, ns);
  new_context.add(symbol);
}

/*******************************************************************\

Function: goto_symext::claim

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::claim(
  const exprt &claim_expr,
  const std::string &msg,
  statet &state)
{
  total_claims++;

  exprt expr=claim_expr;
  state.rename(expr, ns);
  
  // first try simplifier on it
  if(!expr.is_false())
    do_simplify(expr);

  if(expr.is_true() &&
     !options.get_bool_option("all-assertions"))
    return;
    
  state.guard.guard_expr(expr);
  
  remaining_claims++;
  target.assertion(state.guard, expr, msg, state.source);
}

/*******************************************************************\

Function: goto_symext::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::operator()(
  const goto_functionst &goto_functions,
  const goto_programt &goto_program)
{
  statet state;
  state.source.is_set=true;
  state.source.pc=goto_program.instructions.begin();
  state.top().end_of_function=--goto_program.instructions.end();
  state.top().calling_location=state.top().end_of_function;

  while(state.source.pc!=goto_program.instructions.end())
    symex_step(goto_functions, state);
}

/*******************************************************************\

Function: goto_symext::operator()

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::operator()(const goto_functionst &goto_functions)
{
  goto_functionst::function_mapt::const_iterator it=
    goto_functions.function_map.find("main");

  if(it==goto_functions.function_map.end())
    throw "main symbol not found; please set an entry point";

  const goto_programt &body=it->second.body;

  statet state;
  state.initialize(goto_functions);

  while(state.source.pc!=body.instructions.end())
    symex_step(goto_functions, state);
}

/*******************************************************************\

Function: goto_symext::symex_step

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::symex_step(
  const goto_functionst &goto_functions,
  statet &state)
{
  assert(!state.call_stack.empty());

  const goto_programt::instructiont &instruction=*state.source.pc;

  merge_gotos(state);
  
  if(state.guard.is_false())
  {
    if(instruction.is_goto())
    {
      // reset unwinding
      unwind_map[state.source]=0;
    }

    state.source.pc++;
    return; // nothing to do
  }

  // actually do instruction
  switch(instruction.type)
  {
  case SKIP:
    // really ignore
    break;

  case END_FUNCTION:
    symex_end_of_function(state);
    break;
  
  case LOCATION:
    target.location(state.guard, state.source);
    break;
  
  case GOTO:
    symex_goto(state);
    break;
    
  case ASSUME:
    {
      exprt tmp(instruction.guard);
      replace_dynamic_allocation(state, tmp);
      replace_nondet(tmp);
      dereference(tmp, state, false);
      state.rename(tmp, ns);
      state.guard.guard_expr(tmp);
      do_simplify(tmp);
      if(!tmp.is_true())
        target.assumption(state.guard, tmp, state.source);
    }
    break;

  case ASSERT:
    if(options.get_bool_option("assertions") ||
       !state.source.pc->location.get_bool("user-provided"))
    {
      std::string msg=state.source.pc->location.get_string("comment");
      if(msg=="") msg="assertion";
      exprt tmp(instruction.guard);
      replace_dynamic_allocation(state, tmp);
      replace_nondet(tmp);
      dereference(tmp, state, false);
      claim(tmp, msg, state);
    }
    break;
    
  case RETURN:
    symex_return(state);
    break;

  case ASSIGN:
    {
      codet deref_code=instruction.code;
      replace_dynamic_allocation(state, deref_code);
      replace_nondet(deref_code);
      assert(deref_code.operands().size()==2);

      dereference(deref_code.op0(), state, true);
      dereference(deref_code.op1(), state, false);

      basic_symext::symex_assign(state, deref_code);
    }
    break;

  case FUNCTION_CALL:
    {
      code_function_callt deref_code=
        to_code_function_call(instruction.code);

      replace_dynamic_allocation(state, deref_code);
      replace_nondet(deref_code);

      if(deref_code.lhs().is_not_nil())
        dereference(deref_code.lhs(), state, true);

      dereference(deref_code.function(), state, false);

      Forall_expr(it, deref_code.arguments())
        dereference(*it, state, false);
    
      symex_function_call(goto_functions, state, deref_code);
    }
    break;

  case OTHER:
    symex_other(goto_functions, state);
    break;

  case SYNC:
    throw "SYNC not yet implemented";

  case START_THREAD:
    throw "START_THREAD not yet implemented";
  
  case END_THREAD:
    {
      // behaves like assume(0);
      exprt tmp=false_exprt();
      state.guard.guard_expr(tmp);
      target.assumption(state.guard, tmp, state.source);
    }
    break;
  
  case ATOMIC_BEGIN:
  case ATOMIC_END:
    // these don't have path semantics
    break;
  
  default:
    assert(false);
  }

  // next instruction

  if(instruction.type!=GOTO &&
     instruction.type!=FUNCTION_CALL)
    state.source.pc++;
}
