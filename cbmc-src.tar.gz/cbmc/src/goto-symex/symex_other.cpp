/*******************************************************************\

Module: Symbolic Execution

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <expr_util.h>
#include <rename.h>

#include "goto_symex.h"

/*******************************************************************\

Function: goto_symext::symex_other

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void goto_symext::symex_other(
  const goto_functionst &goto_functions,
  statet &state)
{
  const goto_programt::instructiont &instruction=*state.source.pc;

  const codet &code=to_code(instruction.code);

  const irep_idt &statement=code.get_statement();
  
  if(statement==ID_expression)
  {
    // ignore
  }
  else if(statement=="cpp_delete" ||
          statement=="cpp_delete[]")
  {
    codet deref_code(code);

    replace_nondet(deref_code);
    dereference(deref_code, state, false);

    symex_cpp_delete(state, deref_code);
  }
  else if(statement==ID_free)
  {
    // ignore
  }
  else if(statement==ID_printf)
  {
    codet deref_code(code);

    replace_nondet(deref_code);
    dereference(deref_code, state, false);

    symex_printf(state, static_cast<const exprt &>(get_nil_irep()), deref_code);
  }
  else if(statement==ID_input)
  {
    codet deref_code(code);

    replace_nondet(deref_code);
    dereference(deref_code, state, false);

    symex_input(state, deref_code);
  }
  else if(statement==ID_output)
  {
    codet deref_code(code);

    replace_nondet(deref_code);
    dereference(deref_code, state, false);

    symex_output(state, deref_code);
  }
  else if(statement==ID_decl)
  {
    codet deref_code(code);

    replace_nondet(deref_code);
    dereference(deref_code, state, false);

    if(deref_code.operands().size()==2)
      throw "two-operand decl not supported here";

    if(deref_code.operands().size()!=1)
      throw "decl expects one operand";
    
    if(deref_code.op0().id()!="symbol")
      throw "decl expects symbol as first operand";

    // just do the L2 renaming to preseve locality
    const irep_idt &identifier=deref_code.op0().get(ID_identifier);

    const irep_idt &original_id=
      state.top().level1.get_original_name(identifier);
    std::string l1_identifier="";

    // set a proper frame number (we have seen this declaration before)
    do {
      unsigned index=state.top().level1.current_names[original_id];
      state.top().level1.rename(original_id, index+1);
      l1_identifier=state.top().level1(original_id);
    } while(state.declaration_history.find(l1_identifier)!=
        state.declaration_history.end());

    state.declaration_history.insert(l1_identifier); 
    
    state.top().local_variables.insert(l1_identifier);
      
    // seen it before?
    // it should get a fresh value
    statet::level2t::current_namest::iterator it=
      state.level2.current_names.find(l1_identifier);
    
    if(it!=state.level2.current_names.end())
    {
      state.level2.rename(l1_identifier, it->second.count+1);
      it->second.constant.make_nil();
    }
  }
  else if(statement==ID_nondet)
  {
    // like skip
  }
  else if(statement==ID_asm)
  {
    // we ignore this for now
  }
  else
    throw "unexpected statement: "+id2string(statement);
}
