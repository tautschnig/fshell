/*
 * k_induction.cpp
 *
 *  Created on: Sep 17, 2009
 *      Author: alad
 */

#define DEBUG_INSTRUMENTATION 0

#include "k_induction.h"

#include "k_induction_util.h"

#include <loopfrog/pointer_expr.h>

#include <util/arith_tools.h>
#include <util/expr_util.h>
#include <util/std_expr.h>


// Definition for mapping between two programs
typedef std::map<goto_programt::const_targett, goto_programt::targett> targets_mappingt;





void add_havoc_instruction(exprt lhs, goto_programt& method, typet type)
{
	goto_programt::targett havoc_instruction = method.add_instruction(ASSIGN);
	code_assignt havoc_assignment(lhs, nondet_exprt(type));
	havoc_instruction->code.swap(havoc_assignment);
}

void add_instructions_to_havoc_array(exprt array_expression, goto_programt& method, const namespacet ns)
{
	array_typet array_type;

	if(array_expression.type().id() == "symbol")
	{
		array_type = to_array_type(ns.follow(array_expression.type()));
	} else {
		array_type = to_array_type(array_expression.type());
	}

	assert(array_type.size().is_constant());

	std::string size_as_binary_string = array_type.size().get_string("value");

	int size_of_array = 0;

	// This is a ridiculous piece of code - there must be a better way to do this!!
	for(unsigned int i=0; i<size_as_binary_string.size(); i++)
	{
		if(size_as_binary_string.c_str()[size_as_binary_string.size()-i-1] == '1')
		{
			size_of_array += (1 << i);
		}

	}

	for(int i=0; i < size_of_array; i++)
	{
		index_exprt a_i;
		a_i.array() = array_expression;
		a_i.index() = from_integer(i, index_type());
		a_i.type() = array_type.subtype();
		add_havoc_instruction(a_i, method, array_type.subtype());
	}
}


static void	update_targets(goto_programt& prog, targets_mappingt& targets_mapping, namespacet ns)
{
	for(goto_programt::instructionst::iterator
	  it=prog.instructions.begin();
	  it!=prog.instructions.end();
	  it++)
	{

		for(goto_programt::instructiont::targetst::iterator
			t_it=it->targets.begin();
			t_it!=it->targets.end();
			t_it++)
		{
		  targets_mappingt::iterator
			m_target_it=targets_mapping.find(*t_it);

		  if(m_target_it==targets_mapping.end())
		  {
			throw "copy_from: target not found";
		  }

		  *t_it=m_target_it->second;
		}
	}
}

void k_induction_enginet::compute_prefix(goto_programt& main_method, loop_infot::loopt& loop)
{
	targets_mappingt targets_mapping;

	loop_prefix.clear();

	// Loop over program - 1st time collects targets and copy

	for(goto_programt::instructionst::const_iterator
		it=main_method.instructions.begin();
		!loop.contains(it->location_number);
		it++)
	{
		goto_programt::targett new_instruction=loop_prefix.add_instruction();
		targets_mapping[it]=new_instruction;
		*new_instruction=*it;
	}

	update_targets(loop_prefix, targets_mapping, ns);

}

void k_induction_enginet::compute_body(goto_programt& main_method, loop_infot::loopt& loop)
{
	targets_mappingt targets_mapping;

	loop_body.clear();

	configuration.add_loop_invariants(loop_body, ns);

	goto_programt::targett body_element;
	// Loop over program from first statement after loop header, until final GOTO is reached.
	for(
		body_element = get_first_node_after_header(get_iterator_for_loop_header(loop, main_method), loop, main_method);
		!((body_element->type == GOTO) && ((*(body_element->targets.begin()))->location_number == loop.header));
		body_element++)
	{

		goto_programt::targett new_instruction=loop_body.add_instruction();
		targets_mapping[body_element]=new_instruction;
		*new_instruction=*body_element;
	}

	/* The final goto may be a target, so we need to add it, and make it a SKIP statement
	 */
	goto_programt::targett new_instruction=loop_body.add_instruction();
	targets_mapping[body_element]=new_instruction;
	new_instruction->make_skip();
	copy_location_info(new_instruction, body_element);

	update_targets(loop_body, targets_mapping, ns);

}


void k_induction_enginet::compute_postfix(goto_programt& main_method, loop_infot::loopt& loop)
{
	targets_mappingt targets_mapping;

	loop_postfix.clear();

	// Loop over program - 1st time collects targets and copy

	bool reached_postfix = false;

	for(goto_programt::instructionst::const_iterator
		it=main_method.instructions.begin();
		it->type != END_FUNCTION;
		it++)
	{
		assert(it != main_method.instructions.end());

		if(reached_postfix)
		{
			goto_programt::targett new_instruction=loop_postfix.add_instruction();
			targets_mapping[it]=new_instruction;
			*new_instruction=*it;
		} else {
			if((it->type == GOTO) && ((*(it->targets.begin()))->location_number == loop.header))
			{
				reached_postfix = true;
			}
		}

	}

	update_targets(loop_postfix, targets_mapping, ns);

}



void k_induction_enginet::compute_condition(goto_programt& main_method, loop_infot::loopt& loop)
{
	for(goto_programt::instructionst::const_iterator
		it=main_method.instructions.begin();
		;
		it++)
	{
		if(it->location_number == loop.header)
		{

			assert(GOTO == it->type);

			std::cout << "Guard is: \n";
			std::cout << "   " << from_expr(it->guard) << "\n";

			loop_exit_condition_instruction = it;

			if(loop.contains(it->targets.front()->location_number))
			{
				// The GOTO takes us into the loop.  Thus to leave the
				// loop we require the negation of the GOTO's guard
				loop_exit_condition = not_exprt(it->guard);
			} else {
				// The GOTO leaves the loop.  Thus the exit condition
				// is the GOTO's guard
				loop_exit_condition = it->guard;
			}

			std::cout << "Loop exit condition is: \n";
			std::cout << "    " << from_expr(loop_exit_condition) << "\n";


			return;
		}
	}

}


bool k_induction_enginet::program_has_loops()
{
	return has_loops;
}



static goto_programt& find_main(goto_functionst& goto_functions, const namespacet ns)
{

    for(goto_functionst::function_mapt::iterator
    		f_it = goto_functions.function_map.begin();
			;
			f_it++)
    {
    	assert(f_it != goto_functions.function_map.end());
		if(ns.lookup(f_it->first).display_name() == config.main)
		{
			assert(f_it->second.body_available);
			return f_it->second.body;
		}
    }
    assert(false);

}




bool k_induction_enginet::analyse_main_loop(const goto_functionst& functions)
{

	goto_programt& main_method = find_main(const_cast<goto_functionst&>(functions), ns);

	dominator_infot dominator_information(main_method);

    loop_infot loop_info;

    loop_info.find_loops(dominator_information, main_method);

    loop_info.organize_loops(main_method);

#if DEBUG_INSTRUMENTATION

    std::cout << "Main method is:\n";

    main_method.output(ns, "", std::cout);

    std::cout << "Loop info: " << loop_info << "\n";

#endif

    if(0 == loop_info.num_loops())
	{
    	// The program does not have any loops, so standard bmc will be applied.
    	has_loops = false;
    	return false;
    }

	has_loops = true;

    if(1 != loop_info.num_loops())
    {
    	std::cout << "k-induction method currently only applicable to single loop.\n";

    	return true;
    }

    loop_infot::loopt* the_loop = loop_info.loops[0];

    compute_prefix(main_method, *the_loop);
    compute_condition(main_method, *the_loop);
    compute_body(main_method, *the_loop);
    compute_postfix(main_method, *the_loop);

#if DEBUG_INSTRUMENTATION

	std::cout << "****** K-induction data ********\n\n";

	std::cout << "** Loop prefix **\n";

	loop_prefix.output(ns, "", std::cout);

	std::cout << "** Loop condition **\n";

	std::cout << from_expr(loop_exit_condition) << "\n";

	std::cout << "** Loop body **\n";

	loop_body.output(ns, "", std::cout);

	std::cout << "** Loop postfix **\n";

	loop_postfix.output(ns, "", std::cout);

#endif


	return false;
}

static void clone_goto_functions(goto_functionst& result, const goto_functionst& source)
{
	result.clear();

	for(goto_functionst::function_mapt::const_iterator
			f_it = source.function_map.begin();
			f_it != source.function_map.end();
			f_it++)
	{
			result.function_map[f_it->first] = goto_functionst::goto_functiont();

			result.function_map[f_it->first].body_available = f_it->second.body_available;
			result.function_map[f_it->first].type = f_it->second.type;

			if(f_it->second.body_available)
			{
				result.function_map[f_it->first].body.copy_from(f_it->second.body);
			}
	}

}


static void turn_asserts_into_assumes(goto_programt& body)
{

	for(goto_programt::instructionst::iterator
		it=body.instructions.begin();
		it!=body.instructions.end();
		it++)
	{
		if(it->type == ASSERT)
		{
			exprt assertion_guard = it->guard;
			it->make_assumption(assertion_guard);
		}
	}

}

void k_induction_enginet::assemble_base_case(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k)
{
	clone_goto_functions(functions, original_functions);
	goto_programt& main_method = find_main(functions, ns);
	main_method.instructions.clear();

	/* Base case starts with the loop prefix */

	goto_programt prefix_duplicate;
	prefix_duplicate.copy_from(loop_prefix);
	if(k>0) {
		/* If the loop prefix has already been proved, on a previous value of k, we can assume it
		 * Note that this assumes k is starting from 1 and incrementing, i.e. we are not jumping straight
		 * in at k = X.
		 */
		turn_asserts_into_assumes(prefix_duplicate);
	}

	main_method.instructions.splice(main_method.instructions.end(), prefix_duplicate.instructions);

	/* Run through the loop body k-1 times, assuming all assertions (since they have already been proved) */
	for(unsigned int i=1; i<k; i++)
	{
		goto_programt::targett assume_loop_continues = main_method.add_instruction();
		assume_loop_continues->make_assumption(not_exprt(loop_exit_condition));
		copy_location_info(assume_loop_continues, loop_exit_condition_instruction);
		goto_programt body_duplicate;
		body_duplicate.copy_from(loop_body);
		turn_asserts_into_assumes(body_duplicate);
		main_method.instructions.splice(main_method.instructions.end(), body_duplicate.instructions);
	}

	if(k>0) {

		/* Run through the loop body a k-th time, but keeping assertions */
		goto_programt::targett assume_loop_continues = main_method.add_instruction();
		assume_loop_continues->make_assumption(not_exprt(loop_exit_condition));
		copy_location_info(assume_loop_continues, loop_exit_condition_instruction);
		goto_programt body_duplicate;
		body_duplicate.copy_from(loop_body);
		main_method.instructions.splice(main_method.instructions.end(), body_duplicate.instructions);
	}

	/* Now assume that the loop exits */
	goto_programt::targett assume_loop_exits = main_method.add_instruction();
	assume_loop_exits->make_assumption(loop_exit_condition);
	copy_location_info(assume_loop_exits, loop_exit_condition_instruction);

	/* Finally, check the loop postfix, keeping assertions */
	goto_programt postfix_duplicate;
	postfix_duplicate.copy_from(loop_postfix);
	main_method.instructions.splice(main_method.instructions.end(), postfix_duplicate.instructions);

	main_method.add_instruction(END_FUNCTION);

	functions.update();

#if DEBUG_INSTRUMENTATION
	std::cout << "*** Base case ***\n";

	main_method.output(ns, "", std::cout);
#endif

}







void k_induction_enginet::assemble_pure_base_case(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k)
{
	clone_goto_functions(functions, original_functions);
	goto_programt& main_method = find_main(functions, ns);
	main_method.instructions.clear();

	/* Base case starts with the loop prefix */

	goto_programt prefix_duplicate;
	prefix_duplicate.copy_from(loop_prefix);

	main_method.instructions.splice(main_method.instructions.end(), prefix_duplicate.instructions);

	goto_programt::targett exit_gotos[k];

	/* Run through the loop body k times */
	for(unsigned int i=0; i<k; i++)
	{
		exit_gotos[i] = main_method.add_instruction();
		exit_gotos[i]->make_goto();
		exit_gotos[i]->guard = loop_exit_condition;

		goto_programt body_duplicate;
		body_duplicate.copy_from(loop_body);
		main_method.instructions.splice(main_method.instructions.end(), body_duplicate.instructions);

	}

	goto_programt::targett assume_loop_exits = main_method.add_instruction();
	assume_loop_exits->make_assumption(loop_exit_condition);

	/* Finally, check the loop postfix */
	goto_programt postfix_duplicate;
	postfix_duplicate.copy_from(loop_postfix);
	main_method.instructions.splice(main_method.instructions.end(), postfix_duplicate.instructions);

	main_method.add_instruction(END_FUNCTION);

	for(unsigned int i=0; i<k; i++)
	{
		exit_gotos[i]->targets.push_back(assume_loop_exits);
	}

	functions.update();

#if DEBUG_INSTRUMENTATION
	std::cout << "*** Pure base case ***\n";

	main_method.output(ns, "", std::cout);
#endif

}



void k_induction_enginet::assemble_inductive_step(goto_functionst& functions, const goto_functionst& original_functions, const unsigned int k)
{

	clone_goto_functions(functions, original_functions);
	goto_programt& main_method = find_main(functions, ns);
	main_method.instructions.clear();

	/* Inductive step starts by havocing tracker arrays, auxiliary variables, plus all variables used in loop */

	bool_typet bool_type;

	configuration.havoc_globals(main_method, ns);

	/* Go through loop prefix, declaring and havocing local variables */
	for(goto_programt::instructionst::const_iterator
		it=loop_prefix.instructions.begin();
		it!=loop_prefix.instructions.end();
		it++)
	{
		if((it->type == OTHER) && (it->code.id() == "code") && ((to_code(it->code)).get("statement")=="decl"))
		{
			goto_programt::targett decl = main_method.add_instruction();
			decl->type = it->type;
			decl->code = it->code;

			codet decl_code = to_code(it->code);

			typet decl_type = decl_code.op0().type();

			if(decl_type.id() == "symbol") {
				decl_type = ns.follow(decl_type);
			}

			if(decl_type.id() == "array")
			{
				add_instructions_to_havoc_array(decl_code.op0(), main_method, ns);
			} else {
				add_havoc_instruction(decl_code.op0(), main_method, decl_code.op0().type());
			}

		}


	}

	/* Run through the loop body k times, assuming all assertions */
	for(unsigned int i=1; i<=k; i++)
	{
		goto_programt::targett assume_loop_condition = main_method.add_instruction();
		assume_loop_condition->make_assumption(not_exprt(loop_exit_condition));
		copy_location_info(assume_loop_condition, loop_exit_condition_instruction);
		goto_programt body_duplicate;
		body_duplicate.copy_from(loop_body);
		turn_asserts_into_assumes(body_duplicate);
		main_method.instructions.splice(main_method.instructions.end(), body_duplicate.instructions);
	}

	goto_programt::targett continue_or_exit = main_method.add_instruction();
	continue_or_exit->make_goto();

	/* Continue */
	goto_programt::targett assume_loop_continues = main_method.add_instruction();
	assume_loop_continues->make_assumption(not_exprt(loop_exit_condition));
	copy_location_info(assume_loop_continues, loop_exit_condition_instruction);
	/* Run through the loop body a (k+1)-st time, but keeping assertions */
	goto_programt body_duplicate;
	body_duplicate.copy_from(loop_body);
	main_method.instructions.splice(main_method.instructions.end(), body_duplicate.instructions);
	goto_programt::targett goto_end = main_method.add_instruction();
	goto_end->make_goto();


	/* Exit */
	goto_programt::targett assume_loop_exits = main_method.add_instruction();
	assume_loop_exits->make_assumption(loop_exit_condition);
	copy_location_info(assume_loop_exits, loop_exit_condition_instruction);
	/* Do loop postfix, keeping assertions */
	goto_programt postfix_duplicate;
	postfix_duplicate.copy_from(loop_postfix);
	main_method.instructions.splice(main_method.instructions.end(), postfix_duplicate.instructions);

	goto_programt::targett end_of_function = main_method.add_instruction(END_FUNCTION);

	/* Patch up gotos */
	bool_typet boolean_type;
	continue_or_exit->guard = nondet_exprt(boolean_type);
	continue_or_exit->targets.push_back(assume_loop_exits);
	goto_end->targets.push_back(end_of_function);

	functions.update();

#if DEBUG_INSTRUMENTATION
	std::cout << "*** Inductive step ***\n";

	main_method.output(ns, "", std::cout);
#endif

}
