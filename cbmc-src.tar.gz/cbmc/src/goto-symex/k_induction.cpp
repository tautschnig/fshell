/*
 * k_induction.cpp
 *
 *  Created on: Sep 17, 2009
 *      Author: alad
 */

//#define DEBUG_INSTRUMENTATION 1

#include "k_induction.h"

#include <loopfrog/pointer_expr.h>

#include <util/arith_tools.h>
#include <util/expr_util.h>
#include <util/std_expr.h>
#include <util/i2string.h>

#include <scratch/k_induction_bmc.h>

unsigned int K_INDUCTION_DEPTH;


//#define DEMO_MODE

#ifdef DEMO_MODE
void myflush ( std::istream& in )
{
  in.ignore ( std::numeric_limits<std::streamsize>::max(), '\n' );
  in.clear();
}

void mypause()
{
  print(8, "Press [Enter] to continue . . .");
  std::cin.get();
}
#endif


void add_havoc_instruction(exprt lhs, CFGt& method, typet type)
{
	goto_programt temp_program;
	goto_programt::targett havoc_instruction = temp_program.add_instruction(ASSIGN);
	code_assignt havoc_assignment(lhs, nondet_exprt(type));
	havoc_instruction->code.swap(havoc_assignment);
	method.append_node(CFG_nodet(*havoc_instruction));
}

void add_instructions_to_havoc_array(exprt array_expression, CFGt& method, const namespacet ns)
{
	array_typet array_type;

	if(array_expression.type().id() == "symbol")
	{
		array_type = to_array_type(ns.follow(array_expression.type()));
	} else {
		array_type = to_array_type(array_expression.type());
	}

	assert(array_type.size().is_constant());

	std::string size_as_binary_string = array_type.size().get_string("value");

	int size_of_array = 0;

	// This is a ridiculous piece of code - there must be a better way to do this!!
	for(unsigned int i=0; i<size_as_binary_string.size(); i++)
	{
		if(size_as_binary_string.c_str()[size_as_binary_string.size()-i-1] == '1')
		{
			size_of_array += (1 << i);
		}

	}

	for(int i=0; i < size_of_array; i++)
	{
		index_exprt a_i;
		a_i.array() = array_expression;
		a_i.index() = from_integer(i, index_type());
		a_i.type() = array_type.subtype();
		add_havoc_instruction(a_i, method, array_type.subtype());
	}
}


k_induction_enginet::k_induction_enginet(contextt& ctx, k_induction_configurationt& config, cbmc_parseoptionst& cbmc_options, const goto_functionst& goto_functions, message_handlert &_message_handler) :
	messaget(_message_handler), configuration(config), context(ctx), cbmc_options(cbmc_options), goto_functions(goto_functions)
{
}



loop_infot::loopt* k_induction_enginet::analyse_main_loop(CFGt& control_flow_graph)
{
    loop_infot loop_info(control_flow_graph);

#if DEBUG_INSTRUMENTATION

    {
    	namespacet ns(context);
		std::ostringstream stream;
		stream << "Main method is:\n";
		find_main(const_cast<goto_functionst&>(goto_functions), context).output(ns, "", stream);
		stream << "CFG is:\n";
		control_flow_graph.output(ns, "", stream);
		stream << "Loop info: " << loop_info;
		print(8, stream.str());
    }

#endif

    if(0 == loop_info.num_loops())
    {
    	return NULL;
    }

    return loop_info.outer_loops[0];

}


static void clone_goto_function(goto_programt& result, const goto_programt& source, std::set<goto_programt::const_targett>* loop_header_points_result = NULL, std::set<goto_programt::const_targett>* loop_header_points_source = NULL)
{
	/* This is very similar to "copy_from", but required some adaptation to handle
	 * loop header points
	 */

	// Definitions for mapping between the two programs
	typedef std::map<goto_programt::const_targett, goto_programt::targett> targets_mappingt;
	targets_mappingt targets_mapping;

	result.clear();

	// Loop over program - 1st time collects targets and copy
	for(goto_programt::instructionst::const_iterator
	  it=source.instructions.begin();
	  it!=source.instructions.end();
	  it++)
	{
		goto_programt::targett new_instruction = result.add_instruction();
		targets_mapping[it]=new_instruction;
		*new_instruction=*it;

		if(NULL != loop_header_points_result)
		{
			assert(NULL != loop_header_points_source);
			if(loop_header_points_source->end() != loop_header_points_source->find(it))
			{
				loop_header_points_result->insert(new_instruction);
			}
		}

	}

	// Loop over program - 2nd time updates targets

	for(goto_programt::instructionst::iterator
	  it=result.instructions.begin();
	  it!=result.instructions.end();
	  it++)
	{

		for(goto_programt::targetst::iterator
			t_it=it->targets.begin();
			t_it!=it->targets.end();
			t_it++)
		{
			targets_mappingt::iterator
			m_target_it=targets_mapping.find(*t_it);

			if(m_target_it==targets_mapping.end())
			throw "copy_from: target not found";

			*t_it=m_target_it->second;
		}
	}

	result.compute_incoming_edges();
	result.compute_target_numbers();

}




static void clone_goto_functions(goto_functionst& result, const goto_functionst& source, std::set<goto_programt::const_targett>* loop_header_points_result = NULL, std::set<goto_programt::const_targett>* loop_header_points_source = NULL)
{
	result.clear();

	for(goto_functionst::function_mapt::const_iterator
			f_it = source.function_map.begin();
			f_it != source.function_map.end();
			f_it++)
	{
			result.function_map[f_it->first] = goto_functionst::goto_functiont();

			result.function_map[f_it->first].body_available = f_it->second.body_available;
			result.function_map[f_it->first].type = f_it->second.type;

			if(f_it->second.body_available)
			{
				clone_goto_function(result.function_map[f_it->first].body, f_it->second.body, loop_header_points_result, loop_header_points_source);
			}
	}

}


#if 0 /* Useful code for debugging, but compiler generates 'unused' warnings if we do not call these functions */
static void output_CFG_pointers(const CFGt& cfg, std::ostream& out)
{
	for(std::list<CFG_nodet>::const_iterator
			it = cfg.nodes.begin();
			it != cfg.nodes.end();
			it++)
	{
		out << &(*it) << " -> ";
		if(NULL != it->successor_next)
		{
			out << "next:" << it->successor_next << " ";
		}
		if(NULL != it->successor_jump)
		{
			out << "jump:" << it->successor_jump;
		}
		out << "\n";
	}
	out << "\n";
}

static void display_patchup_map(std::map<const CFG_nodet*, CFG_nodet*>& the_map, std::ostream& out)
{
	out << "Patch up map: [ ";
	for(std::map<const CFG_nodet*, CFG_nodet*>::iterator
			it = the_map.begin();
			it != the_map.end();
			it++)
	{
		out << "( " << it->first << " -> " << it->second << " ), ";
	}
	out << "]\n\n";
}
#endif /* End of useful code for debugging */


void k_induction_enginet::assemble_base_case(CFGt& base_case_cfg, const CFGt& control_flow_graph, loop_infot::loopt* outer_loop, const unsigned int k)
{
	base_case_cfg.nodes.clear();

	std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned_outside_loop;
	{

		/* Look through all nodes in the original CFG.
		 * Consider those that are *not* in the loop,
		 * as well as the loop header.
		 * Clone them, and add to the new CFG.  Keep
		 * a map from original to cloned.
		 */
		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(!outer_loop->contains(*it) || (&(*it)==&(outer_loop->header)))
			{
				base_case_cfg.nodes.push_back(*it);
				assert(&(*it) != &(base_case_cfg.nodes.back()));
				original_to_cloned_outside_loop[&(*it)] = &(base_case_cfg.nodes.back());
			}
		}

		base_case_cfg.patchup_pointers(original_to_cloned_outside_loop);

	}

	for(unsigned int i=0; i<k; i++)
	{

		std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned_in_loop = original_to_cloned_outside_loop;
		original_to_cloned_in_loop.erase(&(outer_loop->header));

		CFG_nodet* new_header = NULL;
		CFG_nodet* header_successor_next = NULL;
		CFG_nodet* header_successor_jump = NULL;

		/* Go through every node inside the loop.
		 * Clone each, adding to map, and add clone to CFG.
		 */
		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(outer_loop->contains(*it))
			{
				base_case_cfg.nodes.push_back(*it);
				assert(&(*it) != &(base_case_cfg.nodes.back()));
				original_to_cloned_in_loop[&(*it)] = &(base_case_cfg.nodes.back());
			}

			if(&(*it) == &(outer_loop->header))
			{
				header_successor_next = outer_loop->header.successor_next;
				header_successor_jump = outer_loop->header.successor_jump;
				base_case_cfg.nodes.back().successor_next = NULL;
				base_case_cfg.nodes.back().successor_jump = NULL;
				assert(NULL == new_header);
				new_header = &(base_case_cfg.nodes.back());
			}

		}

		base_case_cfg.patchup_pointers(original_to_cloned_in_loop);
		new_header->successor_next = header_successor_next;
		new_header->successor_jump = header_successor_jump;

	}


	{
		/* Add a final run through the loop, where any jumps to the header are
		 * replaced with jumps to a special return node
		 */

		std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned_in_final_loop_iteration = original_to_cloned_outside_loop;
		CFG_nodet return_node(code_returnt(), base_case_cfg.nodes.back().function, base_case_cfg.nodes.back().location, RETURN);
		base_case_cfg.nodes.push_back(return_node);
		original_to_cloned_in_final_loop_iteration[&(outer_loop->header)] = &base_case_cfg.nodes.back();

		/* Go through every node inside the loop *except* the header.
		 * Clone each, adding to map, and add clone to CFG.
		 */
		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(outer_loop->contains(*it) && (&(*it) != &(outer_loop->header)))
			{
				base_case_cfg.nodes.push_back(*it);
				assert(&(*it) != &(base_case_cfg.nodes.back()));
				original_to_cloned_in_final_loop_iteration[&(*it)] = &(base_case_cfg.nodes.back());
			}
		}

		base_case_cfg.patchup_pointers(original_to_cloned_in_final_loop_iteration);

	}

	base_case_cfg.order_nodes();

#if DEBUG_INSTRUMENTATION
	{
	    std::ostringstream stream;
	    stream << "*** Base case ***\n";
	    base_case_cfg.output(namespacet(context), "", stream);
	    print(8, stream.str());
	}
#endif

}


CFG_nodet assert_to_assume(CFG_nodet node)
{
	CFG_nodet result = node;
	result.type = (node.type == ASSERT ? ASSUME : node.type);
	return result;
}

void k_induction_enginet::assemble_inductive_step(CFGt& step_case_cfg, const CFGt& control_flow_graph, CFGt::nodes_const_sett& loop_header_points, loop_infot::loopt* outer_loop, const unsigned int k)
{
	step_case_cfg.nodes.clear();

	namespacet ns(context);

	loop_header_points.clear();

	std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned_outside_loop;

	/* HAVOC GLOBAL VARIABLES */

	configuration.havoc_globals(step_case_cfg, ns);

	/* HAVOC LOCAL VARIABLES */

	/* Go through loop prefix, declaring and havocing local variables */
	for(std::list<CFG_nodet>::const_iterator
			it = control_flow_graph.nodes.begin();
			it != control_flow_graph.nodes.end();
			it++)
	{
		if(!outer_loop->contains(*it) && it->type == DECL)
		{
			CFG_nodet decl_node(it->code, it->function, it->location, it->type);
			step_case_cfg.append_node(decl_node);

			codet decl_code = to_code(it->code);
			typet decl_type = decl_code.op0().type();

			if(decl_type.id() == "symbol") {
				decl_type = ns.follow(decl_type);
			}

			if(decl_type.id() == "array")
			{
				add_instructions_to_havoc_array(decl_code.op0(), step_case_cfg, ns);
			} else {
				add_havoc_instruction(decl_code.op0(), step_case_cfg, decl_code.op0().type());
			}


		}
	}

	{
		/* Add the loop header, as the first statement after havocs.
		 * If k > 0, the loop header will form part of an 'assume'
		 * pass through the loop, so we need to make it an assume
		 * if it were an assert */
		CFG_nodet new_loop_header = outer_loop->header;
		if(0 != k) {
			new_loop_header = assert_to_assume(new_loop_header);

			if(NULL != new_loop_header.successor_next && !outer_loop->contains(*(new_loop_header.successor_next)))
			{
				assert(new_loop_header.type == GOTO);
				assert(new_loop_header.successor_jump != NULL && outer_loop->contains(*(new_loop_header.successor_jump)));
				CFG_nodet assume_node(code_assumet(), new_loop_header.function, new_loop_header.location, ASSUME);
				assume_node.reasoning_guard = new_loop_header.jump_condition;
				step_case_cfg.append_node(assume_node);
			} else if(NULL != new_loop_header.successor_jump && !outer_loop->contains(*(new_loop_header.successor_jump))) {
				assert(new_loop_header.type == GOTO);
				assert(new_loop_header.successor_next != NULL && outer_loop->contains(*(new_loop_header.successor_next)));
				CFG_nodet assume_node(code_assumet(), new_loop_header.function, new_loop_header.location, ASSUME);
				assume_node.reasoning_guard = not_exprt(new_loop_header.jump_condition);
				step_case_cfg.append_node(assume_node);
			}
		}
		step_case_cfg.append_node(new_loop_header);
		loop_header_points.insert(&step_case_cfg.nodes.back());
	}

	for(unsigned int i=0; i<k; i++)
	{
		/* We add every node in the loop, turning asserts into assumes
		 * (dealing with the header specially), keeping a map from original
		 * nodes to cloned nodes
		 */

		std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned;

		CFG_nodet* new_header = NULL;
		CFG_nodet* header_successor_next = NULL;
		CFG_nodet* header_successor_jump = NULL;

		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(outer_loop->contains(*it))
			{
				CFG_nodet new_node = *it;

				bool require_assume = false;
				CFG_nodet assume_node(code_assumet(), new_node.function, new_node.location, ASSUME);

				/* We always want to turn asserts into assumes.  The *one* exception to this
				 * is the case of the loop header when we add it in the final iteration, since
				 * this forms part of the final run through the loop, where we do want asserts
				 */

				if(i < k-1 || &(*it) != &(outer_loop->header))
				{


					new_node = assert_to_assume(new_node);

					if(NULL != new_node.successor_next && !outer_loop->contains(*(new_node.successor_next)))
					{
						assert(new_node.type == GOTO);
						assert(new_node.successor_jump != NULL && outer_loop->contains(*(new_node.successor_jump)));
						require_assume = true;
						assume_node.reasoning_guard = new_node.jump_condition;
					} else if(NULL != new_node.successor_jump && !outer_loop->contains(*(new_node.successor_jump))) {
						assert(new_node.type == GOTO);
						assert(new_node.successor_next != NULL && outer_loop->contains(*(new_node.successor_next)));
						require_assume = true;
						assume_node.reasoning_guard = not_exprt(new_node.jump_condition);
					}

				}

				if(require_assume)
				{
					step_case_cfg.nodes.push_back(assume_node);
					assert(&(*it) != &(step_case_cfg.nodes.back()));
					original_to_cloned[&(*it)] = &(step_case_cfg.nodes.back());
					CFG_nodet* assume_node_ptr = &step_case_cfg.nodes.back();

					step_case_cfg.nodes.push_back(new_node);
					assert(&(*it) != &(step_case_cfg.nodes.back()));

					assume_node_ptr->successor_next = &step_case_cfg.nodes.back();

				} else {

					step_case_cfg.nodes.push_back(new_node);
					assert(&(*it) != &(step_case_cfg.nodes.back()));
					original_to_cloned[&(*it)] = &(step_case_cfg.nodes.back());
				}

			}

			if(&(*it) == &(outer_loop->header))
			{
				header_successor_next = outer_loop->header.successor_next;
				header_successor_jump = outer_loop->header.successor_jump;
				step_case_cfg.nodes.back().successor_next = NULL;
				step_case_cfg.nodes.back().successor_jump = NULL;
				assert(NULL == new_header);
				new_header = &(step_case_cfg.nodes.back());
				loop_header_points.insert(new_header);
			}

		}

		step_case_cfg.patchup_pointers(original_to_cloned);

		new_header->successor_next = header_successor_next;
		new_header->successor_jump = header_successor_jump;

	}

	{
		/* Add a final run through the loop, where any jumps to the header are
		 * replaced with jumps to a special return node.  This time, asserts are *not*
		 * turned into assumes
		 */

		std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned;
		CFG_nodet return_node(code_returnt(), step_case_cfg.nodes.back().function, step_case_cfg.nodes.back().location, RETURN);
		step_case_cfg.nodes.push_back(return_node);
		original_to_cloned[&(outer_loop->header)] = &step_case_cfg.nodes.back();

		/* Go through every node inside the loop *except* the header.
		 * Clone each, adding to map, and add clone to CFG.
		 */
		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(outer_loop->contains(*it) && (&(*it) != &(outer_loop->header)))
			{
				step_case_cfg.nodes.push_back(*it);
				assert(&(*it) != &(step_case_cfg.nodes.back()));
				original_to_cloned[&(*it)] = &(step_case_cfg.nodes.back());
			}
		}

		step_case_cfg.patchup_pointers(original_to_cloned);

	}

	{
		/* Now, inside the above unwound loop bodies there may have been many jumps to nodes
		 * outside (after) the loop.  Go through all non loop nodes, adding them all to the
		 * step case CFG.  Keep a map from originals to clones, and patch up the step case
		 * CFG
		 */

		/* TODO: optimize:
		 * we require that we never get back in the loop again (this should be guaranteed)
		 * so we use an assert false node, which we link to from statements that would jump
		 * into the loop.  These statements should form an unreachable part of the CFG
		 * and we can garbage-collect them later
		 */

		std::map<const CFG_nodet*, CFG_nodet*> original_to_cloned;
		CFG_nodet assert_false_node(code_assertt(), step_case_cfg.nodes.back().function, step_case_cfg.nodes.back().location, ASSERT);
		assert_false_node.reasoning_guard = false_exprt();
		step_case_cfg.nodes.push_back(assert_false_node);
		original_to_cloned[&(outer_loop->header)] = &step_case_cfg.nodes.back();

		/* Go through every non-loop node.
		 * Clone each, adding to map, and add clone to CFG.
		 */
		for(CFGt::nodest::const_iterator
				it = control_flow_graph.nodes.begin();
				it != control_flow_graph.nodes.end();
				it++)
		{
			if(!(outer_loop->contains(*it)))
			{
				step_case_cfg.nodes.push_back(*it);
				assert(&(*it) != &(step_case_cfg.nodes.back()));
				original_to_cloned[&(*it)] = &(step_case_cfg.nodes.back());
			}
		}

		step_case_cfg.patchup_pointers(original_to_cloned);

	}

	step_case_cfg.order_nodes(&loop_header_points);

#if DEBUG_INSTRUMENTATION
	{
	    std::ostringstream stream;
	    stream << "*** Inductive step ***\n";
	    step_case_cfg.output(ns, "", stream, false, &loop_header_points);
	    print(8, stream.str());
	}
#endif

}






/*******************************************************************\

Function: k_induction_enginet::do_bmc

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

int k_induction_enginet::do_bmc(
  bmc_baset &bmc,
  const goto_functionst &goto_functions)
{
  bmc.set_ui(cbmc_options.get_ui());

  // do actual BMC
  if(bmc.run(goto_functions))
    return 10;

  return 0;
}


unsigned int STARTING_K = 0;


#define LOOP_TOO_COMPLEX 12

int k_induction_enginet::try_k_induction(bmc_baset &bmc, CFGt& control_flow_graph)
{
	DFST_numberingt dfst_numbering(control_flow_graph);
	dominator_infot dominator_information(control_flow_graph);
	if(!(dominator_information.cfg_is_reducible(dfst_numbering)))
	{
		print(8, "The control-flow graph is not reducible, and is thus too complex to handle.");
		return LOOP_TOO_COMPLEX;
	}

	if(cbmc_options.cmdline.isset("monolithic"))
    {
    	control_flow_graph.transform_to_monolithic_loop();
    }

	configuration.add_loop_invariants(control_flow_graph, namespacet(context));

	control_flow_graph.order_nodes();

	return try_k_induction_recursive(bmc, control_flow_graph, 0, true);
}

int k_induction_enginet::try_k_induction_recursive(bmc_baset &bmc, CFGt& control_flow_graph, const unsigned int nesting_level, bool base_case, CFGt::nodes_const_sett* loop_header_points) {

	loop_infot::loopt* outer_loop = analyse_main_loop(control_flow_graph);

	if(NULL == outer_loop)
	{
		print(8, "The program does not have any loops, so BMC will be applied.");

		goto_functionst functions_to_analyze;
		clone_goto_functions(functions_to_analyze, goto_functions);

		goto_programt& main_method = find_main(functions_to_analyze, context);
		main_method.instructions.clear();

		std::set<goto_programt::const_targett> loop_header_instruction_points;

		control_flow_graph.to_goto_program(main_method, loop_header_points, &loop_header_instruction_points);

		// recalculate numbers, etc.
		functions_to_analyze.update();
	    // add loop ids
		functions_to_analyze.compute_loop_numbers();

#if DEBUG_INSTRUMENTATION
		{
		    std::ostringstream stream;
		    stream << "*** Ready to do BMC ***\n";
		    stream << "CFG:\n";
		    control_flow_graph.output(namespacet(context), "", stream);
		    stream << "Program:\n";
		    main_method.output(namespacet(context), "", stream);
		    print(8, stream.str());
		}
#endif

		std::streambuf* cout_backup = NULL;
		std::ostringstream abyss_stream;

		if(!cbmc_options.cmdline.isset("show-step-case-fails") && !base_case)
		{
			/* To avoid printing spurious counter-examples, redirect std::cout to a string stream,
			 * so that such data is sent "into the abyss".  This is *not* an ideal solution.
			 */
			cout_backup = std::cout.rdbuf();
			std::cout.rdbuf(abyss_stream.rdbuf());
		}

		k_induction_bmct new_bmc(cbmc_options.context, bmc.get_message_handler(), loop_header_instruction_points, cbmc_options.cmdline.isset("loop-free-restriction"));
		new_bmc.options = bmc.options;
		new_bmc.set_verbosity(bmc.get_verbosity());
		int result = do_bmc(new_bmc, functions_to_analyze);

		if(!cbmc_options.cmdline.isset("show-step-case-fails") && !base_case)
		{
			/* Restore std::cout if necessary
			 */
			assert(NULL != cout_backup);
			assert(std::cout.rdbuf() == abyss_stream.rdbuf());
			std::cout.rdbuf(cout_backup);
		} else {
			assert(NULL == cout_backup);
		}

		return result;

	}

	if(cbmc_options.cmdline.isset("monolithic"))
	{
		assert(0 == nesting_level);
	}

	{
		std::ostringstream stream;
		stream << "\n*** Starting k";
		if(nesting_level > 0) {
			stream << nesting_level;
		}
		stream << "-induction analysis.  Maximum k";
		if(nesting_level > 0) {
			stream << nesting_level;
		}
		stream << " set to " << K_INDUCTION_DEPTH << " ***\n";
		print(8, stream.str());
	}

	for(unsigned int k=STARTING_K; k <= K_INDUCTION_DEPTH; k++)
	{
		{
			std::ostringstream stream;
			stream << "Depth: k";
			if(nesting_level > 0) {
				stream << nesting_level;
			}
			stream << " = " << k << ".\n";
			print(8, stream.str());
		}

#ifdef DEMO_MODE
		mypause();
#endif

		{

			CFGt base_case_CFG(context);

			assemble_base_case(base_case_CFG, control_flow_graph, outer_loop, k);

			int base_case_result = try_k_induction_recursive(bmc, base_case_CFG, nesting_level+1, base_case);

			if(base_case_result != 0)
			{
				std::ostringstream stream;
				stream << "\nBase case failed (k";
				if(nesting_level > 0) {
					stream << nesting_level;
				}
				stream << " = " << k << ").\n";
				print(8, stream.str());

				return base_case_result;
			}

		}

		{
			std::ostringstream stream;
			stream << "\nBase case succeeded (k";
			if(nesting_level > 0) {
				stream << nesting_level;
			}
			stream << " = " << k << ").  Moving on to inductive step.\n";
			print(8, stream.str());
		}

#ifdef DEMO_MODE
		mypause();
#endif

		{

			CFGt step_case_cfg(context);

			// TODO work out how to get "show-step-case-fails" happening

			CFGt::nodes_const_sett new_loop_header_points;
			assemble_inductive_step(step_case_cfg, control_flow_graph, new_loop_header_points, outer_loop, k);

			int inductive_step_result = try_k_induction_recursive(bmc, step_case_cfg, nesting_level+1, false, &new_loop_header_points);

			if(inductive_step_result == 0 )
			{
				std::ostringstream stream;
				stream << "\nInductive step succeeded (k";
				if(nesting_level > 0) {
					stream << nesting_level;
				}
				stream << " = " << k << ") - verification successful!";
				print(8, stream.str());
				return 0;
			} else {
				std::ostringstream stream;
				stream << "\nInductive step failed (k";
				if(nesting_level > 0) {
					stream << nesting_level;
				}
				stream << " = " << k << ")\n";
				print(8, stream.str());
			}

#ifdef DEMO_MODE
		mypause();
#endif


		}

	}

	print(8, "Could not prove within depth " + i2string(K_INDUCTION_DEPTH) + "\n");

	return 14;

}

