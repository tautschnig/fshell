/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_ansi_c_language()
{
  assert(false);
  return NULL;
} 
