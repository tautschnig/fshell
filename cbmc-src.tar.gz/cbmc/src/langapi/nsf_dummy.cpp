/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_nsf_language()
{
  assert(false);
  return NULL;
} 
