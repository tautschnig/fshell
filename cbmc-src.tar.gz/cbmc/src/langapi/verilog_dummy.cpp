/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_verilog_language()
{
  assert(false);
  return NULL;
} 
