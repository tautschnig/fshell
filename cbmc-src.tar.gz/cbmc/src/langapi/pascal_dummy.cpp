/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_pascal_language()
{
  throw "PASCAL language front-end not compiled in";
  return NULL;
} 
