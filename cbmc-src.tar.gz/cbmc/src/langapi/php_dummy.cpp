/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_php_language()
{
  throw "PHP language front-end not compiled in";
  return NULL;
} 
