/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#include <assert.h>

#include <language.h>

languaget *new_mdl_language()
{
  throw "Simulink language front-end not compiled in";
  return NULL;
} 
