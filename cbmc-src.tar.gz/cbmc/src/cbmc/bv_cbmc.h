/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_CBMC_BV_CBMC_H
#define CPROVER_CBMC_BV_CBMC_H

#include <propdec/bv_pointers.h>

class bv_cbmct:public bv_pointerst
{
public:
  bv_cbmct(propt &_prop):bv_pointerst(_prop) { }
  virtual ~bv_cbmct() { }

protected:
  // overloading
  virtual bool convert_bitvector(const exprt &expr, bvt &bv); // no cache

  virtual bool convert_waitfor(const exprt &expr, bvt &bv);
  virtual bool convert_waitfor_symbol(const exprt &expr, bvt &bv);
};

#endif
