/*******************************************************************\

Module: Command Line Parsing

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_CBMC_PARSEOPTIONS_H
#define CPROVER_CBMC_PARSEOPTIONS_H

#include <langapi/language_ui.h>
#include <ui_message.h>
#include <parseoptions.h>

#include "bmc.h"

#define CBMC_OPTIONS \
  "(program-only)(function):(preprocess)(slice-by-trace):" \
  "(no-simplify)(unwind):(unwindset):(slice)" \
  "(debug-level):(no-substitution)(no-simplify-if)" \
  "(no-bounds-check)(cvc)(smt)(outfile):(no-pointer-check)" \
  "(document-subgoals)(all-claims)D:I:" \
  "(no-div-by-zero-check)(no-unwinding-assertions)" \
  "(no-pretty-names)(overflow-check)(beautify-greedy)(beautify-pbs)" \
  "(floatbv)(fixedbv)(no-assertions)(gui)" \
  "(dimacs)(16)(32)(64)(little-endian)(big-endian)(bv-refine)" \
  "(show-goto-functions)(show-value-sets)(xml-ui)(show-loops)" \
  "(show-symbol-table)(show-vcc)(show-claims)(claim):" \
  "(error-label):(verbosity):(binary):(no-library)" \
  "(version)(i386-linux)(i386-macos)(i386-win32)(ppc-macos)(unsigned-char)" \
  "(arrays-uf-always)(arrays-uf-never)(interpreter)(slice-formula)" \
  "(string-abstraction)(no-arch)(fshell)(query-file):" \
  "(decide)" // legacy, and will eventually disappear

class cbmc_parseoptionst:
  public parseoptions_baset,
  public language_uit
{
public:
  virtual int doit();
  virtual void help();

  cbmc_parseoptionst(int argc, const char **argv):
    parseoptions_baset(CBMC_OPTIONS, argc, argv),
    language_uit(cmdline)
  {
  }
  
  cbmc_parseoptionst(
    int argc,
    const char **argv,
    const std::string &extra_options):
    parseoptions_baset(CBMC_OPTIONS+extra_options, argc, argv),
    language_uit(cmdline)
  {
  }
  
protected:
  virtual void get_command_line_options(optionst &options);
  virtual int do_bmc(bmc_baset &bmc, const goto_functionst &goto_functions);

  virtual bool get_goto_program(
    bmc_baset &bmc,
    goto_functionst &goto_functions);

  virtual bool process_goto_program(
    bmc_baset &bmc,
    goto_functionst &goto_functions);
    
  bool read_goto_binary(goto_functionst &goto_functions);

  bool set_claims(goto_functionst &goto_functions);
  
  void set_verbosity(messaget &message);
  
  // get any additional stuff before finalizing
  virtual bool get_modules(bmc_baset &bmc)
  {
    return false;
  }
  
  void preprocessing();
};

#endif
