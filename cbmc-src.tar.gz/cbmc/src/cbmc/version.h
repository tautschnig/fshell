#define CBMC_VERSION "3.6"
