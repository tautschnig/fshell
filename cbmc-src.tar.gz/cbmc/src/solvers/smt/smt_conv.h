/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com
Revision: Roberto Bruttomesso, roberto.bruttomesso@unisi.ch

\*******************************************************************/

#ifndef CPROVER_SOLVER_SMT_CONV_H
#define CPROVER_SOLVER_SMT_CONV_H

#include <sstream>
#include <set>

#include <hash_cont.h>

#include <solvers/prop/prop_conv.h>
#include <solvers/flattening/pointer_logic.h>

#include "smt_prop.h"

class smt_prop_wrappert
{
public:
  smt_prop_wrappert(
    const std::string &_benchmark,
    const std::string &_source,
    const std::string &_logic,
    std::ostream &_out):
    smt_prop(_benchmark, _source, _logic, _out) 
  { }

protected:
  smt_propt smt_prop;
};

class smt_convt:
  protected smt_prop_wrappert,
  public prop_convt
{
public:
  smt_convt(
    const std::string &_benchmark,
    const std::string &_source,
    const std::string &_logic,    
    std::ostream &_out):
    smt_prop_wrappert(_benchmark, _source, _logic, _out),
    prop_convt(smt_prop),
    array_index_bits(32)
  { }

  virtual ~smt_convt() { }

protected:
  // overloading
  virtual literalt convert(const exprt &expr);
  virtual void set_to(const exprt &expr, bool value);
  virtual exprt get(const exprt &expr) const;

  // new stuff
  void convert_expr(const exprt &expr);
  void convert_type(const typet &type);
  std::string convert_identifier(const irep_idt &identifier);
  void find_symbols(const exprt &expr);
  void find_symbols(const typet &type);
  
  void bvec_to_bool_begin(const typet &type);
  void bvec_to_bool_end(const typet &type);
  void bool_to_bvec_begin(const typet &type);
  void bool_to_bvec_end(const typet &type);

  // arrays
  typet array_index_type() const;
  void array_index(const exprt &expr);

  // pointers
  pointer_logict pointer_logic;
  void convert_address_of_rec(const exprt &expr);
  
  // byte extraction/update
  void convert_byte_update(const exprt &expr);
  void convert_byte_extract(const exprt &expr);

  // keeps track of all symbols
  struct identifiert
  {
    typet type;
    exprt value;
    
    identifiert()
    {
      type.make_nil();
      value.make_nil();
    }
  };
  
  void set_value(
    identifiert &identifier,
    const std::string &v);
  
  typedef hash_map_cont<irep_idt, identifiert, irep_id_hash>
    identifier_mapt;

  identifier_mapt identifier_map;
  
  unsigned array_index_bits;
  
  // for replacing 'array_of'
  typedef std::map<exprt, irep_idt> array_of_mapt;
  array_of_mapt array_of_map;
  
  // for replacing 'array initializers'
  typedef std::map<exprt, irep_idt> array_init_mapt;
  array_init_mapt array_init_map;
};

#endif
