/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

Revisions: Roberto Bruttomesso, roberto.bruttomesso@unisi.ch

\*******************************************************************/

#include <assert.h>

#include <i2string.h>

#include "smt_prop.h"

/*******************************************************************\

Function: smt_propt::smt_propt

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

smt_propt::smt_propt(
  const std::string &benchmark,
  const std::string &source,
  const std::string &logic,
  std::ostream &_out):out(_out)
{
  out << "(benchmark " << benchmark << std::endl;
  out << ":source { " << source << " }" << std::endl;
  out << ":status unknown" << std::endl;
  out << ":logic " << logic << std::endl;
  _no_variables=0;
}

/*******************************************************************\

Function: smt_propt::~smt_propt

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

smt_propt::~smt_propt()
{
  out << ") ; benchmark" << std::endl;
}

/*******************************************************************\

Function: smt_propt::land

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::land(const bvt &bv)
{
  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; land" << std::endl;
  out << " (iff " << smt_literal(l) << " (and";
  
  for(unsigned int i=0; i<bv.size(); i++)
    out << " " << smt_literal(bv[i]);

  out << "))" << std::endl;

  return l;
}
  
/*******************************************************************\

Function: smt_propt::lor

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lor(const bvt &bv)
{
  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; lor" << std::endl;
  out << " (iff " << smt_literal(l) << " (or";

  for(unsigned int i=0; i<bv.size(); i++)
    out << " " << smt_literal(bv[i]);

  out << "))" << std::endl;

  return l;
}
  
/*******************************************************************\

Function: smt_propt::lxor

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lxor(const bvt &bv)
{
  if(bv.size()==0) return const_literal(false);
  if(bv.size()==1) return bv[0];

  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; lxor" << std::endl;
  out << " (iff " << smt_literal(l) << " (xor";

  for(unsigned int i=0; i<bv.size(); i++)
    out << " " << smt_literal(bv[i]);

  out << "))" << std::endl;

  return l;
}
  
/*******************************************************************\

Function: smt_propt::land

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::land(literalt a, literalt b)
{
  if(a==const_literal(true)) return b;
  if(b==const_literal(true)) return a;
  if(a==const_literal(false)) return const_literal(false);
  if(b==const_literal(false)) return const_literal(false);
  if(a==b) return a;

  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; land" << std::endl;
  out << " (iff " << smt_literal(l) << " (and";
  out << " " << smt_literal(a);
  out << " " << smt_literal(b);
  out << "))" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt_propt::lor

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lor(literalt a, literalt b)
{
  if(a==const_literal(false)) return b;
  if(b==const_literal(false)) return a;
  if(a==const_literal(true)) return const_literal(true);
  if(b==const_literal(true)) return const_literal(true);
  if(a==b) return a;
  
  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; lor" << std::endl;
  out << " (iff " << smt_literal(l) << " (or";
  out << " " << smt_literal(a);
  out << " " << smt_literal(b);
  out << "))" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt_propt::lnot

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lnot(literalt a)
{
  a.invert();
  return a;
}

/*******************************************************************\

Function: smt_propt::lxor

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lxor(literalt a, literalt b)
{
  if(a==const_literal(false)) return b;
  if(b==const_literal(false)) return a;
  if(a==const_literal(true)) return lnot(b);
  if(b==const_literal(true)) return lnot(a);

  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; lxor" << std::endl;
  out << " (iff " << smt_literal(l) << " (xor";
  out << " " << smt_literal(a);
  out << " " << smt_literal(b);
  out << "))" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt_propt::lnand

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lnand(literalt a, literalt b)
{
  return lnot(land(a, b));
}

/*******************************************************************\

Function: smt_propt::lnor

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lnor(literalt a, literalt b)
{
  return lnot(lor(a, b));
}

/*******************************************************************\

Function: smt_propt::lequal

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lequal(literalt a, literalt b)
{
  return lnot(lxor(a, b));
}

/*******************************************************************\

Function: smt_propt::limplies

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::limplies(literalt a, literalt b)
{
  return lor(lnot(a), b);
}

/*******************************************************************\

Function: smt_propt::lselect

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::lselect(literalt a, literalt b, literalt c)
{ 
  if(a==const_literal(true)) return b;
  if(a==const_literal(false)) return c;
  if(b==c) return b;

  if(a==const_literal(false)) return b;
  if(b==const_literal(false)) return a;
  if(a==const_literal(true)) return lnot(b);
  if(b==const_literal(true)) return lnot(a);

  out << std::endl;

  literalt l=new_variable();

  out << ":assumption ; lselect" << std::endl;
  out << " (iff " << smt_literal(l) << "(if_then_else "
      << smt_literal(a) << " " << smt_literal(b) << " "
      << smt_literal(c) << ")" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt_propt::new_variable

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt_propt::new_variable()
{
  literalt l;
  l.set(_no_variables, false);
  _no_variables++;
  
  out << ":extrapreds((" << smt_literal(l) << "))" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt_propt::lcnf

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt_propt::lcnf(const bvt &bv)
{
  out << std::endl;
  out << ":assumption ; lcnf" << std::endl;
  out << " ";

  if(bv.empty())
    out << "false ; the empty clause";
  else if(bv.size()==1)
    out << smt_literal(bv.front());
  else
  {
    out << "(or";
    
    for(bvt::const_iterator it=bv.begin(); it!=bv.end(); it++)
      out << " " << smt_literal(*it);

    out << ")";
  }

  out << std::endl;
}

/*******************************************************************\

Function: smt_propt::smt_literal

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string smt_propt::smt_literal(literalt l)
{
  if(l==const_literal(false))
    return "false";
  else if(l==const_literal(true))
    return "true";
    
  std::string v="B"+i2string(l.var_no());

  if(l.sign())
    return "(not "+v+")";  

  return v;
}

/*******************************************************************\

Function: smt_propt::l_get

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

tvt smt_propt::l_get(literalt literal) const
{
  if(literal.is_true()) return tvt(true);
  if(literal.is_false()) return tvt(false);

  unsigned v=literal.var_no();
  if(v>=assignment.size()) return tvt(tvt::TV_UNKNOWN);
  tvt r=assignment[v];
  return literal.sign()?!r:r;
}

/*******************************************************************\

Function: smt_propt::set_assignment

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt_propt::set_assignment(literalt literal, bool value)
{
  if(literal.is_true() || literal.is_false()) return;

  unsigned v=literal.var_no();
  assert(v<assignment.size());
  assignment[v]=tvt(value);
}

/*******************************************************************\

Function: smt_propt::prop_solve

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

propt::resultt smt_propt::prop_solve()
{
  return P_ERROR;
}
