/*******************************************************************\

Module: SMT Backend

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <config.h>
#include <arith_tools.h>
#include <expr_util.h>
#include <std_types.h>
#include <std_expr.h>
#include <i2string.h>
#include <bitvector.h>
#include <string2array.h>
#include <fixedbv.h>
#include <pointer_offset_size.h>

#include <langapi/language_util.h>

#include <solvers/flattening/boolbv_width.h>

#include "smt2_conv.h"

/*******************************************************************\

Function: smt2_convt::dec_solve

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

decision_proceduret::resultt smt2_convt::dec_solve()
{
  smt2_prop.finalize();
  return decision_proceduret::D_ERROR;
}

/*******************************************************************\

Function: smt2_convt::get

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

exprt smt2_convt::get(const exprt &expr) const
{
  if(expr.id()=="symbol")
  {
    const irep_idt &id=to_symbol_expr(expr).get_identifier();

    identifier_mapt::const_iterator it=identifier_map.find(id);

    if(it!=identifier_map.end())
      return it->second.value;
  }

  return static_cast<const exprt &>(get_nil_irep());
}

/*******************************************************************\

Function: smt2_convt::set_value

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::set_value(
  identifiert &identifier,
  const std::string &v)
{
  identifier.value.make_nil();
  
  const typet &type=identifier.type;

  if(type.id()=="signedbv" ||
     type.id()=="unsignedbv" ||
     type.id()=="bv" ||
     type.id()=="fixedbv")
  {
    assert(v.size()==bv_width(type));
    constant_exprt c(type);
    c.set_value(v);
    identifier.value=c;
  }
  else if(type.id()=="bool")
  {
    if(v=="1")
      identifier.value.make_true();
    else if(v=="0")
      identifier.value.make_false();
  }
  else if(type.id()=="pointer")
  {
    // TODO
    #if 0
    assert(v.size()==BV_ADDR_BITS+config.ansi_c.pointer_width);

    pointer_logict::pointert p;
    p.object=integer2long(binary2integer(std::string(v, 0, BV_ADDR_BITS), false));
    p.offset=binary2integer(std::string(v, BV_ADDR_BITS, std::string::npos), true);
    
    identifier.value=pointer_logic.pointer_expr(p, type);
    #endif
  }
  else if(type.id()=="struct")
  {
    // TODO
  }   
  else if(type.id()=="union")
  {
    // TODO
  }   
}

/*******************************************************************\

Function: smt2_convt::array_index_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

typet smt2_convt::array_index_type() const
{
  signedbv_typet t;
  t.set_width(array_index_bits);
  return t;
}

/*******************************************************************\

Function: smt2_convt::array_index

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::array_index(const exprt &expr)
{
  typet t=array_index_type();
  if(t==expr.type()) return convert_expr(expr);
  typecast_exprt tmp(t);
  tmp.op0()=expr;
  convert_expr(tmp);
}

/*******************************************************************\

Function: smt2_convt::convert_address_of_rec

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_address_of_rec(const exprt &expr)
{
  if(expr.id()=="symbol" ||
     expr.id()=="constant" ||
     expr.id()=="string-constant")
  {
    smt2_prop.out
      << "((ind tuple 2) (ind bv"
      << pointer_logic.add_object(expr) << " " << BV_ADDR_BITS << ")"
      << " (ind bv0 " << config.ansi_c.pointer_width << "))";
  }
  else if(expr.id()=="index")
  {
    if(expr.operands().size()!=2)
      throw "index takes two operands";

    const exprt &array=to_index_expr(expr).array();
    const exprt &index=to_index_expr(expr).index();
    
    if(index.is_zero())
    {
      if(array.type().id()=="pointer")
        convert_expr(array);
      else if(array.type().id()=="array")
        convert_address_of_rec(array);
      else
        assert(false);
    }
    else
    {    
      // this is really pointer arithmetic
      exprt new_index_expr=expr;
      new_index_expr.op1()=gen_zero(index.type());
      
      exprt address_of_expr("address_of", pointer_typet());
      address_of_expr.type().subtype()=array.type().subtype();
      address_of_expr.copy_to_operands(new_index_expr);
      
      exprt plus_expr("+", address_of_expr.type());
      plus_expr.copy_to_operands(address_of_expr, index);

      convert_expr(plus_expr);
    }
  }
  else if(expr.id()=="member")
  {
    if(expr.operands().size()!=1)
      throw "member takes one operand";
      
    const member_exprt &member_expr=to_member_expr(expr);

    const exprt &struct_op=member_expr.struct_op();

    if(struct_op.type().id()=="struct")
    {
      const struct_typet &struct_type=
        to_struct_type(struct_op.type());
    
      const struct_typet::componentst &components=
        struct_type.components();
    
      const irep_idt &component_name=
        member_expr.get_component_name();
        
      bool found=false;
      
      mp_integer offset=1; // for the struct itself

      for(struct_typet::componentst::const_iterator
          it=components.begin();
          it!=components.end();
          it++)
      {
        if(component_name==it->get_name()) { found=true; break; }
        const typet &subtype=it->type();
        mp_integer sub_size=pointer_offset_size(subtype);
        if(sub_size==0) assert(false);
        offset+=sub_size;
      }
      
      assert(found);
      
      typet index_type("unsignedbv");
      index_type.set("width", config.ansi_c.pointer_width);

      smt2_prop.out << "(bvadd ";
      convert_address_of_rec(struct_op);
      smt2_prop.out << "((ind zero_extend " << BV_ADDR_BITS << ") ";
      convert_expr(from_integer(offset, index_type));
      smt2_prop.out << "))"; // zero_extend, bvadd
    }
    else
      throw "unexpected type of member operand";

  }
  else
    throw "don't know how to take address of: "+expr.id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_byte_extract

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_byte_extract(const exprt &expr)
{
  mp_integer i;
  if(to_integer(expr.op1(), i))
    throw "byte_extract takes constant as second parameter";
  
  unsigned w;
  if(boolbv_get_width(expr.op0().type(), w))
    throw "failed to get width of byte_extract operand";
        
  smt2_prop.out << "";
  
  mp_integer upper, lower;
  
  if(expr.id()=="byte_extract_little_endian")
  {
    upper = ((i+1)*8)-1;
    lower = i*8;
  } 
  else
  {
    mp_integer max=w-1;
    upper = max-(i*8);
    lower = max-((i+1)*8-1); 
  }
  
  smt2_prop.out << "((ind extract " << upper << " " << lower << ") ";    
  convert_expr(expr.op0());
  smt2_prop.out << ")";
}

/*******************************************************************\

Function: smt2_convt::convert_byte_update

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_byte_update(const exprt &expr)
{
  assert(expr.operands().size()==3);
    
  // The situation: expr.op0 needs to be split in 3 parts
  // |<--- L --->|<--- M --->|<--- R --->|
  // where M is the expr.op1'th byte
  // We need to output L expr.op2 R
  
  mp_integer i;
  if(to_integer(expr.op1(), i))
    throw "byte_extract takes constant as second parameter";
  
  unsigned w;
  if(boolbv_get_width(expr.op0().type(), w))
    throw "failed to get width of byte_extract operand";
              
  mp_integer upper, lower; // of the byte
  mp_integer max=w-1;
  if(expr.id()=="byte_update_little_endian")
  {
    upper = ((i+1)*8)-1;
    lower = i*8;
  } 
  else
  {    
    upper = max-(i*8);
    lower = max-((i+1)*8-1); 
  }
  
  if(upper==max)
  {
    if(lower==0) // there was only one byte
      convert_expr(expr.op2());
    else // uppermost byte selected, only R needed
    {
      smt2_prop.out << "(concat ";    
      convert_expr(expr.op2());
      smt2_prop.out << " ((ind extract " << lower-1 << " 0) ";
      convert_expr(expr.op0());
      smt2_prop.out << "))";
    }
  }
  else
  {
    if(lower==0) // lowermost byte selected, only L needed
    {
      smt2_prop.out << "(concat ";
      smt2_prop.out << "((ind extract " << max << " " << (upper+1) << ") ";
      convert_expr(expr.op0());
      smt2_prop.out << ") ";
      convert_expr(expr.op2());
      smt2_prop.out << ")";
    }
    else // byte in the middle selected, L & R needed
    {
      smt2_prop.out << "(concat (concat ";
      smt2_prop.out << "((ind extract " << max << " " << (upper+1) << ") ";
      convert_expr(expr.op0());
      smt2_prop.out << ") ";
      convert_expr(expr.op2());
      smt2_prop.out << ") ((ind extract " << (lower-1) << " 0) ";
      convert_expr(expr.op0());
      smt2_prop.out << "))";
    }
  }
  
}

/*******************************************************************\

Function: smt2_convt::convert

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

literalt smt2_convt::convert(const exprt &expr)
{
  assert(expr.type().id()=="bool");

  if(expr.is_true())
    return const_literal(true);
  else if(expr.is_false())
    return const_literal(false);

  smt2_prop.out << std::endl;

  find_symbols(expr);

  literalt l=smt2_prop.new_variable();  
  smt2_prop.out << ":assumption ; convert " << std::endl
                << " (= " << smt2_prop.smt2_literal(l) << " ";
  convert_expr(expr);
  smt2_prop.out << ")" << std::endl;

  return l;
}

/*******************************************************************\

Function: smt2_convt::convert_identifier

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string smt2_convt::convert_identifier(const irep_idt &identifier)
{
  // TODO: need to search for '|' in there
  std::string result="|"+id2string(identifier)+"|";
  return result;
}

/*******************************************************************\

Function: smt2_convt::convert_expr

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_expr(const exprt &expr)
{  
  if(expr.id()=="symbol")
  {
    irep_idt id=to_symbol_expr(expr).get_identifier();
    assert(id!="");

    smt2_prop.out << convert_identifier(id);
  }
  else if(expr.id()=="nondet_symbol")
  {
    irep_idt id=expr.get("identifier");
    assert(id!="");

    smt2_prop.out << "nondet_" << convert_identifier(id);
  }
  else if(expr.id()=="typecast")
  {
    convert_typecast(to_typecast_expr(expr));
  }
  else if(expr.id()=="struct")
  {
    convert_struct(expr);
  }
  else if(expr.id()=="union")
  {
    convert_union(expr);
  }
  else if(expr.id()=="constant")
  {
    convert_constant(to_constant_expr(expr));
  }
  else if(expr.id()=="concatenation" || 
          expr.id()=="bitand" ||
          expr.id()=="bitor" ||
          expr.id()=="bitxor" ||
          expr.id()=="bitnand" ||
          expr.id()=="bitnor")
  {
    assert(expr.operands().size()>=2);
  
    smt2_prop.out << "(";

    if(expr.id()=="concatenation")
      smt2_prop.out << "concat";
    else if(expr.id()=="bitand")
      smt2_prop.out << "bvand";
    else if(expr.id()=="bitor")
      smt2_prop.out << "bvor";
    else if(expr.id()=="bitxor")
      smt2_prop.out << "bvxor";
    else if(expr.id()=="bitnand")
      smt2_prop.out << "bvnand";
    else if(expr.id()=="bitnor")
      smt2_prop.out << "bvnor";

    forall_operands(it, expr)
    {
      smt2_prop.out << " ";
      convert_expr(*it);
    }

    smt2_prop.out << ")";
  }
  else if(expr.id()=="bitnot")
  {
    assert(expr.operands().size()==1);
    smt2_prop.out << "(bvnot ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="unary-")
  {
    assert(expr.operands().size()==1);
    smt2_prop.out << "(bvneg ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="if")
  {
    assert(expr.operands().size()==3);
    
    smt2_prop.out << "(ite ";
    convert_expr(expr.op0());
    smt2_prop.out << " ";
    convert_expr(expr.op1());
    smt2_prop.out << " ";
    convert_expr(expr.op2());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="and" ||
          expr.id()=="or" ||
          expr.id()=="xor")
  {
    assert(expr.type().id()=="bool");
    assert(expr.operands().size()>=2);

    if(expr.operands().size()>=2)
    {
      smt2_prop.out << "(" << expr.id();
      forall_operands(it, expr)
      {
        smt2_prop.out << " ";        
        convert_expr(*it);
      }
      smt2_prop.out << ")";
    }
    else
      assert(false);
  }
  else if(expr.id()=="=>")
  {
    assert(expr.type().id()=="bool");
    assert(expr.operands().size()==2);

    smt2_prop.out << "(implies ";    
    convert_expr(expr.op0());
    smt2_prop.out << " ";       
    convert_expr(expr.op1());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="not")
  {
    assert(expr.type().id()=="bool");
    assert(expr.operands().size()==1);

    smt2_prop.out << "(not ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="=" ||
          expr.id()=="notequal")
  {
    assert(expr.operands().size()==2);
    assert(expr.op0().type()==expr.op1().type());

    if(expr.id()=="notequal") 
    {
      smt2_prop.out << "(not (= ";
      convert_expr(expr.op0());
      smt2_prop.out << " ";
      convert_expr(expr.op1());
      smt2_prop.out << "))";
    }
    else
    {
      smt2_prop.out << "(= ";
      convert_expr(expr.op0());
      smt2_prop.out << " ";
      convert_expr(expr.op1());
      smt2_prop.out << ")";
    }
  }
  else if(expr.id()=="<=" ||
          expr.id()=="<" ||
          expr.id()==">=" ||
          expr.id()==">")
  {
    convert_relation(expr);
  }
  else if(expr.id()=="+")
  {
    convert_plus(expr);
  }
  else if(expr.id()=="-")
  {
    convert_minus(expr);
  }
  else if(expr.id()=="/")
  {
    convert_div(expr);
  }
  else if(expr.id()=="mod")
  {
    convert_mod(expr);
  }
  else if(expr.id()=="*")
  {
    convert_mul(expr);
  }
  else if(expr.id()=="address_of" ||
          expr.id()=="implicit_address_of" ||
          expr.id()=="reference_to")
  {
    assert(expr.operands().size()==1);
    assert(expr.type().id()=="pointer");
    convert_address_of_rec(expr.op0());
  }
  else if(expr.id()=="array_of")
  {
    assert(expr.type().id()=="array");
    assert(expr.operands().size()==1);

    // const array_typet &array_type=to_array_type(expr.type());

    // not really there in SMT, so we replace it
    // this is an over-approximation
    array_of_mapt::const_iterator it=array_of_map.find(expr);
    assert(it!=array_of_map.end());

    smt2_prop.out << it->second;
  }
  else if(expr.id()=="index")
  {
    convert_index(to_index_expr(expr));
  }
  else if(expr.id()=="ashr" ||
          expr.id()=="lshr" ||
          expr.id()=="shl")
  {
    assert(expr.operands().size()==2);

    if(expr.type().id()=="unsignedbv" ||
       expr.type().id()=="signedbv" ||
       expr.type().id()=="bv")
    {
      if(expr.id()=="ashr")
        smt2_prop.out << "(bvashr ";
      else if(expr.id()=="lshr")
        smt2_prop.out << "(bvlshr ";
      else if(expr.id()=="shl")
        smt2_prop.out << "(bvshl ";
      else
        assert(false);

      convert_expr(expr.op0());
      smt2_prop.out << " ";
      convert_expr(expr.op1());
      smt2_prop.out << ")";
    }
    else
      throw "unsupported type for "+expr.id_string()+
            ": "+expr.type().id_string();
  }
  else if(expr.id()=="with")
  {
    convert_with(expr);
  }
  else if(expr.id()=="member")
  {
    convert_member(to_member_expr(expr));
  }
  else if(expr.id()=="pointer_offset")
  {
    assert(expr.operands().size()==1);
    assert(expr.op0().type().id()=="pointer");
    smt2_prop.out << "((ind project 2 2) ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="pointer_object")
  {
    assert(expr.operands().size()==1);
    assert(expr.op0().type().id()=="pointer");
    unsigned ext=bv_width(expr.type())-BV_ADDR_BITS;
    
    if(ext>0)
      smt2_prop.out << "((ind zero_extend " << ext << ") ";

    smt2_prop.out << "((ind project 2 1) ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";

    if(ext>0)
      smt2_prop.out << ")";
  }
  else if(expr.id()=="same-object")
  {
    assert(expr.operands().size()==2);

    smt2_prop.out << "(= ((ind project 2 1) ";
    convert_expr(expr.op0());
    smt2_prop.out << ")";

    smt2_prop.out << " ((ind project 2 1) ";
    convert_expr(expr.op1());
    smt2_prop.out << "))";
  }
  else if(expr.id()=="is_dynamic_object")
  {
    convert_is_dynamic_object(expr);
  }
  else if(expr.id()=="invalid-pointer")
  {
    assert(expr.operands().size()==1);

    smt2_prop.out << "(= ((ind project 2 1) ";
    convert_expr(expr.op0());
    smt2_prop.out << ") (ind bv" << pointer_logic.get_invalid_object()
                  << " " << BV_ADDR_BITS << "))";
  }
  else if(expr.id()=="pointer_object_has_type")
  {
    assert(expr.operands().size()==1);

    smt2_prop.out << "false"; // TODO
  }
  else if(expr.id()=="string-constant")
  {
    exprt tmp;
    string2array_mapt::const_iterator fit=string2array_map.find(expr);
    assert(fit!=string2array_map.end());
    
    convert_expr(fit->second);
  }
  else if(expr.id()=="extractbit")
  {
    assert(expr.operands().size()==2);

    if(expr.op0().type().id()=="unsignedbv" ||
       expr.op0().type().id()=="signedbv" ||
       expr.op0().type().id()=="bv" ||
       expr.op0().type().id()=="fixedbv")
    {
      if(expr.op1().is_constant())
      {
        mp_integer i;
        if(to_integer(expr.op1(), i))
          throw "extractbit: to_integer failed";

        smt2_prop.out << "(= ((ind extract " << i << " " << i << ") ";
        convert_expr(expr.op0());
        smt2_prop.out << ") bit1)";
      }
      else
      {
        smt2_prop.out << "(= ((ind extract 0 0) ";
        // the arguments of the shift need to have the same width
        smt2_prop.out << "(bvlshr ";
        convert_expr(expr.op0());
        typecast_exprt tmp(expr.op0().type());
        tmp.op0()=expr.op1();
        convert_expr(tmp);
        smt2_prop.out << ")) bin1)"; // bvlshr, extract, =
      }
    }
    else
      throw "unsupported type for "+expr.id_string()+
            ": "+expr.op0().type().id_string();
  }
  else if(expr.id()=="replication")
  {
    assert(expr.operands().size()==2);

    mp_integer times;
    if(to_integer(expr.op0(), times))
      throw "replication takes constant as first parameter";
    
    smt2_prop.out << "((ind repeat " << times << ") ";
    // todo: need to deal with boolean
    convert_expr(expr.op1());
    smt2_prop.out << ")";
  }
  else if(expr.id()=="byte_extract_little_endian" ||
          expr.id()=="byte_extract_big_endian")
  {
    convert_byte_extract(expr);    
  }
  else if(expr.id()=="byte_update_little_endian" ||
          expr.id()=="byte_update_big_endian")
  {
    convert_byte_update(expr);
  }
  else if(expr.id()=="width")
  {
    unsigned result_width;
    if(boolbv_get_width(expr.type(), result_width))
      throw "conversion failed";

    if(expr.operands().size()!=1)
      throw "width expects 1 operand";

    unsigned op_width;
    if(boolbv_get_width(expr.op0().type(), op_width))
      throw "conversion failed";

    smt2_prop.out << "(ind bv" << op_width/8
                  << " " << result_width << ")";
  }  
  else if(expr.id()=="abs")
  {
    assert(expr.operands().size()==1);
    
    unsigned result_width;
    if(boolbv_get_width(expr.type(), result_width))
      throw "conversion failed";

    const typet &type=expr.type();

    if(type.id()=="signedbv" ||
       type.id()=="fixedbv")
    {
      smt2_prop.out << "(ite (bvslt ";
      convert_expr(expr.op0());
      smt2_prop.out << " (ind bv0 " << result_width << ")) ";
      smt2_prop.out << "(bvneg ";
      convert_expr(expr.op0());
      smt2_prop.out << ") ";
      convert_expr(expr.op0());
      smt2_prop.out << ")";
    }
    else if(type.id()=="floatbv")
    {
      smt2_prop.out << "(bvand ";
      convert_expr(expr.op0());
      smt2_prop.out << " (ind bv"
                    << (power(2, result_width-1)-1)
                    << " " << result_width << "))";
    }
    else
      throw "abs with unsupported operand type";
  }
  else if(expr.id()=="isnan")
  {
    assert(expr.operands().size()==1);

    const typet &op_type=expr.op0().type();

    if(op_type.id()=="fixedbv")
      smt2_prop.out << "false";
    else
      throw "isnan with unsupported operand type";
  }
  else if(expr.id()=="isfinite")
  {
    if(expr.operands().size()!=1)
      throw "isfinite expects one operand";

    const typet &op_type=expr.op0().type();

    if(op_type.id()=="fixedbv")
      smt2_prop.out << "true";
    else
      throw "isfinite with unsupported operand type";
  }
  else if(expr.id()=="isinf")
  {
    if(expr.operands().size()!=1)
      throw "isinf expects one operand";

    const typet &op_type=expr.op0().type();

    if(op_type.id()=="fixedbv")
      smt2_prop.out << "false";
    else
      throw "isinf with unsupported operand type";
  }
  else if(expr.id()=="isnormal")
  {
    if(expr.operands().size()!=1)
      throw "isnormal expects one operand";

    const typet &op_type=expr.op0().type();

    if(op_type.id()=="fixedbv")
      smt2_prop.out << "true";
    else
      throw "isnormal with unsupported operand type";
  }
  else if(expr.id()=="overflow-+" ||
          expr.id()=="overflow--")
  {
    assert(expr.operands().size()==2);
    assert(expr.type().id()=="bool");

    bool subtract=expr.id()=="overflow--";
    const typet &op_type=expr.op0().type();
    unsigned width=bv_width(op_type);

    if(op_type.id()=="signedbv")
    {
      // an overflow occurs if the top two bits of the extended sum differ
      smt2_prop.out << "(let ((?sum (";
      smt2_prop.out << (subtract?"bvsub":"bvadd");
      smt2_prop.out << " ((ind sign_extend 1) ";
      convert_expr(expr.op0());
      smt2_prop.out << ")";
      smt2_prop.out << " ((ind sign_extend 1) ";
      convert_expr(expr.op1());
      smt2_prop.out << ")))) "; // sign_extend, bvadd/sub let2
      smt2_prop.out << "(not (= "
                      "((ind extract " << width << " " << width << ") ?sum) "
                      "((ind extract " << (width-1) << " " << (width-1) << ") ?sum)";
      smt2_prop.out << ")))"; // =, not, let
    }
    else if(op_type.id()=="unsignedbv")
    {
      // overflow is simply carry-out
      smt2_prop.out << "(= ";
      smt2_prop.out << "((ind extract " << width << " " << width << ") ";
      smt2_prop.out << "(" << (subtract?"bvsub":"bvadd");
      smt2_prop.out << " ((ind zero_extend 1) ";
      convert_expr(expr.op0());
      smt2_prop.out << ")";
      smt2_prop.out << " ((ind zero_extend 1) ";
      convert_expr(expr.op1());
      smt2_prop.out << ")))"; // zero_extend, bvsub/bvadd, extract
      smt2_prop.out << " bit1)"; // =
    }                                 
    else
      throw "overflow check on unknown type: "+op_type.id_string();
  }
  else if(expr.id()=="overflow-*")
  {
    assert(expr.operands().size()==2);
    throw "not yet implemented: overflow-*";
  }
  else
    throw "smt2_convt::convert_expr: `"+
          expr.id_string()+"' is unsupported";
}

/*******************************************************************\

Function: smt2_convt::convert_typecast

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_typecast(const typecast_exprt &expr)
{
  assert(expr.operands().size()==1);
  const exprt &op=expr.op0();
  const typet &expr_type=expr.type();
  
  if(expr_type.id()=="bool")
  {
    // this is comparison with zero
    if(op.type().id()=="signedbv" ||
       op.type().id()=="unsignedbv" ||
       op.type().id()=="fixedbv" ||
       op.type().id()=="pointer")
    {
      smt2_prop.out << "(not (= ";
      convert_expr(op);
      smt2_prop.out << " ";
      convert_expr(gen_zero(op.type()));
      smt2_prop.out << "))";
    }
    else
    {
      throw "TODO typecast1 "+op.type().id_string()+" -> bool";
    }
  }
  else if(expr_type.id()=="signedbv" ||
          expr_type.id()=="unsignedbv" ||
          expr_type.id()=="c_enum")
  {
    unsigned to_width=bv_width(expr_type);
    
    if(op.type().id()=="signedbv" || // from signedbv
       op.type().id()=="unsignedbv" || // from unsigedbv
       op.type().id()=="c_enum")
    {
      unsigned from_width=bv_width(op.type());
      
      if(from_width==to_width)
        convert_expr(op); // ignore
      else if(from_width<to_width) // extend
      {
        if(op.type().id()=="signedbv")
          smt2_prop.out << "((ind sign_extend ";
        else
          smt2_prop.out << "((ind zero_extend";
        
        smt2_prop.out << (to_width-from_width)
                      << ") "; // ind
        convert_expr(op);
        smt2_prop.out << ")";
      }
      else // chop off extra bits
      {
        smt2_prop.out << "((ind extract " << (to_width-1) << " 0) ";
        convert_expr(op);
        smt2_prop.out << ")";
      }
    }
    else if(op.type().id()=="fixedbv") // from fixedbv
    {
      const fixedbv_typet &fixedbv_type=to_fixedbv_type(op.type());
                
      unsigned from_width=fixedbv_type.get_width();
      unsigned from_integer_bits=fixedbv_type.get_integer_bits();
      unsigned from_fraction_bits=fixedbv_type.get_fraction_bits();

      if(to_width>from_integer_bits)
      {
        smt2_prop.out << "((ind sign_extend "
                      << (to_width-from_integer_bits) << ") ";
        smt2_prop.out << "((ind extract " << (from_width-1) << " " 
                      << from_fraction_bits << ") ";
        convert_expr(op);
        smt2_prop.out << "))";
      }
      else
      {
        smt2_prop.out << "((ind extract " << (from_fraction_bits+to_width-1)
                      << " " << from_fraction_bits << ") ";
        convert_expr(op);
        smt2_prop.out << ")";
      }
    }
    else if(op.type().id()=="bool") // from boolean
    {
      smt2_prop.out << "(ite ";
      convert_expr(op);
                
      if(expr_type.id()=="fixedbv")
      {
        fixedbvt fbt(expr);
        smt2_prop.out << " (concat (ind bv1 "
                      << fbt.spec.integer_bits << ") " <<
                         "(ind bv0 " << fbt.spec.get_fraction_bits() << ")) " <<
                         "(ind bv0 " << fbt.spec.width << ")";
      }
      else
      {          
        smt2_prop.out << " (ind bv1 " << to_width << ")";
        smt2_prop.out << " (ind bv0 " << to_width << ")";        
      }
      
      smt2_prop.out << ")";
    }
    else
    {
      throw "TODO typecast2 "+op.type().id_string()+
            " -> "+expr_type.id_string();
    }
  }
  else if(expr_type.id()=="fixedbv") // to fixedbv
  {
    const fixedbv_typet &fixedbv_type=to_fixedbv_type(expr_type);
    unsigned to_fraction_bits=fixedbv_type.get_fraction_bits();
    unsigned to_integer_bits=fixedbv_type.get_integer_bits();
    
    if(op.type().id()=="unsignedbv" ||
       op.type().id()=="signedbv" ||
       op.type().id()=="enum")
    {
      unsigned from_width=to_bitvector_type(op.type()).get_width();
      smt2_prop.out << "(concat ";

      if(from_width==to_integer_bits)
        convert_expr(op);
      else if(from_width>to_integer_bits)
      {
        smt2_prop.out << "((ind extract " << (to_integer_bits-1) << " "
                      << to_fraction_bits << ") ";
        convert_expr(op);
        smt2_prop.out << ")";
      }
      else
      {
        assert(from_width<to_integer_bits);
        if(expr_type.id()=="unsignedbv")
        {
          smt2_prop.out << "(ind zero_extend "
                        << (to_integer_bits-from_width) << ") ";
          convert_expr(op);
          smt2_prop.out << ")";
        }
        else
        {
          smt2_prop.out << "((ind sign_extend "
                        << (to_integer_bits-from_width) << ") ";
          convert_expr(op);
          smt2_prop.out << ")";
        }
      }

      smt2_prop.out << "(ind bv0 " << to_fraction_bits << ")";
      smt2_prop.out << ")"; // concat
    }
    else if(op.type().id()=="bool")
    {
      smt2_prop.out << "(concat (concat"
                    << " (ind bv0 " << (to_integer_bits-1) << ")"
                    << " (ite ";
      convert_expr(op); // this returns a Bool
      smt2_prop.out << " bit1 bit0)) (ind bv0 "
                    << to_fraction_bits
                    << "))";
    }
    else if(op.type().id()=="fixedbv")
    {
      const fixedbv_typet &from_fixedbv_type=to_fixedbv_type(op.type());
      unsigned from_fraction_bits=from_fixedbv_type.get_fraction_bits();
      unsigned from_integer_bits=from_fixedbv_type.get_integer_bits();
      unsigned from_width=from_fixedbv_type.get_width();

      // TODO: use let for op
      smt2_prop.out << "(concat ";
      
      if(to_integer_bits<=from_integer_bits)
      {
        smt2_prop.out << "((ind extract "
                      << (from_fraction_bits+to_integer_bits-1) << " "
                      << from_fraction_bits
                      << ") ";
        convert_expr(op);
        smt2_prop.out << ")";
      }
      else
      {
        assert(to_integer_bits>from_integer_bits);
        smt2_prop.out << "((ind sign_extend "
                      << (to_integer_bits-from_integer_bits)
                      << ") ((ind extract "
                      << (from_width-1) << " "
                      << from_fraction_bits
                      << ") ";
        convert_expr(op);
        smt2_prop.out << "))";
      }
      
      smt2_prop.out << " ";
      
      if(to_fraction_bits<=from_fraction_bits)
      {
        smt2_prop.out << "((ind extract "
                      << (from_fraction_bits-1) << " "
                      << (from_fraction_bits-to_fraction_bits)
                      << ") ";
        convert_expr(op);
        smt2_prop.out << ")";
      }
      else
      {
        assert(to_fraction_bits>from_fraction_bits);
        smt2_prop.out << "(concat ((ind extract "
                      << (from_fraction_bits-1) << " 0) ";
        convert_expr(op);
        smt2_prop.out << ")"
                      << " (ind bv0 " << to_fraction_bits-from_fraction_bits
                      << "))";
      }
      
      smt2_prop.out << ")"; // concat
    }
    else
      throw "unexpected typecast to fixedbv";
  }
  else if(expr_type.id()=="pointer")
  {
    if(op.type().id()=="pointer")
    {
      convert_expr(op);
    }
    else
      throw "TODO typecast3 "+op.type().id_string()+" -> pointer";
  }
  else if(expr_type.id()=="range")
  {
    throw "TODO range typecast";
  }
  else
    throw "TODO typecast4 ? -> "+expr_type.id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_struct

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_struct(const exprt &expr)
{
  const struct_typet &struct_type=to_struct_type(expr.type());

  const struct_typet::componentst &components=
    struct_type.components();
    
  assert(components.size()==expr.operands().size());
  
  assert(!components.empty());
  
  if(components.size()==1)
    convert_expr(expr.op0());
  else
  {
    smt2_prop.out << "(concat";
    unsigned i=0;
    for(struct_typet::componentst::const_iterator
        it=components.begin();
        it!=components.end();
        it++, i++)
    {
      if(it->type().id()!="code")
      {
        smt2_prop.out << " ";
        //const exprt &op=expr.operands()[i];

        #if 0        
        if(op.type().id()=="array")
          flatten_array(op);
        else
          convert_expr(op);
        #endif
        // TODO
      }
    }
    
    smt2_prop.out << ")";
  }
}

/*******************************************************************\

Function: smt2_convt::convert_union

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_union(const exprt &expr)
{
  const union_typet &union_type=to_union_type(expr.type());

  assert(expr.operands().size()==1);
  const exprt &op=expr.op0();

  unsigned total_width, member_width;

  if(boolbv_get_width(union_type, total_width))
    throw "failed to get union width for union";

  if(boolbv_get_width(op.type(), member_width))
    throw "failed to get union member width for union";

  if(total_width==member_width)
  {
    // TODO: deal with boolean
    convert_expr(op);
  }
  else
  {
    // we will pad with zeros, but non-det would be better
    assert(total_width>member_width);
    smt2_prop.out << "(concat ";
    smt2_prop.out << "(ind bv0 "
                  << (total_width-member_width) << ") ";
    // TODO: deal with boolean
    convert_expr(op);
    smt2_prop.out << ")";
  }
}

/*******************************************************************\

Function: smt2_convt::convert_constant

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_constant(const constant_exprt &expr)
{
  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv" ||       
     expr.type().id()=="bv" ||
     expr.type().id()=="c_enum")
  {
    mp_integer value;

    if(to_integer(expr, value))
      throw "failed to convert bitvector constant";
      
    unsigned width=bv_width(expr.type());

    if(value<0) value=power(2, width)+value;

    smt2_prop.out << "(ind bv" << value
                  << " " << width << ")";
  }
  else if(expr.type().id()=="fixedbv")
  {
    fixedbv_spect spec(to_fixedbv_type(expr.type()));
    
    std::string v_str=id2string(expr.get("value"));
    mp_integer v=binary2integer(v_str, false);
    
    smt2_prop.out << "(ind bv" << v << " " << spec.width << ")";
  }
  else if(expr.type().id()=="floatbv")
  {
    ieee_float_spect spec(to_floatbv_type(expr.type()));
    
    std::string v_str=id2string(expr.get("value"));
    mp_integer v=binary2integer(v_str, false);
    
    smt2_prop.out << "(ind bv" << v << " " << spec.width() << ")";
  }
  else if(expr.type().id()=="pointer")
  {
    const irep_idt &value=expr.get("value");
    
    if(value=="NULL")
    {
      smt2_prop.out << "((ind tuple 2)"
                    << " (ind bv" << pointer_logic.get_null_object()
                    << " " << BV_ADDR_BITS << ")"
                    << " (ind bv0 " << config.ansi_c.pointer_width
                    << "))";
    }
    else
      throw "unknown pointer constant: "+id2string(value);
  }
  else if(expr.type().id()=="bool")
  {
    if(expr.is_true())
      smt2_prop.out << "true";
    else if(expr.is_false())
      smt2_prop.out << "false";
    else
      throw "unknown boolean constant";
  }
  else if(expr.type().id()=="array")
  {
    array_init_mapt::const_iterator it=array_init_map.find(expr);
    assert(it!=array_init_map.end());
    
    std::string tmp;
    tmp = it->second.as_string();      
    
    assert(expr.operands().size()!=0);
    
    forall_operands(it, expr)
      smt2_prop.out << "(store ";
    
    smt2_prop.out << it->second;
    
    unsigned i=0;
    forall_operands(it, expr)
    {
      exprt inx = from_integer(i, unsignedbv_typet(array_index_bits));        
      smt2_prop.out << " ";
      convert_expr(inx);
      smt2_prop.out << " ";
      convert_expr(*it);
      smt2_prop.out << ")";
      i++;
    }      
  }
  else
    throw "unknown constant: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_mod

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_mod(const exprt &expr)
{
  assert(expr.operands().size()==2);

  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv")
  {
    if(expr.type().id()=="unsignedbv")
      smt2_prop.out << "(bvurem ";
    else
      smt2_prop.out << "(bvsrem ";

    convert_expr(expr.op0());
    smt2_prop.out << " ";
    convert_expr(expr.op1());
    smt2_prop.out << ")";
  }
  else
    throw "unsupported type for mod: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_is_dynamic_object

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_is_dynamic_object(const exprt &expr)
{
  std::vector<unsigned> dynamic_objects;
  pointer_logic.get_dynamic_objects(dynamic_objects);

  assert(expr.operands().size()==1);

  if(dynamic_objects.empty())
    smt2_prop.out << "false";
  else
  {
    smt2_prop.out << "(let ((?obj ((ind project 2 1) ";
    convert_expr(expr.op0());
    smt2_prop.out << "))) ";

    if(dynamic_objects.size()==1)
    {
      smt2_prop.out << "(= (ind bv" << dynamic_objects.front()
                    << " " << BV_ADDR_BITS << ") ?obj)";
    }
    else
    {
      smt2_prop.out << "(or";

      for(std::vector<unsigned>::const_iterator
          it=dynamic_objects.begin();
          it!=dynamic_objects.end();
          it++)
        smt2_prop.out << " (= (ind bv" << *it
                      << " " << BV_ADDR_BITS << ") ?obj)";

      smt2_prop.out << ")"; // or
    }
    
    smt2_prop.out << ")"; // let
  }
}

/*******************************************************************\

Function: smt2_convt::convert_relation

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_relation(const exprt &expr)
{
  assert(expr.operands().size()==2);
  
  const typet &op_type=expr.op0().type();

  smt2_prop.out << "(";

  if(op_type.id()=="unsignedbv")
  {
    if(expr.id()=="<=")
      smt2_prop.out << "bvule";
    else if(expr.id()=="<")
      smt2_prop.out << "bvult";
    else if(expr.id()==">=")
      smt2_prop.out << "bvuge";
    else if(expr.id()==">")
      smt2_prop.out << "bvugt";
    
    smt2_prop.out << " ";
    convert_expr(expr.op0());
    smt2_prop.out << " ";
    convert_expr(expr.op1());
  }
  else if(op_type.id()=="signedbv" ||
          op_type.id()=="fixedbv")
  {
    if(expr.id()=="<=")
      smt2_prop.out << "bvsle";
    else if(expr.id()=="<")
      smt2_prop.out << "bvslt";
    else if(expr.id()==">=")
      smt2_prop.out << "bvsge";
    else if(expr.id()==">")
      smt2_prop.out << "bvsgt";
    
    smt2_prop.out << " ";
    convert_expr(expr.op0());
    smt2_prop.out << " ";
    convert_expr(expr.op1());
  }
  else
    throw "unsupported type for "+expr.id_string()+
          ": "+op_type.id_string();

  smt2_prop.out << ")";
}

/*******************************************************************\

Function: smt2_convt::convert_plus

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_plus(const exprt &expr)
{
  assert(expr.operands().size()>=2);

  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv" ||
     expr.type().id()=="fixedbv")
  {
    smt2_prop.out << "(bvadd";

    forall_operands(it, expr)
    {
      smt2_prop.out << " ";
      convert_expr(*it);
    }
      
    smt2_prop.out << ")";
  }
  else if(expr.type().id()=="pointer")
  {
    if(expr.operands().size()!=2)
      throw "pointer arithmetic with more than two operands";
    
    exprt p=expr.op0(), i=expr.op1();
    
    if(p.type().id()!="pointer")
      p.swap(i);

    if(p.type().id()!="pointer")
      throw "unexpected mixture in pointer arithmetic";
      
    mp_integer element_size=pointer_offset_size(expr.type().subtype());
    
    smt2_prop.out << "(bvadd ";
    convert_expr(p);
    smt2_prop.out << " ";
    smt2_prop.out << "((ind zero_extend " << BV_ADDR_BITS << ") ";

    if(element_size>=2)
    {
      smt2_prop.out << "(bvmul ";
      convert_expr(i);
      smt2_prop.out << " (ind bv" << element_size
                    << " " << config.ansi_c.pointer_width << "))";
    }
    else
      convert_expr(i);

    smt2_prop.out << "))";
  }
  else
    throw "unsupported type for +: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_minus

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_minus(const exprt &expr)
{
  assert(expr.operands().size()==2);

  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv" ||
     expr.type().id()=="fixedbv")
  {
    smt2_prop.out << "(bvsub ";
    
    if(expr.op0().type().id()=="pointer")
      smt2_prop.out << "((ind extract " 
                    << config.ansi_c.pointer_diff_width-1 << " 0) ";
    convert_expr(expr.op0());
    if(expr.op0().type().id()=="pointer")
      smt2_prop.out << ")";
    
    smt2_prop.out << " ";
    
    if(expr.op1().type().id()=="pointer")
      smt2_prop.out << "((ind extract "
                    << config.ansi_c.pointer_diff_width-1 << " 0) ";
    convert_expr(expr.op1());
    if(expr.op1().type().id()=="pointer")
      smt2_prop.out << ")";
          
    smt2_prop.out << ")";
  }
  else if(expr.type().id()=="pointer")
  {
    convert_expr(binary_exprt(
        expr.op0(),
        "+",
        unary_minus_exprt(expr.op1(), expr.op1().type()),
        expr.type()));
  }
  else
    throw "unsupported type for -: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_div

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_div(const exprt &expr)
{
  assert(expr.operands().size()==2);

  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv")
  {
    if(expr.type().id()=="unsignedbv")
      smt2_prop.out << "(bvudiv ";
    else
      smt2_prop.out << "(bvsdiv ";

    convert_expr(expr.op0());
    smt2_prop.out << " ";
    convert_expr(expr.op1());
    smt2_prop.out << ")";
  }
  else if(expr.type().id()=="fixedbv")
  {
    fixedbvt fbt(expr);
    unsigned fraction_bits=fbt.spec.get_fraction_bits();

    smt2_prop.out << "((ind extract " << fbt.spec.width-1 << " 0) ";
    smt2_prop.out << "(bvsdiv ";
    
    smt2_prop.out << "(concat ";
    convert_expr(expr.op0());
    smt2_prop.out << " (ind bv0 " << fraction_bits << ")) ";
    
    smt2_prop.out << "((ind sign_extend " << fraction_bits << ") ";
    convert_expr(expr.op1());
    smt2_prop.out << ")";
    
    smt2_prop.out << "))";
  }
  else
    throw "unsupported type for /: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_mul

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_mul(const exprt &expr)
{
  assert(expr.operands().size()>=2);    
  
  if(expr.type().id()=="unsignedbv" ||
     expr.type().id()=="signedbv")
  {
    forall_operands(it, expr)
      if(it!=expr.operands().begin()) smt2_prop.out << "(bvmul ";
    
    exprt::operandst::const_iterator last;

    forall_operands(it, expr)
    {
      if(it!=expr.operands().begin())
      {        
        convert_expr(*last);
        smt2_prop.out << " ";
        convert_expr(*it);
        smt2_prop.out << ")";          
      }

      last=it;
    }
  }
  else if(expr.type().id()=="fixedbv")
  {
    fixedbvt fbt(expr);
    unsigned fraction_bits=fbt.spec.get_fraction_bits();
    
    smt2_prop.out << "((ind extract "
                  << fbt.spec.width+fraction_bits-1 << " " 
                  << fraction_bits << ") ";
    
    forall_operands(it, expr)
      if(it!=expr.operands().begin())
        smt2_prop.out << "(bvmul ";
    
    exprt::operandst::const_iterator last;
    forall_operands(it, expr)
    {
      smt2_prop.out << "((ind sign_extend " << fraction_bits << ") ";
      convert_expr(*it);
      smt2_prop.out << ") ";
      
      if(it!=expr.operands().begin())
        smt2_prop.out << ")";
    }
    
    smt2_prop.out << ")";
  }          
  else
    throw "unsupported type for *: "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_with

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_with(const exprt &expr)
{
  assert(expr.operands().size()>=3);
  
  if(expr.type().id()=="array")
  {
    smt2_prop.out << "(store ";
    
    convert_expr(expr.op0());
  
    for(unsigned i=1; i<expr.operands().size(); i+=2)
    {
      assert((i+1)<expr.operands().size());
      const exprt &index=expr.operands()[i];
      const exprt &value=expr.operands()[i+1];

      smt2_prop.out << " ";
      convert_expr(index);
      smt2_prop.out << " ";
      
      convert_expr(value);
    }
    
    smt2_prop.out << ")";
  }
  else if(expr.type().id()=="struct")
  {
    const struct_typet &struct_type=to_struct_type(expr.type());

    if(expr.operands().size()==3)
    {
      const exprt &index=expr.op1();
      const exprt &value=expr.op2();

      unsigned total_width, width, offset;

      if(boolbv_get_width(expr.type(), total_width))
        throw "failed to get struct width for with";

      if(boolbv_get_width(value.type(), width))
        throw "failed to get member width for with";

      if(boolbv_member_offset(struct_type, index.get("component_name"), offset))
        throw "failed to get member offset for with";

      if(total_width==width)
        convert_expr(value);
      else
      {        
        // TODO: use let
        smt2_prop.out << "(concat";

        if(offset+width!=total_width)
        {
          smt2_prop.out << " ((ind extract " << (total_width-1)
                        << " " << (offset+width) << ") ";
          convert_expr(expr.op0());
          smt2_prop.out << ")";
        }

        smt2_prop.out << " ";
        convert_expr(value);

        if(offset!=0)
        {
          smt2_prop.out << " ((ind extract " << (offset-1) << " 0) ";
          convert_expr(expr.op0());
          smt2_prop.out << ")";
        }

        smt2_prop.out << ")"; // concat
      }
    }
    else
    {
      assert(false);
    }
  }
  else if(expr.type().id()=="union")
  {
    const union_typet &union_type=to_union_type(expr.type());

    if(expr.operands().size()==3)
    {
      //const exprt &index=expr.op1();
      const exprt &value=expr.op2();

      unsigned total_width, member_width;

      if(boolbv_get_width(union_type, total_width))
        throw "failed to get union width for with";

      if(boolbv_get_width(value.type(), member_width))
        throw "failed to get union member width for with";

      if(total_width==member_width)
      {
        // TODO: need to deal with booleans
        convert_expr(value);
      }
      else
      {        
        assert(total_width>member_width);
        smt2_prop.out << "(concat ";
        smt2_prop.out << "((ind extract " 
                      << (total_width-1)
                      << " " << member_width << ") ";
        convert_expr(expr.op0());
        smt2_prop.out << ") ";
        // TODO: need to deal with booleans
        convert_expr(value);
        smt2_prop.out << ")";
      }
    }
    else
    {
      assert(false);
    }
  }
  else
    throw "with expects struct, union, or array type, "
          "but got "+expr.type().id_string();
}

/*******************************************************************\

Function: smt2_convt::convert_index

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_index(const index_exprt &expr)
{
  assert(expr.operands().size()==2);
  
  smt2_prop.out << "(select ";
  convert_expr(expr.array());
  smt2_prop.out << " ";
  array_index(expr.index());
  smt2_prop.out << ")";
}

/*******************************************************************\

Function: smt2_convt::convert_member

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_member(const member_exprt &expr)
{
  assert(expr.operands().size()==1);

  const member_exprt &member_expr=to_member_expr(expr);
  const exprt &struct_op=member_expr.struct_op();
  const irep_idt &name=member_expr.get_component_name();
  
  if(struct_op.type().id()=="struct")
  {
    const struct_typet &struct_type=
      to_struct_type(struct_op.type());
    
    if(!struct_type.has_component(name))
      throw "failed to find struct member";
      
    unsigned number=struct_type.component_number(name);

    smt2_prop.out << "((ind project "
                  << struct_type.components().size()
                  << " " << (number+1) << ") ";
    convert_expr(struct_op);
    smt2_prop.out << ")";
  }
  else if(struct_op.type().id()=="union")
  {
    if(expr.type().id()=="signedbv" ||
       expr.type().id()=="unsignedbv" ||
       expr.type().id()=="fixedbv" ||
       expr.type().id()=="bv")
    {
      unsigned width;
    
      if(boolbv_get_width(expr.type(), width))
        throw "failed to get union member width";

      smt2_prop.out << "((ind extract "
                    << (width-1)
                    << " 0) ";
      convert_expr(struct_op);
      smt2_prop.out << ")";
    }
    else if(expr.type().id()=="bool")
    {
      smt2_prop.out << "(= ";
      smt2_prop.out << "((ind extract 0 0) ";
      convert_expr(struct_op);
      smt2_prop.out << ")";
      smt2_prop.out << " bit1)";
    }
    else
      throw "union member not implemented";
  }
  else
    assert(false);
}

/*******************************************************************\

Function: smt2_convt::convert_overflow

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_overflow(const exprt &expr)
{
}

/*******************************************************************\

Function: smt2_convt::set_to

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::set_to(const exprt &expr, bool value)
{
  if(expr.id()=="and" && value)
  {
    forall_operands(it, expr)
      set_to(*it, true);
    return;
  }

  smt2_prop.out << std::endl;

  find_symbols(expr);
  
  #if 0
  smt2_prop.out << "; CONV: "
                << from_expr(expr) << std::endl;
  #endif

  smt2_prop.out << ":assumption ; set_to "
                << (value?"true":"false") << std::endl
                << " ";

  assert(expr.type().id()=="bool");

  if(!value)
  {
    smt2_prop.out << "(not ";
    convert_expr(expr);
    smt2_prop.out << ")";
  }
  else
    convert_expr(expr);
    
  smt2_prop.out << std::endl;
}

/*******************************************************************\

Function: smt2_convt::find_symbols

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::find_symbols(const exprt &expr)
{
  find_symbols(expr.type());

  forall_operands(it, expr)
    find_symbols(*it);
    
  if(expr.id()=="symbol" ||
     expr.id()=="nondet_symbol")
  {
    // we don't track function-typed symbols
    if(expr.type().id()=="code")
      return;

    irep_idt identifier;
    
    if(expr.id()=="symbol")
      identifier=to_symbol_expr(expr).get_identifier();
    else
      identifier="nondet_"+id2string(expr.get("identifier"));

    identifiert &id=identifier_map[identifier];

    if(id.type.is_nil())
    {
      id.type=expr.type();
      
      if(id.type.id()=="bool")
      {
        smt2_prop.out << ":extrapreds(("
                      << convert_identifier(identifier)
                      << "))" << std::endl;
      }
      else
      {
        smt2_prop.out << ":extrafuns(("
                      << convert_identifier(identifier)
                      << " ";
        convert_type(expr.type());
        smt2_prop.out << "))" << std::endl;
      }
    }
  }
  else if(expr.id()=="array_of")
  {
    if(array_of_map.find(expr)==array_of_map.end())
    {      
      irep_idt id="array_of'"+i2string(array_of_map.size());
      smt2_prop.out << "; the following is a poor substitute for lambda i. x" << std::endl;
      smt2_prop.out << ":extrafuns(("
                    << id
                    << " ";
      convert_type(expr.type());
      smt2_prop.out << "))" << std::endl;
      
      // we can initialize array_ofs if they have
      // a constant size and a constant element 
      if(expr.type().find("size")!=get_nil_irep() &&
         expr.op0().id()=="constant")
      {
        const array_typet &array_type=to_array_type(expr.type());
        mp_integer size;
        
        if(!to_integer(array_type.size(), size))
        {
          // since we can't use quantifiers, let's enumerate...
          for(mp_integer i=0; i<size; ++i)
          {
            smt2_prop.out
              << ":assumption (= (select " << id
              << " (ind bv"
              << i << " " << array_index_bits << ")) ";
            convert_expr(expr.op0());
            smt2_prop.out << ")" << std::endl;
          }
        }
      }
      
      array_of_map[expr]=id;
    }
  }
  else if(expr.id()=="constant")
  {
    if(expr.type().id()=="array" &&
       array_init_map.find(expr)==array_init_map.end())
    {
      // introduce a temporary array.
      irep_idt id="array_init'"+i2string(array_init_map.size());      
      smt2_prop.out << ":extrafuns(("
                    << id
                    << " ";
      convert_type(expr.type());
      smt2_prop.out << "))" << std::endl;
      array_init_map[expr]=id;
    }    
  }
  else if(expr.id()=="string-constant")
  {
    if(string2array_map.find(expr)==string2array_map.end())
    {
      exprt t;
      string2array(expr, t);
      string2array_map[expr]=t;
      
      // introduce a temporary array.
      irep_idt id="string'"+i2string(array_init_map.size());      
      smt2_prop.out << ":extrafuns(("
                    << id
                    << " ";
      convert_type(t.type());
      smt2_prop.out << "))" << std::endl;
      array_init_map[t]=id;
    }
  }

}

/*******************************************************************\

Function: smt2_convt::convert_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::convert_type(const typet &type)
{
  if(type.id()=="array")
  {
    const array_typet &array_type=to_array_type(type);
    
    smt2_prop.out << "(Array ";
    convert_type(array_index_type());
    smt2_prop.out << " ";
    convert_type(array_type.subtype());
    smt2_prop.out << ")";
  }
  else if(type.id()=="bool")
  {
    smt2_prop.out << "Bool";
  }
  else if(type.id()=="struct")
  {
    const struct_typet::componentst &components=
      to_struct_type(type).components();
      
    smt2_prop.out << "((ind Tuple " << components.size()
                  << ") ";

    for(unsigned i=0; i<components.size(); i++)
      convert_type(components[i].type());
    
    smt2_prop.out << ")";
  }
  else if(type.id()=="code")
  {
    // these may appear in structs
    // we replace this by "Bool" in order to keep the same
    // member count
    smt2_prop.out << "Bool";
  }
  else if(type.id()=="union")
  {
    unsigned width;
    if(boolbv_get_width(type, width))
      throw "failed to get width of union";

    smt2_prop.out << "(ind BitVec " << width << ")";
  }
  else if(type.id()=="pointer" ||
          type.id()=="reference")
  {
    smt2_prop.out << "((ind Tuple 2)";
    smt2_prop.out << " (ind BitVec " << 0 << ")";
    smt2_prop.out << " (ind BitVec " << 0 << ")";
    smt2_prop.out << ")";
  }
  else if(type.id()=="bv" ||
          type.id()=="floatbv" ||
          type.id()=="fixedbv" ||
          type.id()=="unsignedbv" ||
          type.id()=="signedbv" ||
          type.id()=="c_enum")
  {
    smt2_prop.out << "(ind BitVec " << type.get("width") << ")";
  }
  else
    throw "unsupported type: "+type.id_string();
}    

/*******************************************************************\

Function: smt2_convt::find_symbols

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void smt2_convt::find_symbols(const typet &type)
{
  if(type.id()=="array")
  {
    const array_typet &array_type=to_array_type(type);
    find_symbols(array_type.size());
    find_symbols(array_type.subtype());
  }
  else if(type.id()=="incomplete_array")
  {
    find_symbols(type.subtype());
  }
  else if(type.id()=="struct" ||
          type.id()=="union")
  {
    const struct_union_typet::componentst &components=
      to_struct_union_type(type).components();

    for(unsigned i=0; i<components.size(); i++)
      find_symbols(components[i].type());
  }
  else if(type.id()=="code")
  {
    const code_typet::argumentst &arguments=
      to_code_type(type).arguments();

    for(unsigned i=0; i<arguments.size(); i++)
      find_symbols(arguments[i].type());
    
    find_symbols(to_code_type(type).return_type());
  }
  else if(type.id()=="pointer")
  {
    find_symbols(type.subtype());
  }
}
