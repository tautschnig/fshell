/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_BOOLBV_WIDTH_H
#define CPROVER_BOOLBV_WIDTH_H

#include <std_types.h>
#include <namespace.h>

#define BV_ADDR_BITS 8

class boolbv_widtht
{
public:
  explicit boolbv_widtht(const namespacet &_ns);
  virtual ~boolbv_widtht();
 
  virtual bool get_width(const typet &type, unsigned &width) const;

  virtual bool member_offset(
    const struct_typet &type,
    const irep_idt &member,
    unsigned &offset) const;
    
protected:
  const namespacet &ns;
};

bool boolbv_member_offset(
  const struct_typet &type,
  const irep_idt &member,
  unsigned &offset,
  const namespacet &ns);

bool boolbv_get_width(
  const typet &type,
  unsigned &width,
  const namespacet &ns);

#endif
