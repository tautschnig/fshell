/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_BOOLBV_WIDTH_H
#define CPROVER_BOOLBV_WIDTH_H

#include <std_types.h>

#define BV_ADDR_BITS 8

class boolbv_widtht
{
 public:
  boolbv_widtht();
  virtual ~boolbv_widtht();
 
  virtual bool get_width(const typet &type, unsigned &width) const;

  virtual bool member_offset(
    const struct_typet &type,
    const irep_idt &member,
    unsigned &offset) const;
};

bool boolbv_member_offset(
  const struct_typet &type,
  const irep_idt &member,
  unsigned &offset);

bool boolbv_get_width(const typet &type, unsigned &width);

#endif
