/*******************************************************************\

Module: SMT-LIB Builtin Logics, Finalizer for the QF_UFBV logic 

Author: CM Wintersteiger

\*******************************************************************/

#ifndef SMT_FINALIZER_QF_UFBV_H_
#define SMT_FINALIZER_QF_UFBV_H_

#include "builtin_theories.h"

#include "smt_finalizer_QF_UFBV32.h"

class smt_finalizer_QF_UFBVt : public smt_finalizer_QF_UFBV32t
{
  public:
    smt_finalizer_QF_UFBVt(
      contextt &c,
      message_handlert &mh) :
        smt_finalizer_QF_UFBV32t(c, mh) {};
    
    virtual ~smt_finalizer_QF_UFBVt( void ) {};    
      
    virtual std::string logic( void ) const
      { return std::string("QF_UFBV"); }
};

#endif /*SMT_FINALIZER_QF_UFBV_H_*/

