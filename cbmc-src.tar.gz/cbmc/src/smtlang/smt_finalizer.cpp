/*******************************************************************\

Module: SMT-LIB Builtin Logics, Finalizer Base Class 

Author: CM Wintersteiger

\*******************************************************************/

#include "smt_finalizer.h"
