/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#ifndef CPROVER_LANGUAGES_H
#define CPROVER_LANGUAGES_H

void register_languages();

#endif
