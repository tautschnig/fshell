/*******************************************************************\
 
Module: A special command line object for the gcc-like options
 
Author: CM Wintersteiger
 
Date: June 2006
 
\*******************************************************************/

#ifndef GOTO_CC_GCC_CMDLINE_H
#define GOTO_CC_GCC_CMDLINE_H

#include <cmdline.h>
#include <parseoptions.h>

class gcc_cmdlinet: public cmdlinet
{
public:
  bool parse_cmdline_result;

  gcc_cmdlinet(int, const char**);     
  
protected:
  bool parse_cmdline(int, const char**);
};

#endif /*GCC_CMDLINE_H_*/
