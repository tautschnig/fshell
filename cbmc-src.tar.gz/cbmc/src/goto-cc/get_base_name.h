/*******************************************************************\

Module: 

Author: CM Wintersteiger

Date: 

\*******************************************************************/

#include <string>

std::string get_base_name(const std::string &in);
