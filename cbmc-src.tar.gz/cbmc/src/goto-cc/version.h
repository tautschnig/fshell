#ifndef GOTO_CC_VERSION_H
#define GOTO_CC_VERSION_H

#define XML_VERSION "1.4"
#define GOTOCC_VERSION "2.6.2"

#endif /* GOTO_CC_VERSION_H */
