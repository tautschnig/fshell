#ifndef VERSION_H_
#define VERSION_H_

#define XML_VERSION "1.3"
#define GOTOCC_VERSION "2.5"

#endif /*VERSION_H_*/
