/*******************************************************************\
 
Module: GOTO-CC Main Module
 
Authors: Daniel Kroening, kroening@kroening.com
 
Date: May 2006
 
\*******************************************************************/

#include "gcc_cmdline.h"
#include "cmdline_options.h"
#include "compile.h"

/*******************************************************************\
 
Function: main
 
  Inputs:
 
 Outputs:
 
 Purpose:
 
\*******************************************************************/

int main(int argc, const char **argv)
{  
  gcc_cmdlinet cmdline(argc, argv);
  cmdline_optionst cmdline_options(cmdline);
  if (argv!=NULL) {
    cmdline_options.my_name = get_base_name(argv[0]); 
  }
  return cmdline_options.main();
}
