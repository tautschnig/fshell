/*******************************************************************\

Module: Command line interpretation for goto-cc.

Author: CM Wintersteiger

Date: June 2006

\*******************************************************************/

#ifndef CMDLINE_H_
#define CMDLINE_H_

#include <config.h>
#include <langapi/language_ui.h>
#include <cmdline.h>

#include "gcc_cmdline.h"

class cmdline_optionst : public language_uit
{
  public:
    gcc_cmdlinet &cmdline;
    std::string my_name;

    virtual int main( void );
    virtual bool doit( void );
    virtual void help( void );
    virtual void usage_error( void );

    cmdline_optionst(gcc_cmdlinet &_cmdline) :
      language_uit(_cmdline),
      cmdline(_cmdline)
    {}
};

#endif /*CMDLINE_H_*/
