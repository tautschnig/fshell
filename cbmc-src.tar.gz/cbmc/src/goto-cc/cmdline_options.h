/*******************************************************************\

Module: Command line interpretation for goto-cc.

Author: CM Wintersteiger

Date: June 2006

\*******************************************************************/

#ifndef GOTO_CC_CMDLINE_H
#define GOTO_CC_CMDLINE_H

#include <config.h>
#include <langapi/language_ui.h>
#include <cmdline.h>

#include "gcc_cmdline.h"

class cmdline_optionst: public language_uit
{
public:
  gcc_cmdlinet &cmdline;
  std::string my_name;

  virtual int main();
  virtual bool doit();
  virtual void help();
  virtual void usage_error();

  cmdline_optionst(gcc_cmdlinet &_cmdline):
    language_uit(_cmdline),
    cmdline(_cmdline)
  {
    register_languages();
  }
  
private:
  void register_languages();
};

#endif /*CMDLINE_H_*/
