/*******************************************************************\

Module: Command line option container

Author: CM Wintersteiger, 2006

\*******************************************************************/

#include <iostream>
#include <list>
#include <algorithm>
#include <cctype>

#include <message.h>
#include <stdlib.h>

#ifdef _WIN32
#define EX_OK 0
#define EX_USAGE 1
#else
#include <sysexits.h>
#endif

#include "cmdline_options.h"
#include "compile.h"
#include "version.h"

/*******************************************************************\

Function: tokenize

  Inputs: a string, a vector of tokens and a string of delimiters

 Outputs: nothing

 Purpose: fills the token vector with tokens separated by delimiters
          from the string

\*******************************************************************/

void tokenize(
  const std::string& str,
  std::vector<std::string>& tokens,
  const std::string& delimiters = " ")
{
  std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);
  std::string::size_type pos     = str.find_first_of(delimiters, lastPos);

  while (std::string::npos != pos || std::string::npos != lastPos)
  {
    tokens.push_back(str.substr(lastPos, pos - lastPos));
    lastPos = str.find_first_not_of(delimiters, pos);
    pos = str.find_first_of(delimiters, lastPos);
  }
}

/*******************************************************************\

Function: cmdline_optionst::doit

  Inputs:

 Outputs:

 Purpose: does it.

\*******************************************************************/

bool cmdline_optionst::doit()
{
  compilet compiler(cmdline);

  transform(my_name.begin(), my_name.end(), my_name.begin(), tolower);
  if (my_name.substr(0,2)=="ld" || my_name.substr(0,7)=="goto-ld")
    compiler.act_as_ld = true;

  if (cmdline.isset('v'))
  {
    if (compiler.act_as_ld)
      print("GNU ld version 2.16.91 20050610 (goto-cc " GOTOCC_VERSION ")");
    else
      print("gcc version 3.4.4 (goto-cc " GOTOCC_VERSION ")");
    return false;
  }

  if(cmdline.isset("version"))
  {
    if(compiler.act_as_ld)
    {
      print("GNU ld version 2.16.91 20050610 (goto-cc " GOTOCC_VERSION ")");
    }
    else
    {
      print("gcc (GCC) 3.4.4 (goto-cc " GOTOCC_VERSION ")\n");
    }

    print("Copyright (C) 2006 Daniel Kroening, Christoph Wintersteiger,\n"
          "Computer Systems Institute, ETH Zurich");

    return false;
  }

  if(cmdline.isset("dumpversion"))
  {
    std::cout << "3.4.4" << std::endl;
    return false;
  }

  // set the same verbosity for all
  int verbosity=1;

  if(cmdline.isset("Wall"))
  {
    verbosity=2;
  }
  
  if(cmdline.isset("verbosity"))
  {
    verbosity=atoi(cmdline.getval("verbosity"));
  }

  compiler.set_verbosity(verbosity);

  // get configuration

  config.set(cmdline);

  if(cmdline.isset('E'))
    compiler.only_preprocess = true;

  if(cmdline.isset('U'))
    config.ansi_c.undefines=cmdline.get_values('U');

  if (cmdline.isset("undef"))
    config.ansi_c.preprocessor_options.push_back("-undef");

  if(cmdline.isset('L'))
    compiler.library_paths=cmdline.get_values('L');
    // Don't add the system paths!

  if(cmdline.isset('l'))
    compiler.libraries=cmdline.get_values('l');

  compiler.doLink=!( cmdline.isset('c') || cmdline.isset('S') );

  if(cmdline.isset('o'))
    compiler.output_file=cmdline.getval('o');

  if (verbosity > 8)
  {
    std::list<std::string>::iterator it;

    std::cout << "Defines:\n";
    for (it=config.ansi_c.defines.begin(); it != config.ansi_c.defines.end(); it++)
    {
      std::cout << (*it) << std::endl;
    }
    
    std::cout << "Undefines:\n";
    for (it=config.ansi_c.undefines.begin(); it != config.ansi_c.undefines.end(); it++)
    {
      std::cout << (*it) << std::endl;
    }
    
    std::cout << "Preprocessor Options:\n";
    it=config.ansi_c.preprocessor_options.begin();
    for (; it != config.ansi_c.preprocessor_options.end(); it++)
    {
      std::cout << (*it) << std::endl;
    }

    std::cout << "Include Paths:\n";
    for (it=config.ansi_c.include_paths.begin(); it != config.ansi_c.include_paths.end(); it++)
    {
      std::cout << (*it) << std::endl;
    }

    std::cout << "Library Paths:\n";
    for (it=compiler.library_paths.begin(); it != compiler.library_paths.end(); it++)
    {
      std::cout << (*it) << std::endl;
    }

    std::cout << "Output File: " << compiler.output_file << std::endl;
  }

  // Parse input program, convert to goto program, write output
  if (compiler.doit())
    return true;

  return false;
}

/*******************************************************************\

Function: cmdline_optionst::help

  Inputs:

 Outputs:

 Purpose: display command line help

\*******************************************************************/

void cmdline_optionst::help()
{
  std::cout <<
  "\n"
  "* *         goto-cc "
  GOTOCC_VERSION
  " - Copyright (C) 2006, 2007             * *\n"
  "* *        Daniel Kroening, Christoph Wintersteiger         * *\n"
  "* *         Computer Systems Institute, ETH Zurich          * *\n"
  "* *                 kroening@kroening.com                   * *\n"
  "\n"
  "Usage:                       Purpose:\n"
  "\n"
  " goto-cc [-?] [-h] [--help]  show help\n"
  " -I path                     set include path (C/C++)\n"
  " -D macro                    define preprocessor macro (C/C++)\n"
  " -L path                     set library path (C/C++)\n"
  " -o file                     set output filename\n"
  " -c                          compile only\n"
  " --dot                       outputs a dot graph for every output file\n"
  " --v #                       verbosity level\n"
  " --xml                       use the old XML binary format\n"
  " --show-symbol-table         outputs the symbol table after linking\n"
  " --show-function-table       outputs the function table after linking\n"
  "\n";
}

/*******************************************************************\

Function: cmdline_optionst::main

  Inputs: none

 Outputs: true on error, false otherwise

 Purpose: starts the compiler

\*******************************************************************/

int cmdline_optionst::main()
{
  if(cmdline.parse_cmdline_result)
  {
    usage_error();
    return EX_USAGE;
  }

  if(cmdline.isset('?') || cmdline.isset('h') || cmdline.isset("help"))
  {
    help();
    return EX_OK;
  }

  if(doit())
    return EX_USAGE;
  else
    return EX_OK;
}

/*******************************************************************\

Function: cmdline_optionst::usage_error

  Inputs: none

 Outputs: none

 Purpose: prints a message informing the user about incorrect options

\*******************************************************************/

void cmdline_optionst::usage_error()
{
  std::cerr << "Usage error!\n\n";
  help();
}
