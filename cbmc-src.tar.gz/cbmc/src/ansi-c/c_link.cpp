/*******************************************************************\

Module: ANSI-C Linking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <location.h>
#include <namespace.h>
#include <typecheck.h>
#include <base_type.h>
#include <i2string.h>
#include <std_expr.h>
#include <std_types.h>

#include "c_link_type_eq.h"
#include "expr2c.h"
#include "c_link.h"
#include "fix_symbol.h"

class c_linkt:public typecheckt
{
public:
  c_linkt(
    contextt &_context,
    contextt &_new_context,
    const std::string &_module,
    message_handlert &_message_handler,
    fix_symbolt &_symbol_fixer):
    typecheckt(_message_handler),
    context(_context),
    new_context(_new_context),
    module(_module),
    ns(_context, _new_context),    
    symbol_fixer(_symbol_fixer),
    type_counter(0)
  {
    Forall_symbols(it, context.symbols)
      if (it->second.module!="")
        known_modules.insert(it->second.module);
  }
   
  virtual void typecheck();
 
protected:
  void duplicate(symbolt &in_context, symbolt &new_symbol);
  bool duplicate_type(const symbolt &in_context, 
                      const symbolt &new_symbol,
                      bool rename=false);
  void duplicate_symbol(symbolt &in_context, symbolt &new_symbol);
  void move(symbolt &new_symbol);
  void find_clashes();

  // overload to use language specific syntax
  virtual std::string to_string(const exprt &expr);
  virtual std::string to_string(const typet &type);

  contextt &context;
  contextt &new_context;
  std::string module;
  namespacet ns;
  
  typedef hash_set_cont<irep_idt, irep_id_hash> known_modulest;
  known_modulest known_modules;
    
  fix_symbolt &symbol_fixer;

  unsigned type_counter;  
};

/*******************************************************************\

Function: c_linkt::to_string

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string c_linkt::to_string(const exprt &expr)
{ 
  return expr2c(expr, ns);
}

/*******************************************************************\

Function: c_linkt::to_string

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

std::string c_linkt::to_string(const typet &type)
{ 
  return type2c(type, ns);
}

/*******************************************************************\

Function: c_linkt::duplicate

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_linkt::duplicate(
  symbolt &in_context,
  symbolt &new_symbol)
{
  if(new_symbol.is_type!=in_context.is_type)
  {
    str << "class conflict on symbol `" << in_context.name
        << "'";
    throw 0;
  }

  if(new_symbol.is_type)
  {
    if(duplicate_type(in_context, new_symbol))
      in_context.type=new_symbol.type;
  }
  else
    duplicate_symbol(in_context, new_symbol);
}

/*******************************************************************\

Function: c_linkt::duplicate_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool c_linkt::duplicate_type(
  const symbolt &in_context,
  const symbolt &new_symbol,
  bool rename)
{
  // check if it is the same -- use base_type_eq, not c_link_type_eq
  if(!base_type_eq(in_context.type, new_symbol.type, ns))
  {
    if(in_context.type.id()=="incomplete_struct" &&
       new_symbol.type.id()=="struct")
    {
      return true; // store new type
    }
    else if(in_context.type.id()=="struct" &&
            new_symbol.type.id()=="incomplete_struct")
    {
      // ignore
    }
    else if(in_context.type.id()=="struct" &&
            new_symbol.type.id()=="incomplete_struct")
    {
      // ignore
    }
    else if(ns.follow(in_context.type).id()=="incomplete_array" &&
            ns.follow(new_symbol.type).id()=="array")
    {
      return true; // store new type
    }
    else if(ns.follow(in_context.type).id()=="array" &&
            ns.follow(new_symbol.type).id()=="incomplete_array")
    {
      // ignore
    }
    else
    {
      if(rename)
      {              
        // rename, there are no type clashes in C
        irep_idt old_identifier=new_symbol.name;
        irep_idt new_identifier;
        
        do
        {
          new_identifier=
            id2string(old_identifier)+"#link"+i2string(type_counter++);        
        }
        while(context.symbols.find(new_identifier)!=context.symbols.end());
                
        symbol_fixer.insert(old_identifier, symbol_typet(new_identifier));
      }
      else
        throw "This shouldn't happen";
    }
  }
  
  return false;
}

/*******************************************************************\

Function: c_linkt::duplicate_symbol

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_linkt::duplicate_symbol(
  symbolt &in_context,
  symbolt &new_symbol)
{
  // see if it is a function or a variable

  bool is_code_in_context=in_context.type.id()=="code";
  bool is_code_new_symbol=new_symbol.type.id()=="code";

  if(is_code_in_context!=is_code_new_symbol)
  {
    err_location(new_symbol.location);
    str << "error: conflicting definition for symbol \""
        << in_context.display_name()
        << "\"" << std::endl;
    str << "old definition: " << to_string(in_context.type)
        << std::endl;
    str << "Module: " << in_context.module << std::endl;
    str << "new definition: " << to_string(new_symbol.type)
        << std::endl;
    str << "Module: " << new_symbol.module;
    throw 0;
  }

  if(is_code_in_context)
  {
    // both are functions

    // we don't compare the types, they will be too different

    // care about code

    if(!new_symbol.value.is_nil())
    {
      if(in_context.value.is_nil())
      {
        // the one with body wins!
        in_context.value.swap(new_symbol.value);
        in_context.type.swap(new_symbol.type); // for argument identifiers
      }
      else if(in_context.type.get_bool("#inlined"))
      {
        // ok
      }
      else if(base_type_eq(in_context.type, new_symbol.type, ns))
      {
        // keep the one in in_context -- libraries come last!
        str << "warning: function `" << in_context.name << "' in module `" << 
          new_symbol.module << "' is shadowed by a definition in module `" << 
          in_context.module << "'";
        warning();
      }
      else
      {
        err_location(new_symbol.value);
        str << "error: duplicate definition of function `"
            << in_context.name
            << "'" << std::endl;
        str << "In module `" << in_context.module
            << "' and module `" << new_symbol.module << "'";
        throw 0;
      }
    }
  }
  else
  {
    // both are variables

    if(!base_type_eq(in_context.type, new_symbol.type, ns))
    {
      if(ns.follow(in_context.type).id()=="incomplete_array" &&
         ns.follow(new_symbol.type).id()=="array")
      {
        // store new type
        in_context.type=new_symbol.type;
      }
      else if(ns.follow(in_context.type).id()=="array" &&
              ns.follow(new_symbol.type).id()=="incomplete_array")
      {
        // ignore
      }
      else if(in_context.type.id()=="incomplete_struct" &&
              new_symbol.type.id()=="struct")
      {
        // store new type
        in_context.type=new_symbol.type;
      }
      else if(in_context.type.id()=="struct" &&
              new_symbol.type.id()=="incomplete_struct")
      {
        // ignore
      }
      else if(ns.follow(in_context.type).id()=="pointer" &&
              ns.follow(new_symbol.type).id()=="incomplete_array")
      {
        // ignore
      }
      else
      {
        err_location(new_symbol.location);
        str << "error: conflicting definition for variable `"
            << in_context.name
            << "'" << std::endl;
        str << "old definition: " << to_string(in_context.type)
            << std::endl;
        str << "Module: " << in_context.module << std::endl;
        str << "new definition: " << to_string(new_symbol.type)
            << std::endl;
        str << "Module: " << new_symbol.module;
        throw 0;
      }
    }

    // care about initializers    

    if(!new_symbol.value.is_nil() &&
       !new_symbol.value.get_bool("#zero_initializer"))
    {
      if(in_context.value.is_nil() ||
         in_context.value.get_bool("#zero_initializer"))
      {
        in_context.value.swap(new_symbol.value);
      }
      else if(!base_type_eq(in_context.value, new_symbol.value, ns))
      {
        err_location(new_symbol.value);
        str << "error: conflicting initializers for variable `"
            << in_context.name
            << "'" << std::endl;
        str << "old value: " << to_string(in_context.value)
            << std::endl;
        str << "Module: " << in_context.module << std::endl;
        str << "new value: " << to_string(new_symbol.value)
            << std::endl;
        str << "Module: " << new_symbol.module;
        throw 0;
      }
    }
  }
}

/*******************************************************************\

Function: c_linkt::find_clashes

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_linkt::find_clashes()
{
  namespacet ons(context);
  namespacet nns(new_context);
  
  Forall_symbols(it, new_context.symbols)
  { 
    // build module clash table
    if(it->second.file_local && 
       known_modules.find(it->second.module)!=known_modules.end())
    { 
      // we could have a clash      
      unsigned counter=0;
      std::string newname=id2string(it->second.name);
      
      while (context.symbols.find(newname)!=context.symbols.end())
      { 
        // there is a clash, rename!        
        counter++;
        newname = id2string(it->second.name) + "#-mc-" + i2string(counter);    
      }
      
      if(counter>0)
      {
        symbol_exprt subst(newname);
        subst.location() = it->second.location;
        symbol_fixer.insert(it->second.name, 
          static_cast<const typet&>(static_cast<const irept&>(subst)));
        subst.type()=it->second.type;
        symbol_fixer.insert(it->second.name, subst);
      }          
    }
    else if(it->second.is_type)
    {
      // check if there is a type of the same name in the other module
      symbolst::const_iterator fit=context.symbols.find(it->first);
      if(fit!=context.symbols.end())
      {
        typet old_type=fit->second.type, 
              new_type=it->second.type;
        
        base_type(old_type, ons);
        base_type(new_type, nns);

        duplicate_type(fit->second, it->second, true /* rename! */);
      }
    }
  }  
}

/*******************************************************************\

Function: c_linkt::typecheck

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_linkt::typecheck()
{  
  // First fix all type and module clashes!
  
  bool progress;
  
  do 
  {
    progress=false;
    find_clashes();
    
    if(symbol_fixer.fix_context(new_context))
      progress=true;
        
    Forall_symbols(it, new_context.symbols)
      if(symbol_fixer.fix_symbol(it->second))
        progress=true;
  
  // This can propagate to other types via,
  // symbol-types, so keep going...
  } while (progress); 

  // Then move everything
  Forall_symbols(it, new_context.symbols)
  {
    move(it->second);
  }
}

/*******************************************************************\

Function: c_linkt::move

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_linkt::move(symbolt &new_symbol)
{
  // try to add it

  symbolt *new_symbol_ptr;
  if(context.move(new_symbol, new_symbol_ptr))
    duplicate(*new_symbol_ptr, new_symbol);
}

/*******************************************************************\

Function: convert_c

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool c_link(
  contextt &context,
  contextt &new_context,
  message_handlert &message_handler,
  const std::string &module,
  replace_symbolt &replace_symbol)
{
  fix_symbolt sf(replace_symbol);
  
  c_linkt c_link(context, new_context, module, 
                 message_handler, sf);
  
  return c_link.typecheck_main();
}
