/*******************************************************************\

Module: ANSI-CC Language Type Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_ANSI_C_INITIALIZER_H
#define CPROVER_ANSI_C_INITIALIZER_H

class ansi_c_initializert:public exprt
{
public:
  ansi_c_initializert():exprt(ID_initializer)
  {
  }
  
  exprt &value()
  {
    return static_cast<exprt &>(add(ID_value));
  }
  
  const exprt &value() const
  {
    return static_cast<const exprt &>(find(ID_value));
  }
  
  void set_name(const irep_idt &name)
  {
    return set(ID_name, name);
  }
  
  irep_idt get_name() const
  {
    return get(ID_name);
  }
};

extern inline ansi_c_initializert &to_ansi_c_initializer(exprt &expr)
{
  assert(expr.id()==ID_declaration);
  return static_cast<ansi_c_initializert &>(expr);
}

extern inline const ansi_c_initializert &to_ansi_c_initializer(const exprt &expr)
{
  assert(expr.id()==ID_declaration);
  return static_cast<const ansi_c_initializert &>(expr);
}

#endif
