/*******************************************************************\

Module: C++ Language Type Checking

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <config.h>
#include <simplify_expr.h>
#include <arith_tools.h>
#include <std_types.h>
#include <i2string.h>
#include <expr_util.h>

#include "c_typecheck_base.h"
#include "c_types.h"
#include "c_qualifiers.h"

/*******************************************************************\

Function: c_typecheck_baset::typecheck_type

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_typecheck_baset::typecheck_type(typet &type)
{
  if(type.id()==ID_code)
  {
    code_typet &code_type=to_code_type(type);

    code_typet::argumentst &arguments=code_type.arguments();

    // if we don't have any arguments, we assume it's (...)
    if(arguments.empty())
    {
      code_type.make_ellipsis();
    }
    else if(arguments.size()==1 &&
            arguments[0].type().id()==ID_empty)
    {
      // if we just have one argument of type void, remove it
      arguments.clear();
    }
    else
    {
      for(unsigned i=0; i<code_type.arguments().size(); i++)
      {
        code_typet::argumentt &argument=code_type.arguments()[i];
        typet &type=argument.type();

        if(type.id()==ID_KnR)
        {
          // need to look it up
          irep_idt identifier=argument.get_identifier();

          if(identifier==irep_idt())
          {
            err_location(argument);
            throw "failed to find identifier for K&R function argument";
          }

          // may be renamed
          {
            id_replace_mapt::const_iterator m_it=id_replace_map.find(identifier);
            if(m_it!=id_replace_map.end())
              identifier=m_it->second;
          }

          symbolst::iterator s_it=context.symbols.find(identifier);
          if(s_it==context.symbols.end())
          {
            err_location(argument);
            throw "failed to find K&R function argument symbol";
          }
          
          symbolt &symbol=s_it->second;
          
          if(symbol.type.id()==ID_KnR)
          {
            err_location(argument);
            throw "failed to get a type for K&R function argument";
          }

          adjust_function_argument(symbol.type);
          type=symbol.type;
        }
        else
        {
          typecheck_type(type);
          adjust_function_argument(type);
        }
      }
    }

    typecheck_type(code_type.return_type());
  }
  else if(type.id()==ID_array)
  {
    array_typet &array_type=to_array_type(type);
    exprt &size=array_type.size();

    typecheck_expr(size);
    typecheck_type(array_type.subtype());
    make_index_type(size);

    // simplify it
    simplify(size, *this);

    if(size.is_constant())
    {
      mp_integer s;
      if(to_integer(size, s))
      {
        err_location(size);
        str << "failed to convert constant: "
            << size.pretty();
        throw 0;
      }

      if(s<0)
      {
        err_location(size);
        str << "array size must not be negative, "
               "but got " << s;
        throw 0;
      }
    }
  }
  else if(type.id()==ID_incomplete_array)
  {
    typecheck_type(type.subtype());
  }
  else if(type.id()==ID_pointer)
  {
    typecheck_type(type.subtype());
  }
  else if(type.id()==ID_struct ||
          type.id()==ID_union)
  {
    struct_typet &struct_type=to_struct_type(type);
    struct_typet::componentst &components=struct_type.components();

    // check subtypes
    for(struct_typet::componentst::iterator
        it=components.begin();
        it!=components.end();
        it++)
      typecheck_type(it->type());

    unsigned anon_member_counter=0;

    // scan for anonymous members, and name them
    for(struct_typet::componentst::iterator
        it=components.begin();
        it!=components.end();
        it++)
    {
      if(it->get(ID_name)!=irep_idt()) continue;

      it->set(ID_name, "$anon"+i2string(anon_member_counter++));
      it->set_anonymous(true);
    }
  }
  else if(type.id()==ID_c_enum)
  {
  }
  else if(type.id()==ID_c_bitfield)
  {
    typecheck_type(type.subtype());

    // we turn this into unsigedbv/signedbv
    exprt &size=static_cast<exprt &>(type.add(ID_size));

    typecheck_expr(size);
    make_constant_index(size);

    mp_integer i;
    if(to_integer(size, i))
    {
      err_location(type);
      throw "failed to convert bit field width";
    }

    if(i<0)
    {
      err_location(type);
      throw "bit field size is negative";
    }

    const typet &base_type=follow(type.subtype());
    
    if(base_type.id()==ID_bool)
    {
      if(i>1)
      {
        err_location(type);
        throw "bit field size too large";
      }

      type.id(ID_unsignedbv);
      type.set(ID_width, integer2long(i));
    }
    else if(base_type.id()==ID_signedbv ||
            base_type.id()==ID_unsignedbv ||
            base_type.id()==ID_c_enum)
    {
      unsigned width=atoi(base_type.get(ID_width).c_str());

      if(i>width)
      {
        err_location(type);
        throw "bit field size too large";
      }

      width=integer2long(i);

      typet tmp(base_type);
      type.swap(tmp);
      type.set(ID_width, width);
    }
    else
    {
      err_location(type);
      str << "bit field with non-integer type: "
          << to_string(base_type);
      throw 0;
    }
  }
  else if(type.id()==ID_typeof)
  {
    // retain the qualifiers as is
    c_qualifierst c_qualifiers;
    c_qualifiers.read(type);
  
    if(type.find(ID_operands).is_nil())
    {
      typet t=static_cast<const typet &>(type.find(ID_type_arg));
      typecheck_type(t);
      type.swap(t);
    }
    else
    {
      exprt expr=((const exprt &)type).op0();
      typecheck_expr(expr);

      // undo an implicit address-of
      if(expr.id()==ID_address_of &&
         expr.get_bool(ID_C_implicit))
      {
        assert(expr.operands().size()==1);
        exprt tmp;
        tmp.swap(expr.op0());
        expr.swap(tmp);
      }

      type.swap(expr.type());
    }
    
    c_qualifiers.write(type);
  }
  else if(type.id()==ID_symbol)
  {
    // adjust identifier, if needed
    replace_symbol(type);

    const irep_idt &identifier=type.get(ID_identifier);

    symbolst::const_iterator s_it=context.symbols.find(identifier);

    if(s_it==context.symbols.end())
    {
      err_location(type);
      str << "type symbol `" << identifier << "' not found";
      throw 0;
    }

    const symbolt &symbol=s_it->second;

    if(!symbol.is_type)
    {
      err_location(type);
      throw "expected type symbol";
    }
    
    if(symbol.is_macro)
    {
      c_qualifierst c_qualifiers;
      c_qualifiers.read(type);
      type=symbol.type; // overwrite
      c_qualifiers.write(type);
    }
      
    // an extension
    if(symbol.base_name=="__CPROVER_rational")
    {
      type=rational_typet();
    }
    else if(symbol.base_name=="__CPROVER_integer")
    {
      type=integer_typet();
    }
  }
}

/*******************************************************************\

Function: c_typecheck_baset::adjust_function_argument

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_typecheck_baset::adjust_function_argument(typet &type) const
{
  if(type.id()==ID_array ||
     type.id()==ID_incomplete_array)
  {
    type.id(ID_pointer);
    type.remove(ID_size);
    type.remove(ID_C_constant);
  }
  else if(type.id()==ID_code)
  {
    // see ISO/IEC 9899:1999 page 199 clause 8
    pointer_typet tmp;
    tmp.subtype()=type;
    type.swap(tmp);
  }
}
