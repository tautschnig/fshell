/*******************************************************************\

Module: Symbol renaming during C-linking

Author: CM Wintersteiger

\*******************************************************************/

#include "fix_symbol.h"

/*******************************************************************\

Function: fix_symbolt::fix_symbol

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool fix_symbolt::fix_symbol(symbolt &symbol)
{
  type_mapt::const_iterator it=
    type_map.find(symbol.name);
  
  if(it!=type_map.end())
    symbol.name=it->second.id();
    
  bool r1=replace(symbol.type);
  bool r2=replace(symbol.value);
  
  return !r1 || !r2;
}

/*******************************************************************\

Function: fix_symbolt::fix_context

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool fix_symbolt::fix_context(contextt &context)
{
  bool res=false;
  
  for(type_mapt::const_iterator
      t_it=type_map.begin();
      t_it!=type_map.end();
      t_it++)
  {    
    symbolst::iterator s_it=context.symbols.find(t_it->first);
    
    if(s_it!=context.symbols.end()) // Otherwise it's renamed already
    {    
      symbolt s=s_it->second;
      s.name=t_it->second.get("identifier");
      context.symbols.erase(s_it);
      context.move(s);
      res=true;
    }    
  }
  
  return res;
}
