/*******************************************************************\

Module: Symbol renaming during C-linking

Author: CM Wintersteiger

\*******************************************************************/

#include <replace_symbol.h>
#include <context.h>

class fix_symbolt:public replace_symbolt
{
public:
  fix_symbolt(replace_symbolt &rs) : replace_symbolt(rs) {}
  
  bool fix_symbol(symbolt &symbol);
  bool fix_context(contextt &context);
};
