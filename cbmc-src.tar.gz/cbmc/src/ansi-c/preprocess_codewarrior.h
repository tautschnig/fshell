/*******************************************************************\

Module: ANSI-C Language Conversion

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_ANSI_C_LANGUAGE_PREPROCESS_CODEWARRIOR_H
#define CPROVER_ANSI_C_LANGUAGE_PREPROCESS_CODEWARRIOR_H

#include <iostream>

void preprocess_codewarrior(
  std::istream &in,
  std::ostream &out);

#endif
