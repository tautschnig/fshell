asm void test();

void asm test()
{
  mov eax, eax
}
