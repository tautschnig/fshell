/*******************************************************************\

Module: ANSI-C Language Conversion

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "preprocess_codewarrior.h"

/*******************************************************************\

Function: preprocess_codewarrior

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void preprocess_codewarrior(
  std::istream &in,
  std::ostream &out)
{

}
