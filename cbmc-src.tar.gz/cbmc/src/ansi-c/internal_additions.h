/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <string.h>

void ansi_c_internal_additions(std::string &code);
void ansi_c_architecture_strings(std::string &code);
