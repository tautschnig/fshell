/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __LINUX__
#include <unistd.h>
#endif

#ifdef __APPLE__
#include <unistd.h>
#endif

#include <fstream>

#include <str_getline.h>
#include <config.h>
#include <i2string.h>
#include <message_stream.h>
#include <tempfile.h>

#include "c_preprocess.h"

#define GCC_DEFINES_16 \
  " -D__INT_MAX__=32767"\
  " -D__CHAR_BIT__=8"\
  " -D__WCHAR_MAX__=32767"\
  " -D__SCHAR_MAX__=127"\
  " -D__SHRT_MAX__=32767"\
  " -D__LONG_LONG_MAX__=2147483647L"\
  " -D__LONG_MAX__=2147483647" \
  " -D__FLT_MIN__=1.17549435e-38F" \
  " -D__FLT_MAX__=3.40282347e+38F" \
  " -D__FLT_MANT_DIG__=24" \
  " -D__LDBL_MIN__=3.36210314311209350626e-4932L" \
  " -D__LDBL_MAX__=1.18973149535723176502e+4932L" \
  " -D__LDBL_MANT_DIG__=64" \
  " -D__DBL_MIN__=2.2250738585072014e-308" \
  " -D__DBL_MAX__=1.7976931348623157e+308" \
  " -D__DBL_MANT_DIG__=53" \
  " -D __SIZE_TYPE__=\"unsigned int\""\
  " -D __PTRDIFF_TYPE__=int"\
  " -D __WCHAR_TYPE__=int"\
  " -D __WINT_TYPE__=int"\
  " -D __INTMAX_TYPE__=\"long long int\""\
  " -D __UINTMAX_TYPE__=\"long long unsigned int\""

#define GCC_DEFINES_32 \
  " -D__INT_MAX__=2147483647"\
  " -D__CHAR_BIT__=8"\
  " -D__WCHAR_MAX__=2147483647"\
  " -D__SCHAR_MAX__=127"\
  " -D__SHRT_MAX__=32767"\
  " -D__LONG_LONG_MAX__=9223372036854775807LL"\
  " -D__LONG_MAX__=2147483647L" \
  " -D__FLT_MIN__=1.17549435e-38F" \
  " -D__FLT_MAX__=3.40282347e+38F" \
  " -D__FLT_MANT_DIG__=24" \
  " -D__LDBL_MIN__=3.36210314311209350626e-4932L" \
  " -D__LDBL_MAX__=1.18973149535723176502e+4932L" \
  " -D__LDBL_MANT_DIG__=64" \
  " -D__DBL_MIN__=2.2250738585072014e-308" \
  " -D__DBL_MAX__=1.7976931348623157e+308" \
  " -D__DBL_MANT_DIG__=53" \
  " -D __SIZE_TYPE__=\"long unsigned int\""\
  " -D __PTRDIFF_TYPE__=int"\
  " -D __WCHAR_TYPE__=int"\
  " -D __WINT_TYPE__=int"\
  " -D __INTMAX_TYPE__=\"long long int\""\
  " -D __UINTMAX_TYPE__=\"long long unsigned int\""
                        
#define GCC_DEFINES_LP64 \
  " -D__INT_MAX__=2147483647"\
  " -D__CHAR_BIT__=8"\
  " -D__WCHAR_MAX__=2147483647"\
  " -D__SCHAR_MAX__=127"\
  " -D__SHRT_MAX__=32767"\
  " -D__LONG_LONG_MAX__=9223372036854775807LL"\
  " -D__LONG_MAX__=9223372036854775807L"\
  " -D__FLT_MIN__=1.17549435e-38F" \
  " -D__FLT_MAX__=3.40282347e+38F" \
  " -D__FLT_MANT_DIG__=24" \
  " -D__LDBL_MIN__=3.36210314311209350626e-4932L" \
  " -D__LDBL_MAX__=1.18973149535723176502e+4932L" \
  " -D__LDBL_MANT_DIG__=64" \
  " -D__DBL_MIN__=2.2250738585072014e-308" \
  " -D__DBL_MAX__=1.7976931348623157e+308" \
  " -D__DBL_MANT_DIG__=53" \
  " -D __SIZE_TYPE__=\"long unsigned int\""\
  " -D __PTRDIFF_TYPE__=int"\
  " -D __WCHAR_TYPE__=int"\
  " -D __WINT_TYPE__=int"\
  " -D __INTMAX_TYPE__=\"long long int\""\
  " -D __UINTMAX_TYPE__=\"long long unsigned int\""

/*******************************************************************\

Function: c_preprocess

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess(
  std::istream &instream,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  std::string file=get_temporary_file("tmp.stdin", ".c");
  FILE *tmp=fopen(file.c_str(), "wt");

  char ch;
  while(instream.read(&ch, 1)!=NULL)
    fputc(ch, tmp);

  fclose(tmp);

  bool result=c_preprocess(file, outstream, message_handler);
  
  unlink(file.c_str());
  
  return result;
}

/*******************************************************************\

Function: is_dot_i_file

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

static bool is_dot_i_file(const std::string &path)
{
  const char *ext=strrchr(path.c_str(), '.');
  return ext!=NULL && std::string(ext)==".i";
}

/*******************************************************************\

Function: c_preprocess

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_codewarrior(const std::string &, std::ostream &, message_handlert &);
bool c_preprocess_arm(const std::string &, std::ostream &, message_handlert &);
bool c_preprocess_gcc(const std::string &, std::ostream &, message_handlert &);
bool c_preprocess_none(const std::string &, std::ostream &, message_handlert &);
bool c_preprocess_visual_studio(const std::string &, std::ostream &, message_handlert &);

bool c_preprocess(
  const std::string &path,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  switch(config.ansi_c.mode)
  {
  case configt::ansi_ct::MODE_CODEWARRIOR:
    return c_preprocess_codewarrior(path, outstream, message_handler);
  
  case configt::ansi_ct::MODE_GCC:
    return c_preprocess_gcc(path, outstream, message_handler);
  
  case configt::ansi_ct::MODE_VISUAL_STUDIO:
    return c_preprocess_visual_studio(path, outstream, message_handler);
  
  case configt::ansi_ct::MODE_ARM:
    return c_preprocess_arm(path, outstream, message_handler);
  
  default:
    assert(false);
  }

  // not reached  
  return true;
}

/*******************************************************************\

Function: c_preprocess_visual_studio

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_visual_studio(
  const std::string &file,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  // check extension
  if(is_dot_i_file(file))
    return c_preprocess_none(file, outstream, message_handler);

  #ifndef _WIN32
  // we fall back to gcc
  return c_preprocess_gcc(file, outstream, message_handler);
  #endif

  message_streamt message_stream(message_handler);

  std::string stderr_file=get_temporary_file("tmp.stderr", ".txt");

  std::string command;
  
  // use VC98 CL
  
  command="CL /nologo /E /D__CPROVER__";
  command+=" /D__WORDSIZE="+i2string(config.ansi_c.pointer_width);
  if(config.ansi_c.pointer_width==64)
  {
    command+=" \"/D__PTRDIFF_TYPE__=long long int\"";
    command+=" /D_WIN64"; // yes, both _WIN32 and _WIN64 get defined
  }
  else
    command+=" /D__PTRDIFF_TYPE__=int";

  // Standard Defines, ANSI9899 6.10.8
  command += " /D __STDC_VERSION__=199901L";
  command += " /D __STDC_IEC_559__=1";
  command += " /D __STDC_IEC_559_COMPLEX__=1";
  command += " /D __STDC_ISO_10646__=1";
  
  for(std::list<std::string>::const_iterator
      it=config.ansi_c.defines.begin();
      it!=config.ansi_c.defines.end();
      it++)
    command+=" /D \""+*it+"\"";

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.include_paths.begin();
      it!=config.ansi_c.include_paths.end();
      it++)
    command+=" /I \""+*it+"\"";

  std::string tmpi=get_temporary_file("tmp.cl", ".i");

  command+=" \""+file+"\"";
  command+=" > \""+tmpi+"\"";
  command+=" 2> \""+stderr_file+"\"";

  // _popen isn't very reliable on WIN32
  // that's why we use system()
  int result=system(command.c_str());

  FILE *stream=fopen(tmpi.c_str(), "r");

  if(stream==NULL)
  {
    unlink(tmpi.c_str());
    unlink(stderr_file.c_str());
    message_stream.error("Preprocessing failed (fopen failed)");
    return true;
  }

  {
    char ch;
    while((ch=fgetc(stream))!=EOF)
      outstream << ch;
  }

  fclose(stream);
  unlink(tmpi.c_str());

  // errors/warnings
  {
    std::ifstream stderr_stream(stderr_file.c_str());
    char ch;
    while((stderr_stream.read(&ch, 1))!=NULL)
      message_stream.str << ch;
  }

  unlink(stderr_file.c_str());

  if(result!=0)
  {
    message_stream.error_parse(1);
    message_stream.error("Preprocessing failed");
    return true;
  }
  else
    message_stream.error_parse(2);  

  return false;
}

/*******************************************************************\

Function: c_preprocess_codewarrior

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_codewarrior(
  const std::string &file,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  message_streamt message_stream(message_handler);

  // CodeWarrior prepends some header to the file,
  // marked with '#' signs.
  // We skip over it.
  //
  // CodeWarrior has an ugly way of marking lines, e.g.:
  //
  // /* #line 1      "__ppc_eabi_init.cpp"   /* stack depth 0 */
  //
  // We remove the initial '/* ' prefix
  
  std::ifstream in(file.c_str());
  
  std::string line;
  
  while(in)
  {
    str_getline(in, line);
    
    if(line.size()>=1 &&
       line[0]=='#' && (line[1]=='#' || line[1]==' ' || line[1]=='\t'))
    {
      // skip the line!
    }
    else if(line.size()>=3 &&
            line[0]=='/' && line[1]=='*' && line[2]==' ')
    {
      outstream << line.c_str()+3 << std::endl; // strip the '/* '
    }
    else
      outstream << line << std::endl;
  }
  
  return false;
}

/*******************************************************************\

Function: c_preprocess_gcc

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_gcc(
  const std::string &file,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  // check extension
  if(is_dot_i_file(file))
    return c_preprocess_none(file, outstream, message_handler);

  // preprocessing
  message_streamt message_stream(message_handler);

  std::string stderr_file=get_temporary_file("tmp.stderr", ".txt");

  std::string command;
  
  command=getenv("CPP")?getenv("CPP"):"gcc -E";
  command+=" -undef -D__CPROVER__";

  if(config.ansi_c.os!=configt::ansi_ct::OS_WIN)
  {
    command+=" -D__null=0";
    command+=" -D__WORDSIZE="+i2string(config.ansi_c.pointer_width);
    command+=" -D__GNUC__=4";
    command+=" -D__GNUC_MINOR__=3"; // pretty arbitrary
    
    // Tell the system library which standards we support.
    // these are not gcc-default!
    //command+=" -D_POSIX_SOURCE=1 -D_POSIX_C_SOURCE=200112L";
    //command+=" -D__STRICT_ANSI__=1";

    if(config.ansi_c.int_width==16)
      command+=GCC_DEFINES_16;
    else if(config.ansi_c.int_width==32)
      command+=GCC_DEFINES_32;
    else if(config.ansi_c.int_width==64)
      command+=GCC_DEFINES_LP64;
  }
      
  switch(config.ansi_c.os)
  {
  case configt::ansi_ct::OS_LINUX:
    if(config.ansi_c.arch==configt::ansi_ct::ARCH_I386)
       command+=" -Di386 -D__i386 -D__i386__";
    else if(config.ansi_c.arch==configt::ansi_ct::ARCH_X86_64)
       command+=" -D__LP64__ -D__x86_64 -D__x86_64__ -D_LP64";
    command+=" -Dlinux -D__linux -D__linux__ -D__gnu_linux__";
    command+=" -Dunix -D__unix -D__unix__";
    command+=" -D__USE_UNIX98";
    break;

  case configt::ansi_ct::OS_MACOS:
    if(config.ansi_c.arch==configt::ansi_ct::ARCH_I386)
      command+=" -Di386 -D__i386 -D__i386__ -D__LITTLE_ENDIAN__";
    else if(config.ansi_c.arch==configt::ansi_ct::ARCH_PPC)
      command+=" -D__BIG_ENDIAN__";
    command+=" -D__APPLE__ -D__MACH__";
    // needs to be __APPLE_CPP__ for C++
    command+=" -D__APPLE_CC__";
    break;

  case configt::ansi_ct::OS_WIN:
    command+=" -D _MSC_VER=1400";
    command+=" -D _WIN32";
    command+=" -D _M_IX86=Blend";

    if(config.ansi_c.arch==configt::ansi_ct::ARCH_X86_64)
      command+=" -D _WIN64"; // yes, both _WIN32 and _WIN64 get defined

    if(config.ansi_c.char_is_unsigned)
      command+=" -D _CHAR_UNSIGNED";
    break;

  case configt::ansi_ct::NO_OS:
    command+=" -nostdinc"; // make sure we don't mess with the system library
    break;
    
  default:
    assert(false);
  }
  
  // Standard Defines, ANSI9899 6.10.8
  command += " -D __STDC_VERSION__=199901L";
  command += " -D __STDC_IEC_559__=1";
  command += " -D __STDC_IEC_559_COMPLEX__=1";
  command += " -D __STDC_ISO_10646__=1";
  
  for(std::list<std::string>::const_iterator
      it=config.ansi_c.defines.begin();
      it!=config.ansi_c.defines.end();
      it++)
#if defined(__MINGW32__)
    command+=" -D \""+*it+"\"";
#else
    command+=" -D'"+*it+"'";
#endif

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.include_paths.begin();
      it!=config.ansi_c.include_paths.end();
      it++)
#if defined(__MINGW32__)
    command+=" -I \""+*it+"\"";
#else
    command+=" -I'"+*it+"'";
#endif

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.include_files.begin();
      it!=config.ansi_c.include_files.end();
      it++)
    command+=" -include '"+*it+"'";

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.preprocessor_options.begin();
      it!=config.ansi_c.preprocessor_options.end();
      it++)
    command+=" "+*it;
    
  int result;

  #ifdef _WIN32
  std::string tmpi=get_temporary_file("tmp.cl", ".i");
  command+=" \""+file+"\"";
  command+=" > \""+tmpi+"\"";
  command+=" 2> \""+stderr_file+"\"";

  // _popen isn't very reliable on WIN32
  // that's why we use system() and a temporary file
  result=system(command.c_str());

  FILE *stream=fopen(tmpi.c_str(), "r");

  if(stream!=NULL)
  {
    char ch;
    while((ch=fgetc(stream))!=EOF)
      outstream << ch;

    fclose(stream);
    unlink(tmpi.c_str());
  }
  else
  {
    unlink(tmpi.c_str());
    unlink(stderr_file.c_str());
    message_stream.error("Preprocessing failed (fopen failed)");
    return true;
  }
  #else
  command+=" \""+file+"\"";
  command+=" 2> \""+stderr_file+"\"";

  FILE *stream=popen(command.c_str(), "r");

  if(stream!=NULL)
  {
    char ch;
    while((ch=fgetc(stream))!=EOF)
      outstream << ch;

    result=pclose(stream);
  }
  else
  {
    unlink(stderr_file.c_str());
    message_stream.error("Preprocessing failed (popen failed)");
    return true;
  }
  #endif

  // errors/warnings
  {
    std::ifstream stderr_stream(stderr_file.c_str());
    char ch;
    while((stderr_stream.read(&ch, 1))!=NULL)
      message_stream.str << ch;
  }

  unlink(stderr_file.c_str());

  if(result!=0)
  {
    message_stream.error_parse(1);
    message_stream.error("Preprocessing failed");
    return true;
  }
  else
    message_stream.error_parse(2);

  return false;
}

/*******************************************************************\

Function: c_preprocess_arm

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_arm(
  const std::string &file,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  // check extension
  if(is_dot_i_file(file))
    return c_preprocess_none(file, outstream, message_handler);

  // preprocessing using armcc
  message_streamt message_stream(message_handler);

  std::string stderr_file=get_temporary_file("tmp.stderr", ".txt");

  std::string command;
  
  command="armcc -E -D__CPROVER__";
  
  command+=" -D__sizeof_int="+i2string(config.ansi_c.int_width/8);
  command+=" -D__sizeof_long="+i2string(config.ansi_c.long_int_width/8);
  command+=" -D__sizeof_ptr="+i2string(config.ansi_c.pointer_width/8);
  //command+=" -D__EDG_VERSION__=308";
  //command+=" -D__EDG__";
  command+=" -D__CC_ARM=1";
  //command+=" -D__ARMCC_VERSION=410000";
  command+=" -D__arm__";

  if(config.ansi_c.endianess==configt::ansi_ct::IS_BIG_ENDIAN)
    command+=" -D__BIG_ENDIAN";

  if(config.ansi_c.char_is_unsigned)
    command+=" -D__CHAR_UNSIGNED__";
    
  if(config.ansi_c.os!=configt::ansi_ct::OS_WIN)
  {
    command+=" -D__null=0";
    command+=" -D__WORDSIZE="+i2string(config.ansi_c.pointer_width);

    if(config.ansi_c.int_width==16)
      command+=GCC_DEFINES_16;
    else if(config.ansi_c.int_width==32)
      command+=GCC_DEFINES_32;
    else if(config.ansi_c.int_width==64)
      command+=GCC_DEFINES_LP64;
  }
      
  // Standard Defines, ANSI9899 6.10.8
  command+=" -D__STDC__";
  //command+=" -D__STDC_VERSION__=199901L";

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.defines.begin();
      it!=config.ansi_c.defines.end();
      it++)
    command+=" \"-D"+*it+"\"";

  for(std::list<std::string>::const_iterator
      it=config.ansi_c.include_paths.begin();
      it!=config.ansi_c.include_paths.end();
      it++)
    command+=" \"-I"+*it+"\"";

  int result;

  #ifdef _WIN32
  std::string tmpi=get_temporary_file("tmp.cl", ".i");
  command+=" \""+file+"\"";
  command+=" > \""+tmpi+"\"";
  command+=" 2> \""+stderr_file+"\"";

  //std::cout << "C: "<< command << std::endl;

  // _popen isn't very reliable on WIN32
  // that's why we use system() and a temporary file
  result=system(command.c_str());

  FILE *stream=fopen(tmpi.c_str(), "r");

  if(stream!=NULL)
  {
    char ch;
    while((ch=fgetc(stream))!=EOF)
      outstream << ch;

    fclose(stream);
    unlink(tmpi.c_str());
  }
  else
  {
    unlink(tmpi.c_str());
    unlink(stderr_file.c_str());
    message_stream.error("Preprocessing failed (fopen failed)");
    return true;
  }
  #else
  command+=" \""+file+"\"";
  command+=" 2> \""+stderr_file+"\"";

  FILE *stream=popen(command.c_str(), "r");

  if(stream!=NULL)
  {
    char ch;
    while((ch=fgetc(stream))!=EOF)
      outstream << ch;

    result=pclose(stream);
  }
  else
  {
    unlink(stderr_file.c_str());
    message_stream.error("Preprocessing failed (popen failed)");
    return true;
  }
  #endif

  // errors/warnings
  {
    std::ifstream stderr_stream(stderr_file.c_str());
    char ch;
    while((stderr_stream.read(&ch, 1))!=NULL)
      message_stream.str << ch;
  }

  unlink(stderr_file.c_str());

  if(result!=0)
  {
    message_stream.error_parse(1);
    message_stream.error("Preprocessing failed");
    return true;
  }
  else
    message_stream.error_parse(2);

  return false;
}

/*******************************************************************\

Function: c_preprocess_none

  Inputs:

 Outputs:

 Purpose: ANSI-C preprocessing

\*******************************************************************/

bool c_preprocess_none(
  const std::string &file,
  std::ostream &outstream,
  message_handlert &message_handler)
{
  std::ifstream infile(file.c_str());
  
  if(!infile)
  {
    message_streamt message_stream(message_handler);
    message_stream.error("failed to open `"+file+"'");
    return true;
  }

  char ch;

  while(infile.read(&ch, 1))
    outstream << ch;

  return false;
}
