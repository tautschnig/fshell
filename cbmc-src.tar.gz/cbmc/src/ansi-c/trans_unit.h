/*******************************************************************\

Module: Translation Unit

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <string>

std::string translation_unit(const std::string &path);
