/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <sstream>

#include <config.h>

#include "cprover_library.h"
#include "ansi_c_language.h"

/*******************************************************************\

Function: add_cprover_library

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

struct cprover_library_entryt
{
  const char *function;
  const char *model;
} cprover_library[]=
{
{ "c::abs",      "inline int abs(int i) { return __CPROVER_abs(i); }" },
{ "c::labs",     "inline long int labs(long int i) { return __CPROVER_labs(i); }" },
{ "c::fabs",     "inline double fabs(double d) { return __CPROVER_fabs(d); }" },
{ "c::fabsl",    "inline long double fabsl(long double d) { return __CPROVER_fabsl(d); }" },
{ "c::fabsf",    "inline float fabsf(float f) { return __CPROVER_fabsf(f); }" },
{ "c::isfinite", "inline int isfinite(double d) { return __CPROVER_isfinite(d); }" },
{ "c::isinf",    "inline int isinf(double d) { return __CPROVER_isinf(d); }" },
{ "c::isnan",    "inline int isnan(double d) { return __CPROVER_isnan(d); }" },
{ "c::isnormal", "inline int isnormal(double) { return __CPROVER_isnormal(d); }" },
{ "c::signbit",  "inline int signbit(double) { return __CPROVER_sign(d); }" },
{ "c::putchar", 
  "inline int putchar(int c)\n"
  "{\n"
  "  _Bool error;\n"
  "  __CPROVER_HIDE: printf(\"%c\\n\", c);\n"
  "  return (error?-1:c);\n"
  "}\n" },
{ "c::puts",
  "inline int puts(const char *s)\n"
  "{\n"
  "  _Bool error;\n"
  "  int ret;\n"
  "  __CPROVER_HIDE: printf(\"%s\\n\", s);\n"
  "  if(error) ret=-1; else __CPROVER_assume(ret>=0);\n"
  "  return ret;\n"
  "}\n" },
{ "c::strcpy",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline char *strcpy(char *dst, const char *src)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(src), \"strcpy zero-termination of 2nd argument\");\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(dst)>__CPROVER_zero_string_length(src), \"strcpy buffer overflow\");\n"
  "  dst[__CPROVER_zero_string_length(src)]=0;\n"
  "  __CPROVER_is_zero_string(dst)=1;\n"
  "  __CPROVER_zero_string_length(dst)=__CPROVER_zero_string_length(src);\n"
  "  #else\n"
  "  for(size_t i=0; src[i]!=0; i++)\n"
  "    dst[i]=src[i];\n"
  "  #endif\n"
  "  return dst;\n"
  "}\n"},
{ "c::strncpy",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline char *strncpy(char *dst, const char *src, size_t n)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(src), \"strncpy zero-termination of 2nd argument\");\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(dst)>=n, \"strncpy buffer overflow\");\n"
  "  __CPROVER_is_zero_string(dst)=__CPROVER_zero_string_length(src)<n;\n"
  "  __CPROVER_zero_string_length(dst)=__CPROVER_zero_string_length(src);\n"  
  "  #else\n"
  "  size_t i=0;\n"
  "  for( ; i<n && src[i]!=0; i++)\n"
  "    dst[i]=src[i];\n"
  "  for( ; i<n ; i++)\n"
  "    dst[i]=0;\n"
  "  #endif\n"
  "  return dst;\n"
  "}\n"},
{ "c::strcat",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline char *strcat(char *dst, const char *src)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  size_t new_size;\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(dst), \"strcat zero-termination of 1st argument\");\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(src), \"strcat zero-termination of 2nd argument\");\n"
  "  new_size=__CPROVER_zero_string_length(dst)+__CPROVER_zero_string_length(src);\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(dst)>new_size,\n"
  "                   \"strcat buffer overflow\");\n"
  "  size_t old_size=__CPROVER_zero_string_length(dst);\n"
  //"  for(size_t i=0; i<__CPROVER_zero_string_length(src); i++)\n"
  //"    dst[old_size+i];\n"
  "  dst[new_size]=0;\n"
  "  __CPROVER_is_zero_string(dst)=1;\n"
  "  __CPROVER_zero_string_length(dst)=new_size;\n"
  "  #endif\n"
  "  return dst;\n"
  "}\n"},
{ "c::strncat",  
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline char *strncat(char *dst, const char *src, size_t n)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  size_t additional, new_size;\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(dst), \"strncat zero-termination of 1st argument\");\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(src) || __CPROVER_buffer_size(src)>=n, \"strncat zero-termination of 2nd argument\");\n"
  "  additional=(n<__CPROVER_zero_string_length(src))?n:__CPROVER_zero_string_length(src);\n"
  "  new_size=__CPROVER_is_zero_string(dst)+additional;\n" 
  "  __CPROVER_assert(__CPROVER_buffer_size(dst)>new_size,\n"
  "                   \"strncat buffer overflow\");\n"   
  "  size_t dest_len=__CPROVER_zero_string_length(dst);\n" 
  "  size_t i;\n"
  "  for (i = 0 ; i < n && i<__CPROVER_zero_string_length(src) ; i++)\n"
  "    dst[dest_len + i] = src[i];\n"
  "  dst[dest_len + i] = 0;\n"
  "  __CPROVER_is_zero_string(dst)=1;\n"
  "  __CPROVER_zero_string_length(dst)=new_size;\n"
  "  #endif\n"
  "  return dst;\n"
  "}\n" },
{ "c::strcmp",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline int strcmp(const char *s1, const char *s2)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  int retval;\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(s1), \"strcmp zero-termination of 1st argument\");\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(s2), \"strcmp zero-termination of 2nd argument\");\n"
  "  if(s1 != 0 && s1 == s2) return 0;\n"
  "  if(__CPROVER_zero_string_length(s1) != __CPROVER_zero_string_length(s1)) __CPROVER_assume(retval != 0);\n"
  "  #endif\n"
  "  return retval;\n"
  "}\n" },
{ "c::strncmp",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline int strncmp(const char *s1, const char *s2, size_t n)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(s1) || __CPROVER_buffer_size(s1)>=n, \"strncmp zero-termination of 1st argument\");\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(s1) || __CPROVER_buffer_size(s2)>=n, \"strncmp zero-termination of 2nd argument\");\n"
  "  if(s1 != 0 && s1 == s2) return 0;\n"
  "  #else\n"
  "  ;\n"
  "  #endif\n"
  "}\n" },
{ "c::strlen",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline size_t strlen(const char *s)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(s), \"strlen zero-termination\");\n"
  "  return __CPROVER_zero_string_length(s);\n"
  "  #else\n"
  "  ;\n"
  "  #endif\n"
  "}\n" },
{ "c::fopen",
  "inline FILE *fopen(const char *f, const char *m)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  FILE *f=malloc(sizeof(FILE));\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(f), \"fopen zero-termination of 1st argument\");\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(m), \"fopen zero-termination of 2nd argument\");\n"
  "  #endif\n"
  "  return f;\n"
  "}\n" },
{ "c::fdopen",
  "inline FILE *fdopen(int, const char *m)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  FILE *f=malloc(sizeof(FILE));\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(m), \"fdopen zero-termination of 2nd argument\");\n"
  "  #endif\n"
  "  return f;\n"
  "}\n" },
{ "c::fgets",
  "inline char *fgets(char *str, int size, FILE *stream)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  _Bool error;\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  int resulting_size;\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(str)>=size, \"buffer-overflow in fgets\");\n"
  "  if(size>0)\n"
  "  {\n"
  "    __CPROVER_assume(resulting_size<size);\n"
  "    __CPROVER_is_zero_string(str)=!error;\n"
  "    __CPROVER_zero_string_length(str)=resulting_size;\n"
  "  }\n"
  "\n"
  "  #endif\n"
  "  return error?0:str;\n"
  "}\n" },
{ "c::strdup",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline char *strdup(char *str)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  size_t bufsz;\n"
  "  bufsz=(strlen(str)+1)*sizeof(char);\n"
  "  char *cpy=malloc(bufsz);\n"
  "  if(cpy==((void *)0)) return 0;\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assume(__CPROVER_buffer_size(cpy)==bufsz);\n"
  "  #endif\n"
  "  cpy=strcpy(cpy, str);\n" 
  "  return cpy;\n"
  "}\n" },
{ "c::getopt",
  "extern char *optarg;"
  "inline int getopt(int argc, char * const argv[],\n"
  "                  const char *optstring)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  unsigned result_index;\n"
  "  __CPROVER_assume(result_index<argc);\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_is_zero_string(optstring), "
     "\"getopt zero-termination of 3rd argument\");\n"
  "  #endif\n"
  "  optarg = argv[result_index];"
  "}\n" },
{ "c::memcpy",
  "#ifndef __CPROVER_STRING_H_INCLUDED\n"
  "#include <string.h>\n"
  "#define __CPROVER_STRING_H_INCLUDED\n"
  "#endif\n"
  "inline void *memcpy(void *dst, const void *src, size_t n)\n"
  "{\n"
  "  __CPROVER_HIDE:\n"
  "  #ifdef __CPROVER_STRING_ABSTRACTION\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(src)>=n, \"memcpy buffer overflow\");\n"
  "  __CPROVER_assert(__CPROVER_buffer_size(dst)>=n, \"memcpy buffer overflow\");\n"
  //"  for(size_t i=0; i<n ; i++) dst[i]=src[i];\n"
  "  if(__CPROVER_is_zero_string(src) &&\n"
  "     n > __CPROVER_zero_string_length(src))\n"
  "  {\n"
  "    __CPROVER_is_zero_string(dst)=1;\n"
  "    __CPROVER_zero_string_length(dst)=__CPROVER_zero_string_length(src);\n"
  "  }\n"
  "  else if(!(__CPROVER_is_zero_string(dst) &&\n"
  "            n <= __CPROVER_zero_string_length(dst)))\n"
  "    __CPROVER_is_zero_string(dst)=0;\n"
  "  #endif\n"
  "  return dst;\n"
  "}\n" },
{ "c::isalnum",
  "inline int isalnum(int c)\n"
  "{ return (c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9'); }\n" },
{ "c::isalpha",
  "inline int isalpha(int c)\n"
  "{ return (c>='a' && c<='z') || (c>='A' && c<='Z'); }\n" },
{ "c::isblank",
  "inline int isblank(int c)\n"
  "{ return c==' ' || c=='\t'; }\n" },
{ "c::iscntrl",
  "inline int iscntrl(int c)\n"
  "{ return (c>=0 && c<='\\037') || c=='\\177'; }\n" },
{ "c::isdigit",
  "inline int isdigit(int c)\n"
  "{ return c>='0' && c<='9'; }\n" },
{ "c::isgraph",
  "inline int isgraph(int c)\n"
  "{ return c>='!' && c<='~'; }\n" },
{ "c::islower",
  "inline int islower(int c)\n"
  "{ return c>='a' && c<='z'; }\n" },
{ "c::isprint",
  "inline int isprint(int c)\n"
  "{ return c>=' ' && c<='~'; }\n" },
{ "c::ispunct",
  "inline int ispunct(int c)\n"
  "{ return c=='!' ||\n" 
  "         c=='\"' ||\n"
  "         c=='#' ||\n"
  "         c=='$' ||\n" 
  "         c=='%' ||\n" 
  "         c=='&' ||\n" 
  "         c=='\\'' ||\n" 
  "         c=='(' ||\n" 
  "         c==')' ||\n" 
  "         c=='*' ||\n" 
  "         c=='+' ||\n" 
  "         c==',' ||\n" 
  "         c=='-' ||\n" 
  "         c=='.' ||\n" 
  "         c=='/' ||\n" 
  "         c==':' ||\n" 
  "         c==';' ||\n" 
  "         c=='<' ||\n" 
  "         c=='=' ||\n" 
  "         c=='>' ||\n" 
  "         c=='?' ||\n" 
  "         c=='@' ||\n" 
  "         c=='[' ||\n" 
  "         c=='\\\\' ||\n" 
  "         c==']' ||\n" 
  "         c=='^' ||\n" 
  "         c=='_' ||\n" 
  "         c=='`' ||\n" 
  "         c=='{' ||\n" 
  "         c=='|' ||\n" 
  "         c=='}' ||\n" 
  "         c=='~'; }\n" },
{ "c::isspace",
  "inline int isspace(int c)\n"
  "{ return c=='\\t' ||\n"
  "         c=='\\n' ||\n"
  "         c=='\\v' ||\n" 
  "         c=='\\f' ||\n" 
  "         c=='\\r' ||\n" 
  "         c==' '; }\n" },
{ "c::isupper",
  "inline int isupper(int c)\n"
  "{ return c>='A' && c<='Z'; }\n" },
{ "c::isxdigit",
  "inline int isxdigit(int c)\n"
  "{ return (c>='A' && c<='F') || (c>='a' && c<='f') || (c>='0' && c<='9'); }\n" },
{ "c::tolower",
  "inline int tolower(int c)\n"
  "{ return (c>='A' && c<='Z')?c+('a'-'A'):c; }\n" },
{ "c::toupper",
  "inline int toupper(int c)\n"
  "{ return (c>='a' && c<='z')?c-('a'-'A'):c; }\n" },
{ "c::pthread_mutex_init",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "inline int pthread_mutex_init("
  "pthread_mutex_t *mutex, const pthread_mutexattr_t *mutexattr)\n"
  "{ __CPROVER_HIDE: __CPROVER_mutex_lock_field(*mutex)=0; return 0; }\n" },
{ "c::pthread_mutex_lock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "inline int pthread_mutex_lock(pthread_mutex_t *mutex)\n"
  "{ __CPROVER_HIDE:\n"
  "  __CPROVER_atomic_begin();\n"
  "  __CPROVER_assume(!__CPROVER_mutex_lock_field(*mutex));\n"
  "  __CPROVER_mutex_lock_field(*mutex)=1;\n"
  "  __CPROVER_atomic_end();\n"
  "  return 0; // we never fail\n"
  "}\n" },
{ "c::pthread_mutex_trylock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_mutex_trylock(pthread_mutex_t *mutex)\n"
  "{ __CPROVER_HIDE:\n"
  "  __CPROVER_atomic_begin();\n"
  "  if(__CPROVER_mutex_lock_field(*mutex)) { __CPROVER_atomic_end(); return 1; }\n"
  "  __CPROVER_mutex_lock_field(*mutex)=1;\n"
  "  __CPROVER_atomic_end();\n"
  "  return 0;\n"
  "}\n" },
{ "c::pthread_mutex_unlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_mutex_unlock(pthread_mutex_t *mutex)\n"
  "{ __CPROVER_HIDE:\n"
  "  __CPROVER_assert(__CPROVER_mutex_lock_field(*mutex),"
  "\"must hold lock upon unlock\");\n"
  "  __CPROVER_mutex_lock_field(*mutex)=0;\n"
  "  return 0; // we never fail\n"
  "}\n" },
{ "c::pthread_mutex_destroy",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_mutex_destroy(pthread_mutex_t *mutex)\n"
  "{ }\n" },
{ "c::pthread_exit",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "void pthread_exit(void *value_ptr)\n"
  "{ __CPROVER_assume(0); }\n" },
{ "c::pthread_rwlock_destroy",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_destroy(pthread_rwlock_t *lock)\n"
  "{ }\n" },
{ "c::pthread_rwlock_init",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_init(pthread_rwlock_t *lock, "
    "const pthread_rwlockattr_t *attr)\n"
  "{ __CPROVER_HIDE: __CPROVER_rwlock_field(*lock)=0; }\n" },
{ "c::pthread_rwlock_rdlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_rdlock(pthread_rwlock_t *lock)\n"
  "{ /* TODO */ }\n" },
{ "c::pthread_rwlock_tryrdlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_tryrdlock(pthread_rwlock_t *lock)\n"
  "{ /* TODO */ }\n" },
{ "c::pthread_rwlock_trywrlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_trywrlock(pthread_rwlock_t *lock)\n"
  "{ __CPROVER_HIDE:\n"
  "  __CPROVER_atomic_begin();\n"
  "  if(__CPROVER_rwlock_field(*lock)) { __CPROVER_atomic_end(); return 1; }\n"
  "  __CPROVER_rwlock_field(*lock)=1;\n"
  "  __CPROVER_atomic_end();\n"
  "  return 0;\n"
  "}\n" },
{ "c::pthread_rwlock_unlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_unlock(pthread_rwlock_t *lock)\n"
  "{ __CPROVER_HIDE: __CPROVER_rwlock_field(*lock)=0; }\n" },
{ "c::pthread_rwlock_wrlock",
  "#ifndef __CPROVER_PTHREAD_H_INCLUDED\n"
  "#include <pthread.h>\n"
  "#define __CPROVER_PTHREAD_H_INCLUDED\n"
  "#endif\n"
  "int pthread_rwlock_wrlock(pthread_rwlock_t *lock)\n"
  "{ __CPROVER_HIDE:\n"
  "  __CPROVER_atomic_begin();\n"
  "  __CPROVER_assume(!__CPROVER_rwlock_field(*lock));\n"
  "  __CPROVER_rwlock_field(*lock)=1;\n"
  "  __CPROVER_atomic_end();\n"
  "  return 0; // we never fail\n"
  "}\n" },
{ 0, 0 }
};

void add_cprover_library(
  contextt &context,
  message_handlert &message_handler)
{
  if(config.ansi_c.lib==configt::ansi_ct::LIB_NONE)
    return;

  std::ostringstream library_text;

  library_text <<
    "#line 1 \"<builtin-library>\"\n"
    "#include <stdio.h>\n"
    "#include <stdlib.h>\n"
    "#include <string.h>\n"
    "#undef inline\n"
    "void __CPROVER_atomic_begin();\n"
    "void __CPROVER_atomic_end();\n";

  // this is for the pthread locks
  switch(config.ansi_c.os)
  {
  case configt::ansi_ct::OS_I386_MACOS:
  case configt::ansi_ct::OS_PPC_MACOS:
    library_text << "#define __CPROVER_mutex_lock_field(a) ((a).__opaque[0])\n";
    library_text << "#define __CPROVER_rwlock_field(a) ((a).__opaque[0])\n";
    break;

  case configt::ansi_ct::OS_I386_LINUX:
    library_text << "#define __CPROVER_mutex_lock_field(a) ((a).__data.__lock)\n";
    library_text << "#define __CPROVER_rwlock_field(a) ((a).__data.__lock)\n";
    break;
    
  default:;
  }

  if(config.ansi_c.string_abstraction)
    library_text << "#define __CPROVER_STRING_ABSTRACTION\n";

  unsigned count=0;
  
  for(cprover_library_entryt *e=cprover_library;
      e->function!=NULL;
      e++)
  {
    irep_idt id=e->function;
    
    symbolst::const_iterator old=
      context.symbols.find(id);

    if(old!=context.symbols.end() &&
       old->second.value.is_nil())
    {
      count++;
      library_text << e->model;
    }
  }

  if(count>0)
  {
    std::istringstream in(library_text.str());
    ansi_c_languaget ansi_c_language;
    ansi_c_language.parse(in, "", message_handler);

    contextt new_context;
    ansi_c_language.typecheck(
      new_context, "<built-in-library>", message_handler);
    
    ansi_c_language.merge_context(
      context, new_context, 
      message_handler, "<built-in-library>");
  }
}

