/* FUNCTION: __noop */

int __noop()
{
  // does nothing
}
