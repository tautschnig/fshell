/* FUNCTION: err */

#ifndef __CPROVER_ERR_H_INCLUDED
#include <err.h>
#define __CPROVER_ERR_H_INCLUDED
#endif

void err(int eval, const char *fmt, ...)
{
  // should check arguments
}

/* FUNCTION: err */

#ifndef __CPROVER_ERR_H_INCLUDED
#include <err.h>
#define __CPROVER_ERR_H_INCLUDED
#endif

void errx(int eval, const char *fmt, ...)
{
  // should check arguments
}

/* FUNCTION: warn */

#ifndef __CPROVER_ERR_H_INCLUDED
#include <err.h>
#define __CPROVER_ERR_H_INCLUDED
#endif

void warn(const char *fmt, ...)
{
  // should check arguments
}

/* FUNCTION: warnx */

#ifndef __CPROVER_ERR_H_INCLUDED
#include <err.h>
#define __CPROVER_ERR_H_INCLUDED
#endif

void warnx(const char *fmt, ...)
{
  // should check arguments
}
