/* FUNCTION: calloc */

#ifndef __CPROVER_STDLIB_H_INCLUDED
#include <stdlib.h>
#define __CPROVER_STDLIB_H_INCLUDED
#endif

inline void* calloc(size_t nmemb, size_t size)
{
  __CPROVER_HIDE:;
  void *res = malloc(nmemb*size);
  #ifdef __CPROVER_STRING_ABSTRACTION
  __CPROVER_is_zero_string(res);
  __CPROVER_zero_string_length(res)=0;
  //for(int i=0; i<nmemb*size; i++) res[i]=0;
  #else
  char *p=res;
  for(int i=0; i<nmemb*size; i++) p[i]=0;
  #endif
  return res;
}
