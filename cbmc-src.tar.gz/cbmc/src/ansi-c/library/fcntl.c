/* FUNCTION: fcntl */

#ifndef __CPROVER_FCNTL_H_INCLUDED
#include <fcntl.h>
#define __CPROVER_FCNTL_H_INCLUDED
#endif

int fcntl(int fd, int cmd, ...)
{
__CPROVER_hide:
  int return_value;
  return return_value;
}
