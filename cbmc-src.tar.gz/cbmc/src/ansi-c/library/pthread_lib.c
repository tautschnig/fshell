/* FUNCTION: pthread_mutex_init */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

inline int pthread_mutex_init(
  pthread_mutex_t *mutex, const pthread_mutexattr_t *mutexattr)
{ __CPROVER_HIDE: __CPROVER_mutex_lock_field(*mutex)=0; return 0; }

/* FUNCTION: pthread_mutex_lock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

inline int pthread_mutex_lock(pthread_mutex_t *mutex)
{ __CPROVER_HIDE:
  __CPROVER_atomic_begin();
  __CPROVER_assume(!__CPROVER_mutex_lock_field(*mutex));
  __CPROVER_mutex_lock_field(*mutex)=1;
  __CPROVER_atomic_end();
  return 0; // we never fail
}

/* FUNCTION: pthread_mutex_trylock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_mutex_trylock(pthread_mutex_t *mutex)
{
  __CPROVER_HIDE:
  __CPROVER_atomic_begin();
  if(__CPROVER_mutex_lock_field(*mutex)) { __CPROVER_atomic_end(); return 1; }
  __CPROVER_mutex_lock_field(*mutex)=1;
  __CPROVER_atomic_end();
  return 0;
}

/* FUNCTION: pthread_mutex_unlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_mutex_unlock(pthread_mutex_t *mutex)
{ __CPROVER_HIDE:
  __CPROVER_assert(__CPROVER_mutex_lock_field(*mutex),
    "must hold lock upon unlock");
  __CPROVER_mutex_lock_field(*mutex)=0;
  return 0; // we never fail
}

/* FUNCTION: pthread_mutex_destroy */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_mutex_destroy(pthread_mutex_t *mutex)
{ }

/* FUNCTION: pthread_exit */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

void pthread_exit(void *value_ptr)
{ __CPROVER_assume(0); }

/* FUNCTION: pthread_rwlock_destroy */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_destroy(pthread_rwlock_t *lock)
{ }

/* FUNCTION: pthread_rwlock_init */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_init(pthread_rwlock_t *lock, 
  const pthread_rwlockattr_t *attr)
{ __CPROVER_HIDE: __CPROVER_rwlock_field(*lock)=0; }

/* FUNCTION: pthread_rwlock_rdlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_rdlock(pthread_rwlock_t *lock)
{ /* TODO */ }

/* FUNCTION: pthread_rwlock_tryrdlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_tryrdlock(pthread_rwlock_t *lock)
{ /* TODO */ }

/* FUNCTION: pthread_rwlock_trywrlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_trywrlock(pthread_rwlock_t *lock)
{ __CPROVER_HIDE:
  __CPROVER_atomic_begin();
  if(__CPROVER_rwlock_field(*lock)) { __CPROVER_atomic_end(); return 1; }
  __CPROVER_rwlock_field(*lock)=1;
  __CPROVER_atomic_end();
  return 0;
}

/* FUNCTION: pthread_rwlock_unlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_unlock(pthread_rwlock_t *lock)
{ __CPROVER_HIDE: __CPROVER_rwlock_field(*lock)=0; }

/* FUNCTION: pthread_rwlock_wrlock */

#ifndef __CPROVER_PTHREAD_H_INCLUDED
#include <pthread.h>
#define __CPROVER_PTHREAD_H_INCLUDED
#endif

int pthread_rwlock_wrlock(pthread_rwlock_t *lock)
{ __CPROVER_HIDE:
  __CPROVER_atomic_begin();
  __CPROVER_assume(!__CPROVER_rwlock_field(*lock));
  __CPROVER_rwlock_field(*lock)=1;
  __CPROVER_atomic_end();
  return 0; // we never fail
}
