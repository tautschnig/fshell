/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <message_stream.h>
#include <namespace.h>
#include <std_types.h>
#include <replace_symbol.h>
#include <replace_expr.h>

#include "c_final.h"
#include "cprover_library.h"

/*******************************************************************\

Function: c_final

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void c_finalize_expression(
  const contextt &context,
  exprt &expr,
  message_handlert &message_handler)
{
  if(expr.id()=="symbol")
  {
    if(expr.type().id()=="incomplete_array")
    {
      symbolst::const_iterator it=
        context.symbols.find(expr.get("identifier"));

      if(it==context.symbols.end())
      {
        message_streamt message_stream(message_handler);
        message_stream.str
          << "failed to find symbol "
          << expr.get("identifier");
        message_stream.error();
        throw 0;
      }
      
      const symbolt &symbol=it->second;

      if(symbol.type.id()=="array")
        expr.type()=symbol.type;
      else if(symbol.type.id()=="incomplete_array")
      {
        message_streamt message_stream(message_handler);
        message_stream.err_location(symbol.location);
        message_stream.str
          << "symbol `" << symbol.display_name()
          << "' has incomplete type";
        message_stream.error();
        throw 0;            
      }
      else
      {
        message_streamt message_stream(message_handler);
        message_stream.err_location(symbol.location);
        message_stream.str
          << "symbol `" << symbol.display_name()
          << "' has an unexpected type";
        message_stream.error();
        throw 0;      
      }
    }
  }

  if(expr.has_operands())
    Forall_operands(it, expr)
      c_finalize_expression(context, *it, message_handler);
}

/*******************************************************************\

Function: add_external_objects

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool add_external_objects(
  contextt &context, 
  message_handlert &message_handler)
{
  namespacet ns(context);
    
  replace_mapt replace_map;
  
  Forall_symbols(it, context.symbols)
  {
    symbolt &symbol=it->second;    
    const typet &final_type=ns.follow(symbol.type);

    if(symbol.mode=="C" && 
       symbol.is_extern && !symbol.is_type)
    {      
      if(final_type.id()=="incomplete_array")
      {
        // all arrays get a symbol-type
        // (see c_typecheck_baset::typecheck_new_symbol)
        assert(symbol.type.id()=="symbol");
        
        message_streamt message_stream(message_handler);
        message_stream.err_location(symbol.location);
        message_stream.str
          << "symbol `" << symbol.display_name()
          << "' is declared extern but never defined. "
          << "The object will be modeled as an array of infinite size.";
        message_stream.warning();
        
        array_typet new_type;
        new_type.subtype()=final_type.subtype();
        new_type.size()=exprt("infinity");
                
        const irep_idt &ident=symbol.type.get("identifier");
        symbolst::iterator fit=context.symbols.find(ident);
        
        if(fit==context.symbols.end())
          throw std::string("symbol not found: `")+ident.as_string()+"'";
        
        // set the new type
        fit->second.type=new_type;
      }      
    }
  }
    
  return false;
}

/*******************************************************************\

Function: c_final

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool c_final(contextt &context, message_handlert &message_handler)
{
  add_cprover_library(context, message_handler);
  add_external_objects(context, message_handler);
  
  try
  {
    Forall_symbols(it, context.symbols)
    {
      symbolt &symbol=it->second;

      if(symbol.mode=="C")
      {
        c_finalize_expression(context, symbol.value, message_handler);
      }
    }
  }

  catch(int e)
  {
    return true;
  }

  return false;
}
