open Goto_program;;

(** Replaces explicit return statements by an assignment to
    a variable retn_function_name. The function calls
    are adjusted accordingly. *)

let remove_return (src: goto_instruction): goto_instruction list=
  match src.instruction_type with
    RETURN ->
    (* does it return a value? *)
    if (DynArray.length src.code#operands) = 1 then
      (* we split up into an assignment and a branch to the
         end of the function *)
      let assignment=src in
      
      assignment.instruction_type <- ASSIGN;
      assignment.code <- Expr.code_assign;

      (* this becomes the branch to the function exit point *)      
      let branch=empty_instruction in
      
      branch.instruction_type <- GOTO;
      branch.instruction_location <- src.instruction_location;
      branch.instruction_function_name <- src.instruction_function_name;
      branch.guard <- Expr.true_expr;
      
      assignment :: [branch]
    else
      [src]
    
  | FUNCTION_CALL ->
    (* does it assign the return value? *)
    if src.code#op0#is_not_nil then
      (* we split up into the call itself and an assignment *)
      let call=src in
      
      call.instruction_type <- FUNCTION_CALL;
      call.code#op0#make_nil; (* cleans the return assignment *)

      (* this becomes the new assignment *)      
      let assignment=empty_instruction in
      
      assignment.instruction_type <- ASSIGN;
      assignment.instruction_location <- src.instruction_location;
      assignment.code <- Expr.code_assign;
      
      call :: [assignment]
    else
      [src]

  | _ -> [src]
;;

let remove_return (src: goto_instruction list): goto_instruction list=
  match src with
    [] -> []
  | head :: tail -> remove_return (head) @ tail
;;

let remove_return (src: goto_function): unit=
  src.instructions <- remove_return src.instructions
;;

let remove_return (src: goto_program): unit=
  List.iter remove_return src.functions;
;;
