(* Read 4 bytes and patch them together to form an integer *)

let read_binary_long(ic: in_channel):int =
  let b0=input_byte ic in
  let b1=input_byte ic in
  let b2=input_byte ic in
  let b3=input_byte ic in
  (b0 lsl 24) lor
  (b1 lsl 16) lor
  (b2 lsl 8) lor
  (b3)
;;

(* Read a string *)

let rec read_binary_string_rec(ic: in_channel)(buf: Buffer.t):unit =
  let input=input_char ic in
  if input<>'\x00' then begin
    let next_char=
      if input='\\' then (* escape! *)
        input_char ic
      else
        input
    in
      Buffer.add_char buf next_char;
    
    read_binary_string_rec ic buf; (* recursion *)
  end
;;

let read_binary_string(ic: in_channel):string =
  let buf = Buffer.create 100 in
  read_binary_string_rec ic buf;
  Buffer.contents buf
;;
