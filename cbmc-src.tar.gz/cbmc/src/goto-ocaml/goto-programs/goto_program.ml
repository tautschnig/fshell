open Array;;
open Map;;
open Read_irep;;
open Irep;;

type goto_symbol = {
  symbol_type: irep;
  value: irep;
  location: irep;

  symbol_name: string;
  module_name: string;
  base_name: string;
  mode: string;
  pretty_name: string;

  ordering: int;
  
  is_type: bool;
  theorem: bool;
  is_macro: bool;
  is_exported: bool;
  is_input: bool;
  is_output: bool;
  is_statevar: bool;
  is_actual: bool;
  free_var: bool;
  binding: bool;
  lvalue: bool;
  static_lifetime: bool;
  thread_local: bool;
  file_local: bool;
  is_extern: bool;
  is_volatile: bool;
};;

type goto_instruction_type =
    NO_INSTRUCTION_TYPE
  | GOTO          (** branch, possibly guarded *)
  | ASSUME        (** non-failing guarded self loop *)
  | ASSERT        (** assertions *)
  | OTHER         (** anything else *)
  | SKIP          (** just advance the PC *)
  | START_THREAD  (** spawns an asynchronous thread *)
  | END_THREAD    (** end the current thread *)
  | LOCATION      (** semantically like SKIP *)
  | END_FUNCTION  (** exit point of a function *)
  | ATOMIC_BEGIN  (** marks a block without interleavings *)
  | ATOMIC_END    (** end of a block without interleavings *)
  | RETURN        (** return from a function *)
  | ASSIGN        (** assignment lhs:=rhs *)
  | DECL          (** declare a local variable *)
  | DEAD          (** marks the end-of-live of a local variable *)
  | FUNCTION_CALL (** call a function *)
  | THROW         (** throw an exception *)
  | CATCH         (** catch an exception *)

type goto_instruction = {
  mutable code: irep;
  mutable function_name: string;
  mutable instruction_location: irep;
  mutable instruction_type: goto_instruction_type;
  mutable guard: irep;
  mutable target_number: int;
  mutable targets: int list;
  mutable labels: string list;
};;

let no_target_number:int = 4294967295;;

let instruction_type_as_string(instruction_type: goto_instruction_type)=
  match instruction_type with
    NO_INSTRUCTION_TYPE -> "NO_INSTRUCTION_TYPE"
  | GOTO -> "GOTO"
  | ASSUME -> "ASSUME"
  | ASSERT -> "ASSERT"
  | OTHER -> "OTHER"
  | SKIP -> "SKIP"
  | START_THREAD -> "START_THREAD"
  | END_THREAD -> "END_THREAD"
  | LOCATION -> "LOCATION"
  | END_FUNCTION -> "END_FUNCTION"
  | ATOMIC_BEGIN -> "ATOMIC_BEGIN"
  | ATOMIC_END -> "ATOMIC_END"
  | RETURN -> "RETURN"
  | ASSIGN -> "ASSIGN"
  | DECL -> "DECL"
  | DEAD -> "DEAD"
  | FUNCTION_CALL -> "FUNCTION_CALL"
  | THROW -> "THROW"
  | CATCH -> "CATCH"
;;

let empty_instruction: goto_instruction =
{
  code = new irep;
  function_name = "";
  instruction_location = new irep;
  instruction_type = NO_INSTRUCTION_TYPE;
  guard = new irep;
  target_number = 0;
  targets = [];
  labels = [];
};;

type goto_function = {
  mutable name: string;
  mutable instructions: goto_instruction list;
};;

type goto_program = {
  mutable symbols: goto_symbol list;
  mutable functions: goto_function list;
};;

let dump_symbol(s: goto_symbol)=
  print_string ("Name: " ^ s.symbol_name ^ "\n");
  print_string ("  Module: " ^ s.module_name ^ "\n");
  print_string ("  Base name: " ^ s.base_name ^ "\n");
  print_string ("  Mode: " ^ s.mode ^ "\n");
  print_string ("  Pretty name: " ^ s.pretty_name ^ "\n");
  print_string ("  Flags:");
  if s.is_type then print_string (" is_type");
  if s.theorem then print_string (" theorem");
  if s.is_macro then print_string (" is_macro");
  if s.is_exported then print_string (" is_exported");
  if s.is_input then print_string (" is_input");
  if s.is_output then print_string (" is_output");
  if s.is_statevar then print_string (" is_statevar");
  if s.is_actual then print_string (" is_actual");
  if s.free_var then print_string (" free_var");
  if s.binding then print_string (" binding");
  if s.lvalue then print_string (" lvalue");
  if s.static_lifetime then print_string (" static_lifetime");
  if s.thread_local then print_string (" thread_local");
  if s.file_local then print_string (" file_local");
  if s.is_extern then print_string (" is_extern");
  if s.is_volatile then print_string (" is_volatile");
  print_string ("\n");
  print_string ("  Type: " ^ s.symbol_type#as_string ^ "\n");
  print_string ("  Value: " ^ s.value#as_string ^ "\n");
  print_string ("  Location: " ^ location_as_string s.location ^ "\n");
  print_string ("\n");
;;

let dump_instruction(i: goto_instruction)=
  print_string ("  Function: " ^ i.function_name ^ "\n");
  print_string ("  Location: " ^ location_as_string i.instruction_location ^ "\n");
  print_string ("  Type: " ^ instruction_type_as_string i.instruction_type ^ "\n");
  print_string ("  Code: " ^ i.code#as_string ^ "\n");
  print_string ("  Guard: " ^ i.guard#as_string ^ "\n");
  
  if i.target_number != no_target_number then
    print_string ("  Target_number: " ^ string_of_int i.target_number ^ "\n");

  print_string ("  Targets: ");
  let print_target(l: int)=print_string(" "^string_of_int l) in
  List.iter print_target i.targets;
  print_string ("\n");

  print_string ("  Labels: ");
  let print_label(s: string)=print_string(" "^s) in
  List.iter print_label i.labels;
  print_string ("\n");
  
  print_string ("\n");
;;

let dump_function(f: goto_function)=
  print_string ("Name: " ^ f.name ^ "\n");
  List.iter dump_instruction f.instructions;
;;

let dump(p: goto_program): unit =
  print_string "Symbols\n";
  print_string "=======\n\n";
  List.iter dump_symbol p.symbols;
  print_string "\n";

  print_string "Functions\n";
  print_string "=========\n\n";
  List.iter dump_function p.functions;
;;
