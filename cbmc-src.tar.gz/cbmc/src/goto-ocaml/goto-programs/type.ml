let bool_type : Irep.irep =
  let result=new Irep.irep in
  result#set_id "bool";
  result
;;