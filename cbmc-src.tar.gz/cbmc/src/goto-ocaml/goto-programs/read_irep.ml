open Read_binary;;
open Irep;;

exception Format_error of string;;

class irep_reader (tmp_ic: in_channel) = object (self)
  val ic: in_channel = tmp_ic;

  val mutable string_map_set : bool DynArray.t = DynArray.create();
  val mutable string_map_value : string DynArray.t = DynArray.create();
  
  method read_long: int =
    read_binary_long(ic);

  method private resize_string_map(i: int) =
    let old_length=DynArray.length string_map_set in
    if i>=old_length then begin
      DynArray.append (DynArray.init (i-old_length+1) (fun _ -> false))
                      string_map_set;
      DynArray.append (DynArray.init (i-old_length+1) (fun _ -> ""))
                      string_map_value;
    end;
  
  method read_binary_string: string=
    read_binary_string(ic);

  method read_string : string =
    let string_nr = read_binary_long(ic) in
    (* print_string "Read STRING ";
    print_int string_nr;
    flush stdout; *)
    self#resize_string_map(string_nr);
    if DynArray.get string_map_set string_nr then begin
      (* print_string (" OLD " ^ string_map_value.(string_nr)^ "\n");
      flush stdout; *)
      DynArray.get string_map_value string_nr
    end else begin
      DynArray.set string_map_set string_nr true;
      let s=read_binary_string(ic) in
      DynArray.set string_map_value string_nr s;
      (* print_string (" NEW " ^ s ^ "\n");
      flush stdout; *)
      s
    end;
    
  val mutable irep_map_set : bool DynArray.t = DynArray.create();
  val mutable irep_map_value : irep DynArray.t = DynArray.create();

  method private resize_irep_map(i: int) =
    let old_length=DynArray.length irep_map_set in
    if i>=old_length then begin
      DynArray.append (DynArray.init (i-old_length+1) (fun _->false))
                      irep_map_set;
      DynArray.append (DynArray.init (i-old_length+1) (fun _->new irep))
                      irep_map_value;
      for j=old_length to i do
        DynArray.set irep_map_value j (new irep);
      done;
    end;

  method private read_binary_irep(result: irep): unit =
    result#set_id(self#read_string);
    (* print_string ("ID: " ^ result#id ^ "\n"); *)
    let tag = ref (input_char ic) in
    (* print_string ("First tag: " ^ (String.make 1 !tag) ^"\n"); *)
    while !tag<>'\x00' do
      if !tag<>'S' && !tag<>'N' && !tag<>'C' then
        raise (Format_error ("unknown irep tag `" ^ (String.make 1 !tag) ^ "'"));
    
      (match !tag with
          '\x00' -> ()
        | 'S' -> (* print_string "SUB\n"; *)
                 result#add_sub(self#read_irep)
        | 'N' -> let n=self#read_string in
                 (* print_string ("N: " ^ n ^ "\n"); *)
                 let s=self#read_irep in
                 result#add_named_sub n s
        | 'C' -> let n=self#read_string in
                 (* print_string ("C: " ^ n ^ "\n"); *)
                 let s=self#read_irep in
                 result#add_comment n s
        | x -> ());

      let next_tag = input_char ic in
      (* print_string ("Next tag: " ^ (String.make 1 next_tag) ^"\n"); *)
      tag := next_tag;
    done;
    ();

  method read_irep : irep =
    (* print_string "READ IREP "; *)
    let irep_nr = read_binary_long(ic) in
    (* print_int irep_nr; *)
    self#resize_irep_map(irep_nr);
    if DynArray.get irep_map_set irep_nr then begin
      (* print_string " OLD\n"; *) 
    end else begin
      (* print_string " NEW\n"; *)
      DynArray.set irep_map_set irep_nr true;
      self#read_binary_irep(DynArray.get irep_map_value irep_nr);
      (* print_string ("Done reading ");
      print_int irep_nr;
      print_string (" " ^ irep_map_value.(irep_nr)#id ^ "\n");
      *)
    end;
    DynArray.get irep_map_value irep_nr

end;;

