open Array;;
open Map;;
open Read_binary;;
open Read_irep;;
open Goto_program;;

let getbit(i: int)(bitnr: int): bool=
  (i lsr bitnr)<>0;;

let read_symbol(ir: irep_reader):goto_symbol =
  (* the ordering of the following matters! *)
  let tmp_symbol_type = ir#read_irep in
  let tmp_value = ir#read_irep in
  let tmp_location = ir#read_irep in

  let tmp_symbol_name = ir#read_string in
  print_string ("Reading symbol " ^ tmp_symbol_name ^"\n");
  flush stdout;
  let tmp_module_name = ir#read_string in
  let tmp_base_name = ir#read_string in
  let tmp_mode = ir#read_string in
  let tmp_pretty_name = ir#read_string in

  let tmp_ordering = ir#read_long in

  let tmp_flags = ir#read_long in

  {
    symbol_type = tmp_symbol_type;
    value = tmp_value;
    location = tmp_location;

    symbol_name = tmp_symbol_name;
    module_name = tmp_module_name;
    base_name = tmp_base_name;
    mode = tmp_mode;
    pretty_name = tmp_pretty_name;

    ordering = tmp_ordering;

    is_type=getbit tmp_flags 15;
    theorem=getbit tmp_flags 14;
    is_macro=getbit tmp_flags 13;
    is_exported=getbit tmp_flags 12;
    is_input=getbit tmp_flags 11;
    is_output=getbit tmp_flags 10;
    is_statevar=getbit tmp_flags 9;
    is_actual=getbit tmp_flags 8;
    free_var=getbit tmp_flags 7;
    binding=getbit tmp_flags 6;
    lvalue=getbit tmp_flags 5;
    static_lifetime=getbit tmp_flags 4;
    thread_local=getbit tmp_flags 3;
    file_local=getbit tmp_flags 2;
    is_extern=getbit tmp_flags 1;
    is_volatile=getbit tmp_flags 0;
  };;  

let rec read_symbols(ir: irep_reader) (number_of_symbols: int): goto_symbol list =
  if number_of_symbols<0 then
    raise (Format_error "number_of_symbols<0")
  else if number_of_symbols=0 then
    []
  else
    let symbol=read_symbol(ir) in
    symbol :: (read_symbols ir (number_of_symbols-1))
;;

(* reads the number of symbols, then that many symbols *)
let read_symbols(ir: irep_reader) =
  let number_of_symbols=ir#read_long in
  print_string "Reading ";
  print_int number_of_symbols;
  print_string " symbols\n";
  read_symbols ir number_of_symbols
;;

(* read a list of target numbers *)
let rec read_targets(ir: irep_reader) (number_of_targets: int): int list =
  if number_of_targets<0 then
    raise (Format_error "number_of_targets<0")
  else if number_of_targets=0 then
    []
  else
    let target=ir#read_long in
    target :: (read_targets ir (number_of_targets-1))
;;

(* read a list of labels *)
let rec read_labels(ir: irep_reader) (number_of_labels: int): string list =
  if number_of_labels<0 then
    raise (Format_error "number_of_labels<0")
  else if number_of_labels=0 then
    []
  else
    let label=ir#read_string in
    label :: (read_labels ir (number_of_labels-1))
;;

let convert_instruction_type(i: int):goto_instruction_type=
  match i with
    0 -> NO_INSTRUCTION_TYPE
  | 1 -> GOTO
  | 2 -> ASSUME
  | 3 -> ASSERT
  | 4 -> OTHER
  | 5 -> SKIP
  | 6 -> START_THREAD
  | 7 -> END_THREAD
  | 8 -> LOCATION
  | 9 -> END_FUNCTION
  | 10 -> ATOMIC_BEGIN
  | 11 -> ATOMIC_END
  | 12 -> RETURN
  | 13 -> ASSIGN
  | 14 -> DECL
  | 15 -> DEAD
  | 16 -> FUNCTION_CALL
  | 17 -> THROW
  | 18 -> CATCH
  | _ -> raise (Format_error "unexpected instruction type") 
;;

(* reads an instruction *)
let read_instruction(ir: irep_reader) =
  let tmp_code=ir#read_irep in
  let tmp_function_name=ir#read_string in
  let tmp_location=ir#read_irep in
  let tmp_instruction_type=ir#read_long in
  let tmp_guard=ir#read_irep in
  let _=ir#read_string in (* former event *)
  let tmp_target_number=ir#read_long in
  let number_of_targets=ir#read_long in
  let tmp_targets=read_targets ir number_of_targets in
  let number_of_labels=ir#read_long in
  let tmp_labels=read_labels ir number_of_labels in
  {
    code=tmp_code;
    function_name=tmp_function_name;
    instruction_location=tmp_location;
    instruction_type=convert_instruction_type(tmp_instruction_type);
    guard=tmp_guard;
    target_number=tmp_target_number;
    targets=tmp_targets;
    labels=tmp_labels;
  }
;;

(* reads the given number of instructions *)
let rec read_instructions(ir: irep_reader) (number_of_instructions: int): goto_instruction list =
  if number_of_instructions<0 then
    raise (Format_error "number_of_instructions<0")
  else if number_of_instructions=0 then
    []
  else
    let instruction=read_instruction(ir) in
    instruction :: (read_instructions ir (number_of_instructions-1))
;;

(* reads a function *)
let read_function(ir: irep_reader):goto_function =
  (* the function name is a string, not a string ref *)
  let tmp_name = ir#read_binary_string in
  let number_of_instructions = ir#read_long in
  print_string ("Reading function " ^ tmp_name ^ " with ");
  print_int number_of_instructions;
  print_string " instructions\n";
  {
    name = tmp_name;
    instructions = read_instructions ir number_of_instructions;
  }
;;

(* reads the given number of functions *)
let rec read_functions(ir: irep_reader) (number_of_functions: int): goto_function list =
  if number_of_functions<0 then
    raise (Format_error "number_of_functions<0")
  else if number_of_functions=0 then
    []
  else
    let a_function=read_function(ir) in
    a_function :: (read_functions ir (number_of_functions-1))
;;

(* reads the number of functions, then that many functions *)
let read_functions(ir: irep_reader) =
  let number_of_functions=ir#read_long in
  print_string "Reading ";
  print_int number_of_functions;
  print_string " functions\n";
  read_functions ir number_of_functions
;;

let read(ic: in_channel):goto_program =
  (* Read magic signature *)
  let h0 = input_char ic in
  let h1 = input_char ic in
  let h2 = input_char ic in
  let h3 = input_char ic in
  
  (* Check magic signature *)
  if h0<>'\x7f' || h1<>'G' || h2<>'B' || h3<>'F' then
    raise (Format_error "wrong signature");

  (* Read version *)
  let version=read_binary_long(ic) in

  (* Check version *)
  if version<>2 then
    raise (Format_error "wrong version");
    
  let ir=new irep_reader(ic) in
  let tmp_symbols=read_symbols(ir) in
  let tmp_functions=read_functions(ir) in
  { symbols = tmp_symbols;
    functions = tmp_functions; }
