class irep = object (self)
  val mutable id: string = "";
  val mutable sub: irep DynArray.t = DynArray.create();
  val mutable named_sub: (string * irep) list = [];
  val mutable comments: (string * irep) list = [];
  
  method id = id;
  method sub = sub;
  method named_sub = named_sub;
  method comments = comments;
  
  method set_id(tmp_id)= id<-tmp_id;
  method add_sub(s: irep)= DynArray.add sub s;
  method add_named_sub(n: string)(s: irep)= named_sub<-(n, s) :: named_sub;
  method add_comment(n: string)(s: irep)= comments<-(n, s) :: comments;
  
  method as_string:string =
    if DynArray.empty sub && named_sub = [] && comments = [] then
      id
    else begin
      let result = ref "" in

      let add_named(sub: (string*irep)):unit=begin
          if String.length !result != 0 then
            if !result.[String.length !result-1] != '[' then
              result:=!result ^ ", ";
          result:=!result ^ fst sub ^ "=" ^ (snd sub)#as_string
        end
        
      and add_unnamed(sub: irep):unit=begin
          if String.length !result != 0 then
            if !result.[String.length !result-1] != '[' then
              result:=!result ^ ", ";
          result:=!result ^ sub#as_string
        end
        
      in

      result := !result ^ id ^ "[";
      DynArray.iter add_unnamed sub;
      List.iter add_named named_sub;
      List.iter add_named comments;
      result := !result ^ "]";
      !result
    end;
end;;

let location_as_string(i: irep):string=
  i#as_string
;;
