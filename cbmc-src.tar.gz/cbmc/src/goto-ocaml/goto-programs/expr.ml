let constant_expr : Irep.irep =
  let result=new Irep.irep in
  result#set_id "constant";
  result

let true_expr : Irep.irep =
  let result=constant_expr in
  result

let false_expr : Irep.irep =
  let result=constant_expr in
  result

let code_expr : Irep.irep =
  let result=new Irep.irep in
  result#set_id "code";
  result

let code_assign : Irep.irep =
  let result = code_expr in
  result
