(* This is main *)

(* This main offers a basic command line for reading
   a goto-binary, and then dumping either the
   goto-binary in text form, or convert it to SIL,
   and then display that. *)

if Array.length Sys.argv = 1
(* and
   Sys.argv.(1)="--version" *) then begin
  print_string ("version 1.0\n");
  exit 0

end else if Array.length Sys.argv <> 3 then begin
  (* show some help *)
  print_string ("Options:\n"^
                "  goto-ocaml --dump goto-binary\n"^
                "  goto-ocaml --sil goto-binary\n");
  exit 1

end else begin
  let infile_name = Sys.argv.(2) in

  print_string ("Reading "^infile_name^"\n");

  let infile = open_in infile_name in

  try
    let goto_binary_file = Read_goto_binary.read infile in
    
    match Sys.argv.(1) with
      "--dump" -> Goto_program.dump goto_binary_file
    | "--sil" -> Goto_to_sil.goto_to_sil goto_binary_file
    | _ -> print_string("Please specify --dump or --sil\n");
           exit 2
    
  with
    (* any errors reading/converting? *)
  | Read_irep.Format_error msg ->
      close_in_noerr infile;
      print_string "Format error: ";
      print_string msg;
      print_string "\n";
      exit 2
  
  | Conversion_exception.Conversion_error msg ->
      print_string "Conversion error: ";
      print_string msg;
      print_string "\n";
      exit 2
      
  | e->
      close_in_noerr infile;
      print_string "Some other error while reading!\n";
      raise e;
  ;

  exit 0
end;;

