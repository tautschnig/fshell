(* This is main *)

if Array.length Sys.argv <> 3 then begin
  print_string ("Options:\n"^
                "  goto-ocaml --dump goto-binary\n"^
                "  goto-ocaml --sil goto-binary\n");
  exit 1
end else begin
  print_string ("Reading "^Sys.argv.(2)^"\n");

  let infile = open_in Sys.argv.(2) in

  try
    let goto_binary_file = Read_goto_binary.read infile in
    
    match Sys.argv.(1) with
      "--dump" -> Goto_program.dump goto_binary_file
    | "--sil" -> Goto2sil.compute_icfg goto_binary_file
    | _ -> print_string("Please specify --dump or --sil\n");
           exit 2
    
  with
    Read_irep.Format_error msg ->
      close_in_noerr infile;
      print_string "Format error: ";
      print_string msg;
      print_string "\n";
      exit 2
  | e->
      close_in_noerr infile;
      print_string "Some other error while reading!\n";
      raise e;
  ;

  exit 0
end;;

