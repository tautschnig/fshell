(* This is main *)

(* This main offers a basic command line for reading
   a goto-binary, and then dumping either the
   goto-binary in text form, or convert it to SIL,
   and then display that. *)

if Array.length Sys.argv = 1
(* and
   Sys.argv.(1)="--version" *) then begin
  print_string ("version 1.0\n");
  exit 0

end else if Array.length Sys.argv <> 3 then begin
  (* show some help *)
  print_string ("Options:\n"^
                "  goto-ocaml --dump goto-binary\n"^
                "  goto-ocaml --dump-sil goto-binary\n");
  exit 1

end else begin
  try
    let infile_name = Sys.argv.(2) in

    print_string ("Reading "^infile_name^"\n\n");

    let infile = open_in infile_name in

    let goto_binary_file = Read_goto_binary.read infile in

    close_in_noerr infile;
    
    match Sys.argv.(1) with
      "--dump" ->
      print_string ("Dumping goto binary\n\n");

      Goto_program.dump goto_binary_file
    | "--dump-sil" ->
      print_string ("Converting goto binary\n\n");
      Goto_to_sil.goto_to_sil goto_binary_file;
      print_string ("Printing SIL\n\n");
      let formatter = Format.std_formatter in
      let node_list = Cfg_new.get_all_nodes () in
      List.map (fun node ->
        Format.fprintf formatter "node %d@." (Cfg_new.node_get_id node);
        Cfg_new.pp_node_instr ~sub_instrs:true formatter node) node_list;
      Cfg_new.print_icfg_dotty []
    | _ -> print_string("Please specify --dump or --dump-sil\n");
           exit 2
    
  with
    (* any errors reading/converting? *)
  | Sys_error msg ->
      print_string msg;
      print_string "\n";
      exit 3
    
  | Read_irep.Format_error msg ->
      print_string "Format error: ";
      print_string msg;
      print_string "\n";
      exit 2
  
  | Conversion_exception.Conversion_error msg ->
      print_string "Conversion error: ";
      print_string msg;
      print_string "\n";
      exit 2
      
  | e->
      print_string "Some other error while reading!\n";
      raise e;
  ;

  exit 0
end;;

