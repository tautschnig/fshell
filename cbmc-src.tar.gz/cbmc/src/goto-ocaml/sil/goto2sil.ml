let compute_icfg(goto_program: Goto_program.goto_program): unit=
  print_string "huhu\n";
