open Goto_program;;
open Cfg_new;;
open Expr_to_sil;;
open Conversion_exception;;

(** conversion of symbols in the symbol table *)

let register_identifiers(symbol: goto_symbol): unit=
  (* we distinguish type symbols from non-type symbols *)
  if symbol.is_type then
    (* a type symbol *)
    let sil_typename = Ident.string_to_name symbol.symbol_name in 
    Sil.tenv_create sil_typename
  else 
    let symbol_type = symbol.symbol_type in
    if symbol_type#id = "code" then
      (* we ignore functions here *)
      ()
    else
      (* a non-type, non-function symbol *)
      (* we just add it as a fresh identifier (the symbol names are unique) *)
      let sil_name = Ident.string_to_name symbol.symbol_name in
      let sil_ident = Ident.create_normal_ident sil_name 0 in
      ignore(sil_ident)
;;

let convert_symbol(symbol: goto_symbol): unit=
  (* print_string ("Converting symbol " ^ symbol.symbol_name ^ "\n\n"); *)
  (* we distinguish type symbols from non-type symbols *)
  if symbol.is_type then
    (* a type symbol *)
    let sil_typename = Ident.string_to_name symbol.symbol_name in 
    let sil_typ = type_to_sil symbol.symbol_type in
    Sil.tenv_add sil_typename sil_typ
  else 
    ()
;;

let convert_symbols(goto_program: Goto_program.goto_program): unit=
  (** two phases: first register all the identifiers *)
  List.iter register_identifiers goto_program.symbols;
  
  (** now define the type symbols *)
  List.iter convert_symbol goto_program.symbols
;;

(** conversion of CFG nodes *)

(** cleans an expression by introducing temporary variables *)

let rec clean_expr_rhs
  (clean_instr: Sil.instr list ref)
  (temp_vars: Ident.ident list ref)
  (expr: Irep.irep): unit =

  let operands = expr#operands in
  for i = 0 to (DynArray.length operands) -1 do
    clean_expr_rhs clean_instr temp_vars (DynArray.get operands i)
  done;
  
  match expr#id with
  | "symbol" ->
    (* add a new instruction that reads this symbol *)
    let name = Ident.string_to_name (expr#get "identifier") in
    let ident = Ident.create_primed_ident name 0 in 
    let cil_location=location_to_cil expr#location in
    let sil_expr = expr_to_sil expr in
    let sil_type = type_to_sil expr#expr_type in
    let read_instr = Sil.Letderef (ident, sil_expr, sil_type, cil_location) in 
    clean_instr:=!clean_instr @ [read_instr];
    temp_vars:=!temp_vars @ [ident];
    
    (* now we have a 'pure symbol' for the expression! *)
    expr#set_id "pure_symbol";
    
  | "dereference" ->
    (* add a new instruction that performs the indirect read *)
    let name = Ident.string_to_name "@ptr" in
    let ident = Ident.create_primed_ident name 0 in 
    let cil_location=location_to_cil expr#location in
    let sil_expr = expr_to_sil expr in
    let sil_type = type_to_sil expr#expr_type in
    let read_instr = Sil.Letderef (ident, sil_expr, sil_type, cil_location) in 
    clean_instr:=!clean_instr @ [read_instr];
    temp_vars:=!temp_vars @ [ident];
    
    (* now we have a 'pure symbol' for the expression! *)
    expr#set_id "pure_symbol";
    expr#set "identifier" "@ptr";
    
  | _ -> ()
;;

(** cleans an expression by introducing addresses *)

let rec clean_expr_lhs
  (clean_instr: Sil.instr list ref)
  (temp_vars: Ident.ident list ref)
  (expr: Irep.irep):unit=

  let operands = expr#operands in
  for i = 0 to (DynArray.length operands) -1 do
    clean_expr_lhs clean_instr temp_vars (DynArray.get operands i)
  done;
  
;;

(** converts function call arguments *)

let convert_arguments(args: Irep.irep): (Sil.exp * Sil.typ) list =

  let sub=args#sub in
  let result = ref [] in
  let l = DynArray.length sub in

  (* we do this backwards to get efficient list cons *)  
  for i = 0 to l-1 do
    let expr = (DynArray.get sub (l-i-1)) in 
    let elem = (expr_to_sil expr, type_to_sil expr#expr_type) in
    result:= elem :: !result
  done;

  !result
;;

(** get a node with a particular ID *)
type location_node_hashtbl = (int, node) Hashtbl.t
let location_node_map : location_node_hashtbl = Hashtbl.create 1000;;

let convert_instruction(pdesc: proc_desc)(i: goto_instruction): unit=

  let cil_location=location_to_cil i.instruction_location in
  
  (* look up the SIL node *)
  let node = Hashtbl.find location_node_map i.location_number in

  (* set location *)
  node_set_loc node cil_location;

  (* debug *)  
  dump_instruction(i);

  (match i.instruction_type with
    (** not used *)
  | NO_INSTRUCTION_TYPE ->
    raise (Conversion_error "found NO_INSTRUCTION_TYPE")

    (** branch, possibly guarded *)
  | GOTO ->
    (** look up target *)
    let target_node =
      match i.targets with
      | [ tmp_node ] -> Hashtbl.find location_node_map tmp_node.location_number
      | _ -> raise (Conversion_error "unexpected targets");
    in
    
    if Expr.is_true i.guard then begin
      node_set_kind node (Skip_node "unguarded jump");
      node_set_succs node [ target_node ];
      node_add_preds target_node [ node ]      
      end
    else begin
      let clean_instr = ref [] in
      let temp_vars = ref [] in
      clean_expr_rhs clean_instr temp_vars i.guard;
    
      (** we generate _two_ prune nodes for these *)
      node_set_kind node (Skip_node "guarded jump");
      
      let node_true = node_create_base () in
      let node_false = node_create_base () in
      
      (** set the guards *)

      let sil_guard = expr_to_sil i.guard in
      let neg_sil_guard = Sil.UnOp (Cil.LNot, sil_guard) in
      node_set_kind node_true (Prune_node (!clean_instr, sil_guard));
      node_set_kind node_false (Prune_node (!clean_instr, neg_sil_guard));
      node_set_dead node_true !temp_vars;
      node_set_dead node_false !temp_vars;
      
      (** set successors/predecessors appropriately *)
      
      let old_succs = node_get_succs node in
      node_set_succs node ( node_true :: [ node_false ] );
      node_set_preds node_true [ node ];
      node_set_preds node_false [ node ];
      node_set_succs node_true [ target_node ];
      node_set_succs node_false old_succs
    end

    (** non-failing guarded self loop, ignored *)
  | ASSUME -> node_set_kind node
    (Skip_node "assume")
    
    (** assertions -- we turn these into a function call node *)
  | ASSERT ->
    let clean_instr = ref [] in
    let temp_vars = ref [] in
    clean_expr_rhs clean_instr temp_vars i.guard;
    
    let name = (Ident.string_to_name "c::assert") in
    let sil_function = Sil.Const (Sil.Cfun name) in
    let sil_arguments = [ (expr_to_sil i.guard, Sil.Tint Sil.Tint_bool ) ] in
    let cil_location = location_to_cil i.instruction_location in
    let sil_instr = Sil.Call (None, sil_function, sil_arguments, cil_location) in
    node_set_kind node (Call_node (!clean_instr @ [sil_instr], []));
    node_set_dead node !temp_vars

    (** anything else *)
  | OTHER -> node_set_kind node
    (Skip_node "other")
 
    (** just advance the PC *)
  | SKIP -> node_set_kind node
    (Skip_node "skip")

    (** spawns an asynchronous thread, ignored *)
  | START_THREAD -> node_set_kind node
    (Skip_node "start_thread")

    (** end the current thread, ignored *)
  | END_THREAD -> node_set_kind node
    (Skip_node "end_thread")

    (** semantically like SKIP *)
  | LOCATION -> node_set_kind node
    (Skip_node "location")

    (** exit point of a function *)
  | END_FUNCTION -> node_set_kind node
    (Skip_node "end of function")

    (** marks a block without interleavings *)
  | ATOMIC_BEGIN -> node_set_kind node
    (Skip_node "atomic_begin")

    (** end of a block without interleavings *)
  | ATOMIC_END -> node_set_kind node
    (Skip_node "atomic_end")

    (** return from a function *)
  | RETURN -> node_set_kind node
    (Skip_node "return");
    let exit_node = proc_desc_get_exit_node pdesc in
    node_add_preds exit_node [ node ];
    node_set_succs node [ exit_node ];

    (** assignment lhs:=rhs *)
  | ASSIGN ->
    let clean_instr = ref [] in
    let temp_vars = ref [] in
    clean_expr_lhs clean_instr temp_vars i.code#op0;
    clean_expr_rhs clean_instr temp_vars i.code#op1;

    let lhs = i.code#op0 in
    let lhs_type = lhs#expr_type
    and rhs = i.code#op1 in
    let cil_location = location_to_cil i.instruction_location in
    let sil_lhs = expr_to_sil lhs in
    let sil_lhs_type = type_to_sil lhs_type in
    let sil_rhs = expr_to_sil rhs in
    let sil_instr = Sil.Set ( sil_lhs, sil_lhs_type, sil_rhs, cil_location ) in
    node_set_kind node (Cfg_new.Stmt_node (!clean_instr @ [sil_instr]));
    node_set_dead node !temp_vars

    (** declare a local variable *)
  | DECL -> node_set_kind node
    (Skip_node "declaration")
       
    (** marks the end-of-live of a local variable *)
  | DEAD -> node_set_kind node
    (Skip_node "dead")

    (** call a function *)
  | FUNCTION_CALL ->
    (** clean *)
    let clean_instr = ref [] in
    let temp_vars = ref [] in
    clean_expr_lhs clean_instr temp_vars i.code#op0;
    clean_expr_rhs clean_instr temp_vars i.code#op1;
    clean_expr_rhs clean_instr temp_vars i.code#op2;

    let lhs=i.code#op0
    and called_function=i.code#op1
    and argument_vector=i.code#op2 in
    let sil_lhs =
      if lhs#is_nil then
        None
      else
        Some (expr_to_sil lhs, type_to_sil lhs#expr_type, type_to_sil lhs#expr_type)
    in
    let sil_function = expr_to_sil called_function in
    let sil_arguments = convert_arguments argument_vector in
    let cil_location = location_to_cil i.instruction_location in
    let sil_instr = Sil.Call (sil_lhs, sil_function, sil_arguments, cil_location) in
    node_set_kind node (Call_node ( !clean_instr @ [sil_instr], []));
    node_set_dead node !temp_vars;
    
    (** we produce a return site node, as a matter of principle *)
    let return_site_node = node_create_base () in
    node_set_kind return_site_node (Return_Site_node []);
    
    let old_succs = node_get_succs node in
    node_set_succs node [ return_site_node ];
    node_add_preds return_site_node [ node ];
    node_set_succs return_site_node old_succs

    (** throw an exception *)
  | THROW ->
    node_set_kind node (Skip_node "throw")

    (** catch an exception *)
  | CATCH ->
    node_set_kind node (Skip_node "catch")
  )
;;

let create_node_for_instruction(i: goto_instruction): unit =
  let node = node_create_base () in
  Hashtbl.add location_node_map i.location_number node
;;

let rec set_successors_rec
  (prev_node: Cfg_new.node)
  (l: goto_instruction list)
  (exit_node: Cfg_new.node): unit =
  match l with
    | [] ->
      (* do the links to the exit node *)
      node_add_succs prev_node [ exit_node ];
      node_add_preds exit_node [ prev_node ]
    | i :: rest ->
      let this_node = Hashtbl.find location_node_map i.location_number in
      (* link the two nodes *)
      node_add_succs prev_node [ this_node ];
      node_add_preds this_node [ prev_node ];
      (* recursive call *)
      set_successors_rec this_node rest exit_node
;;
  
let convert_function(f: goto_function): unit=
  print_string ("Converting function " ^ f.function_name ^ "\n\n");

  (* We first create the proc_desc. *)
  let pdesc = proc_desc_create_base f.function_name in

  (* This also produces a start and exit node. *)
  let start_node=proc_desc_get_start_node pdesc in
  let exit_node=proc_desc_get_exit_node pdesc in
  
  (* We now create the nodes and store them in location_node_map. *)
  Hashtbl.clear location_node_map;
  List.iter create_node_for_instruction f.instructions;

  (* now set successors and predecessors *)
  set_successors_rec start_node f.instructions exit_node;

  (* now we do the actual node conversion *)
  List.iter (convert_instruction pdesc) f.instructions;
;;

let convert_functions(goto_program: Goto_program.goto_program): unit=
  List.iter convert_function goto_program.functions
;;

let goto_to_sil(goto_program: Goto_program.goto_program): unit=
  convert_symbols goto_program;
  convert_functions goto_program
;;
