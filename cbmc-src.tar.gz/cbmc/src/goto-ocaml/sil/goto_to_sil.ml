open Goto_program;;
open Cfg_new;;

(*
let convert_node(i: goto_program_instruction):node=
  
;;
*)

let goto_to_sil(goto_program: Goto_program.goto_program): unit=
  print_string "huhu\n";
