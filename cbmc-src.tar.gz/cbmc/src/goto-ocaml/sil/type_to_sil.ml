open Sil;;
open Conversion_exception;;

let rec array_type_to_sil (irep: Irep.irep): Sil.typ =
  (* we can only do fixed-size arrays! *)
  let size=(irep#find "size") in
  if size#id = "constant" then
    let subtype=type_to_sil (irep#find "subtype") in
    let size_int=(int_of_string ("0b" ^ (size#get "value"))) in
    (* the above may break if the size gets too large *)
    Tarray (subtype, size_int)
  else
    raise (Conversion_error "non-constant array size")
    
and struct_type_to_sil (irep: Irep.irep): Sil.typ = begin
    let components = (irep#find "components")#sub in
    let fields = ref [] in

    let add_field(c: Irep.irep): unit=begin
      let fieldname = Ident.string_to_name (c#get "name") in
      fields := !fields @ [(fieldname, type_to_sil (c#find "type"))]
    end in

    DynArray.iter add_field components;
    Tstruct !fields
  end 

(** Convert a goto-program type to a SIL type *)
and type_to_sil (irep: Irep.irep): Sil.typ =
  match irep#id with
  | "unsignedbv" -> Tint (* ignores width *)
  | "signedbv" -> Tint   (* ignores width *)
  | "bv" -> Tint         (* ignores width *)
  | "symbol" -> Tvar (Ident.string_to_name (irep#get "identifier"))
  | "floatbv" -> Tfloat  (* ignores width *)
  | "fixedbv" -> Tfloat  (* ignores width *)
  | "empty" -> Tvoid
  | "code" -> Tfun       (* ignores argument and return type *)
  | "pointer" -> Tptr (type_to_sil (irep#find "subtype"))
  | "struct" -> struct_type_to_sil irep
  | "union" -> struct_type_to_sil irep (* not quite right *)
  | "array" -> array_type_to_sil irep
  | _ -> raise (Conversion_error ("unexpected type " ^ irep#id))
;;

