(** thrown in case of a conversion error *)
exception Conversion_error of string;;
