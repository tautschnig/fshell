open Sil;;
open Conversion_exception;;

let location_to_cil (irep: Irep.irep): Cil.location =
  let l=irep#get "line" and c=irep#get "column" in
  {
    Cil.line = if l="" then -1 else int_of_string l;
    Cil.file = irep#get "file";
    Cil.byte = -1;
    Cil.column = if c="" then -1 else int_of_string c;
  }
;;

let rec array_type_to_sil (irep: Irep.irep): Sil.typ =
  (* we do arrays that may have variable size! *)
  let size=(irep#find "size") in
  (* two recursive calls follow *)
  let subtype=type_to_sil (irep#find "subtype") in
  let size_exp=expr_to_sil size in
  Tarray (subtype, size_exp)
    
and struct_type_to_sil (irep: Irep.irep): Sil.typ = begin
    let components = (irep#find "components")#sub in
    let fields = ref [] in

    let add_field(c: Irep.irep): unit=begin
      let fieldname = Ident.string_to_name (c#get "name") in
      fields := !fields @ [(fieldname, type_to_sil (c#find "type"))]
    end in

    DynArray.iter add_field components;
    Tstruct !fields
  end 

(** Convert a goto-program type to a SIL type *)
and type_to_sil (irep: Irep.irep): Sil.typ =
  match irep#id with
  | "bool" -> Tint Tint_bool
  | "unsignedbv" ->
    let width: int = int_of_string (irep#get "width") in
    let int_kind =(match width with
       | 8 -> Tint_char (Tunsigned, width)
       | 16 -> Tint_short (Tunsigned, width)
       | 32 -> Tint_int (Tunsigned, width)
       | 64 -> Tint_long (Tunsigned, width)
       | _ -> Tint_longlong (Tunsigned, width)) in
    Tint int_kind
  | "signedbv" ->
    let width: int = int_of_string (irep#get "width") in
    let int_kind =(match width with
       | 8 -> Tint_char (Tsigned, width)
       | 16 -> Tint_short (Tsigned, width)
       | 32 -> Tint_int (Tsigned, width)
       | 64 -> Tint_long (Tsigned, width)
       | _ -> Tint_longlong (Tsigned, width)) in
    Tint int_kind
  | "bv" ->
    let width: int = int_of_string (irep#get "width") in
    Tint (Tint_int (Tunsigned, width))
  | "symbol" -> Tvar (Ident.string_to_name (irep#get "identifier"))
  | "floatbv" ->
    let width: int = int_of_string (irep#get "width") in
    let float_kind =
      (match width with | 32 -> Tfloat_float width | 64 -> Tfloat_double width | _ -> Tfloat_long_double width) in
    Tfloat float_kind
  | "fixedbv" ->
    let width: int = int_of_string (irep#get "width") in
    let float_kind =
      (match width with | 32 -> Tfloat_float width | 64 -> Tfloat_double width | _ -> Tfloat_long_double width) in
    Tfloat float_kind
  | "empty" -> Tvoid
  | "code" -> Tfun       (* ignores argument types and return type *)
  | "pointer" -> Tptr (type_to_sil (irep#find "subtype"))
  | "struct" -> struct_type_to_sil irep
  | "union" -> struct_type_to_sil irep (* not quite right *)
  | "incomplete_struct" -> Tstruct []
  | "incomplete_union" -> Tstruct []
  | "array" -> array_type_to_sil irep
  | "incomplete_array" -> raise (Conversion_error ("need to decide what to do with incomplete_array"))
  | _ -> raise (Conversion_error ("unexpected type " ^ irep#id))

(** Convert a type cast expression to a SIL cast expression *)

and typecast_to_sil (irep: Irep.irep): Sil.exp =
  if irep#number_of_operands != 1 then 
    raise (Conversion_error "typecast expects to have one operand");
    
  let op = irep#op0 in
  let from_type = (op#find "type") in
  let to_type = (irep#find "type") in
  (* These are turned into SIL casts, loosing the from_type *)
  ignore(from_type);
  Cast (type_to_sil to_type, expr_to_sil op)

(** Convert a goto-program expression to a SIL expression *)
and expr_to_sil (irep: Irep.irep): Sil.exp =
  match irep#id with
  | "constant" -> (** constants *)
    (* first check wether this is sizeof *)
    let sizeof_type=irep#find "#c_sizeof_type" in
    if sizeof_type#is_not_nil then
      Sizeof (type_to_sil sizeof_type) (** a sizeof expression *)
    else
      let constant_type=(irep#find "type") in
      let value=(irep#get "value") in
      let value_int: int64 =
      match constant_type#id with
      | "bool" -> if value="true" then Int64.of_int 1 else Int64.of_int 0
      | "unsignedbv" -> (Int64.of_string ("0b" ^ value))
      | "signedbv" -> (Int64.of_string ("0b" ^ value))
      | "pointer" -> if value="NULL" then Int64.of_int 0 else
                       raise (Conversion_exception.Conversion_error
                         ("unexpected pointer constant "^value))
      | _ -> raise (Conversion_exception.Conversion_error
                      ("unexpected constant "^constant_type#id))
      in Const (Cint value_int)
  | "unary-" -> (** unary operator *)
    UnOp (Cil.Neg, expr_to_sil (irep#op0))
  | "not" -> (** boolean negation *)
    UnOp (Cil.LNot, expr_to_sil (irep#op0))
  | "bitnot" -> (** boolean negation *)
    UnOp (Cil.BNot, expr_to_sil (irep#op0))
  | "+"   -> BinOp (Cil.PlusA, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "-"   -> BinOp (Cil.MinusA, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "*"   -> BinOp (Cil.Mult, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "/"   -> BinOp (Cil.Div, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "mod" -> BinOp (Cil.Mod, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "ashr"-> BinOp (Cil.Shiftrt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "lshr"-> BinOp (Cil.Shiftrt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "shl" -> BinOp (Cil.Shiftlt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "<"   -> BinOp (Cil.Lt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | ">"   -> BinOp (Cil.Gt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | ">="  -> BinOp (Cil.Ge, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "<="  -> BinOp (Cil.Le, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "="   -> BinOp (Cil.Eq, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "notequal"-> BinOp (Cil.Ne, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitand"  -> BinOp (Cil.BAnd, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitor"   -> BinOp (Cil.BOr, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitxor"  -> BinOp (Cil.BXor, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "and"     -> BinOp (Cil.LAnd, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "or"      -> BinOp (Cil.LOr, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "member" -> (** a field offset *)
    Lfield (expr_to_sil (irep#op0),
            Ident.string_to_name (irep#get "component_name"))
  | "index" -> (** an array index offset: [exp1\[exp2\]] *)
    Lindex (expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "symbol" -> 
    let symbol_name = Ident.string_to_name (irep#get "identifier") in
    let symbol_type = (irep#find "type") in
    if symbol_type#id = "code" then
      (* function value! *)
      Const (Cfun symbol_name)
    else
      (* the address of a program variable *)
      Lvar (mk_pvar_global symbol_name)
  | "pure_symbol" -> 
    let symbol_name = Ident.string_to_name (irep#get "identifier") in
    (** pure variable: it is not an lvalue *)
    Var (Ident.create_primed_ident symbol_name 0)
  | "if" -> (* we compile it away *)
    raise (Conversion_exception.Conversion_error ("unexpected if expression"))
  | "dereference" -> (* we compile it away *)
    raise (Conversion_exception.Conversion_error ("unexpected dereference expression"))
  | "address_of" -> (* we can only have symbols *)
    let op=irep#op0 in
    if op#id <> "symbol" then
      raise (Conversion_exception.Conversion_error ("unexpected argument for address_of"))
    else
      expr_to_sil op
  | "typecast" -> typecast_to_sil irep
  | "infinity" -> Const (Cint (Int64.of_int 0)) (* TODO: not quite *)
  | "array_of" -> Const (Cint (Int64.of_int 0)) (* TODO: not quite *)
  | "abs" -> Const (Cint (Int64.of_int 0)) (* an extension *)
  | _ -> raise (Conversion_exception.Conversion_error ("unexpected expression "^irep#id))
;;
