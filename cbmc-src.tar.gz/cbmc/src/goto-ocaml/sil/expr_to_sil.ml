open Sil;;
open Type_to_sil;;

(** Convert a goto-program expression to a SIL expression *)
let rec expr_to_sil (irep: Irep.irep): Sil.exp =
  match irep#id with
  | "constant" -> (** integer constants *)
    let constant_type=(irep#find "type") in
    let value=(irep#get "value") in
    let value_int: int =
    match constant_type#id with
    | "bool" -> if value="true" then 1 else 0
    | "unsignedbv" -> (int_of_string value)
    | "signedbv" -> (int_of_string value)
    | "pointer" -> if value="NULL" then 0 else
                     raise (Conversion_exception.Conversion_error
                       ("unexpected constant "^constant_type#id))
    | _ -> raise (Conversion_exception.Conversion_error
                    ("unexpected constant "^constant_type#id))
    in Const_int value_int
  | "typecast" -> (** type cast *)
    Cast (type_to_sil (irep#find "type"),
          expr_to_sil (irep#op0))
  | "unary-" -> (** unary operator *)
    UnOp (Cil.Neg, expr_to_sil (irep#op0))
  | "not" -> (** boolean negation *)
    UnOp (Cil.LNot, expr_to_sil (irep#op0))
  | "bitnot" -> (** boolean negation *)
    UnOp (Cil.BNot, expr_to_sil (irep#op0))
  | "+"   -> BinOp (Cil.PlusA, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "-"   -> BinOp (Cil.MinusA, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "*"   -> BinOp (Cil.Mult, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "/"   -> BinOp (Cil.Div, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "mod" -> BinOp (Cil.Mod, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "ashr"-> BinOp (Cil.Shiftrt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "lshr"-> BinOp (Cil.Shiftrt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "shl" -> BinOp (Cil.Shiftlt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "<"   -> BinOp (Cil.Lt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | ">"   -> BinOp (Cil.Gt, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | ">="  -> BinOp (Cil.Ge, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "<="  -> BinOp (Cil.Le, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "="   -> BinOp (Cil.Eq, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "notequal"-> BinOp (Cil.Ne, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitand"  -> BinOp (Cil.BAnd, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitor"   -> BinOp (Cil.BOr, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "bitxor"  -> BinOp (Cil.BXor, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "and"     -> BinOp (Cil.LAnd, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "or"      -> BinOp (Cil.LOr, expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "member" -> (** a field offset *)
    Lfield (expr_to_sil (irep#op0),
            Ident.string_to_name (irep#get "component_name"))
  | "index" -> (** an array index offset: [exp1\[exp2\]] *)
    Lindex (expr_to_sil (irep#op0), expr_to_sil (irep#op1))
  | "symbol" -> 
    let symbol_name = Ident.string_to_name (irep#get "identifier") in
    let symbol_type = (irep#find "type") in
    if symbol_type#id = "code" then
      (** function value *)
      Const_fun symbol_name
    else
      (** the address of a program variable *)
      Lvar (mk_pvar_global symbol_name)
  | _ -> raise (Conversion_exception.Conversion_error ("unexpected expression "^irep#id))
;;

 (* missing: if, dereference, address_of *)

    (*
    | Var of ident (** pure variable: it is not an lvalue *)
    | Sizeof of typ (** a sizeof expression *)
    *)
