let db_dir: string ref = ref ""

let curr_filename: string ref = ref ""

let abd_background: string = ""

let num_cores: int ref = ref 0

let in_child_process: bool ref = ref false

let test: bool ref = ref false

let tick: bool ref = ref false

let nelseg: bool ref = ref false
