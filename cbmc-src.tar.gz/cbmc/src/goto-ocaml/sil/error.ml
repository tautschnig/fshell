type error_mode=DEFAULT

module type ErrArg = sig
  val mode: error_mode
end

module MyErr (S : ErrArg) = struct
  let err fmt = Format.fprintf Format.std_formatter fmt
  let stderr fmt = Format.fprintf Format.std_formatter fmt
  let log fmt = Format.fprintf Format.std_formatter fmt
end

module PTtyp_full = struct
  let dummy = print_endline "hello"
end

type pttypes = PTtyp_full | PThpred | PTtyp_list | PTpvar | PTexp |
               PTexp_list | PTtexp_full | PToff | PToff_list | PTloc |
               PTinstr | PTinstr_list | PTatom | PTsexp | PTnode_instrs

let add_print_action(x: (pttypes * Obj.t)): unit=
  ()

