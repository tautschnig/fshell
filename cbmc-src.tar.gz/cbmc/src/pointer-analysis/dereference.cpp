/*******************************************************************\

Module: Symbolic Execution of ANSI-C

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <expr_util.h>
#include <c_misc.h>
#include <base_type.h>
#include <arith_tools.h>
#include <rename.h>
#include <i2string.h>
#include <array_name.h>
#include <config.h>
#include <std_expr.h>
#include <cprover_prefix.h>
#include <pointer_offset_size.h>

#include <ansi-c/c_types.h>
#include <ansi-c/c_typecast.h>

#include <goto-programs/dynamic_memory.h>
#include <pointer-analysis/value_set.h>

#include <langapi/language_util.h>

#include "dereference.h"
#include "pointer_offset_sum.h"

// global data, horrible
unsigned int dereferencet::invalid_counter=0;

/*******************************************************************\

Function: dereferencet::has_dereference

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool dereferencet::has_dereference(const exprt &expr) const
{
  forall_operands(it, expr)
    if(has_dereference(*it))
      return true;

  if(expr.id()=="dereference" ||
     expr.id()=="implicit_dereference" ||
     (expr.id()=="index" && expr.operands().size()==2 &&
      expr.op0().type().id()=="pointer"))
    return true;

  return false;
}

/*******************************************************************\

Function: dereferencet::get_symbol

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

const exprt& dereferencet::get_symbol(const exprt &expr)
{
  if(expr.id()=="member" || expr.id()=="index")
    return get_symbol(expr.op0());
  
  return expr;
}

/*******************************************************************\

Function: dereferencet::dereference

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void dereferencet::dereference(
  exprt &dest,
  const guardt &guard,
  const modet mode)
{
  if(dest.type().id()!="pointer")
    throw "dereference expected pointer type, but got "+
          dest.type().pretty();

  // save the dest for later, dest might be destroyed
  const exprt deref_expr(dest);
  
  // type of the object
  const typet &type=deref_expr.type().subtype();

  #if 0
  std::cout << "DEREF: " << dest.pretty() << std::endl;
  #endif

  // collect objects dest may point to
  value_setst::valuest points_to_set;
  
  dereference_callback.get_value_set(dest, points_to_set);

  // now build big case split
  // only "good" objects

  exprt value;
  value.make_nil();

  // if it's empty, we have a problem
  if(points_to_set.empty())
  {
    if(options.get_bool_option("pointer-check"))
    {
      dereference_callback.dereference_failure(
        "pointer dereference",
        "invalid pointer", guard);
    }
  }

  for(value_setst::valuest::const_iterator
      it=points_to_set.begin();
      it!=points_to_set.end();
      it++)
  {
    exprt new_value, pointer_guard;

    build_reference_to(
      *it, mode, dest, type, 
      new_value, pointer_guard, guard);

    if(new_value.is_not_nil())
    {
      if(value.is_nil())
        value.swap(new_value);
      else
      {
        if_exprt tmp;
        tmp.type()=type;
        tmp.cond()=pointer_guard;
        tmp.true_case()=new_value;
        tmp.false_case().swap(value);
        value.swap(tmp);
      }
    }
  }

  if(value.is_nil())
  {
    // first see if we have a "failed object" for this pointer
    
    const symbolt *failed_symbol;

    if(dereference_callback.has_failed_symbol(deref_expr, failed_symbol))
    {
      // yes!
      value=symbol_expr(*failed_symbol);
    }
    else
    {
      // else, do new symbol

      symbolt symbol;
      symbol.name="symex::invalid_object"+i2string(invalid_counter++);
      symbol.base_name="invalid_object";
      symbol.type=type;

      // make it a lvalue, so we can assign to it
      symbol.lvalue=true;
      
      get_new_name(symbol, ns);

      value=symbol_expr(symbol);
      
      new_context.move(symbol);
    }
    
    value.set("#invalid_object", true);
  }

  dest.swap(value);
}

/*******************************************************************\

Function: dereferencet::add_checks

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void dereferencet::add_checks(
  const exprt &dest,
  const guardt &guard,
  const modet mode)
{
  if(dest.type().id()!="pointer")
    throw "dereference expected pointer type, but got "+
          dest.type().pretty();

  #if 0
  std::cout << "ADD CHECK: " << dest.pretty() << std::endl;
  #endif

  const typet &type=dest.type().subtype();

  // collect objects dest may point to
  value_setst::valuest points_to_set;

  dereference_callback.get_value_set(dest, points_to_set);
  
  // if it's empty, we have a problem
  if(points_to_set.empty())
  {
    if(options.get_bool_option("pointer-check"))
    {
      dereference_callback.dereference_failure(
        "pointer dereference",
        "invalid pointer", guard);
    }
  }
  else
  {
    for(value_setst::valuest::const_iterator
        it=points_to_set.begin();
        it!=points_to_set.end();
        it++)
    {
      exprt new_value, pointer_guard;

      build_reference_to(
        *it, mode, dest, type,
        new_value, pointer_guard, guard);
    }
  }
}

/*******************************************************************\

Function: dereferencet::dereference_type_compare

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool dereferencet::dereference_type_compare(
  exprt &object,
  const typet &dereference_type) const
{
  const typet &object_type=object.type();

  if(dereference_type.id()=="empty")
    return true; // always ok

  if(base_type_eq(object_type, dereference_type, ns))
    return true; // ok, they just match

  // check for struct prefixes

  const typet ot_base=ns.follow(object_type),
              dt_base=ns.follow(dereference_type);

  if(ot_base.id()=="struct" &&
     dt_base.id()=="struct")
  {
    if(to_struct_type(dt_base).is_prefix_of(
         to_struct_type(ot_base)))
    {
      object.make_typecast(dereference_type);
      return true; // ok, dt is a prefix of ot
    }
  }
  
  // we are generous about code pointers
  if(dereference_type.id()=="code" &&
     object_type.id()=="code")
    return true;

  // really different

  return false;
}

/*******************************************************************\

Function: dereferencet::build_reference_to

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void dereferencet::build_reference_to(
  const exprt &what,
  const modet mode,
  const exprt &deref_expr,
  const typet &type,
  exprt &value,
  exprt &pointer_guard,
  const guardt &guard)
{
  value.make_nil();
  pointer_guard.make_false();

  if(what.id()=="unknown" ||
     what.id()=="invalid")
  {
    if(options.get_bool_option("pointer-check"))
    {
      // constraint that it actually is an invalid pointer

      exprt invalid_pointer_expr("invalid-pointer", bool_typet());
      invalid_pointer_expr.copy_to_operands(deref_expr);
      
      // produce new guard
      
      guardt tmp_guard(guard);
      tmp_guard.add(invalid_pointer_expr);
      dereference_callback.dereference_failure(
        "pointer dereference",
        "invalid pointer", 
        tmp_guard);
    }
    
    return;
  }
  
  if(what.id()!="object_descriptor")
    throw "unknown points-to: "+what.id_string();
  
  const object_descriptor_exprt &o=to_object_descriptor_expr(what);

  const exprt &root_object=o.root_object();
  const exprt &object=o.object();
  
  if(root_object.id()=="NULL-object")
  {
    if(options.get_bool_option("pointer-check"))
    {
      constant_exprt pointer(typet("pointer"));
      pointer.type().subtype()=type;
      pointer.set_value("NULL");

      guardt tmp_guard(guard);
      
      if(o.offset().is_zero())
      {
        tmp_guard.add(equality_exprt(deref_expr, pointer));

        dereference_callback.dereference_failure(
          "pointer dereference",
          "NULL pointer", tmp_guard);
      }
      else
      {
        exprt pointer_guard("same-object", bool_typet());
        pointer_guard.copy_to_operands(deref_expr, pointer);
        tmp_guard.add(pointer_guard);

        dereference_callback.dereference_failure(
          "pointer dereference",
          "NULL plus offset pointer", tmp_guard);
      }
    }
  }
  else if(root_object.id()=="dynamic_object")
  {
    const dynamic_object_exprt &dynamic_object=
      to_dynamic_object_expr(root_object);
  
    value=exprt("dereference", type);
    value.copy_to_operands(deref_expr);

    if(options.get_bool_option("pointer-check"))
    {
      // constraint that it actually is a dynamic object

      exprt is_dynamic_object_expr("is_dynamic_object", bool_typet());
      is_dynamic_object_expr.copy_to_operands(deref_expr);

      if(!dynamic_object.valid().is_true())
      {
        // check if it is still alive
        guardt tmp_guard(guard);
        tmp_guard.add(is_dynamic_object_expr);
        tmp_guard.add(gen_not(valid_object(ns, deref_expr)));
        dereference_callback.dereference_failure(
          "pointer dereference",
          "invalidated dynamic object", 
          tmp_guard);
      }

      if(options.get_bool_option("bounds-check") &&
         !o.offset().is_zero())
      {
        {
          // check lower bound
          exprt zero=gen_zero(index_type());
          assert(zero.is_not_nil());

          exprt object_offset=unary_exprt(
            "pointer_offset", deref_expr, index_type());

          binary_relation_exprt
            inequality(object_offset, "<", zero);

          guardt tmp_guard(guard);
          tmp_guard.add(is_dynamic_object_expr);
          tmp_guard.add(inequality);
          dereference_callback.dereference_failure(
            "pointer dereference",
            "dynamic object lower bound", tmp_guard);
        }

        {
          // check upper bound
          exprt size_expr=dynamic_size(ns, deref_expr);
            
          mp_integer element_size=pointer_offset_size(ns, type);
          
          if(element_size!=1)
          {
            exprt element_size_expr=
              from_integer(element_size, size_type());
          
            size_expr=binary_exprt(
              size_expr, "*", element_size_expr, size_type());
          }

          exprt object_offset=
            unary_exprt("pointer_offset", deref_expr, index_type());
          object_offset.make_typecast(size_type());

          binary_relation_exprt
            inequality(size_expr, "<=", object_offset);

          guardt tmp_guard(guard);
          tmp_guard.add(is_dynamic_object_expr);
          tmp_guard.add(inequality);
          dereference_callback.dereference_failure(
            "pointer dereference",
            "dynamic object upper bound", tmp_guard);
        }
      }

      exprt tmp_object(object);

      // check type
      if(!dereference_type_compare(tmp_object, type))
      {
        exprt type_expr=exprt("pointer_object_has_type", bool_typet());
        type_expr.copy_to_operands(deref_expr);
        type_expr.set("object_type", type);
        type_expr.make_not();
      
        guardt tmp_guard(guard);
        tmp_guard.add(is_dynamic_object_expr);
        tmp_guard.add(type_expr);
        
        std::string msg="wrong object type (got `";
        msg+=from_type(ns, "", object.type());
        msg+="', expected `";
        msg+=from_type(ns, "", type);
        msg+="')";

        dereference_callback.dereference_failure(
          "pointer dereference",
          msg, tmp_guard);
      }
    }
  }
  else
  {
    value=object;
    
    exprt object_pointer("address_of", pointer_typet());
    object_pointer.type().subtype()=object.type();
    object_pointer.copy_to_operands(object);

    pointer_guard=exprt("same-object", bool_typet());
    pointer_guard.copy_to_operands(deref_expr, object_pointer);

    guardt tmp_guard(guard);
    tmp_guard.add(pointer_guard);
    
    valid_check(object, tmp_guard, mode);

    exprt offset;
    
    if(o.offset().is_constant())
      offset=o.offset();
    else
    {
      exprt pointer_offset=
        unary_exprt("pointer_offset", deref_expr, index_type());
      
      exprt base=
        unary_exprt("pointer_offset", object_pointer, index_type());

      // need to subtract base address
      offset=binary_exprt(pointer_offset, "-", base, index_type());
    }

    if(!dereference_type_compare(value, type))
    {
      if(memory_model(value, type, tmp_guard, offset))
      {
        // ok
      }
      else
      {
        if(options.get_bool_option("pointer-check"))
        {
          std::string msg="memory model not applicable (got `";
          msg+=from_type(ns, "", value.type());
          msg+="', expected `";
          msg+=from_type(ns, "", type);
          msg+="')";

          dereference_callback.dereference_failure(
            "pointer dereference",
            msg, tmp_guard);
        }

        value.make_nil();
        return; // give up, no way that this is ok
      }
    }
    else
    {
      // do we have an array?
      if(value.id()=="index")
      {
        exprt adjusted_offset;
        mp_integer size=pointer_offset_size(ns, value.type());

        if(size==1 || offset.is_zero())
          adjusted_offset=offset;
        else
        {
          exprt size_expr=from_integer(size, offset.type());
          adjusted_offset=
            binary_exprt(offset, "/", size_expr, offset.type());
        }

        index_exprt &index_expr=to_index_expr(value);
        index_expr.index()=adjusted_offset;
        bounds_check(index_expr, tmp_guard);
      }
      else if(!offset.is_zero())
      {
        if(options.get_bool_option("pointer-check"))
        {
          equality_exprt
            offset_not_zero(offset, gen_zero(offset.type()));
          offset_not_zero.make_not();
          
          guardt tmp_guard2(guard);
          tmp_guard2.add(offset_not_zero);
          
          dereference_callback.dereference_failure(
            "pointer dereference",
            "offset not zero (non-array-object)", tmp_guard2);
        }
      }
    }
  }
}

/*******************************************************************\

Function: dereferencet::valid_check

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void dereferencet::valid_check(
  const exprt &object,
  const guardt &guard,
  const modet mode)
{
  if(!options.get_bool_option("pointer-check"))
    return;

  if(mode==FREE)
  {
    dereference_callback.dereference_failure(
      "pointer dereference",
      "free() of non-dynamic memory",
      guard);
    return;
  }
    
  const exprt &symbol=get_symbol(object);

  if(symbol.id()=="string-constant")
  {
    // always valid, but can't write
    
    if(mode==WRITE)
    {
      dereference_callback.dereference_failure(
        "pointer dereference",
        "write access to string constant",
        guard);
    }
  }
  else if(symbol.is_nil() ||
          symbol.get_bool("#invalid_object"))
  { 
    // always "valid", shut up
    return;
  }
  else if(symbol.id()=="symbol")
  {
    const irep_idt identifier=symbol.get("identifier");
  
    if(dereference_callback.is_valid_object(identifier))
      return; // always ok
  }
}

/*******************************************************************\

Function: dereferencet::bounds_check

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void dereferencet::bounds_check(
  const index_exprt &expr,
  const guardt &guard)
{
  if(!options.get_bool_option("bounds-check"))
    return;

  const typet &array_type=ns.follow(expr.op0().type());

  if(array_type.id()!="array")
    throw "bounds check expected array type";

  std::string name=array_name(ns, expr.array());
  
  {
    mp_integer i;
    if(!to_integer(expr.index(), i) &&
       i>=0)
    {
    }
    else
    {
      exprt zero=gen_zero(expr.index().type());

      if(zero.is_nil())
        throw "no zero constant of index type "+
          expr.index().type().to_string();

      binary_relation_exprt
        inequality(expr.index(), "<", zero);

      guardt tmp_guard(guard);
      tmp_guard.add(inequality);
      dereference_callback.dereference_failure(
        "array bounds",
        name+" lower bound", tmp_guard);
    }
  }

  const exprt &size_expr=
    to_array_type(array_type).size();

  if(size_expr.id()!="infinity")
  {
    if(size_expr.is_nil())
      throw "index array operand of wrong type";

    binary_relation_exprt inequality(expr.index(), ">=", size_expr);

    if(c_implicit_typecast(
      inequality.op0(),
      inequality.op1().type(),
      ns))
      throw "index address of wrong type";

    guardt tmp_guard(guard);
    tmp_guard.add(inequality);
    dereference_callback.dereference_failure(
      "array bounds",
      name+" upper bound", tmp_guard);
  }
}

/*******************************************************************\

Function: dereferencet::memory_model

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

static unsigned bv_width(const typet &type)
{
  return atoi(type.get("width").c_str());
}

static bool is_a_bv_type(const typet &type)
{
  return type.id()=="unsignedbv" ||
         type.id()=="signedbv" ||
         type.id()=="bv" ||
         type.id()=="fixedbv" ||
         type.id()=="floatbv";
}

bool dereferencet::memory_model(
  exprt &value,
  const typet &to_type,
  const guardt &guard,
  exprt &new_offset)
{
  // we will allow more or less arbitrary pointer type cast

  const typet from_type=value.type();

  // first, check if it's really just a conversion

  if(is_a_bv_type(from_type) &&
     is_a_bv_type(to_type) &&
     bv_width(from_type)==bv_width(to_type))
    return memory_model_conversion(value, to_type, guard, new_offset);

  // otherwise, we will stich it together from bytes
  
  return memory_model_bytes(value, to_type, guard, new_offset);
}

/*******************************************************************\

Function: dereferencet::memory_model_conversion

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool dereferencet::memory_model_conversion(
  exprt &value,
  const typet &to_type,
  const guardt &guard,
  exprt &new_offset)
{
  const typet from_type=value.type();

  // avoid semantic conversion in case of
  // cast to float or fixed-point
  if(from_type.id()!="bv" &&
     (to_type.id()=="fixedbv" || to_type.id()=="floatbv"))
  {
    value.make_typecast(bv_typet(bv_width(from_type)));
    value.make_typecast(to_type);
  }
  else
  {
    // only doing type conversion
    // just do the typecast
    value.make_typecast(to_type);
  }

  // also assert that offset is zero

  if(options.get_bool_option("pointer-check"))
  {
    equality_exprt offset_not_zero(new_offset, gen_zero(new_offset.type()));
    offset_not_zero.make_not();
  
    guardt tmp_guard(guard);
    tmp_guard.add(offset_not_zero);
    dereference_callback.dereference_failure(
      "word bounds",
      "offset not zero", tmp_guard);
  }

  return true;
}

/*******************************************************************\

Function: dereferencet::memory_model_bytes

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool dereferencet::memory_model_bytes(
  exprt &value,
  const typet &to_type,
  const guardt &guard,
  exprt &new_offset)
{
  const typet from_type=value.type();

  // we won't try to convert to/from code
  if(from_type.id()=="code" || to_type.id()=="code")
    return false;

  // won't do this without a committment to an endianess
  if(config.ansi_c.endianess==configt::ansi_ct::NO_ENDIANESS)
    return false; 

  // But anything else we will try!

  // We allow reading more or less anything as bit-vector.
  if(to_type.id()=="bv" ||
     to_type.id()=="unsignedbv" ||
     to_type.id()=="signedbv")
  {
    exprt byte_extract(byte_extract_id(), to_type);
    byte_extract.copy_to_operands(value, new_offset);
    value=byte_extract;
  
    if(!new_offset.is_zero())
    {
      if(options.get_bool_option("pointer-check"))
      {
        exprt bound=exprt("width", new_offset.type());
        bound.copy_to_operands(value.op0());

        binary_relation_exprt
          offset_upper_bound(new_offset, ">=", bound);
        
        guardt tmp_guard(guard);
        tmp_guard.add(offset_upper_bound);
        dereference_callback.dereference_failure(
          "word bounds",
          "word offset upper bound", tmp_guard);
      }

      if(options.get_bool_option("pointer-check"))
      {
        binary_relation_exprt
          offset_lower_bound(new_offset, "<",
                             gen_zero(new_offset.type()));

        guardt tmp_guard(guard);
        tmp_guard.add(offset_lower_bound);                
        dereference_callback.dereference_failure(
          "word bounds",
          "word offset lower bound", tmp_guard);
      }
    }

    return true;
  }
  
  return false;
}

/*******************************************************************\

Function: dereferencet::byte_extract_id

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

irep_idt dereferencet::byte_extract_id()
{
  switch(config.ansi_c.endianess)
  {
  case configt::ansi_ct::IS_LITTLE_ENDIAN:
    return "byte_extract_little_endian";

  case configt::ansi_ct::IS_BIG_ENDIAN:
    return "byte_extract_big_endian";
    
  case configt::ansi_ct::NO_ENDIANESS:
    assert(false);
  }
    
  return "";
}
