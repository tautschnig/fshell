/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "boolbv.h"

/*******************************************************************\

Function: boolbvt::convert_if

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool boolbvt::convert_if(const exprt &expr, bvt &bv)
{
  const exprt::operandst &operands=expr.operands();
  
  unsigned width;
  if(boolbv_get_width(expr.type(), width))
    return true;

  if(operands.size()!=3)
    throw "if takes three operands";

  bvt op1_bv, op2_bv;

  literalt op0=convert(operands[0]);
  
  if(convert_bv(operands[1], op1_bv)) return true;
  if(convert_bv(operands[2], op2_bv)) return true;

  if(op1_bv.size()!=width || op2_bv.size()!=width) return true;

  bv=bv_utils.select(op0, op1_bv, op2_bv);
  
  return false;
}
