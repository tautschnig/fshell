/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <assert.h>

#include <arith_tools.h>

#include "boolbv.h"

/*******************************************************************\

Function: boolbvt::convert_byte_update

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool boolbvt::convert_byte_update(const exprt &expr, bvt &bv)
{
  if(expr.operands().size()!=3)
    throw "byte_update takes three operands";
    
  const exprt &op0=expr.op0();
  const exprt &op1=expr.op1();
  const exprt &op2=expr.op2();

  bool little_endian;
  
  if(expr.id()=="byte_update_little_endian")
    little_endian=true;
  else if(expr.id()=="byte_update_big_endian")
    little_endian=false;
  else
    assert(false);

  if(convert_bv(op0, bv))
    return true;

  unsigned bytes=bv.size()/8;
  
  if(bytes==0)
    throw "byte_update expects at least one byte as operand";

  bvt op2_bv;

  if(convert_bv(op2, op2_bv))
    return true;

  if(op2_bv.size()!=8)
    throw "byte_update takes a byte as third operand";

  // see if the byte number is constant

  mp_integer index;
  if(!to_integer(op1, index))
  {
    mp_integer offset;
    
    if(little_endian)
      offset=index*8;
    else
      offset=(mp_integer(bv.size()/8)-index-1)*8;

    if(mp_integer(bv.size())<offset+8 || offset<0)
    {
      // out of bounds
    }
    else
    {
      for(unsigned i=0; i<8; i++)
        bv[integer2long(offset+i)]=op2_bv[i];
    }

    return false;
  }

  throw "byte_update with variable not implemented";

  return false;
}
