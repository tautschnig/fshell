/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include "boolbv.h"

/*******************************************************************\

Function: boolbvt::convert_concatenation

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool boolbvt::convert_concatenation(const exprt &expr, bvt &bv)
{
  unsigned width;
  if(boolbv_get_width(expr.type(), width))
    return true;
    
  const exprt::operandst &operands=expr.operands();

  if(operands.size()==0)
    throw "concatenation takes at least one operand";

  unsigned offset=width;
  bv.resize(width);

  forall_expr(it, operands)
  {
    bvt op;

    if(convert_bv(*it, op)) return true;

    if(op.size()>offset)
      throw "concatenation operand width too big";

    offset-=op.size();

    for(unsigned i=0; i<op.size(); i++)
      bv[offset+i]=op[i];
  }    

  if(offset!=0)
    throw "concatenation operand width too small";

  return false;
}
