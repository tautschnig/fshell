/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <std_types.h>

#include "boolbv.h"
#include "boolbv_type.h"

#ifdef HAVE_FLOATBV
#include "../floatbv/float_utils.h"
#endif

/*******************************************************************\

Function: boolbvt::convert_unary_minus

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool boolbvt::convert_unary_minus(const exprt &expr, bvt &bv)
{
  unsigned width;
  if(boolbv_get_width(expr.type(), width))
    return true;

  const exprt::operandst &operands=expr.operands();

  if(operands.size()!=1)
    throw "unary minus takes one operand";
    
  const exprt &op0=expr.op0();

  bvt op_bv;
  if(convert_bv(op0, op_bv)) return true;

  bvtypet bvtype=get_bvtype(expr.type());
  bvtypet op_bvtype=get_bvtype(op0.type());
  unsigned op_width=op_bv.size();

  bool no_overflow=(expr.id()=="no-overflow-unary-minus");
  
  if(op_width!=0)
  {
    if(bvtype==IS_FIXED && op_bvtype==IS_FIXED)
    {
      if(no_overflow)
        bv=bv_utils.negate_no_overflow(op_bv);
      else
        bv=bv_utils.negate(op_bv);

      return false;
    }
    else if(bvtype==IS_FLOAT && op_bvtype==IS_FLOAT)
    {
      #ifdef HAVE_FLOATBV
      assert(!no_overflow);
      float_utilst float_utils(prop);
      float_utils.spec=to_floatbv_type(expr.type());
      bv=float_utils.negate(op_bv);
      return false;
      #endif
    }
    else if((op_bvtype==IS_SIGNED || op_bvtype==IS_UNSIGNED) &&
            (bvtype==IS_SIGNED || bvtype==IS_UNSIGNED))
    {
      if(no_overflow)
        prop.l_set_to(bv_utils.overflow_negate(op_bv), false);

      if(no_overflow)
        bv=bv_utils.negate_no_overflow(op_bv);
      else
        bv=bv_utils.negate(op_bv);

      return false;
    }
  }
  
  return true;
}
