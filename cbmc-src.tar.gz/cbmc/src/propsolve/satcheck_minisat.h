/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_SATCHECK_MINISAT_H
#define CPROVER_SATCHECK_MINISAT_H

#include <vector>
#include <set>

#include "cnf.h"
#include "resolution_proof.h"

class satcheck_minisat_baset:public cnf_solvert
{
public:
  satcheck_minisat_baset():solver(NULL)
  {
  }
  
  virtual ~satcheck_minisat_baset();
  
  virtual const std::string solver_text();
  virtual resultt prop_solve();
  virtual tvt l_get(literalt a) const;

  virtual void lcnf(const bvt &bv);
  
  virtual void set_assignment(literalt a, bool value);

  // extra MiniSat feature: solve with assumptions
  void set_assumptions(const bvt &_assumptions)
  {
    assumptions=_assumptions;
  }
  
protected:
  class Solver *solver;
  void add_variables();
  bvt assumptions;
};

class satcheck_minisatt:public satcheck_minisat_baset
{
public:
  satcheck_minisatt();
};

class satcheck_minisat_prooft:public satcheck_minisatt
{
public:
  satcheck_minisat_prooft();
  ~satcheck_minisat_prooft();
  
  virtual const std::string solver_text();
  simple_prooft &get_resolution_proof();
  //void set_partition_id(unsigned p_id);

protected:
  class Proof *proof;
  class minisat_prooft *minisat_proof;
};

class satcheck_minisat_coret:public satcheck_minisat_prooft
{
public:
  satcheck_minisat_coret();
  ~satcheck_minisat_coret();

  virtual const std::string solver_text();
  virtual resultt prop_solve();
  
  bool is_in_core(literalt l) const
  {
    assert(l.var_no()<in_core.size());
    return in_core[l.var_no()];
  }
  
protected:
  std::vector<bool> in_core;
};
#endif
