/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_SATCHECK_MINISAT2_H
#define CPROVER_SATCHECK_MINISAT2_H

#include <vector>
#include <set>

#include "cnf.h"

class satcheck_minisat_baset:public cnf_solvert
{
public:
  satcheck_minisat_baset():solver(NULL)
  {
  }
  
  virtual ~satcheck_minisat_baset();
  
  virtual const std::string solver_text();
  virtual resultt prop_solve();
  virtual tvt l_get(literalt a) const;

  virtual void lcnf(const bvt &bv);
  
  virtual void set_assignment(literalt a, bool value);

  // extra MiniSat feature: solve with assumptions
  void set_assumptions(const std::list<literalt> &_assumptions)
  {
    assumptions=_assumptions;
  }

protected:
  class SimpSolver *solver;
  void add_variables();
  std::list<literalt> assumptions;
};

class satcheck_minisatt:public satcheck_minisat_baset
{
public:
  satcheck_minisatt();
};

#endif
