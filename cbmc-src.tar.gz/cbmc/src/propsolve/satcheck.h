/*******************************************************************\

Module:

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_SATCHECK_H
#define CPROVER_SATCHECK_H

//#define SATCHECK_ZCHAFF
#define SATCHECK_MINISAT
//#define SATCHECK_BOOLEFORCE

#ifdef SATCHECK_ZCHAFF

#include "satcheck_zchaff.h"

typedef satcheck_zchafft satcheckt;

#else
#ifdef SATCHECK_BOOLEFORCE

#include "satcheck_booleforce.h"

typedef satcheck_booleforcet satcheckt;

#else

#ifdef SATCHECK_MINISAT

#include "satcheck_minisat.h"

typedef satcheck_minisatt satcheckt;

#else
#error NO SAT CHECKER
#endif
#endif
#endif

#endif
