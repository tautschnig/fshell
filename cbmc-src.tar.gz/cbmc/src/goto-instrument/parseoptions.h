/*******************************************************************\

Module: Command Line Parsing

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_GOTO_INSTRUMENT_PARSEOPTIONS_H
#define CPROVER_GOTO_INSTRUMENT_PARSEOPTIONS_H

#include <ui_message.h>
#include <parseoptions.h>

#include <langapi/language_ui.h>
#include <goto-programs/goto_functions.h>

#define GOTO_INSTRUMENT_OPTIONS \
  "(all)(document-claims)" \
  "(bounds-check)(no-bounds-check)" \
  "(pointer-check)(no-pointer-check)" \
  "(div-by-zero-check)(no-div-by-zero-check)" \
  "(no-assertions)" \
  "(nan-check)(no-nan-check)" \
  "(overflow-check)(no-overflow-check)" \
  "(show-goto-functions)(show-value-sets)" \
  "(show-symbol-table)(show-claims)" \
  "(error-label):(verbosity):" \
  "(version)(string-abstraction)"

class goto_instrument_parseoptionst:
  public parseoptions_baset,
  public language_uit
{
public:
  virtual int doit();
  virtual void help();

  goto_instrument_parseoptionst(int argc, const char **argv):
    parseoptions_baset(GOTO_INSTRUMENT_OPTIONS, argc, argv),
    language_uit(cmdline)
  {
  }
  
protected:
  virtual void register_languages();

  //virtual void get_command_line_options(optionst &options);

  virtual bool get_goto_program(
    goto_functionst &goto_functions);

  virtual bool process_goto_program(
    goto_functionst &goto_functions);
    
  bool read_goto_binary(goto_functionst &goto_functions);

  bool set_claims(goto_functionst &goto_functions);
  
  void set_verbosity(messaget &message);
};

#endif
