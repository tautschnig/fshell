/*******************************************************************\

Module: CVC Parser

Author: Daniel Kroening, kroening@cs.cmu.edu

\*******************************************************************/

#include "parser.h"

extern class parsert cvc_parser;

#define PARSER cvc_parser
