#include <iostream>

bool cvc_typecheck(std::ostream &err, exprt &expr);

