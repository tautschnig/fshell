/*******************************************************************\

Module: Command Line Parsing

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#ifndef CPROVER_WOLVER_PARSEOPTIONS_H
#define CPROVER_WOLVER_PARSEOPTIONS_H

#include <ui_message.h>
#include <parseoptions.h>

#include <langapi/language_ui.h>
#include <goto-programs/goto_functions.h>
#include <goto-symex/goto_trace.h>

#include "wolver.h"

#define WOLVER_OPTIONS \
  "(function):(preprocess)" \
  "(no-bounds-check)(pointer-check)D:I:" \
  "(unwind):(unwindset):(log):(interpolator):" \
  "(path-length-threshold):(force-cover):(div-by-zero-check)" \
  "(overflow-check)(floatbv)(fixedbv)(no-assertions)" \
  "(16)(32)(64)(little-endian)(big-endian)" \
  "(show-goto-functions)(show-value-sets)(show-invariants)(xml-ui)" \
  "(show-symbol-table)(show-claims)(claim):" \
  "(error-label):(verbosity):(no-library)" \
  "(version)(i386-linux)(i386-macos)(i386-win32)(ppc-macos)(unsigned-char)" \
  "(arrays-uf-always)(arrays-uf-never)" \
  "(no-proof-lifting)(weak-interpolants)" \
  "(string-abstraction)(no-arch)(no-slicing)(no-path-slicing)" \
  "(round-to-nearest)(round-to-plus-inf)(round-to-minus-inf)(round-to-zero)" 

class wolver_parseoptionst:
  public parseoptions_baset,
  public language_uit
{
public:
  virtual int doit();
  virtual void help();

  wolver_parseoptionst(int argc, const char **argv);

protected:
  virtual void get_command_line_options(optionst &options);
  virtual int do_modelcheck(
    wolver_baset &wolver, const goto_functionst &goto_functions);

  virtual bool get_goto_program(
    wolver_baset &wolver,
    goto_functionst &goto_functions);

  virtual bool process_goto_program(
    wolver_baset &wolver,
    goto_functionst &goto_functions);
    
  bool set_claims(goto_functionst &goto_functions);
  
  void set_verbosity(messaget &message);

  // get any additional stuff before finalizing
  virtual bool get_modules(wolver_baset &wolver)
  {
    return false;
  }
  
  void preprocessing();
};

#endif
