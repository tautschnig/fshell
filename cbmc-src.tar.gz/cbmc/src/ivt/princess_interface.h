/*******************************************************************\

Module: Interface to the Princess tool for interpolation in
        Presburger arithmetic

Author: Philipp Ruemmer, ph_r@gmx.net
        Angelo Brillout, bangelo@inf.ethz.ch

\*******************************************************************/

#ifndef PRINCESS_INTERFACE_H
#define PRINCESS_INTERFACE_H

#include <sstream>
#include <map>
#include <cmath>
#include <stack>

#include <config.h>
#include <simplify_expr.h>
#include <arith_tools.h>
#include <solvers/flattening/boolbv.h>
#include <solvers/flattening/boolbv_width.h>
#include <solvers/flattening/pointer_logic.h>
#include <i2string.h>

#include <wordlevel_interpolator.h>

#include "version.h"

//#define DEBUG

using namespace std;


/* ************************************************************************** */

class PrincessLineariser {

public:
  PrincessLineariser(ostream& out, const namespacet &ns)
    : out(out), ns(ns), pointer_logic(ns), currentTransitionRelationNum(0),
      undefVariableCounter(0), arrayOfCounter(0) {}

  void lineariseFormula(const exprt &e) { lineariseExpr(e, true); }
  void lineariseExpr(const exprt &e, bool bool_context);
  void incTransitionRelation() { ++currentTransitionRelationNum; }

  ////////////////////////////////////////////////////////////////////////////

  struct SymInfo {
    string originalName;
    string linearisedName;
    unsigned int transitionRelationNum;
    typet type;
    exprt initializeExpr;

    SymInfo()
          : originalName(""), linearisedName(""),
            transitionRelationNum(0), type(type),
            initializeExpr(exprt(ID_nil)) {}

    SymInfo(const string& originalName,
            const string& linearisedName,
            unsigned int transitionRelationNum,
            const typet& type)
      : originalName(originalName),
        linearisedName(linearisedName),
        transitionRelationNum(transitionRelationNum),
        type(type),
        initializeExpr(exprt(ID_nil)) {}

    SymInfo(const string& originalName,
            const string& linearisedName,
            unsigned int transitionRelationNum,
            const typet& type,
            const exprt& initializeExpr)
      : originalName(originalName),
        linearisedName(linearisedName),
        transitionRelationNum(transitionRelationNum),
        type(type),
        initializeExpr(initializeExpr) {}
  };

  void printVariableRanges();
  void printPartHeader(unsigned int i);
  void printVariableDecls();

  typedef map<string, SymInfo> SymInfoMap;
  SymInfoMap symbolsFromLin;

private:
  ostream& out;
  const namespacet &ns;
  pointer_logict pointer_logic;

  unsigned int currentTransitionRelationNum;
  unsigned int undefVariableCounter;
  unsigned int arrayOfCounter;

  SymInfoMap symbolsFromOri;

  unsigned safe_width(const exprt &e);
  unsigned safe_width(const typet &type);
  void lineariseSym(const exprt& e, const exprt& initializer = exprt(ID_nil));
  void lineariseUndefSymbol(const typet& type, bool bool_context);

};



////////////////////////////////////////////////////////////////////////////////

class PrincessFormulaParser {

public:
  PrincessFormulaParser(const PrincessLineariser::SymInfoMap& vocabulary,
                        const string& charSeq)
    : vocabulary(vocabulary), charSeq(charSeq), currentPos(0),
      hasNextToken(false), nextToken("") {
    computeNextToken();
  }

  exprt parse() { return parseFormula(1); }

private:
  const PrincessLineariser::SymInfoMap& vocabulary;

  typedef set<exprt> Quans;
  typedef stack<Quans> QuanStack;
  QuanStack quanStack;

  const string charSeq;
  unsigned int currentPos;
  istringstream tokens;
  bool hasNextToken;
  string nextToken;

  exprt parseFormula(int polarity);
  exprt parseTerm(bool& untranslatable);
  void expect(const string& token);
  void consumeWhiteSpaces();
  void computeNextToken();

};

////////////////////////////////////////////////////////////////////////////////

class TypeAdjuster
{
public:
  TypeAdjuster(const namespacet &ns) : ns(ns) {}
  void adjust(exprt& e) { adjust(e, e.type(), 0); }

private:
  const namespacet &ns;
  void adjust(exprt& e, typet& expectedType, unsigned additionalWidth);
  void setNewWidth(typet &type, const unsigned& additionalWidth);
  unsigned getAdditionalWidth(exprt& e);
};

#endif
