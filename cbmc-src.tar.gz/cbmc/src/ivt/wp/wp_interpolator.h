/*******************************************************************\

Module: Interpolator interface for Weakest Precondition

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef CPROVER_WP_INTERPOLATOR_H
#define CPROVER_WP_INTERPOLATOR_H

#include "../path_interpolator.h"

/*******************************************************************\

  Class:   wp_interpolatort

  Purpose: Interpolator based on the weakest precondition

\*******************************************************************/

class wp_interpolatort: public path_interpolatort
{
public:
  wp_interpolatort(
    goto_program_unwindingt::unwinding_grapht &_graph,
    const namespacet &_ns):
    path_interpolatort(_graph, _ns)
  {
  }
  
  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&, 
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&);

  virtual void process_options(const optionst&);

  virtual ~wp_interpolatort() { }

protected:
  exprt wp(const symex_target_equationt::SSA_stept&, const exprt&);
};

#endif
