/*******************************************************************\

Module: WP-based interpolator of Wolverine

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include <simplify_expr.h>
#include <goto-programs/wp.h>

#include "../wolver_sat.h"
#include "../wolver_slice.h"
#include "../path_interpolator.h"
#include "../version.h"

#include "wp_interpolator.h"

#define DEBUG

/*******************************************************************\

Function: wp_interpolatort::process_options

  Inputs:

 Outputs:

 Purpose: Processes command-line options

\*******************************************************************/
void wp_interpolatort::process_options(const optionst &options)
{
}


/*******************************************************************\

Function: wp_interpolatort::interpolate

  Inputs:

 Outputs:

 Purpose: Computes interpolants for an infeasible path using the 
          weakest precondition. Intuitively, it computes the
          "safe" states by means of computing the weakest 
          precondition of the assertion.

          Returns decision_proceduret::D_UNSATISFIABLE if
          it successfully computed interpolants,
          decision_proceduret::D_SATISFIABLE if the trace 
          is feasible.

\*******************************************************************/
decision_proceduret::resultt wp_interpolatort::interpolate(
  const goto_program_unwindingt::unwinding_stept &step, 
  const exprt& condition,
  unsigned from_node,
  path_interpolatort::interpolant_mapt& result)
{
  const symex_target_equationt &equation=step.equation;

  exprt expression(condition);
  expression.negate(); // we use the original condition

  goto_program_unwindingt::unwinding_patht path=
    unwinding_graph.path_prefix(step.node);
  goto_program_unwindingt::unwinding_patht::iterator p_it=path.begin();

  unsigned ssa_index=equation.SSA_steps.size();

  for(symex_target_equationt::SSA_stepst::const_reverse_iterator
        r_it=equation.SSA_steps.rbegin();
      !(p_it.get_index()==from_node && ssa_index==p_it->ssa_index);
      ++r_it, --ssa_index)
  {
    while(ssa_index==p_it->ssa_index && p_it.get_index()!=from_node)
    {
      // ideally we should do simplification based on pointer information here!
      simplify(expression, ns);
      result[p_it.get_index()]=expression;

#ifdef DEBUG
      std::cout << "WP-interpolant for " << p_it.get_index() << " is " 
                << from_expr(ns, "", expression) << std::endl;
#endif
      
      // process previous block
      ++p_it;
    }

    if(p_it.get_index()==from_node && ssa_index==p_it->ssa_index)
      break;

    const symex_target_equationt::SSA_stept &step=*r_it;
    exprt precondition=wp(step, expression);
    expression.swap(precondition);
  }

  // now bit-blast the final pre-condition 
  // and check whether it is true (i.e., path is safe)
  simplify(expression, ns);
  if(expression.is_true())
    return decision_proceduret::D_UNSATISFIABLE;

  wolver_satcheckt satcheck(ns);
  satcheck.set_to_false(expression);

  switch(satcheck.dec_solve())
  {
  case decision_proceduret::D_UNSATISFIABLE:
    return decision_proceduret::D_UNSATISFIABLE;
  case decision_proceduret::D_SATISFIABLE:
#ifdef DEBUG
    std::cout << "WP refiner found feasible trace." << std::endl;
#endif
    return decision_proceduret::D_SATISFIABLE;
  default:
    throw "Unexpected error in WP refinement step";
  }
}


/*******************************************************************\

Function: wp_interpolatort::wp

  Inputs:

 Outputs:

 Purpose: Computes the weakest precondition of an SSA step with
          respect to a given post-condition over SSA variables. 
          The result is an expression over SSA variables.

\*******************************************************************/
exprt wp_interpolatort::wp(
  const symex_target_equationt::SSA_stept& step, const exprt& post)
{
  if(step.ignore)
    return post;

  if(step.is_assignment())
  {
    code_assignt code(step.lhs, step.rhs);
    return ::wp(code, post, ns);
  }
  else if(step.is_assert() || step.is_assume())
  {
    code_assumet code;
    code.copy_to_operands(step.cond_expr);
    return ::wp(code, post, ns);
  }

  return post;
}
