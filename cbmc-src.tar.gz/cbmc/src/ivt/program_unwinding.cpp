/*******************************************************************\

Module: Interpolation Based Model Checking for ANSI-C

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name,
        Mark Kattenbelt, mark.kattenbelt@comlab.ox.ac.uk

\*******************************************************************/

#include <sstream>

#include <location.h>
#include <i2string.h>
#include <base_type.h>
#include <simplify_expr.h>

#include <solvers/sat/satcheck.h>
#include <solvers/smt1/smt1_dec.h>
#include <goto-symex/build_goto_trace.h>

#include <wordlevel_interpolator.h>
#include <prop_interpolator.h>

#include "program_unwinding.h"
#include "path_interpolator.h"
#include "wolver_sat.h"
#include "wolver_slice.h"
#include "princess_dec.h"
#include "version.h"

#include "wp/wp_interpolator.h"

#define DEBUG
//#define PRINCESS
//#define SMT1

/*******************************************************************\

Function: goto_program_unwindingt::operator()

  Inputs:

 Outputs:

 Purpose: Unwinds the control flow graph. Returns false if the
          program is safe, true if a counterexample is found.

\*******************************************************************/
bool goto_program_unwindingt::operator()()
{
  // set up initial node
  goto_functionst::function_mapt::const_iterator it=
    goto_functions.function_map.find(ID_main);
  
  if(it==goto_functions.function_map.end())
    throw "main symbol not found; please set an entry point";
  
  const goto_programt &body=it->second.body;
  end_of_instructions=body.instructions.end();
  
  symex_wolvert::statet state;
  state.initialize(goto_functions);

  worklist.push_front(unwinding_stept(state, symex.get_equation()));
  worklist.front().node=unwinding_graph.add_node(worklist.front());

  // start exploring
  unsigned uncovered=1;
 
  do
  {
    unwinding_stept& current_step=worklist.front();

    // avoid unreachable nodes
    if(!reachable(current_step))
    {
      worklist.pop_front();
      uncovered=worklist.size(); // refine may have uncovered nodes
      continue;
    }

    bool covered=false;

    // try to cover nodes
    {
      unwinding_patht path=
        unwinding_graph.path_prefix(current_step.node);

      for(unwinding_patht::iterator p_it=path.begin();
          p_it!=path.end(); ++p_it)
      {
#ifdef DEBUG
        std::cout << " Call close on " << p_it.get_index() << std::endl;
#endif
        if(!close(p_it.get_index()))
        {
          covered=true;
          break;
        }
      }
    }

    if(!covered && !force_cover(current_step))
    {
      worklist.pop_front();
      uncovered=worklist.size(); // force_cover may have uncovered nodes
      continue;
    }

    if(covered)
    {
      worklist.defer_front();
      uncovered--;
    }
    else
    {
      if(expand(current_step))
        return true;
      uncovered=worklist.size();
    }
  } 
  while (uncovered!=0);

#ifdef DEBUG
  std::cout << "Explored " << unwinding_graph.size() << " nodes.\n";
#endif
  success();

  return false;
}

/*******************************************************************\

Function: goto_program_unwindingt::set_interpolator

  Inputs:

 Outputs:

 Purpose: Chooses an interpolating decision procedure

\*******************************************************************/
void goto_program_unwindingt::set_interpolator(
  const std::string& name, const optionst &options)
{
  std::auto_ptr<path_interpolatort> 
    wolver_interpolator(select_interpolator(
                          name, options, unwinding_graph, ns));
  interpolator=wolver_interpolator;
}

/*******************************************************************\

Function: goto_program_unwindingt::initialise_interpolator

  Inputs:

 Outputs:

 Purpose: Calls the initialisation function of the interpolator

\*******************************************************************/
bool goto_program_unwindingt::initialise_interpolator()
{
  return interpolator->initialise();
}

/*******************************************************************\

Function: goto_program_unwindingt::start_logging

  Inputs:

 Outputs:

 Purpose: Start logging the unwinding graph

\*******************************************************************/
bool goto_program_unwindingt::start_logging(
  const std::string& filename)
{
  logfile.open(filename.c_str());
  logging=logfile.is_open();

  logfile << "digraph " << TOOL_NAME <<" {" << std::endl;

  return logging;
}

/*******************************************************************\

Function: goto_program_unwindingt::stop_logging

  Inputs:

 Outputs:

 Purpose: Stop logging

\*******************************************************************/
void goto_program_unwindingt::stop_logging()
{
  if(logging && logfile.is_open())
  {
    for(unsigned index=0; index<unwinding_graph.size(); ++index)
    {
      const unwinding_nodet &node=unwinding_graph[index];
      
      // report the interpolants
      logfile << index << " [shape=box,label=\"" << index << ": "  
              << from_expr(ns, "", node.label)
              << "\"]" << std::endl;

      // print coverings
      std::set<unsigned> covered_nodes=covering.covered_by(index);
      
      for(std::set<unsigned>::const_iterator n_it=covered_nodes.begin();
          n_it!=covered_nodes.end(); ++n_it)
      {
        logfile << (*n_it) << "->" << index 
                << " [style=dotted]" << std::endl;
      }
    }

    logfile << "}" << std::endl;
    logfile.close();
  }
  logging=false;
}

/*******************************************************************\

Function: goto_program_unwindingt::log

  Inputs:

 Outputs:

 Purpose: Log a step in the unwinding tree

\*******************************************************************/
void goto_program_unwindingt::log(
  unsigned n, unsigned m, unwinding_stept &step)
{
  if(!logging)
    return;

  symex_target_equationt &equation=step.equation;
  const unwinding_nodet &previous=unwinding_graph[n];

  std::string transition;

  unsigned ssa_index=equation.SSA_steps.size();

  for(symex_target_equationt::SSA_stepst::const_reverse_iterator
        s_it=equation.SSA_steps.rbegin();
      s_it!=equation.SSA_steps.rend();
      ++s_it, --ssa_index)
  {
    if(ssa_index==previous.ssa_index)
      break;

    const symex_target_equationt::SSA_stept &step=*s_it;
    const goto_programt::const_targett &pc=step.source.pc;

    if(step.is_assert() || step.is_assume() || step.is_assignment())
    {
      exprt condition=step.cond_expr;
      simplify(condition, ns);
      std::stringstream ss;
      ss << pc->location;
      transition=from_expr(ns, "", condition)+" \\\\ "+
        ss.str()+"\\n"+transition;
    }
  }

  logfile << n << "->" << m;
  logfile << " [label=\"" << transition << "\"]" << std::endl;
}

/*******************************************************************\

Function: goto_program_unwindingt::expand()

  Inputs:

 Outputs:

 Purpose: Process the top element of the worklist. Returns true
          if a counterexample is detected, false otherwise

\*******************************************************************/
bool goto_program_unwindingt::expand(
  unwinding_stept &current_step)
{
  symex_wolvert::statet &state=current_step.state;
  symex_target_equationt &equation=current_step.equation;

  const goto_programt::instructiont &instruction=*state.source.pc;

  bool found_counterexample=false;

  std::ostringstream msg;
  msg << "Expanding node " << current_step.node 
      << " at " << instruction.location;
  symex.status(msg.str());

  switch(instruction.type)
  {
  case GOTO:
    expand_goto(current_step);
    break;

  case ASSERT:
    found_counterexample=expand_assert(current_step);
    break;

  case FUNCTION_CALL:
    expand_function_call(current_step);
    break;

  case RETURN:
    expand_return(current_step);
    break;

  default:
  {
    if(symex.symex_step_until(goto_functions, state,
                              end_of_instructions, equation))
    {
      worklist.pop_front(); // reached end of program
      break;
    }
    // create target node
    const unsigned node=current_step.node;
    current_step.node=unwinding_graph.add_node(current_step);
    unwinding_graph.add_edge(node, current_step.node);
    log(node, current_step.node, current_step);
    break;
  }
  }
  
  return found_counterexample;
}

/*******************************************************************\

Function: goto_program_unwindingt::expand_goto()

  Inputs:

 Outputs:

 Purpose: Process the top element of the worklist

\*******************************************************************/
void goto_program_unwindingt::expand_goto(
  unwinding_stept &current_step)
{
  symex_wolvert::statet &state=current_step.state;
  symex_target_equationt &equation=current_step.equation;

  const goto_programt::instructiont &instruction=*state.source.pc;  

  if (instruction.targets.size()!=1)
    throw "no support for non-deterministic gotos";

  goto_programt::const_targett goto_target=
    instruction.targets.front();
  
  bool forward=
    (instruction.location_number<
     goto_target->location_number);

  bool exceeded=false;
  if (!forward)
  {
    unsigned &unwind=++current_step.unwind_map[state.source];
    if(get_unwind(state.source, unwind))
      exceeded=true;
  }

  bool unconditional=instruction.guard.is_true();

  if(exceeded && unconditional)
  {
    // FIXME: refine here and warn user if feasible
    worklist.pop_front();
    return;
  }

  bool taken=(!exceeded && !forward) || unconditional;

  // create a new branching node
  unsigned node=current_step.node;
  unwinding_stept new_step=current_step; // copy

  // process current leaf
  {
    symex.symex_step_goto(state, equation, taken);
    if(taken)
      state.source.pc=goto_target;
    else
      state.source.pc++; 
    current_step.node=
      unwinding_graph.add_node(current_step);
    unwinding_graph.add_edge(node, current_step.node);

    log(node, current_step.node, current_step);
  }

  if(unconditional || exceeded)
    return;

  // create new leaf
  {
    symex.symex_step_goto(new_step.state, new_step.equation, !taken);
    if(taken)
      new_step.state.source.pc++;
    else
    {
      assert(forward); // we favour forward edges
      new_step.state.source.pc=goto_target;
    }

    new_step.node=
      unwinding_graph.add_node(new_step);
    unwinding_graph.add_edge(node, new_step.node);
    worklist.push_front(new_step);

    log(node, new_step.node, new_step);
  }
}

/*******************************************************************\

Function: goto_program_unwindingt::expand_return()

  Inputs:

 Outputs:

 Purpose: Process a return. Treated as unconditional goto to
          the end of the current function.

\*******************************************************************/
void goto_program_unwindingt::expand_return(
  unwinding_stept &current_step)
{
  symex_wolvert::statet &state=current_step.state;
  symex_target_equationt &equation=current_step.equation;
  goto_programt::const_targett &target=state.top().end_of_function;

  symex.symex_step_return(state, equation);

  unsigned node=current_step.node;

  state.source.pc=target;
  current_step.node=unwinding_graph.add_node(current_step);
  unwinding_graph.add_edge(node, current_step.node);

  log(node, current_step.node, current_step);
}

/*******************************************************************\

Function: goto_program_unwindingt::expand_function_call()

  Inputs:

 Outputs:

 Purpose: Process the top element of the worklist

\*******************************************************************/
void goto_program_unwindingt::expand_function_call(
  unwinding_stept &current_step)
{
  symex_wolvert::statet &state=current_step.state;
  symex_target_equationt &equation=current_step.equation;

  const goto_programt::instructiont &instruction=*state.source.pc;  
  irep_idt function_name;

  if (!symex.get_function_name(instruction, state, function_name))
  {
    unsigned &unwind=++current_step.recursion_map[function_name];
  
    if(get_unwind_recursion(function_name, unwind))
    {
      // FIXME: refine here and warn user if feasible
      worklist.pop_front();
      return;
    }
    
    std::ostringstream msg;
    msg << "Processing function call: " << function_name;
    symex.status(msg.str());
  }

  symex.symex_step(goto_functions, state, equation);

// create a new node
  unsigned node=current_step.node;
  current_step.node=unwinding_graph.add_node(current_step);
  unwinding_graph.add_edge(node, current_step.node);

  log(node, current_step.node, current_step);
}

/*******************************************************************\

Function: goto_program_unwindingt::expand_assert()

  Inputs:

 Outputs:

 Purpose: Process the top element of the worklist. Returns true
          if a counterexample is detected, false otherwise.

\*******************************************************************/
bool goto_program_unwindingt::expand_assert(
  unwinding_stept& current_step)
{
  symex_wolvert::statet &state=current_step.state;

  const goto_programt::instructiont &instruction=*state.source.pc;
  assert(instruction.type==ASSERT);

  symex_target_equationt &equation=current_step.equation;

  exprt assertion;
  symex.get_assertion_guard(instruction, state, assertion);
  assertion.negate();
  
  decision_proceduret::resultt result=
    refine(current_step, assertion);

  switch (result)
  {
  case decision_proceduret::D_UNSATISFIABLE: // assertion holds
  {
    symex.symex_step(goto_functions, state, equation);
    // pc was increased in symex_step
    const unsigned node=current_step.node;

    current_step.node=unwinding_graph.add_node(current_step);
    unwinding_graph.add_edge(node, current_step.node);

    log(node, current_step.node, current_step);
    break;
  }
  case decision_proceduret::D_SATISFIABLE:
  case decision_proceduret::D_TAUTOLOGY:
  case decision_proceduret::D_ERROR:
  {
    symex.symex_step(goto_functions, state, equation);
    if(!(--current_step.equation.SSA_steps.end())->is_assert())
      break; // not an assertion? Then we don't care
  
    goto_tracet trace;
    if(!get_counterexample(current_step, trace))
    {
      failure(trace);
      return true; 
    }
    else
    {
      symex.status("Failed to refute infeasible counterexample.");
#ifdef DEBUG
      std::cerr << current_step.equation << std::endl;
#endif
      throw "Failed to refute infeasible counterexample.";
    }
  }
  }
  
  return false;
}

/*******************************************************************\

Function: goto_program_unwindingt::refine

  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/
decision_proceduret::resultt goto_program_unwindingt::refine(
  unwinding_stept &step)
{
  true_exprt tmp;
  return refine(step, tmp);
}


/*******************************************************************\

Function: goto_program_unwindingt::refine

  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/
decision_proceduret::resultt goto_program_unwindingt::refine(
  unwinding_stept &step, exprt& condition, unsigned from_node)
{
  // translate condition into respective time-frame
  step.state.rename(condition, ns);

  if(path_slicing)
    wolver_slice(step.equation, condition);

  path_interpolatort::interpolant_mapt interpolants;
  decision_proceduret::resultt result=
    interpolator->interpolate(step, condition, from_node, interpolants); 

  if(result==decision_proceduret::D_ERROR)
  {
    // give the weakest precondition-based interpolator a chance
    wp_interpolatort wpi(unwinding_graph, ns);
    interpolants.clear();
    result=wpi.interpolate(step, condition, from_node, interpolants);
  }

  if(result==decision_proceduret::D_UNSATISFIABLE)
  {
    for(path_interpolatort::interpolant_mapt::iterator 
          i_it=interpolants.begin();
        i_it!=interpolants.end(); 
        ++i_it)
    {
      unsigned index=i_it->first;
      exprt &ssa_interpolant=i_it->second;
      exprt interpolant(ssa_interpolant);

      // eliminate the reference to the time-frame
      step.state.level2.get_original_name(interpolant);

      unwinding_nodet &node=unwinding_graph[index];

#ifdef DEBUG
      std::cout << "Interpolant for node " << index << " at "
                << node.pc->location << " with " 
                << from_expr(ns, "", node.label) << ": " 
                << from_expr(ns, "", interpolant) << std::endl;
#endif

      if(!check_implication(node.label, interpolant))
      {
        conjoin (interpolant, node.label);
        simplify(node.label, ns);
        conjoin (ssa_interpolant, node.ssa_label);
        simplify(node.ssa_label, ns);
        covering.remove_cover(index);

#ifdef DEBUG
        std::cout << "Strengthening interpolant at " 
                  << node.pc->location << " to " 
                  << from_expr(ns, "", node.label) << std::endl;
#endif
      }
      node.refined=true;
    }
  }

  return result;
}

/*******************************************************************\

Function: goto_program_unwindingt::get_counterexample

  Inputs:

 Outputs:

 Purpose: Returns true and a goto-trace if the given path is 
          feasible. Returns false otherwise.

\*******************************************************************/
bool goto_program_unwindingt::get_counterexample(
  unwinding_stept& unwinding_step, goto_tracet& goto_trace)
{
  symex_target_equationt &equation=unwinding_step.equation;

  unwinding_patht path=unwinding_graph.path_prefix(unwinding_step.node);
  unwinding_patht::iterator p_it=path.begin();

#ifndef SMT1
  wolver_satcheckt checker(ns);
#else
  smt1_dect checker(ns, TOOL_NAME, "generated by " TOOL_NAME, 
                    "QF_AUFBV", smt1_dect::YICES);
#endif

  for(symex_target_equationt::SSA_stepst::iterator
        it=equation.SSA_steps.begin();
      it!=equation.SSA_steps.end();
      ++it)
  {
    symex_target_equationt::SSA_stept &step=*it;
    step.guard_literal=const_literal(true);

    if(step.is_assert() || step.is_assume() || step.is_assignment())
    {
      exprt tmp(step.cond_expr);

      if(step.is_assert() && it == --equation.SSA_steps.end())
      {
        checker.set_to_false(tmp);      
        step.cond_literal=const_literal(false);
      }
      else
      {
        checker.set_to_true(tmp);      
        step.cond_literal=const_literal(true);
      }
    }
  }  
  
  switch(checker.dec_solve())
  {
  case decision_proceduret::D_UNSATISFIABLE:
    break;
    
  case decision_proceduret::D_SATISFIABLE:
    build_goto_trace(equation, checker, goto_trace);
    return false;
    
  default:
    throw "unexpected result from dec_solve()";
  }

  // failed to refute
  return true;
}

/*******************************************************************\

Function: goto_program_unwindingt::collect_invariants

  Inputs:

 Outputs:

 Purpose: Extracts the invariants of the program locations
          occurring in the reachability tree.

\*******************************************************************/
void goto_program_unwindingt::collect_invariants(
  invariant_mapt& invariant_map)
{
  invariant_mapt::iterator i_it;

  for(unsigned index=0; index<unwinding_graph.size(); index++)
  {
    const unwinding_nodet &node=unwinding_graph[index];
    const unsigned location_number=node.pc->location_number;

    i_it=invariant_map.find(location_number);
    if(i_it==invariant_map.end())
    {
      or_exprt disjunction(false_exprt(), node.label);
      invariant_map[location_number]=disjunction;
    }
    else
    {
      (i_it->second).copy_to_operands(node.label);
    }
  }

  for(i_it=invariant_map.begin(); i_it!=invariant_map.end(); ++i_it)
  {
    simplify(i_it->second, ns);
  }
}

/*******************************************************************\

Function: goto_program_unwindingt::show_invariants

  Inputs:

 Outputs:

 Purpose: Shows the invariants of the program locations
          occurring in the reachability tree.

\*******************************************************************/
void goto_program_unwindingt::show_invariants(
  std::ostream& out)
{
  invariant_mapt invariant_map;
  collect_invariants(invariant_map);

  out << "\nINVARIANTS:\n\n";

  forall_goto_functions(f_it, goto_functions)
  {
    if(f_it->second.body_available)
    {
      out << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << std::endl;
      out << std::endl;

      const symbolt &symbol=ns.lookup(f_it->first);
      out << symbol.display_name() << ":" << std::endl;
      
      const goto_programt::instructionst 
        &instructions=f_it->second.body.instructions;
      
      goto_programt::instructionst::const_iterator i_it;

      for(i_it=instructions.begin(); i_it!=instructions.end(); ++i_it)
      {
        invariant_mapt::const_iterator it=
          invariant_map.find(i_it->location_number);

        if(it!=invariant_map.end())
        {
          out << "        // " << it->first << " ";
          if(!i_it->location.is_nil())
            out << i_it->location.as_string();
          else
            out << "no location";
          out << std::endl;
          out << "        " << from_expr(ns, "", it->second);
          out << std::endl << std::endl;
        }
      }
    }
  }
}

/*******************************************************************\

Function: goto_program_unwindingt::close

  Inputs: A node 

 Outputs: 

 Purpose: Updates the coverage. Returns false if it managed to
          find a covering node, true otherwise.

\*******************************************************************/
bool goto_program_unwindingt::close(unsigned index)
{
  if (index==0)
    return true;

  if(covering.covered(index))
    return false;

  const unwinding_nodet &node=unwinding_graph[index];

  preceding_nodest previous_nodes=
    unwinding_graph.preceding_nodes(index);

  for(preceding_nodest::iterator n_it=++previous_nodes.begin();
      n_it!=previous_nodes.end(); ++n_it)
  {
    const unsigned current_index=n_it.get_index();
    const unwinding_nodet &current=*n_it;

    { 
      // not part of the algorithm in McMillan CAV 06
      if(covering.covered(current_index))
        continue; // not sound to use this for covering "index"
    }
    
#ifdef DEBUG
    std::cout << "Check whether " << current_index << " covers " << index << std::endl;
#endif 

    if(check_implication(node.label, current.label))
    {
      // index covered by current
      cover(index, current_index);

#ifdef DEBUG
      std::cout << "Interpolant " << from_expr(ns, "", current.label)
                << " covers " << from_expr(ns, "", node.label)
                << " at " << current.pc->location 
                << " (node " << current_index 
                << " covers " << index << ")" 
                << std::endl;
#endif
      
      return false;
    }
  }
  return true;
}

/*******************************************************************\

Function: goto_program_unwindingt::cover

  Inputs: Two nodes, the former covered by the latter

 Outputs: 

 Purpose: Updates the coverage. Unlike "cover" in McMillan's paper,
          this function doesn't check anymore whether the covering
          actually holds (i.e., the interpolant of covering is
          implied by the interpolant of covered).

\*******************************************************************/
void goto_program_unwindingt::cover(
  unsigned covered_node, unsigned covering_node)
{
  covering.add_cover(covered_node, covering_node);

  // run over all successor nodes and update covering
  subtreet successors=unwinding_graph.subtree(covered_node);
  
  for(subtreet::iterator s_it=successors.begin();
      s_it!=successors.end(); ++s_it)
  {
    covering.remove_cover(s_it.get_index());
  }
}

/*******************************************************************\

Function: goto_program_unwindingt::reachable

  Inputs: An unwinding step

 Outputs: 

 Purpose: Returns true if one of the invariants along
          the path leading to the given node is FALSE.
          Also uses a heuristic to refine paths at certain points.
          Changes the labels of all nodes after the invariant
          FALSE to FALSE.

\*******************************************************************/
bool goto_program_unwindingt::reachable(unwinding_stept& step)
{
  unsigned n=step.node;
  // check whether the node n is dominated by an invariant FALSE
  std::stack<unsigned> visited;
  unwinding_patht path=unwinding_graph.path_prefix(n);

  for (unwinding_patht::iterator p_it=path.begin();
       p_it!=path.end(); ++p_it)
  {
    unwinding_nodet &current_node=*p_it;
    
    if(current_node.label.is_false())
    {
      for(; !visited.empty(); visited.pop())
      {
        unsigned index=visited.top();
        unwinding_graph[index].label.make_false();
        covering.remove_cover(index);
      }
      return false;
    }
    visited.push(p_it.get_index());
  }

  if(step.equation.SSA_steps.size()==0)
    return true;

  // refine path to see whether it's still feasible
  symex_target_equationt::SSA_stept &last_step=
    *(--step.equation.SSA_steps.end());
  if(last_step.is_assume() && 0==(--step.decision_counter))
  {
    step.decision_counter=path_length_threshold;
    decision_proceduret::resultt result=refine(step);
    if(result==decision_proceduret::D_UNSATISFIABLE)
    {
      return false;
    }
  }

  return true;
}

/*******************************************************************\

Function: goto_program_unwindingt::nearest_common_ancestor

  Inputs: Two node indices

 Outputs: 

 Purpose: Returns the nearest common ancestor of two nodes
          in the reachability tree.

\*******************************************************************/
unsigned goto_program_unwindingt::nearest_common_ancestor(
  unsigned a, unsigned b)
{
  unwinding_patht::iterator 
    a_it=unwinding_graph.path_prefix(a).begin(), 
    b_it=unwinding_graph.path_prefix(b).begin();
  
  while(a_it.get_index()!=b_it.get_index())
  {
    if(a_it.get_index()>b_it.get_index())
      ++a_it;
    else
      ++b_it;
  }

  return a_it.get_index();
}

/*******************************************************************\

Function: goto_program_unwindingt::force_cover

  Inputs: A step corresponding to a leaf in the unwinding tree

 Outputs: 

 Purpose: Tries to force a cover by checking whether a previously
          found interpolant holds at the end of the given path.
          Checks "a few recently generated vertices representing
          the same program location".

\*******************************************************************/
bool goto_program_unwindingt::force_cover(unwinding_stept &step)
{
  unsigned counter=0;

  if(force_cover_threshold==0)
    return true;

  preceding_nodest previous_nodes=
    unwinding_graph.preceding_nodes(step.node);

  for(preceding_nodest::iterator n_it=++previous_nodes.begin();
      n_it!=previous_nodes.end(); ++n_it, ++counter)
  {
    if(counter>=force_cover_threshold)
      break;

    const unsigned current_index=n_it.get_index();

    { 
      if(covering.covered(current_index))
        continue; // not sound to use this for covering "index"
    }

    if(!force_cover(step, current_index))
      return false;
  }

  return true;
}

/*******************************************************************\

Function: goto_program_unwindingt::force_cover

  Inputs: A step corresponding to a leaf in the unwinding tree,
          a previously generated node referring to the same 
          program location

 Outputs: 

 Purpose: Tries to force a cover by checking whether the interpolant
          at the previously generated node holds at the end of the 
          given path.

\*******************************************************************/
bool goto_program_unwindingt::force_cover(
  unwinding_stept &step, unsigned node)
{
  assert(!covering.covered(node));
  
  unsigned ancestor=nearest_common_ancestor(step.node, node);

  exprt condition=unwinding_graph[node].label;
  condition.negate();

  decision_proceduret::resultt result=
    refine(step, condition, ancestor);
  
  if(result==decision_proceduret::D_UNSATISFIABLE)
  {
    // step.node is covered by node
    cover(step.node, node);
    
#ifdef DEBUG
    std::cout << "FORCED COVER: " 
              << node << " covers " << step.node << std::endl;
#endif

    return false;
  }
  
  return true;
}
 
/*******************************************************************\

Function: goto_program_unwindingt::check_implication

  Inputs: Two expressions

 Outputs: 

 Purpose: returns true if the first expression implies the second.

\*******************************************************************/
bool goto_program_unwindingt::check_implication(
  const exprt& a, const exprt& b)
{
  if(a.is_false() || b.is_true() || a==b)
    return true;
  
  binary_relation_exprt impl(a, "or", b);
  impl.op0().negate();

  expr_cachet::const_iterator it=implication_cache.find(impl);

  if (it==implication_cache.end())
  {
#ifndef SMT1
#ifdef PRINCESS
    princess_sat_dect checker(ns);
#else
    wolver_satcheckt checker(ns);
#endif
#else
    smt1_dect checker(ns, TOOL_NAME, "generated by " TOOL_NAME,
                      "QF_AUFBV", smt1_dect::YICES);
#endif
    
    checker.set_to_false(impl);
    decision_proceduret::resultt result=checker.dec_solve();

    bool implied=(result==decision_proceduret::D_UNSATISFIABLE);
    implication_cache[impl]=implied;
    return implied; 
  }
  else
    return it->second;
}


/*******************************************************************\

Function: goto_program_unwindingt::conjoin

  Inputs: Two boolean expressions

 Outputs: The conjunction of the two expressions 

 Purpose: The result is stored in the second parameter, 
          the expression handed over as first parameter is invalid
          after the call.

\*******************************************************************/
void goto_program_unwindingt::conjoin(exprt &source, exprt &target)
{
  if(target.is_true() || target.is_nil())
    target.swap(source);
  else if(target.id()=="and")
    target.move_to_operands(source);
  else
  {
    and_exprt tmp(target, source);
    target.swap(tmp);
  }
}

/*******************************************************************\

Function: ...::unwinding_patht::iterator::operator++

  Inputs:

 Outputs:

 Purpose: Increments path iterator

\*******************************************************************/
goto_program_unwindingt::unwinding_patht::iterator&
goto_program_unwindingt::unwinding_patht::iterator::operator++()
{
  if(!invalid)
  {
    unwinding_nodet &current_node=unwinding_graph[index];

    if(index!=0)
    {
      const graph<unwinding_nodet>::edgest &in=current_node.in;
      assert (in.size()==1);
      index=(in.begin())->first;
    }
    else
      invalid=true;
  }
  return (*this);
} 

/*******************************************************************\

Function: ...::preceding_nodest::iterator::operator++

  Inputs:

 Outputs:

 Purpose: Increments preceding nodes iterator

\*******************************************************************/
goto_program_unwindingt::preceding_nodest::iterator&
goto_program_unwindingt::preceding_nodest::iterator::operator++()
{
  if(!invalid)
  {
    unwinding_nodet &current_node=unwinding_graph[index];
    if (current_node.previous==index)
      invalid=true;
    else
      index=current_node.previous;
  }
  return (*this);
} 

/*******************************************************************\

Function: ...::subtree::iterator::operator++

  Inputs:

 Outputs:

 Purpose: Increments subtree iterator

\*******************************************************************/
goto_program_unwindingt::subtreet::iterator&
goto_program_unwindingt::subtreet::iterator::operator++()
{
  if(!invalid)
  {
    assert(index==queue.top());
    queue.pop();

    // push successors on the stack
    unwinding_nodet &current_node=unwinding_graph[index];
    for(unwinding_grapht::edgest::const_iterator o_it=
          current_node.out.begin(); 
        o_it!=current_node.out.end(); o_it++)
      queue.push(o_it->first);

    // advance to next element
    if(queue.empty())
      invalid=true;
    else
      index=queue.top();
  }
  return (*this);
}

/*******************************************************************\

Function: program_unwindingt::unwinding_grapht::graph_locationt

  Inputs: An unwinding step

 Outputs:

 Purpose: Constructor

\*******************************************************************/
goto_program_unwindingt::unwinding_grapht::graph_locationt::graph_locationt(
  const unwinding_stept &step)
{
  const goto_programt::const_targett &pc=step.state.source.pc;
  location_number=pc->location_number;

  const goto_symext::statet::call_stackt &stack=step.state.call_stack;

  for(goto_symex_statet::call_stackt::const_iterator s_it=stack.begin();
      s_it!=stack.end(); ++s_it)
  {
    const goto_symex_statet::framet &frame=*s_it;
    calling_context.push_back(frame.calling_location.pc->location_number);
  }
}

/*******************************************************************\

Function: program_unwindingt::unwinding_graph::ordert::operator()

  Inputs: Two locations in an unwinding graph

 Outputs: 

 Purpose: Imposes an order between two locations in an 
          unwinding graph

\*******************************************************************/
bool goto_program_unwindingt::unwinding_grapht::ordert::operator()
  (const graph_locationt& first, const graph_locationt& second) const
{
  if(first.location_number!=second.location_number)
    return (first.location_number<second.location_number);
  
  if(first.calling_context.size()!=second.calling_context.size())
    return (first.calling_context.size()<
            second.calling_context.size());

  std::list<unsigned>::const_iterator f_it=
    first.calling_context.begin();
  std::list<unsigned>::const_iterator s_it=
    second.calling_context.begin();

  for(; f_it!=first.calling_context.end(); ++f_it, ++s_it)
  {
    if(*f_it!=*s_it)
      return ((*f_it)<(*s_it));
  }

  // the locations are equal
  return false;
}

/*******************************************************************\

Function: program_unwindingt::unwinding_grapht::add_node

  Inputs:

 Outputs:

 Purpose: adds a node to the unwinding graph

\*******************************************************************/
unsigned goto_program_unwindingt::unwinding_grapht::add_node(
  unwinding_stept &step)
{
  goto_programt::const_targett &pc=step.state.source.pc;
  graph_locationt location(step);

  unsigned n=
    graph<goto_program_unwindingt::unwinding_nodet>::add_node();
  unwinding_nodet &node=nodes[n];
  node.pc=pc;
  node.ssa_index=step.equation.SSA_steps.size();

#ifdef DEBUG
  std::cout << "Adding node " << n << " for location " 
            << pc->location << std::endl;
#endif

  predecessor_mapt::const_iterator pre=predecessor_map.find(location);
  if(pre!=predecessor_map.end())
    node.previous=pre->second;
  else
    node.previous=n;

  predecessor_map[location]=n;
  return n;
}

/*******************************************************************\

Function: program_program_unwindingt::coveringt::add_cover

  Inputs: A covered node and a covering node

 Outputs:

 Purpose: adds a covering 

\*******************************************************************/
void goto_program_unwindingt::coveringt::add_cover(
  unsigned covered_node, unsigned covering_node)
{
  unwinding_nodet &node=graph[covered_node];
  node.covered=true;
  
  covering_nodes.insert(
    std::pair<unsigned, unsigned>(covering_node, covered_node));
}

/*******************************************************************\

Function: program_program_unwindingt::coveringt::remove_cover

  Inputs: A covering node

 Outputs:

 Purpose: removes a covering.

\*******************************************************************/
void goto_program_unwindingt::coveringt::remove_cover(
  unsigned covering)
{
  const std::pair<covering_itt, covering_itt> range=
    covering_nodes.equal_range(covering);
  
  for(covering_itt it=range.first; it!=range.second; ++it)
  {
    const unsigned &covered=it->second;
    unwinding_nodet &node=graph[covered];
    
#ifdef DEBUG
    if(node.covered)
      std::cout << "Uncovering node " << covered << std::endl;
#endif
    node.covered=false;

  }
  
  covering_nodes.erase(range.first, range.second);
}

/*******************************************************************\

Function: program_program_unwindingt::coveringt::covered

  Inputs: A node n

 Outputs:

 Purpose: returns true if n is covered (also by means of 
          being a successor of a covered node)

\*******************************************************************/
bool goto_program_unwindingt::coveringt::covered(unsigned n)
{
  unwinding_patht path=graph.path_prefix(n);

  for (unwinding_patht::iterator p_it=path.begin();
       p_it!=path.end(); ++p_it)
  {
    unwinding_nodet &current_node=*p_it;
    
    if(current_node.covered)
      return true;
  }
  return false;
}

/*******************************************************************\

Function: program_program_unwindingt::coveringt::covered_by

  Inputs: A node n

 Outputs:

 Purpose: returns a set of nodes covered by the given node n.
          This is mainly used for logging.

\*******************************************************************/
std::set<unsigned> goto_program_unwindingt::coveringt::covered_by(
  unsigned n)
{
  std::set<unsigned> result;

  const std::pair<covering_itt, covering_itt> range=
    covering_nodes.equal_range(n);
  
  for(covering_itt it=range.first; it!=range.second; ++it)
  {
    result.insert(it->second);
  }

  return result;
}

/*******************************************************************\

Function: goto_program_unwindingt::get_unwind

  Inputs:

 Outputs:

 Purpose: Returns true if the loop bound is exceeded

\*******************************************************************/

bool goto_program_unwindingt::get_unwind(
  const symex_targett::sourcet &source,
  unsigned unwind)
{
  unsigned id=source.pc->loop_number;
  unsigned long this_loop_max_unwind=max_unwind;

  if(unwind_set.count(id)!=0)
    this_loop_max_unwind=unwind_set[id];

  #if 1
  {
    std::string msg=
      "Unwinding loop "+i2string(id)+" iteration "+i2string(unwind)+
      " "+source.pc->location.as_string();
    std::cout << msg << std::endl;;
  }
  #endif

  return this_loop_max_unwind!=0 &&
         unwind>=this_loop_max_unwind;
}

/*******************************************************************\

Function: goto_program_unwindingt::get_unwind_recursion

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool goto_program_unwindingt::get_unwind_recursion(
  const irep_idt &identifier,
  unsigned unwind)
{
  unsigned long this_loop_max_unwind=max_unwind;

  #if 0
  if(unwind!=0)
  {
    const symbolt &symbol=ns.lookup(identifier);
  
    std::string msg=
      "Unwinding recursion "+
      id2string(symbol.display_name())+
      " iteration "+i2string(unwind);
      
    if(this_loop_max_unwind!=0)
      msg+=" ("+i2string(this_loop_max_unwind)+" max)";

    std::cout << msg << std::endl;
  }
  #endif

  return this_loop_max_unwind!=0 &&
         unwind>=this_loop_max_unwind;
}
