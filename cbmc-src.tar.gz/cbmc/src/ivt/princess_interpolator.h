/*******************************************************************\

Module: Interpolator interface

Author: Philipp Ruemmer, philipp.ruemmer@comlab.ox.ac.uk
        Georg Weissenbacher, georg@weissenbacher.name


\*******************************************************************/

#ifndef CPROVER_PRINCESS_INTERPOLATOR_H
#define CPROVER_PRINCESS_INTERPOLATOR_H

#include <sys/types.h>
#ifdef _MSC_VER
#include <io.h>
#else
#include <unistd.h>
#endif

#include "path_interpolator.h"
#include "piped_process.h"
#include "princess_dec.h"

/*******************************************************************\

  Class:   princess_interpolatort

  Purpose: Uses the Princess prover for the interpolation

\*******************************************************************/

class princess_interpolatort:
  public wolver_interpolatort,
  public princess_instancet
{
public:
  princess_interpolatort(
    goto_program_unwindingt::unwinding_grapht &_graph,
    const namespacet &_ns):
      wolver_interpolatort(_graph, _ns),
      callCount(0), satCount(0), interpolantCount(0) { }

  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&, 
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&);

  virtual ~princess_interpolatort() { }

private:
  unsigned int callCount, satCount, interpolantCount;
};

#endif
