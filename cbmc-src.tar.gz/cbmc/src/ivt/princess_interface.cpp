/*******************************************************************\

Module: Interface to the Princess tool for interpolation in
        Presburger arithmetic

Author: Philipp Ruemmer, ph_r@gmx.net
        Angelo Brillout, bangelo@inf.ethz.ch

\*******************************************************************/

#include <sstream>
#include <map>
#include <cmath>

#include <config.h>
#include <simplify_expr.h>
#include <arith_tools.h>
#include <solvers/flattening/boolbv.h>
#include <solvers/flattening/boolbv_width.h>
#include <i2string.h>
#include <pointer_offset_size.h>

#include <wordlevel_interpolator.h>

#include "princess_interface.h"
#include "path_interpolator.h"
#include "version.h"

//#define DEBUG

using namespace std;


/* ************************************************************************** */

/**
 * Bit-width of arithmetic operators is now specified in max-int-format; e.g.,
 * signed 32-bit addition is "addSigned(2*1024*1024*1024, x, y)"
 */
string width2base(unsigned int width) {
  assert(width > 0);
  --width;

  ostringstream str;

  while (width >= 10) {
    str << "1024*";
    width -= 10;
  }

  str << (1 << width);

  return str.str();
}


/* ************************************************************************** */


void PrincessLineariser::printVariableRanges() {
  if(symbolsFromLin.empty()) {
    out << "true";
    return;
  }

  bool first_range_printed = false;
  for(PrincessLineariser::SymInfoMap::iterator it = symbolsFromLin.begin();
      it != symbolsFromLin.end();
      ++it) {
    SymInfo info = it->second;

    if(info.type.id()=="struct") continue;
    if(first_range_printed) out << " & " << endl;

    if (info.type.id() == "array") {
      if(info.initializeExpr.is_not_nil()) {
        mp_integer array_size;
        bool infinite_size=to_integer(to_array_type(info.type).size(), array_size);

        if(!infinite_size) {
          out << "\\forall int i; ((0 <= i & i < " << array_size.to_long() << ") -> ";
          out << "select(" << info.linearisedName << ",i)=";
          lineariseExpr(info.initializeExpr, false);
          out << ")";
        } else out << "true";
      } else
        out << "inArray(" << info.linearisedName << ")";
    } else {
      if(info.type.id()=="unsignedbv" || info.type.id()=="bool")
        out << "inUnsigned";
      else
        out << "inSigned";
      out << "(" << width2base(safe_width(info.type)) << ", ";
      out << info.linearisedName << ")";
    }
    first_range_printed = true;
  }

  if(!first_range_printed) out << "true" << endl;
}

void PrincessLineariser::printPartHeader(unsigned int i) {
  out << "\\part[p" << setfill('0') << setw(4) << i << "] ";
}

void PrincessLineariser::printVariableDecls() {
  if(symbolsFromLin.empty()) return;
  out << "\\functions {\nint ";
  string sep = "";
  for(PrincessLineariser::SymInfoMap::iterator it = symbolsFromLin.begin();
      it != symbolsFromLin.end();
      ++it) {
    out << sep << it->second.linearisedName;
    sep = ", ";
  }
  out << ";\n}\n";
}

unsigned PrincessLineariser::safe_width(const exprt &e) {
  return safe_width(ns.follow(e.type()));
}

unsigned PrincessLineariser::safe_width(const typet &type) {
  if(type.id()=="pointer" || type.id()=="reference")
    return config.ansi_c.pointer_width;

        boolbv_widtht boolbv_width(ns);
        return boolbv_width(type);
}

void PrincessLineariser::lineariseSym(const exprt& e, const exprt& initializer) {
  const string oriName = e.get("identifier").as_string();
  assert(oriName!="");
  const map<string, SymInfo>::iterator pos = symbolsFromOri.find(oriName);

  if (pos == symbolsFromOri.end()) {
    const string linName = string("sym") + i2string(symbolsFromOri.size());
    SymInfo info(oriName, linName, currentTransitionRelationNum, e.type(), initializer);
    symbolsFromLin.insert(pair<string, SymInfo>(linName, info));
    symbolsFromOri.insert(pair<string, SymInfo>(oriName, info));
    out << linName;

  } else {
    out << pos->second.linearisedName;
  }
}

void PrincessLineariser::lineariseUndefSymbol(const typet& type, bool bool_context) {
  const string name = string("undef") + i2string(undefVariableCounter);
  undefVariableCounter++;

  SymInfo info ("", name, currentTransitionRelationNum, type);
  symbolsFromLin.insert(pair<string, SymInfo>(name, info));

  out << name;
  if (bool_context)
    out << "=1";
}

void PrincessLineariser::lineariseExpr(const exprt &e, bool bool_context = false) {
  assert(!e.is_nil());
  if(e.id()=="symbol") {

    lineariseSym(e);
    if (bool_context)
      out << "=1";

  } else if(e.id()=="constant") {

    if (e.type().id() == "bool") {

      if (bool_context)
        out << e.get_string("value");
      else
        out << (e.get_string("value") == "false" ? 0 : 1);

    } else {

      mp_integer mi;
      to_integer(e, mi);

      if(bool_context) {
        if(mi==0)
          out << "false";
        else
          out << "true";
      } else {
        out << integer2string(mi);
      }

    }

  } else if(e.id()=="=" || e.id()=="notequal" ||
          e.id()=="<" || e.id()==">" || e.id()=="<=" || e.id()==">=") {

    assert(e.operands().size()==2);
    string op = e.id() == "notequal" ? "!=" : e.id_string();

    if (bool_context) {

      out << "(";
      lineariseExpr(e.op0());
      out << op;
      lineariseExpr(e.op1());
      out << ")";

    } else {
      if (op == "=" || op == "!=") {

        if (op=="!=") out << "bitNegU1(";
        out << "equals(";
        lineariseExpr(e.op0());
        out << ", ";
        lineariseExpr(e.op1());
        out << ")";
        if (op=="!=") out << ")";

      } else if(op == "<=" || op==">") {

        if (op==">") out << "bitNegU1(";
        out << "lessEqual(";
        lineariseExpr(e.op0());
        out << ", ";
        lineariseExpr(e.op1());
        out << ")";
        if (op==">") out << ")";

      } else if(op == "<" || op==">=") {

        if (op==">=") out << "bitNegU1(";
        out << "lessThan(";
        lineariseExpr(e.op0());
        out << ", ";
        lineariseExpr(e.op1());
        out << ")";
        if (op==">=") out << ")";

      } else
        throw (string("Missing Arith-1 Function: ") + op);
    }

  } else if(e.id()=="not") {

    assert(e.operands().size()==1);
    const unsigned w=safe_width(e);


    if (bool_context) {

      out << "!";

    } else {

      out << "bitNeg";

      if(e.type().id()=="unsignedbv" || e.type().id()=="bool")
        out << "U";

      out << width2base(w);

    }

    out << "(";
    lineariseExpr(e.op0(), bool_context);
    out << ")";

  } else if(e.id()=="and" || e.id()=="or") {

    assert(e.operands().size()>=2);
    assert(bool_context);

    const bool isAnd = e.id()=="and";

    out << "(";
    string sep = "";

    forall_operands(it, e) {
      out << sep;

      if (isAnd)
        sep = " & ";
      else
        sep = " | ";

      lineariseExpr(*it, true);
    }

    out << ")";

  } else if(e.id()=="+" || e.id()=="-" || e.id()=="*" ||
            e.id()=="/" || e.id()=="mod" ||
            e.id()=="bitand" || e.id()=="bitor" || e.id()=="bitxor") {

    assert(e.operands().size()>=2);
    assert(!bool_context);

    unsigned w = safe_width(e);
    std::string op = e.id()=="+"      ? "add" :
                 e.id()=="-"      ? "sub" :
                 e.id()=="*"      ? "mul" :
                 e.id()=="/"      ? "div" :
                 e.id()=="mod"    ? "mod" :
                 e.id()=="bitand" ? "and" :
                 e.id()=="bitor"  ? "or"  :
                 "xor";

    if(op=="add" || op=="sub" || op=="mul" || op=="div") {
      if(e.type().id()=="unsignedbv" || e.type().id()=="bool")
        op += "Unsigned";
      else
        op += "Signed";

      //width dependent operations
      op += "(";
      op += width2base(w);
      op += ", ";
    } else op += "(";

    // if commutative, sort the operands so that constant terms occur last
    // (this is advantageous for the used axiomatisation of bitvector operations)

    vector<exprt> ops;
    if (e.id()=="+" || e.id()=="*" ||
        e.id()=="bitand" || e.id()=="bitor" || e.id()=="bitxor") {
        forall_operands(it, e) {
          if (it->id() != "constant")
            ops.push_back(*it);
        }
        forall_operands(it, e) {
          if (it->id() == "constant")
            ops.push_back(*it);
        }
    } else {
        forall_operands(it, e)
          ops.push_back(*it);
    }

    for (unsigned int i = 1; i < ops.size(); ++i)
      out << op;

    vector<exprt>::const_iterator it = ops.begin();
    lineariseExpr(*it);

    ++it;
    while (it != ops.end()) {
      out << ", ";
      lineariseExpr(*it);
      out << ")";
      ++it;
    }

  } else if(e.id()=="with" &&
           (e.type().id()=="array" || e.type().id()=="mathint")) {
    // array type mathint means that the array variable has been quantified
    assert(e.operands().size()==3);
    const exprt &old_array=e.operands()[0];
    const exprt &index=e.operands()[1];
    const exprt &value=e.operands()[2];

    // array type mathint means that the array variable has been quantified:
    if(e.type().id()=="mathint")
      assert(old_array.type().id()=="mathint" && old_array.id()=="boundVar");

    out << "store(";
    lineariseExpr(old_array);
    out << ",";
    lineariseExpr(index);
    out << ",";
    lineariseExpr(value);
    out << ")";

  } else if(e.id()=="index") {

    assert(e.operands().size()==2);

    const exprt &array=e.op0();
    const exprt &index=e.op1();

    out << "select(";
    lineariseExpr(array);
    out << ",";
    lineariseExpr(index);
    out << ")";

    if(e.type().id()==ID_bool) out << "!=0";

  } else if(e.id()=="with" && e.type().id()=="struct") {

    const with_exprt with_struct = to_with_expr(e);

    const exprt &old_struct = with_struct.old();
    const exprt &member_name=with_struct.where();
    const exprt &value=with_struct.new_value();

    assert(old_struct.type()==with_struct.type());

    const struct_typet struct_type = to_struct_type(old_struct.type());

    const unsigned component_number =
        struct_type.component_number(member_name.get("component_name"));

    out << "store(";
    lineariseExpr(old_struct);
    out << "," << component_number << ",";
    lineariseExpr(value);
    out << ")";

  } else if(e.id()=="member") {

    const member_exprt &struct_member = to_member_expr(e);
    const exprt &from_struct = struct_member.struct_op();

    const struct_typet struct_type = to_struct_type(from_struct.type());

    const unsigned component_number =
        struct_type.component_number(struct_member.get_component_name());

    out << "select(";
    lineariseExpr(from_struct);
    out << "," << component_number << ")";

  } else if(e.id()==ID_pointer_offset) {

    // not clear whath this operator is supposed to express, as expressions like
    //   ar@1#0[(4 * i@1#1 + POINTER_OFFSET(ar@1#1)) / 4]
    // tend to occur. just assume that it is 0 for the time being
    out << "0";

  } else if(e.id()==ID_address_of) {
    assert(e.operands().size()==1);
    if(e.op0().id()==ID_symbol)
      out << pointer_logic.add_object(e.op0()); //this does not include the offset yet
    else if(e.op0().id()==ID_index) {
      assert(e.op0().operands().size()==2);

      const index_exprt &index_expr=to_index_expr(e.op0());
      const exprt &array=index_expr.array();
      const typet &array_type=ns.follow(array.type());

      if(array_type.id()==ID_array && array.id()==ID_symbol)
        out << pointer_logic.add_object(e.op0()); //this does not include the offset yet

    } else
      cerr << "Warning: ignored address_of: " << endl << e.pretty(0) << endl;
  } else if(e.id()=="nondet_symbol" || e.id()=="boundVar") {
    lineariseSym(e);
  } else if(e.id()=="array_of") {

    assert(e.operands().size()==1);
    assert(e.type().id()=="array");

    symbol_exprt array_of_sym("__PRINCESS_array_of"+i2string(arrayOfCounter), e.type());
    arrayOfCounter++;
    lineariseSym(array_of_sym, e.op0());

  } else if(e.id()=="exists" || e.id()=="forall") {

    std::string quan = e.id()=="exists"? "\\exists " : "\\forall ";

    out << quan;

    const exprt::operandst& quanVars = e.find_expr("qvars").operands();

    assert(e.operands().size()==1 && quanVars.size()>0);
    const exprt& formula = e.operands()[0];

    for(exprt::operandst::const_iterator iter = quanVars.begin();
        iter != quanVars.end(); iter++)
    {
      assert(iter->type().id()=="mathint");
      if(iter == quanVars.begin()) out << "int "; else out << ", ";
      lineariseSym(*iter);
    }
    out << "; ";
    lineariseFormula(formula);

  } else if(e.id()=="lshr" || e.id()=="ashr") {
    // for presburger arithmetic logical and arithmetic shifts are the same

    assert(e.operands().size()==2);
    out << "shiftRight(";
    lineariseExpr(e.op0());
    out << ",";
    lineariseExpr(e.op1());
    out << ")";

  } else if(e.id()=="shl") {

    assert(e.operands().size()==2);
    out << "shiftLeft(";
    lineariseExpr(e.op0());
    out << ",";
    lineariseExpr(e.op1());
    out << ")";

  } else if(e.id()=="unary-") {

    assert(e.operands().size()==1);

    unsigned w = safe_width(e);
    out << "minus";
    if(e.type().id()=="unsignedbv" || e.type().id()=="bool")
      out << "Unsigned";
    else
      out << "Signed";

    out << "(" << width2base(w) << ", ";
    lineariseExpr(e.op0());
    out << ")";

  } else if(e.id()=="typecast") {

    assert(e.operands().size()==1);
    boolbv_widtht boolbv_width(ns);

    if((e.type().id()=="unsignedbv" || e.type().id()=="signedbv")
      &&(e.op0().id()=="symbol" || e.op0().id()=="boundVar")
      && boolbv_width(e.type()) >= boolbv_width(e.op0().type()))
      lineariseExpr(e.op0());
    else if(e.type().id()=="signedbv" && e.op0().type().id()=="unsignedbv")
      lineariseExpr(e.op0()); //width changes are already taken care of by the range predicates
    else if(e.type().id()=="unsignedbv" && e.op0().type().id()=="signedbv" &&
            boolbv_width(e.type())>=boolbv_width(e.op0().type())) {
      out << "signed2unsigned(" << boolbv_width(e.type()) << ",";
      lineariseExpr(e.op0());
      out << ")";
    } else if(e.type().id()==e.op0().type().id()) //width changes are already taken care of by the range predicates
      lineariseExpr(e.op0());
    else {
      cerr << "Warning: ignored typecast: " << endl << e.pretty(0) << endl;
      lineariseUndefSymbol(e.type(), bool_context);
    }

  } else if(e.id()=="abs") {
    assert(e.operands().size()==1);

    out << "abs(";
    lineariseExpr(e.op0());
    out << ")";

  } else if(e.id()=="width") {

    assert(e.operands().size()==1);
    boolbv_widtht boolbv_width(ns);

    unsigned op_width = boolbv_width(e.op0().type());
    assert(op_width!=0);

    out << op_width;

  } else {
    cerr << "Unhandled operator: " << e.id_string() << endl;
    cerr << e.pretty(0) << endl;
    lineariseUndefSymbol(e.type(), bool_context);
  }
}

////////////////////////////////////////////////////////////////////////////////

exprt PrincessFormulaParser::parseFormula(int polarity) {
  assert(hasNextToken);

  expect("(");
  exprt res;

  const string op = nextToken;
  computeNextToken();
  if (op == "true" || op == "false") {
    res.id("constant");
    res.set("value", op);
  } else if (op == "=" || op == "<=" || op == ">=") {
    // some expressions might not be translatable ... in this
    // case we currently just replace the subformula with true/false
    bool untranslatable = false;

    const exprt left = parseTerm(untranslatable);
    const exprt right = parseTerm(untranslatable);

    if (untranslatable) {
      res.id("constant");
      res.set("value", polarity > 0 ? "false" : "true");
    } else {
      res.id(op);
      res.copy_to_operands(left, right);
    }
  } else if (op == "&" || op == "|") {
    const exprt left = parseFormula(polarity);
    const exprt right = parseFormula(polarity);

    res.id(op == "&" ? "and" : "or");
    res.copy_to_operands(left, right);
  } else if (op == "!") {
    const exprt sub = parseFormula(-polarity);

    res.id("not");
    res.copy_to_operands(sub);
  } else if(op == "exists" || op == "forall") {
    (op == "exists")? res.id("exists") : res.id("forall");

    exprt& qv = res.add_expr("qvars");
    qv.id("qvars");

    quanStack.push(Quans());
    const exprt formula = parseFormula(polarity);

    for(Quans::const_iterator iter = quanStack.top().begin();
        iter != quanStack.top().end();
        iter++)
      qv.copy_to_operands(*iter);

    quanStack.pop();

    res.copy_to_operands(formula);
  } else {
    throw (string("Unknown boolean operator: ") + op);
  }

  res.set("type", "bool");

  expect(")");
  return res;
}

exprt PrincessFormulaParser::parseTerm(bool& untranslatable) {
  assert(hasNextToken);

  expect("(");
  exprt res;

  const string op = nextToken;
  computeNextToken();
  if (op == "+" || op == "*") {
    res.id(op);
    res.copy_to_operands(parseTerm(untranslatable));

    while (nextToken == "(")
      res.copy_to_operands(parseTerm(untranslatable));

  } else if (op == "sym") {
    res.id("symbol");

    PrincessLineariser::SymInfoMap::const_iterator pos =
      vocabulary.find(nextToken);
    if (pos == vocabulary.end())
      throw (string("Expected an identifier, but received ") + nextToken);

    res.set("identifier", pos->second.originalName);
    res.set("type", pos->second.type);

    computeNextToken();
  } else if (op == "lit") {
    res.id("constant");

    // the next token is an integer (not the binary representation)
    res.set("value", nextToken);

    computeNextToken();
  } else if (op == "boundVar") {

    res.id("boundVar");
    res.set("identifier", nextToken);

    //boundVar are mathematical integers
    res.set("type", "mathint");

    quanStack.top().insert(res);

    computeNextToken();

  } else if (op == "store") {
    // store is also used to represent structs so we need to differentiate

    res.id("with");
    res.copy_to_operands(parseTerm(untranslatable)); //old array or struct
    res.copy_to_operands(parseTerm(untranslatable)); //index or member number
    assert(res.op0().id()=="symbol");

    if(res.op0().type().id()=="struct") {
      // member number has to be replaced with its name

      // member number must be a constant
      mp_integer member_number;
      const constant_exprt &const_expr = to_constant_expr(res.op1());
      to_integer(const_expr, member_number);

      const struct_typet &struct_type = to_struct_type(res.op0().type());
      res.op1().id("member_name");
      res.op1().set("component_name", struct_type.components()[integer2long(member_number)].get_name());
    }

    res.copy_to_operands(parseTerm(untranslatable)); // value

    res.type()=res.op0().type();

  } else if (op == "select") {
    // store is also used to represent structs so we need to differentiate

    res.copy_to_operands(parseTerm(untranslatable)); // array or struct

    if (res.op0().type().id() == "") {
      // TODO: for now we assume that this select is for an array and not a struct.
      // this of course is not always the case but there is no obvious solution for now
      res.id("index");
      res.copy_to_operands(parseTerm(untranslatable)); // index      
      untranslatable = true;
    } else if(res.op0().type().id()=="mathint") {
      //array has been quantified
      res.id("index");
      res.copy_to_operands(parseTerm(untranslatable)); // index
      res.type()=res.op0().type();

    } else if(res.op0().type().id()=="struct") {
      res.id("member");

      // parsing member number which must be a constant
      const constant_exprt const_expr = to_constant_expr(parseTerm(untranslatable));
      mp_integer member_number = string2integer(const_expr.get_string("value"));

      const struct_typet &struct_type = to_struct_type(res.op0().type());
      struct_union_typet::componentt component =
          struct_type.components()[integer2long(member_number)];
      res.set("component_name", component.get_name());

      assert(component.type().id()!="");
      res.type()=component.type();

    } else {
      res.id("index");
      res.copy_to_operands(parseTerm(untranslatable)); // index
      assert(res.op0().type().subtype().id()!="");
      res.type()=res.op0().type().subtype();
    }

  } else {
    throw (string("Unknown operator: ") + op);
  }

  expect(")");
  return res;
}

void PrincessFormulaParser::expect(const string& token) {
  if (nextToken != token)
    throw (string("Expected ") + token + " but received " + nextToken);
  computeNextToken();
}

void PrincessFormulaParser::consumeWhiteSpaces() {
  while (currentPos < charSeq.size() && charSeq[currentPos] == ' ')
    ++currentPos;
}

void PrincessFormulaParser::computeNextToken() {
  consumeWhiteSpaces();

  if (currentPos == charSeq.size()) {
    hasNextToken = false;
    nextToken = "EOF";
    return;
  }

  hasNextToken = true;

  switch (charSeq[currentPos]) {
  case '(': case ')':
    nextToken = charSeq[currentPos];
    ++currentPos;
    break;

  default:
    nextToken = "";
    do {
      nextToken += charSeq[currentPos];
      ++currentPos;
    } while (charSeq[currentPos] != '(' &&
         charSeq[currentPos] != ')' &&
         charSeq[currentPos] != ' ');
    break;
  }
}

////////////////////////////////////////////////////////////////////////////////

void TypeAdjuster::adjust(exprt& e, typet& expectedType, unsigned additionalWidth)
{
  if(e.id()=="+" || e.id()=="-" || e.id()=="*")
  {
    assert(e.operands().size()>1);

    //if unclear find out the expected operation type
    unsigned nb_operands=e.operands().size();
    if(expectedType.id()=="")
    {
      for(unsigned i=0; i<nb_operands; i++)
        if(e.operands()[i].type().id()!="")
        {
          expectedType=e.operands()[i].type();
          break;
        }
    }

    for(unsigned i=0; i<nb_operands; i++)
      adjust(e.operands()[i], expectedType, additionalWidth);

    //setting the new type
    e.type()=e.operands()[0].type();

  }
  else if(e.id()=="symbol" || e.id()=="boundVar")
  {
    assert(e.type().id()!="");
    if(additionalWidth!=0)
    {
      //we need to copy the type since we don't know who is pointing to it
      typet newType = e.type();
      setNewWidth(newType, additionalWidth);

      exprt symbol = e;
      e.clear();
      e=typecast_exprt(newType);
      e.op0()=symbol;

    }
  }
  else if(e.id()=="constant")
  {
    assert(expectedType.id()!="");

    //set the correct type
    if(additionalWidth!=0)
    {
      //we need to copy the type since we don't know who is pointing to it
      typet newType = expectedType;
      setNewWidth(newType, additionalWidth);
      e.type()=newType;
    }
    else if(e.type().id()=="")
      e.type()=expectedType;

    //adjust the value
    if(e.type().id()!="bool")
      e.set("value", from_integer(e.get_int("value"), e.type()).get("value"));
  }
  else if (e.id() == "=" || e.id() == "<=" ||
           e.id() == ">=" || e.id() == "and" || e.id()==  "or")
  {
    assert(e.type()==expectedType);
    assert(e.operands().size()==2 && e.type().id()=="bool");
    assert(additionalWidth==0);

    typet& expectedOperandsType=
        (e.op0().type().id()!="") ? e.op0().type() : e.op1().type();

    unsigned newAdditionalWidth=
        max(getAdditionalWidth(e.op0()), getAdditionalWidth(e.op1()));

    adjust(e.op0(), expectedOperandsType, newAdditionalWidth);
    adjust(e.op1(), expectedOperandsType, newAdditionalWidth);

  }
  else if(e.id()=="exists" || e.id() =="forall" || e.id()=="not")
  {
    assert(e.operands().size()==1);
    adjust(e.op0(), e.op0().type(), additionalWidth);
    //here the width should change
  }
  else if(e.id()=="with")
  {
    //TODO : the following needs to be adapted for structs
    assert(e.operands().size()==3);

    typet& expectedIndexType=
        (typet &) e.op0().type().find_type("size").find("type");

    adjust(e.op0(), e.op0().type(), additionalWidth); //old_array
    adjust(e.op1(), expectedIndexType, additionalWidth); //index
    adjust(e.op2(), e.type(), additionalWidth); //value

    assert(e.type().id()!="" && e.op0().type().id()!="");

    if(e.op2().type().id()=="")
      e.op2().type()=e.type();


  }
  else if(e.id()=="index")
  {
    assert(e.operands().size()==2);
    assert(e.type().id()!="");
    assert(e.op0().id()=="symbol" && e.op0().type().id()=="array");

    typet& expectedIndexType=
        (typet&) e.op0().type().find_type("size").find("type");

    adjust(e.op0(), e.op0().type(), additionalWidth); //array
    adjust(e.op1(), expectedIndexType, additionalWidth) ; //index

  }
  else if(e.id()=="member")
  {
    assert(e.operands().size()==1);
    assert(e.type().id()!="" && e.op0().type().id()!="");
    assert(e.op0().type().id()==ID_struct);

    if(additionalWidth!=0 && e.op0().id()==ID_symbol) {
      //we need to copy the type since we don't know who is pointing to it
      typet newType = e.type();
      setNewWidth(newType, additionalWidth);

      exprt member_expr = e;
      e.clear();
      e=typecast_exprt(newType);
      e.op0()=member_expr;
    } else if(e.op0().id()!=ID_symbol)
      adjust(e.op0(), e.op0().type(), additionalWidth); //from_struct

  }
  else throw (string("Unexpected expression: ") + e.pretty(0));
}

void TypeAdjuster::setNewWidth(typet &type, const unsigned& additionalWidth)
{
  assert(type.id()!="");
  if(additionalWidth!=0)
  {
    boolbv_widtht boolbv_width(ns);
    unsigned oldWidth = boolbv_width(type);
    assert(type.get_int("width")==(int)oldWidth);
    unsigned newWidth = oldWidth;
    newWidth += additionalWidth;
    type.set("width", newWidth);
  }
}

unsigned TypeAdjuster::getAdditionalWidth(exprt& e)
{
  if(e.id()=="+" || e.id()=="-" || e.id()=="*")
  {
    unsigned maxAdditionalWidth=0;
    unsigned nb_operands=e.operands().size();
    for(unsigned i=0; i<nb_operands; i++)
      maxAdditionalWidth =
          max(maxAdditionalWidth, getAdditionalWidth(e.operands()[i]));

    // since addition in princess corresponds to mathematical addition we need
    // to make sure that no overflow occurs by increasing the width
    if(e.id()=="+" || e.id()=="-")
      maxAdditionalWidth += log2(nb_operands);

    return maxAdditionalWidth;
  }
  else return 0;
}


