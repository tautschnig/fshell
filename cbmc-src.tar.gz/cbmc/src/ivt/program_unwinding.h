/*******************************************************************\

Module: Functions for unwinding the control flow graph

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef CPROVER_WOLVER_UNWINDING_H
#define CPROVER_WOLVER_UNWINDING_H

// number of assumes on a sub-path before refine is called
// low values seem to be counter-productive
#define PATH_LENGTH_THRESHOLD 100

// number of nodes checked to force a cover
#define FORCE_COVER_THRESHOLD 5

#include <assert.h>
#include <stack>
#include <map>
#include <fstream>
#include <memory>

#include <graph.h>
#include <expr.h>
#include <std_expr.h>
#include <hash_cont.h>
#include <decision_procedure.h>

#include <pointer-analysis/value_set.h>
#include <goto-programs/goto_functions.h>
#include <goto-symex/goto_trace.h>

#include "symex_wolver.h"

/*******************************************************************\

   Class: goto_program_unwindingt

 Purpose: A class encapsulating the tree corresponding to an
          unwound control flow graph

\*******************************************************************/

class goto_program_unwindingt
{
public:
  goto_program_unwindingt(
    const namespacet &_ns,
    symex_wolvert &_symex,
    const goto_functionst &_goto_functions,
    goto_tracet &_trace):
    ns(_ns),
    symex(_symex),
    goto_functions(_goto_functions),
    trace(_trace),
    covering(unwinding_graph),
    logging(false),
    output_invariants(false),
    path_length_threshold(PATH_LENGTH_THRESHOLD),
    force_cover_threshold(FORCE_COVER_THRESHOLD),
    path_slicing(true)
  {
  }

  bool operator()();
  void set_interpolator(const std::string&, const optionst&);
  bool initialise_interpolator();
  bool start_logging(const std::string&);
  void stop_logging();
  void set_path_length_threshold(unsigned threshold)
  { path_length_threshold=threshold; }
  void set_force_cover_threshold(unsigned threshold)
  { force_cover_threshold=threshold; }
  void set_path_slicing(bool on)
  { path_slicing=on; }
  void report_invariants() // on success only
  { output_invariants=true; }

  /*******************************************************************\

     Class: unwinding_stept

   Purpose: The last step of an unwound path, holding the
            corresponding equation

  \*******************************************************************/

  class unwinding_stept { 
  public:
    unwinding_stept(
      symex_wolvert::statet &_state, 
      symex_target_equationt &_equation):
      state(_state),
      equation(_equation),
      predecessor(0),
      decision_counter(PATH_LENGTH_THRESHOLD)
    {
    }

    unwinding_stept(
      const namespacet &ns):
      equation(ns),
      decision_counter(PATH_LENGTH_THRESHOLD)
    { 
    }

    symex_wolvert::statet state;
    symex_target_equationt equation;
    unsigned node;
    unsigned predecessor;
    unsigned decision_counter;

    std::map<symex_targett::sourcet, unsigned> unwind_map;
    std::map<irep_idt, unsigned> recursion_map;
  };

  class worklistt:public std::list<unwinding_stept>
  {
  public:
    void defer_front()
    { if(size()>1) splice(end(), (*this), begin()); }
  };

  /*******************************************************************\

     Class: unwinding_nodet

   Purpose: A node of the unwinding graph

  \*******************************************************************/
  
  class unwinding_nodet:public graph_nodet<empty_nodet>
  {
  public:
    unwinding_nodet(): 
      covered(false), 
      refined(false)
    {
      label.make_true();
      ssa_label.make_true();
    }

    exprt label;
    exprt ssa_label;    // label referring to original ssa indices
    goto_programt::const_targett pc;
    unsigned covered;

    bool refined;
    unsigned previous;  // previous node with same location
    unsigned ssa_index; // size of SSA equation at this point
  };

  /*******************************************************************\

     Class: node_iterator

   Purpose: Common methods for iterator that traverses a graph

  \*******************************************************************/
  
  class node_iterator:public std::iterator<std::input_iterator_tag, 
                                           unwinding_nodet>
  {
  public:
    node_iterator(
      graph<unwinding_nodet>& _graph, 
      unsigned _index, 
      bool _invalid=false):
      unwinding_graph(_graph), index(_index), invalid(_invalid) 
    { 
    }

    virtual ~node_iterator() { }
    
    bool operator==(const node_iterator& other) const
    { return ((invalid && other.invalid) || 
              (invalid==other.invalid && index==other.index)); }
    bool operator!=(const node_iterator& other) const
    { return !((*this)==other); }
    
    unwinding_nodet& operator*() 
    { return unwinding_graph[index]; }

    unwinding_nodet* operator->() 
    { return &*((node_iterator)*this); }

    bool get_index(unsigned &i) { i=index; return !invalid; }
    unsigned get_index() { assert(!invalid); return index; }

  protected:
    graph<unwinding_nodet>& unwinding_graph;
    unsigned index;
    bool invalid;
  };

  /*******************************************************************\

     Class: unwinding_patht

   Purpose: Encapsulates a sequence of unwinding_nodets.
            begin() returns a node that corresponds to a leaf in
            the unwinding tree.

  \*******************************************************************/

  class unwinding_patht
  {
  public:
    unwinding_patht(
      graph<unwinding_nodet>& _graph, 
      unsigned _node):
      unwinding_graph(_graph), 
      final_node(_node),
      iterator_begin(unwinding_graph, final_node),
      iterator_end(unwinding_graph, 0, true)
    {
    }

    class iterator:public node_iterator
    {
    public:
      iterator(
        graph<unwinding_nodet>& _graph, 
        unsigned _index, 
        bool _invalid=false):
        node_iterator(_graph, _index, _invalid)
      {
      }

      using node_iterator::operator*;
      using node_iterator::operator->;

      iterator& operator++();
    };

    iterator& begin() 
    { return iterator_begin; }

    iterator& end() 
    { return iterator_end; }

  protected:
    graph<unwinding_nodet>& unwinding_graph;
    const unsigned final_node;
    iterator iterator_begin;
    iterator iterator_end;
  };


  /*******************************************************************\

     Class: preceding_nodest

   Purpose: A collection of nodes that may potentially cover
            a given node. The iterators encapsulate the order 
            in which the nodes are considered for coverage checks.

  \*******************************************************************/

  class preceding_nodest
  {
  public:
    preceding_nodest(
      graph<unwinding_nodet>& _graph, 
      unsigned _node):
      unwinding_graph(_graph), 
      cover_node(_node),
      iterator_begin(unwinding_graph, cover_node),
      iterator_end(unwinding_graph, 0, true)
    {
    }

    class iterator:public node_iterator
    {
    public:
      iterator(
        graph<unwinding_nodet>& _graph, 
        unsigned _index, 
        bool _invalid=false):
        node_iterator(_graph, _index, _invalid)
      {
      }

      using node_iterator::operator*;
      using node_iterator::operator->;

      iterator& operator++();
    };

    iterator& begin() 
    { return iterator_begin; }

    iterator& end() 
    { return iterator_end; }

  protected:
    graph<unwinding_nodet>& unwinding_graph;
    const unsigned cover_node;
    iterator iterator_begin;
    iterator iterator_end;
  };

  /*******************************************************************\

     Class: subtreet

   Purpose: An object representing a subtree of the unwinding graph.
            The iterator traverses the subtree in preorder.

  \*******************************************************************/

  class subtreet
  {
  public:
    subtreet(
      graph<unwinding_nodet>& _graph, 
      unsigned _node):
      unwinding_graph(_graph), 
      root_node(_node),
      iterator_begin(unwinding_graph, root_node),
      iterator_end(unwinding_graph, 0, true)
    {
    }

    class iterator:public node_iterator
    {
    public:
      iterator(
        graph<unwinding_nodet>& _graph, 
        unsigned _index, 
        bool _invalid=false):
        node_iterator(_graph, _index, _invalid)
      {
        if(!invalid)
          queue.push(index);
      }

      using node_iterator::operator*;
      using node_iterator::operator->;

      iterator& operator++();
    protected:
      std::stack<unsigned> queue;
    };

    iterator& begin() 
    { return iterator_begin; }

    iterator& end() 
    { return iterator_end; }

  protected:
    graph<unwinding_nodet>& unwinding_graph;
    const unsigned root_node;
    iterator iterator_begin;
    iterator iterator_end;
  };

  /*******************************************************************\

     Class: unwinding_grapht

   Purpose: a graph representing the unwound tree (a set of paths)

  \*******************************************************************/

  class unwinding_grapht:public graph<unwinding_nodet>
  {
  public:
    unsigned add_node(unwinding_stept&);

    unwinding_patht path_prefix(unsigned n)
    { return unwinding_patht(*this, n); }

    preceding_nodest preceding_nodes(unsigned n)
    { return preceding_nodest(*this, n); }

    subtreet subtree(unsigned n)
    { return subtreet(*this, n); }

    class graph_locationt 
    {
    public:
      graph_locationt(const unwinding_stept&);

      unsigned location_number;
      std::list<unsigned> calling_context;
    };

   
  protected:
    struct ordert
    {
      bool operator()(const graph_locationt&, const graph_locationt&) const;
    };

    typedef std::map<graph_locationt, unsigned, ordert> predecessor_mapt;
    predecessor_mapt predecessor_map;
  };

  unsigned long max_unwind;
  std::map<unsigned, long> unwind_set;

  void show_invariants(std::ostream&);

  /*******************************************************************\

     Class: coveringt

   Purpose: Stores the information on covered and covering nodes

  \*******************************************************************/

  class coveringt {
  public:
    coveringt(unwinding_grapht& _graph):
      graph(_graph)
    {
    }

    void add_cover(unsigned, unsigned);
    void remove_cover(unsigned);
    bool covered(unsigned);
    std::set<unsigned> covered_by(unsigned);
    inline bool uncovered(unsigned n) { return !covered(n); }
    
  protected:
    typedef std::multimap<unsigned, unsigned> covering_nodest;
    typedef covering_nodest::iterator covering_itt;

    covering_nodest covering_nodes;
    unwinding_grapht &graph;
  };

  static void conjoin(exprt&, exprt&);

protected:
  const namespacet &ns;
  symex_wolvert &symex;
  const goto_functionst &goto_functions;
  goto_tracet &trace;

  worklistt worklist;
  unwinding_grapht unwinding_graph;
  coveringt covering;

  std::auto_ptr<class path_interpolatort> interpolator;

  goto_programt::const_targett end_of_instructions;

  typedef hash_map_cont<exprt, bool, irep_hash> expr_cachet;

  typedef hash_map_cont<unsigned, exprt> invariant_mapt;
  
  expr_cachet implication_cache;

  // members to store command line parameters
  bool logging;
  bool output_invariants;
  std::ofstream logfile;

  unsigned path_length_threshold;
  unsigned force_cover_threshold;

  bool path_slicing;

  bool expand(unwinding_stept&);
  void expand_goto(unwinding_stept&);
  void expand_function_call(unwinding_stept&);
  bool expand_assert(unwinding_stept&);
  void expand_return(unwinding_stept&);

  void log(unsigned, unsigned, unwinding_stept&);

  bool close(unsigned);
  void cover(unsigned, unsigned);

  bool reachable(unwinding_stept&);

  bool force_cover(unwinding_stept&);
  bool force_cover(unwinding_stept&, unsigned);

  unsigned nearest_common_ancestor(unsigned, unsigned);

  bool check_implication(const exprt&, const exprt&);

  decision_proceduret::resultt refine(
    unwinding_stept&, exprt&, unsigned from_node=0);

  decision_proceduret::resultt refine(unwinding_stept &step);

  bool get_unwind(const symex_targett::sourcet&, unsigned);
  bool get_unwind_recursion(const irep_idt&, unsigned);

  bool get_counterexample(unwinding_stept&, goto_tracet&);

  void collect_invariants(invariant_mapt&);
  
  void failure(const goto_tracet& trace)
  {
    symex.status("\nVERIFICATION FAILED\n");
    trace.output(ns, std::cout);
  }

  void success()
  { 
    if(output_invariants)
      show_invariants(std::cout);
    symex.status("\nVERIFICATION SUCCESSFUL\n"); 
  }
};

#endif
