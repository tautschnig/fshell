/*******************************************************************\

Module: Main Module 

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

#include <fstream>
#include <memory>

#include <config.h>
#include <expr_util.h>

#include <goto-programs/goto_convert_functions.h>
#include <goto-programs/goto_check.h>
#include <goto-programs/goto_inline.h>
#include <goto-programs/goto_function_pointers.h>
#include <goto-programs/show_claims.h>
#include <goto-programs/set_claims.h>
#include <goto-programs/read_goto_binary.h>
#include <goto-programs/interpreter.h>
#include <goto-programs/string_abstraction.h>
#include <goto-programs/string_instrumentation.h>
#include <goto-programs/loop_numbers.h>
#include <goto-programs/slicer.h>

#include <pointer-analysis/value_set_analysis.h>
#include <pointer-analysis/goto_program_dereference.h>
#include <pointer-analysis/add_failed_symbols.h>
#include <pointer-analysis/show_value_sets.h>

#include <langapi/mode.h>

#include <ansi-c/ansi_c_language.h>

#ifdef HAVE_CPP
#include <cpp/cpp_language.h>
#endif

#ifdef HAVE_SPECC
#include <specc/specc_language.h>
#endif

#include "parseoptions.h"
#include "version.h"

/*******************************************************************\

Function: wolver_parseoptionst::wolver_parseoptionst

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

wolver_parseoptionst::wolver_parseoptionst(int argc, const char **argv):
  parseoptions_baset(WOLVER_OPTIONS, argc, argv),
  language_uit("WOLVER " WOLVER_VERSION, cmdline)
{
}
  
/*******************************************************************\

Function: wolver_parseoptionst::set_verbosity

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_parseoptionst::set_verbosity(messaget &message)
{
  int v=8;
  
  if(cmdline.isset("verbosity"))
  {
    v=atoi(cmdline.getval("verbosity"));
    if(v<0)
      v=0;
    else if(v>9)
      v=9;
  }
  
  message.set_verbosity(v);
}

/*******************************************************************\

Function: wolver_parseoptionst::get_command_line_options

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_parseoptionst::get_command_line_options(optionst &options)
{
  if(config.set(cmdline))
  {
    usage_error();
    exit(1);
  }

  if(cmdline.isset("program-only"))
    options.set_option("program-only", true);

  if(cmdline.isset("show-vcc"))
    options.set_option("show-vcc", true);

  if(cmdline.isset("no-simplify"))
    options.set_option("simplify", false);
  else
    options.set_option("simplify", true);

  if(cmdline.isset("all-claims"))
    options.set_option("all-claims", true);
  else
    options.set_option("all-claims", false);

  if(cmdline.isset("unwind"))
    options.set_option("unwind", cmdline.getval("unwind"));

  if(cmdline.isset("debug-level"))
    options.set_option("debug-level", cmdline.getval("debug-level"));

  if(cmdline.isset("slice-by-trace"))
    options.set_option("slice-by-trace", cmdline.getval("slice-by-trace"));

  if(cmdline.isset("unwindset"))
    options.set_option("unwindset", cmdline.getval("unwindset"));

  // check array bounds
  if(cmdline.isset("bounds-check"))
    options.set_option("bounds-check", true);
  else
    options.set_option("bounds-check", false);

  // check division by zero
  if(cmdline.isset("div-by-zero-check"))
    options.set_option("div-by-zero-check", true);
  else
    options.set_option("div-by-zero-check", false);

  // check overflow
  if(cmdline.isset("overflow-check"))
    options.set_option("overflow-check", true);
  else
    options.set_option("overflow-check", false);

  // check for NaN (not a number)
  if(cmdline.isset("nan-check"))
    options.set_option("nan-check", true);
  else
    options.set_option("nan-check", false);

  // check pointers
  if(cmdline.isset("pointer-check"))
    options.set_option("pointer-check", true);
  else
    options.set_option("pointer-check", false);

  // check assertions
  if(cmdline.isset("no-assertions"))
    options.set_option("assertions", false);
  else
    options.set_option("assertions", true);

  // magic error label
  if(cmdline.isset("error-label"))
    options.set_option("error-label", cmdline.getval("error-label"));

  // don't generate unwinding assertions
  options.set_option("unwinding-assertions", false);

  // remove unused equations
  options.set_option("slice", cmdline.isset("slice"));

  // simplify if conditions and branches
  if(cmdline.isset("no-simplify-if"))
    options.set_option("simplify-if", false);
  else
    options.set_option("simplify-if", true);

  if(cmdline.isset("arrays-uf-always"))
    options.set_option("arrays-uf", "always");
  else if(cmdline.isset("arrays-uf-never"))
    options.set_option("arrays-uf", "never");
  else
    options.set_option("arrays-uf", "auto");

  options.set_option("pretty-names", 
                     !cmdline.isset("no-pretty-names"));

  // turn path-slicing on or off
  if(cmdline.isset("no-path-slicing"))
    options.set_option("no-path-slicing", true);
  else
    options.set_option("no-path-slicing", false);

  // turn printing of invariants on or off
  if(cmdline.isset("show-invariants"))
    options.set_option("show-invariants", true);
  else
    options.set_option("show-invariants", false);

  // turn proof-lifting on or off (built-in interpolator only)
  if(cmdline.isset("no-proof-lifting"))
    options.set_option("no-proof-lifting", true);
  else
    options.set_option("no-proof-lifting", false);

  // tune the strength of interpolants (built-in interpolator only)
  if(cmdline.isset("weak-interpolants"))
    options.set_option("weak-interpolants", true);
  else
    options.set_option("weak-interpolants", false);

  if(cmdline.isset("log"))
    options.set_option("log", cmdline.getval("log"));

  if(cmdline.isset("path-length-threshold"))
    options.set_option("path-length-threshold", 
                       cmdline.getval("path-length-threshold"));

  if(cmdline.isset("force-cover"))
    options.set_option("force-cover", cmdline.getval("force-cover"));

  if(cmdline.isset("interpolator"))
    options.set_option("interpolator", cmdline.getval("interpolator"));
}

/*******************************************************************\

Function: wolver_parseoptionst::doit

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int wolver_parseoptionst::doit()
{
  if(cmdline.isset("version"))
  {
    std::cout << TOOL_NAME " " WOLVER_VERSION << std::endl;
    return 0;
  }

  goto_functionst goto_functions;

  goto_tracet trace;
  wolvert wolver(context, goto_functions, trace, ui_message_handler);

  // languages

  register_language(new_ansi_c_language);
  
  #ifdef HAVE_CPP
  register_language(new_cpp_language);
  #endif
  
  #ifdef HAVE_SPECC
  register_language(new_specc_language);
  #endif

  //
  // command line options
  //

  get_command_line_options(wolver.options);
  set_verbosity(wolver);
  set_verbosity(*this);

  if(cmdline.isset("preprocess"))
  {
    preprocessing();
    return 0;
  }

  if(get_goto_program(wolver, goto_functions))
    return 6;

  if(cmdline.isset("show-claims"))
  {
    const namespacet ns(context);
    show_claims(ns, get_ui(), goto_functions);
    return 0;
  }

  if(set_claims(goto_functions))
    return 7;

  // do actual model checking
  return do_modelcheck(wolver, goto_functions);
}

/*******************************************************************\

Function: wolver_parseoptionst::set_claims

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

bool wolver_parseoptionst::set_claims(goto_functionst &goto_functions)
{
  try
  {
    if(cmdline.isset("claim"))
      ::set_claims(goto_functions, cmdline.get_values("claim"));  
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  return false;
}

/*******************************************************************\

Function: wolver_parseoptionst::get_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/
  
bool wolver_parseoptionst::get_goto_program(
  wolver_baset &wolver,
  goto_functionst &goto_functions)
{
  if(cmdline.args.size()==0)
  {
    error("Please provide a foe to fight (or a program to verify)");
    return true;
  }

  try
  {
    if(cmdline.args.size()==1 &&
       is_goto_binary(cmdline.args[0]))
    {
      status("Reading GOTO program from file");

      if(read_goto_binary(cmdline.args[0],
           context, goto_functions, get_message_handler()))
        return true;
        
      config.ansi_c.set_from_context(context);

      if(cmdline.isset("show-symbol-table"))
      {
        show_symbol_table();
        return true;
      }
    }
    else
    {
      if(parse()) return true;
      if(typecheck()) return true;
      if(get_modules(wolver)) return true;    
      if(final()) return true;

      // we no longer need any parse trees or language files
      clear_parse();

      if(cmdline.isset("show-symbol-table"))
      {
        show_symbol_table();
        return true;
      }

      status("Generating GOTO Program");

      goto_convert(
        context, wolver.options, goto_functions,
        ui_message_handler);
    }

    if(cmdline.isset("interpreter"))
    {
      status("Starting interpeter");
      interpreter(context, goto_functions);
      return true;
    }

    if(process_goto_program(wolver, goto_functions))
      return true;
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  catch(std::bad_alloc)
  {
    error("Out of memory");
    return true;
  }
  
  return false;
}

/*******************************************************************\

Function: wolver_parseoptionst::preprocessing

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/
  
void wolver_parseoptionst::preprocessing()
{
  try
  {
    if(cmdline.args.size()!=1)
    {
      error("Please provide one program to preprocess");
      return;
    }

    std::string filename=cmdline.args[0];

    std::ifstream infile(filename.c_str());

    if(!infile)
    {
      error("failed to open input file");
      return;
    }

    languaget *ptr=get_language_from_filename(filename);

    if(ptr==NULL)
    {
      error("failed to figure out type of file");
      return;
    }

    std::auto_ptr<languaget> language(ptr);
  
    if(language->preprocess(
      infile, filename, std::cout, get_message_handler()))
      error("PREPROCESSING ERROR");
  }

  catch(const char *e)
  {
    error(e);
  }

  catch(const std::string e)
  {
    error(e);
  }
  
  catch(int)
  {
  }
}

/*******************************************************************\

Function: wolver_parseoptionst::process_goto_program

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/
  
bool wolver_parseoptionst::process_goto_program(
  wolver_baset &wolver,
  goto_functionst &goto_functions)
{
  try
  {
    if(cmdline.isset("string-abstraction"))
      string_instrumentation(
        context, get_message_handler(), goto_functions);

    remove_function_pointers(goto_functions);

    namespacet ns(context);

    // do partial inlining
    goto_partial_inline(goto_functions, ns, ui_message_handler);
    
    // add generic checks
    goto_check(ns, wolver.options, goto_functions);
    
    if(!cmdline.isset("no-string-abstraction"))
    {
      status("String Abstraction");
      string_abstraction(context,
        get_message_handler(), goto_functions);
    }

    if(cmdline.isset("pointer-check") ||
       cmdline.isset("show-value-sets"))
    {
      status("Pointer Analysis");
      value_set_analysist value_set_analysis(ns);
      value_set_analysis(goto_functions);
      
      // show it?
      if(cmdline.isset("show-value-sets"))
      {
        show_value_sets(get_ui(), goto_functions, value_set_analysis);
        return true;
      }

      status("Adding Pointer Checks");
      
      // add pointer checks
      pointer_checks(
        goto_functions, ns, wolver.options, value_set_analysis);
    }

    // add failed symbols
    add_failed_symbols(context);
    
    // recalculate numbers, etc.
    goto_functions.update();

    // add loop ids
    goto_functions.compute_loop_numbers();

    // show it?
    if(cmdline.isset("show-loops"))
    {
      show_loop_numbers(get_ui(), goto_functions);
      return true;
    }

    // show it?
    if(cmdline.isset("show-goto-functions"))
    {
      goto_functions.output(ns, std::cout);
      return true;
    }

    if(!cmdline.isset("no-slicing"))
    {
      status("Slicing Program.");
      slicer(goto_functions);
    }
  }

  catch(const char *e)
  {
    error(e);
    return true;
  }

  catch(const std::string e)
  {
    error(e);
    return true;
  }
  
  catch(int)
  {
    return true;
  }
  
  return false;
}

/*******************************************************************\

Function: wolver_parseoptionst::do_modelcheck

  Inputs:

 Outputs:

 Purpose: invoke main modules

\*******************************************************************/

int wolver_parseoptionst::do_modelcheck(
  wolver_baset &wolver,
  const goto_functionst &goto_functions)
{
  wolver.set_ui(get_ui());

  // do actual model checking run
  if(wolver.fight())
    return 10;

  return 0;
}

/*******************************************************************\

Function: wolver_parseoptionst::help

  Inputs:

 Outputs:

 Purpose: display command line help

\*******************************************************************/

void wolver_parseoptionst::help()
{
  std::cout <<
    "\n"
    "* *         " TOOL_NAME " " WOLVER_VERSION 
    " - Copyright (C) 2001-2010          * *\n"
    "* *           Georg Weissenbacher, Daniel Kroening           * *\n"
    "* *        University of Oxford, Computing Laboratory        * *\n"
    "* *     georg@weissenbacher.name, kroening@kroening.com      * *\n"
    "\n"
    " The wolverine (Gulo gulo) is a predatory species of the weasel \n"
    " family.  The carnivore resembles a small bear and dwells in in \n"
    " isolated northern areas in Canada, Siberia, and Scandinavia.   \n"
    "\n"
    "Usage:                       Purpose:\n"
    "\n"
    " wolverine --help             show help\n"
    " wolverine file.c ...         source file names\n"
    "\n"
    "Frontend options:\n"
    " -I path                      set include path (C/C++)\n"
    " -D macro                     define preprocessor macro (C/C++)\n"
    " --preprocess                 stop after preprocessing\n"
    " --16, --32, --64             set width of machine word\n"
    " --little-endian              allow little-endian word-byte conversions\n"
    " --big-endian                 allow big-endian word-byte conversions\n"
    " --unsigned-char              make \"char\" unsigned by default\n"
    " --show-symbol-table          show symbol table\n"
    " --show-goto-functions        show goto program\n"
    " --ppc-macos                  set MACOS/PPC architecture\n"
    #ifdef _WIN32
    " --i386-macos                 set MACOS/I386 architecture\n"
    " --i386-linux                 set Linux/I386 architecture\n"
    " --i386-win32                 set Windows/I386 architecture (default)\n"
    #else
    #ifdef __APPLE__
    " --i386-macos                 set MACOS/I386 architecture (default)\n"
    " --i386-linux                 set Linux/I386 architecture\n"
    " --i386-win32                 set Windows/I386 architecture\n"
    #else
    " --i386-macos                 set MACOS/I386 architecture\n"
    " --i386-linux                 set Linux/I386 architecture (default)\n"
    " --i386-win32                 set Windows/I386 architecture\n"
    #endif
    #endif
    " --no-arch                    don't set up an architecture\n"
    " --no-library                 disable built-in abstract C library\n"
    " --round-to-nearest           IEEE floating point rounding mode (default)\n"
    " --round-to-plus-inf          IEEE floating point rounding mode\n"
    " --round-to-minus-inf         IEEE floating point rounding mode\n"
    " --round-to-zero              IEEE floating point rounding mode\n"
    " --interpeter                 do concrete execution\n"
    "\n"
    "Program instrumentation options:\n"
    " --bounds-check               enable array bounds checks\n"
    " --div-by-zero-check          enable division by zero checks\n"
    " --pointer-check              enable pointer checks\n"
    " --overflow-check             enable arithmetic over- and underflow checks\n"
    " --show-claims                only show claims\n"
    " --error-label label          check that label is unreachable\n"
    "\n"
    "Program unwinding options:\n"
    " --function name              set main function name\n"
    " --all-claims                 keep all claims\n"
    " --unwind nr                  unwind nr times\n"
    " --unwindset nr               unwind given loop nr times\n"
    " --no-slicing                 don't slice assignments unrelated to property\n"

    "\n"
    "Backend options:\n"
    " --interpolator id            use the interpolator <id>\n"
    " --path-length-threshold n    check feasibility of path after <n> decisions\n"
    " --force-cover n              restrict forced cover to at most <n> nodes\n"
    " --no-path-slicing            deactivate path slicing\n"
    " --arrays-uf-never            never turn arrays into uninterpreted functions\n"
    " --arrays-uf-always           always turn arrays into uninterpreted functions\n"
    "\n"
    "Options for built-in interpolator:\n"
    " --no-proof-lifting           deactivate proof lifting\n"
    " --weak-interpolants          generate weaker interpolants\n"
    "\n"
    "Other options:\n"
    " --log filename               log the unwinding to <filename>\n"
    " --show-invariants            show invariants of program\n"
    "\n";
}
