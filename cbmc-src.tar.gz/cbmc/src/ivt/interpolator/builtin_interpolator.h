/*******************************************************************\

Module: Wolverine's built-in interpolator

Author: Georg Weissenbacher, georg@weissenbacher.name

Info:   An interpolator supporting propositional structure
        based on the wordlevel_interpolator

\*******************************************************************/

#ifndef CPROVER_BUILTIN_INTERPOLATOR_H
#define CPROVER_BUILTIN_INTERPOLATOR_H

#include "prop_interpolator.h"

typedef prop_interpolatort builtin_interpolatort;
//typedef transitivity_interpolatort builtin_interpolatort;

#endif
