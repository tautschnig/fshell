/*******************************************************************\

Module: Interface for propositional interpolator

Author: Georg Weissenbacher, georg@weissenbacher.name

Info:   An interpolator supporting propositional structure
        based on the wordlevel_interpolator

\*******************************************************************/

#ifndef CPROVER_PROP_INTERPOLATOR_H
#define CPROVER_PROP_INTERPOLATOR_H

#include <iostream>

#include <solvers/sat/satcheck.h>
#ifndef SATCHECK_MINISAT1
#error WOLVERINE REQUIRES PROOF-LOGGING MINISAT v1.14
#endif

#include <hash_cont.h>
#include <graph.h>
#include <expr.h>

#include <solvers/flattening/bv_pointers.h>
#include <util/decision_procedure.h>

#include "proof_logging.h"
#include "wordlevel_interpolator.h"

/*******************************************************************\

 Proof- and core-generating SAT solvers

\*******************************************************************/

class proof_wrappert
{
protected:
  propositional_prooft proof;
};

class propsolver_wrappert: public proof_wrappert
{
public:
  propsolver_wrappert():
    solver(proof)
  {
  }

  satcheck_coret solver;
};

class bit_blastert:
  public propsolver_wrappert,
  public bv_pointerst
{
public:
  virtual const std::string description()
  { return "Bit-flattening solver (with core)"; }

  bit_blastert(const namespacet& ns):bv_pointerst(ns, solver)
  { 
    equality_propagation=false;
    use_cache=true;
  }

  virtual literalt get_literal(const irep_idt &identifier)
  { return bv_pointerst::get_literal(identifier); }
};

class sat_listenert {
public:
  /* called upon generation of a new literal */
  virtual void notify(const literalt&)=0;
  /* called when a new clause is added*/
  virtual void notify(const bvt&)=0;
};

class notifying_solvert: public satcheck_proof_loggingt
{
public:
  notifying_solvert(
    sat_listenert &_listener,
    propositional_prooft &proof):
    satcheck_proof_loggingt(proof),
    listener(_listener) 
  { 
  }

protected:
  virtual literalt new_variable();
  virtual void lcnf(const bvt&);
  sat_listenert &listener;
};

class notifying_solver_wrappert
{
public:
  notifying_solver_wrappert(
    sat_listenert &listener,
    propositional_prooft &proof):
    solver(listener, proof)
  {
  }
  
  notifying_solvert solver;
};

class proof_generatort:
  public notifying_solver_wrappert,
  public prop_convt
{
public:
  proof_generatort(
    const namespacet& ns,
    sat_listenert &listener, 
    propositional_prooft &proof):
    notifying_solver_wrappert(listener, proof),
    prop_convt(ns, solver)
  { 
    equality_propagation=false;
    use_cache=false;
  }

  virtual const std::string description()
  { return "Proof-generating SAT solver"; }
};

/*******************************************************************\

 Interface for classes mapping skeleton literals to wordlevel
 facts and literals and clauses to partition ranges

\*******************************************************************/

class bitlevel_informationt
{
public:
  /* functions for literals */
  virtual wordlevel_factt map_to_wordlevel(const literalt&, bool&)=0;
  virtual colour_ranget get_partition_range(const literalt&)=0;

  typedef enum {A_LOCAL, B_LOCAL, SHARED} partition_typet;
  virtual partition_typet get_partition_type(
    const literalt&, wordlevel_factt::partitiont)=0;

  /* functions for clauses  */
  virtual bool is_blocking_clause(const bvt&)=0;
  virtual bool map_to_wordlevel(const bvt&, wordlevel_factst&)=0;
  virtual bool get_partition(const bvt&, wordlevel_factt::partitiont&)=0;
};

/*******************************************************************\

 Different interpolation systems

\*******************************************************************/

class interpolation_systemt
{
public:
  interpolation_systemt(
    const namespacet &_ns, bitlevel_informationt &information):
    ns(_ns),
    bitlevel_information(information)
  {
  }

  /* partial interpolants for initial nodes  */
  virtual exprt get_partial_interpolant(
    const bvt&, 
    wordlevel_factt::partitiont, // threshold
    wordlevel_factt::partitiont)=0;
  
  /* partial interpolants for internal nodes */
  virtual exprt get_partial_interpolant(
    const literalt&, 
    wordlevel_factt::partitiont, // threshold
    exprt&, exprt&)=0;

protected:
  const namespacet &ns;
  bitlevel_informationt &bitlevel_information;
};

/* McMillan's propositional interpolation system */
class mcmillan_interpolation_systemt: public interpolation_systemt
{
public:
  mcmillan_interpolation_systemt(
    const namespacet& ns, bitlevel_informationt &information):
    interpolation_systemt(ns, information)
  {
  }
  
  exprt get_partial_interpolant(
    const bvt&, wordlevel_factt::partitiont, wordlevel_factt::partitiont);

  exprt get_partial_interpolant(
    const literalt&, wordlevel_factt::partitiont, exprt&, exprt&);
};

/* Inverse McMillan interpolation system */
class inv_mcmillan_interpolation_systemt: public interpolation_systemt
{
public:
  inv_mcmillan_interpolation_systemt(
    const namespacet& ns, bitlevel_informationt &information):
    interpolation_systemt(ns, information)
  {
  }
  
  exprt get_partial_interpolant(
    const bvt&, wordlevel_factt::partitiont, wordlevel_factt::partitiont);

  exprt get_partial_interpolant(
    const literalt&, wordlevel_factt::partitiont, exprt&, exprt&);
};

/*******************************************************************\

 Class that reduces the formula to a propositional skeletont
 over the skeleton literals that are in the core and generates
 a resolution proof using the skeleton and the blocking clauses.

\*******************************************************************/

class liftert: public sat_listenert, public bitlevel_informationt
{
public:
  /* types */
  class clause_comparet
  {
  public:
    size_t operator()(const bvt&, const bvt&) const;
  protected:
    static void canonicalise(bvt&);
  };

  typedef 
  std::map<bvt, std::vector<exprt>, clause_comparet> partial_interpolantst;

  liftert(const namespacet& _ns, propositional_prooft &_proof):
    ns(_ns), proof(_proof), bit_blaster(ns), 
    proof_generator(ns, *this, proof),
    log_sat(false),
    current_partition(0),
    maximal_partition(0),
    max_skeleton_literal(0),
    weak_interpolants(false)
  { 
  }

  void add_formula(const exprt&, wordlevel_factt::partitiont);
  void set_maximal_partition(wordlevel_factt::partitiont);

  decision_proceduret::resultt lift(bool, partial_interpolantst&);

  /* bitlevel information functions       */
  wordlevel_factt map_to_wordlevel(const literalt&, bool&);
  colour_ranget get_partition_range(const literalt&);
  bitlevel_informationt::partition_typet 
  get_partition_type(const literalt&, wordlevel_factt::partitiont);

  bool is_blocking_clause(const bvt&);
  bool map_to_wordlevel(const bvt&, wordlevel_factst&);
  bool get_partition(const bvt&, wordlevel_factt::partitiont&);

  void generate_weak_interpolants() { weak_interpolants=true; }

  /* callback functions for SAT solvers   */
  virtual void notify(const literalt&);  
  virtual void notify(const bvt&);  

protected:
  const namespacet &ns;
  propositional_prooft &proof;

  /* SAT solvers                          */
  bit_blastert bit_blaster;
  proof_generatort proof_generator;
  
  bool log_sat;
  wordlevel_factt::partitiont current_partition;
  wordlevel_factt::partitiont maximal_partition;
  unsigned max_skeleton_literal;

  bool weak_interpolants;

  /* the propositional skeleton (divided into partitions) */
  std::vector<exprt> skeleton;

  struct literal_hasht
  {
    size_t operator()(const literalt &lit) const 
    { return (size_t)lit.get(); }
  };

  /* mapping skeleton literals to theory atoms */
  typedef hash_map_cont<literalt, exprt, literal_hasht> literal_mapt;
  literal_mapt literal_map;

  /* mapping skeleton literals partitions      */
  typedef hash_map_cont<unsigned, colour_ranget> partition_mapt;
  partition_mapt partition_map;

  /* remember blocking clauses */
  typedef std::set<bvt, clause_comparet> blocking_clausest;
  blocking_clausest blocking_clauses;

  /* mapping skeleton clauses to partitions    */
  typedef std::map<bvt, wordlevel_factt::partitiont, 
                   clause_comparet> clause_mapt;
  clause_mapt clause_map;

  void atomise(exprt&, wordlevel_factt::partitiont, expr_listt&);
  void add_skeleton(prop_convt&);
  void reduce(exprt&);
  decision_proceduret::resultt generate_core();
  decision_proceduret::resultt lift_blocking_clause(
    const bvt&, std::vector<exprt>&);
  decision_proceduret::resultt generate_smt_proof(partial_interpolantst&);
  bool has_core_literals(const exprt&);
};

/*******************************************************************\

 Propositional interpolator

\*******************************************************************/

class prop_interpolatort: wordlevel_interpolatort
{
public:
  prop_interpolatort(const namespacet&);
  void add_formulas(const expr_listt&,
                    wordlevel_factt::partitiont partition=0);
  void add_formula(const exprt&, wordlevel_factt::partitiont);
  void set_maximal_partition(wordlevel_factt::partitiont);
  decision_proceduret::resultt infer();
  void get_interpolant(wordlevel_factt::partitiont, exprt&);
  void get_interpolants(expr_listt&);
  ~prop_interpolatort () { }

  /* interpolator-specific options */
  void deactivate_proof_lifting() { proof_lifting=false; }
  void generate_weak_interpolants() 
  { 
    weak_interpolants=true; 
    lifter.generate_weak_interpolants();
  }

protected:
  const namespacet &ns;
  wordlevel_factt::partitiont maximal_partition;
  bool proof_lifting;
  bool weak_interpolants;
  propositional_prooft proof;
  liftert lifter;

  typedef hash_map_cont<unsigned, exprt> interpolant_cachet;
  interpolant_cachet partial_interpolant_cache;

  mcmillan_interpolation_systemt strong_interpolation_system;
  inv_mcmillan_interpolation_systemt weak_interpolation_system;
  liftert::partial_interpolantst partial_interpolants;

  void add_fact(const wordlevel_factt&);

  unsigned resolve(const bvt&, const bvt&, unsigned, bvt&);
  exprt get_partial_interpolant(unsigned, wordlevel_factt::partitiont);
};

#endif
