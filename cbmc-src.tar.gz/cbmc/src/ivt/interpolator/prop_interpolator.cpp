/*******************************************************************\

Module: Interpolation for formulae with propositional structure

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include <algorithm>

#include <std_expr.h>
#include <simplify_expr.h>
#include <threeval.h>

#include "prop_interpolator.h"

//#define DEBUG

/*******************************************************************\

Function: notifying_solver::new_variable

  Inputs: 

 Outputs: 

 Purpose: Notifies the listener when a (new) literal is requested

\*******************************************************************/
literalt notifying_solvert::new_variable()
{
  literalt literal=satcheck_minisatt::new_variable();
  listener.notify(literal);
  return literal;
}

/*******************************************************************\

Function: notifying_solver::lcnf

  Inputs: 

 Outputs: 

 Purpose: Notifies the listener when a clause is added

\*******************************************************************/
void notifying_solvert::lcnf(const bvt &bv)
{
  bvt new_bv;
  satcheck_minisatt::lcnf(bv);

  if(!process_clause(bv, new_bv))
    listener.notify(new_bv);
}

/*******************************************************************\

Function: liftert::set_maximal_partition

  Inputs: The highest partition number

 Outputs: 

 Purpose: Stores the highest partition number

\*******************************************************************/
void liftert::set_maximal_partition(
  wordlevel_factt::partitiont partition)
{
  maximal_partition=partition;
}

/*******************************************************************\

Function: liftert::add_formula

  Inputs: A wordlevel fact and a partition number

 Outputs: 

 Purpose: Adds a formula and extracts its atoms

\*******************************************************************/
void liftert::add_formula
(const exprt& formula, wordlevel_factt::partitiont partition)
{
  assert(formula.type().id()==ID_bool);

  expr_listt inferred;
  exprt skel(formula);
  atomise(skel, partition, inferred);

  maximal_partition=std::max(maximal_partition, partition);
  if(partition>=skeleton.size())
    skeleton.resize(partition+1, true_exprt());

  if(inferred.size()!=0)
  {
    exprt constrained(ID_and, bool_typet());
    constrained.copy_to_operands(skel);
    for(expr_listt::const_iterator c_it=inferred.begin();
        c_it!=inferred.end(); ++c_it)
    {
      constrained.copy_to_operands(*c_it);
    }
    skel.swap(constrained);
  }

  if(skeleton[partition].is_true())
    skeleton[partition]=skel;
  else
  {
    and_exprt conjunction(skeleton[partition], skel);
    skeleton[partition].swap(conjunction);
  }
}

/*******************************************************************\

Function: liftert::atomise

  Inputs: A wordlevel fact, a partition number, a target list
          of inferred literals

 Outputs: 

 Purpose: Extracts the atoms of a formula and puts them in a
          skeleton literal map. Replaces all theory atoms
          by the respective theory literals. If an atom
          turns out to be true or false, adds a respective
          constraint to inferred_literals

\*******************************************************************/
void liftert::atomise
(exprt& formula, 
 wordlevel_factt::partitiont partition,
 expr_listt& inferred_literals)
{
  literalt literal;

  if(formula.is_constant())
    return;

  if(formula.id()==ID_symbol)
  {
    literal=bit_blaster.get_literal(formula.get(ID_identifier));
  }
  else if(formula.id()=="literal")
  {
    literal.set(atoi(formula.get("literal").c_str()));
  }
  else if(formula.id()=="nondet_symbol")
  {
    literal=bit_blaster.prop.new_variable();
  }
  else if (formula.id()==ID_or || 
           formula.id()==ID_and || 
           formula.id()==ID_xor ||
           formula.id()==ID_nor || 
           formula.id()==ID_nand ||
           formula.id()==ID_not ||
           formula.id()=="=>" ||
           formula.id()=="constraint_select_one")
  {
    Forall_operands(it, formula)
    {
      atomise(*it, partition, inferred_literals);
    }
    return;
  }
  else if(formula.id()==ID_if) 
  {
    // this may happen if ID_if hasn't been lifted
    assert(formula.has_operands() && formula.operands().size()==3);
    assert(formula.op0().type().id()==ID_bool);
    atomise(formula.op0(), partition, inferred_literals);
    if(formula.op1().type().id()==ID_bool)
    {
      assert(formula.op2().type().id()==ID_bool);
      atomise(formula.op1(), partition, inferred_literals); 
      atomise(formula.op2(), partition, inferred_literals);
    }
    return;
  }
  else // this is an atom
  {
    literal=bit_blaster.convert(formula);
  }

  if(literal.is_constant()) 
  {
    // The flattener knows better whether somethings true or false
    bool negate=literal.is_false();
    literal=bit_blaster.prop.new_variable();
    inferred_literals.push_back(exprt("literal", typet(ID_bool)));
    exprt &constraint=inferred_literals.back();
    constraint.set("literal", integer2string(literal.get()));
    if(negate)
      constraint.negate();
  }

  if(literal.var_no()>max_skeleton_literal)
    max_skeleton_literal=literal.var_no();

  // store the atom and its colour in the hash maps
  colour_ranget &range=partition_map[literal.var_no()];
  if(range.first>range.second)
  {
    range.first=range.second=partition;
  }
  else
  {
    // update range
    if(range.first>partition)
      range.first=partition;
    else if(range.second<partition)
      range.second=partition;
  }

  literal_map[literal]=formula;

#ifdef DEBUG
  std::cout << "The literal for " << from_expr(ns, "", formula)
            << " is " << literal.get() 
            << " (variable " << literal.var_no() << ")" 
            << " in [" << range.first << "," << range.second << "]"
            << std::endl;
#endif

  // now replace the atom with the literal
  formula=exprt ("literal", typet(ID_bool));
  formula.set("literal", integer2string(literal.get()));
}

/*******************************************************************\

Function: liftert::add_skeleton

  Inputs: 

 Outputs: 

 Purpose: Adds the propositional skeleton to the SAT instance

\*******************************************************************/
void liftert::add_skeleton(prop_convt &converter)
{
  for(current_partition=0; current_partition<skeleton.size();
      current_partition++)
  {
    converter.set_to_true(skeleton[current_partition]);
  }
}


/*******************************************************************\

Function: liftert::generate_core

  Inputs: 

 Outputs: 

 Purpose: Adds the skeleton and runs the SAT solver in order
          to generate an unsatisfiable core.
          Returns the verdict of the SAT-solver or D_ERROR
          if the solver failed to generate a valid resolution proof.

\*******************************************************************/
decision_proceduret::resultt liftert::generate_core()
{
  add_skeleton(bit_blaster);
  decision_proceduret::resultt verdict=bit_blaster.dec_solve();
  if(verdict!=decision_proceduret::D_UNSATISFIABLE)
    return verdict;
  
  if(!bit_blaster.solver.has_valid_proof())
    return decision_proceduret::D_ERROR;
  
  return verdict;
}

/*******************************************************************\

Function: liftert::reduce

  Inputs: A formula to be reduced

 Outputs: 

 Purpose: Reduces the skeleton of a formula by eliminating
          conjuncts that are not in the core

\*******************************************************************/
void liftert::reduce(exprt &formula)
{
  if(formula.id()==ID_and)
  {
    Forall_operands(it, formula)
      reduce(*it);
  }
  else if(!has_core_literals(formula))
  {
    formula.make_true();
  }
}

/*******************************************************************\

Function: liftert::has_core_literals

  Inputs: A formula

 Outputs: 

 Purpose: Returns true if one of the literals in the 
          formula is in the core

\*******************************************************************/
bool liftert::has_core_literals(const exprt &formula)
{
  assert(bit_blaster.solver.has_valid_proof());

  if(formula.is_constant())
    return false;

  if(formula.id()==ID_literal)
  {
    literalt literal;
    literal.set(atoi(formula.get("literal").c_str()));
    assert(!literal.is_constant());
    return bit_blaster.solver.is_in_core(literal);
  }

  if(formula.id()==ID_nondet_symbol || formula.id()==ID_symbol)
  {
    throw "Unexpected expression in skeleton formula: " + 
      from_expr(ns, "", formula);
  }

  forall_operands(it, formula)
  {
    if (has_core_literals(*it))
      return true;
  }
  
  return false;
}

/*******************************************************************\

Function: liftert::clause_comparet::canonicalise

  Inputs: 

 Outputs: 

 Purpose: Transforms a clause into a canonical form
          (ordered by literal.get())

\*******************************************************************/
bool compare_literals(const literalt& a, const literalt& b)
{
  return (a.get()<b.get());
} 

void liftert::clause_comparet::canonicalise(bvt& clause)
{
  sort(clause.begin(), clause.end(), compare_literals);
}

/*******************************************************************\

Function: liftert::clause_comparet::operator()

  Inputs: 

 Outputs: 

 Purpose: Hash code for clauses

\*******************************************************************/
size_t liftert::clause_comparet::operator()(
  const bvt& a, const bvt& b) const
{
  if(a.size()!=b.size())
    return (a.size()<b.size());

  bvt acanonical(a), bcanonical(b);
  canonicalise(acanonical);
  canonicalise(bcanonical);
  
  bvt::const_iterator a_it=acanonical.begin();
  bvt::const_iterator b_it=bcanonical.begin();

  for(; a_it!=acanonical.end(); ++a_it, ++b_it)
  {
    if(*a_it!=*b_it)
      return (*a_it<*b_it);
  }

  return false;
}

/*******************************************************************\

Function: liftert::notify

  Inputs: 

 Outputs: 

 Purpose: Assigns a partition to literals that do not directly 
          correspond to a theory atom (such as Tseitin literals)

\*******************************************************************/
void liftert::notify(const literalt &literal)
{
  if(log_sat)
  {
#ifdef DEBUG
    std::cout << "Fresh Tseitin literal " << literal.var_no() 
              << " in partition " << current_partition << std::endl;
#endif
    colour_ranget &range=partition_map[literal.var_no()];
    range.first=range.second=current_partition;
  }
}

/*******************************************************************\

Function: liftert::notify

  Inputs: 

 Outputs: 

 Purpose: Assigns a partition to a clause

\*******************************************************************/
void liftert::notify(const bvt &clause)
{
  if(log_sat)
  {
    clause_map[clause]=current_partition;
  }
}

/*******************************************************************\

Function: liftert::lift

  Inputs: A flag indicating whether
          the proof should be reduced to the core

 Outputs: Partial interpolants for the blocking clauses

 Purpose: Lifts a propositional proof to the wordlevel.
          Returns D_UNSATISFIABLE in case of success.
          If reduce_to_core is true and the bit-flattening
          decides that the formula is satisfiable, returns
          D_SATISFIABLE. Returns D_ERROR if it fails to
          generate a proof.

\*******************************************************************/
decision_proceduret::resultt liftert::lift(bool reduce_to_core,
  partial_interpolantst& interpolants)
{
  decision_proceduret::resultt verdict;

  if(reduce_to_core)
  {
    verdict=generate_core();
    if(verdict!=decision_proceduret::D_UNSATISFIABLE)
      return verdict;
  }

  wordlevel_factt::partitiont partition=0;
  
  for(std::vector<exprt>::iterator s_it=skeleton.begin();
      s_it!=skeleton.end(); ++s_it, partition++)
  {
    if(reduce_to_core)
      reduce(*s_it);

    simplify(*s_it, ns);
  }

  verdict=generate_smt_proof(interpolants);
  if(verdict==decision_proceduret::D_UNSATISFIABLE && !proof.is_valid())
    return decision_proceduret::D_ERROR;

  return verdict;
}

/*******************************************************************\

Function: liftert::get_partition_range

  Inputs: A literal

 Outputs: A partition range

 Purpose: Returns the partition range in which a literal occured

\*******************************************************************/
colour_ranget liftert::get_partition_range(const literalt& literal)
{
  return partition_map[literal.var_no()];
}

/*******************************************************************\

Function: liftert::get_partition

  Inputs: A propositional CNF clause

 Outputs: A partition

 Purpose: Returns the partition to which the clause belongs in the
          second parameter. Returns true if the clause doesn't 
          belong to any partition.

\*******************************************************************/
bool liftert::get_partition(
  const bvt& clause, wordlevel_factt::partitiont &partition)
{
  clause_mapt::const_iterator it=clause_map.find(clause);
  if(it==clause_map.end())
    return true;

  partition=it->second;
  return false;
}

/*******************************************************************\

Function: liftert::map_to_wordlevel

  Inputs: A literal

 Outputs: A wordlevel fact. 

 Purpose: Maps a literal back to the corresponding wordlevel 
          expression. Sets status to true if there is no 
          corresponding wordlevel expression, false otherwise.

\*******************************************************************/
wordlevel_factt liftert::map_to_wordlevel(
  const literalt& literal, bool &status)
{
  bool inverted=false;
  literalt l=literal;

  literal_mapt::const_iterator l_it=literal_map.find(literal);
  if(l_it==literal_map.end())
  {
    l.invert();
    inverted=true;
    l_it=literal_map.find(l);
    if(l_it==literal_map.end())
    {
      status=true;
      return wordlevel_factt(true_exprt(), 0);
    }
  }
  
  exprt expression=l_it->second;
  if(inverted) 
    expression.negate(); // invert literals
  
  partition_mapt::const_iterator p_it=partition_map.find(l.var_no());
  assert(p_it!=partition_map.end());
  

  // favour A-partition in case of weak interpolants, B-partition otherwise
  wordlevel_factt::partitiont partition=
    weak_interpolants?((p_it->second).first):((p_it->second).second);

  status=false;
  return wordlevel_factt(expression, partition);
}

/*******************************************************************\

Function: liftert::is_blocking_clause

  Inputs: A blocking clause

 Outputs: 

 Purpose: Returns true if a clause is a blocking clause and not
          a skeleton clause

\*******************************************************************/
bool liftert::is_blocking_clause(const bvt& clause)
{
  blocking_clausest::const_iterator b_it=blocking_clauses.find(clause);
  return (b_it!=blocking_clauses.end());
}

/*******************************************************************\

Function: liftert::map_to_wordlevel

  Inputs: A blocking clause, and empty list of facts

 Outputs: 

 Purpose: Generates the inconsistent wordlevel conjunction
          for a bit-level blocking clause. Returns true on failure.

\*******************************************************************/
bool liftert::map_to_wordlevel(
  const bvt& clause, wordlevel_factst& facts)
{
  transitivity_interpolatort interpolator(ns);
  interpolator.set_maximal_partition(maximal_partition);

  bool status;

  for(bvt::const_iterator it=clause.begin();
      it!=clause.end(); ++it)
  {
    literalt literal=*it;

    // we want a blocking clause, so invert literal!
    literal.invert();
    wordlevel_factt fact=map_to_wordlevel(literal, status);
    if(status)
      return true;

    facts.push_back(fact);
  }

  return false;
}

/*******************************************************************\

Function: liftert::lift_blocking_clause

  Inputs: An interpolator, a blocking clause

 Outputs: Partial interpolants for the blocking clause

 Purpose: 

\*******************************************************************/
decision_proceduret::resultt liftert::lift_blocking_clause(
  const bvt &clause,
  std::vector<exprt> &interpolants)
{
  wordlevel_factst facts;
  bool mapping_failed=map_to_wordlevel(clause, facts);
  assert(!mapping_failed);

  transitivity_interpolatort interpolator(ns);
  interpolator.set_maximal_partition(maximal_partition);

  for(wordlevel_factst::const_iterator f_it=facts.begin();
      f_it!=facts.end(); ++f_it)
  {
    const wordlevel_factt &fact=*f_it;
    interpolator.add_formula(fact.expression, fact.partition);
  }

  decision_proceduret::resultt result=interpolator.infer();
  if(result!=decision_proceduret::D_UNSATISFIABLE)
  {
#ifdef DEBUG
    std::cout << "The wordlevel interpolator failed." << std::endl;
    for(wordlevel_factst::const_iterator f_it=facts.begin();
        f_it!=facts.end(); ++f_it)
    {
      const wordlevel_factt &fact=*f_it;
      std::cout << fact.partition << ": " 
                << from_expr(ns, "", fact.expression) << std::endl;
    } 
#endif
    return result;
  }
  
  expr_listt interpolant_list;
  interpolator.get_interpolants(interpolant_list);
  
  interpolants.resize(interpolant_list.size());
  
  wordlevel_factt::partitiont partition=0;
  for(expr_listt::iterator i_it=interpolant_list.begin();
      i_it!=interpolant_list.end(); ++i_it, partition++)
  {
    interpolants[partition].swap(*i_it);
  }
  
#ifdef DEBUG
  for(partition=0; partition<interpolants.size(); partition++)
    std::cout << "Partial interpolant for partition " << partition 
              << " is "
              << from_expr(ns, "", interpolants[partition]) << std::endl;
#endif

  return decision_proceduret::D_UNSATISFIABLE;
}


/*******************************************************************\

Function: liftert::generate_smt_proof

  Inputs: 

 Outputs: 

 Purpose: Runs an SMT-like decision procedure (assuming that
          all blocking clauses correspond to unsatisfiable
          theory conjunctions). Returns a corresponding annotated
          resolution proof.

\*******************************************************************/
decision_proceduret::resultt liftert::generate_smt_proof(
  partial_interpolantst& interpolants)
{
  proof_generator.solver.new_variables(max_skeleton_literal);

  // now make sure we don't miss out on new Tseitin literals and clauses!
  log_sat=true;
  add_skeleton(proof_generator);
  log_sat=false;

  while(proof_generator.dec_solve()!=decision_proceduret::D_UNSATISFIABLE)
  {
    exprt blocking_expression(ID_or, bool_typet());
    bvt blocking_clause;

    // get the satisfying assignment for the skeleton literals
    for(literal_mapt::const_iterator l_it=literal_map.begin();
        l_it!=literal_map.end(); ++l_it)
    {
      literalt literal=l_it->first;
      if(bit_blaster.solver.has_valid_proof() && 
         !bit_blaster.solver.is_in_core(literal))
        continue;

      tvt val=proof_generator.solver.l_get(literal);

      if(val.is_known())
      {
        exprt tmp("literal", typet(ID_bool));
        tmp.set("literal", integer2string(literal.get()));
        if(val.is_true())
        {
          tmp.negate();
          literal.invert();
        }
        blocking_expression.copy_to_operands(tmp);
        blocking_clause.push_back(literal);
      }
    }
    
    std::vector<exprt> &partial=interpolants[blocking_clause];
    decision_proceduret::resultt verdict=    
      lift_blocking_clause(blocking_clause, partial);

    if(verdict!=decision_proceduret::D_UNSATISFIABLE)
      return verdict;

    // add blocking clause
    proof_generator.set_to_true(blocking_expression);
    blocking_clauses.insert(blocking_clause);
  }

  return decision_proceduret::D_UNSATISFIABLE;
}

/*******************************************************************\

Function: liftert::get_partition_type

  Inputs: 

 Outputs: 

 Purpose: Determines to which partition a literal belongs

\*******************************************************************/
bitlevel_informationt::partition_typet 
liftert::get_partition_type(
  const literalt& literal, wordlevel_factt::partitiont threshold)
{
  colour_ranget range=get_partition_range(literal);
  
  if(range.first<threshold && range.second<threshold)
    return bitlevel_informationt::A_LOCAL;
  
  if(range.first>=threshold && range.second>=threshold)
    return bitlevel_informationt::B_LOCAL;

  return bitlevel_informationt::SHARED;
}

/*******************************************************************\

Function: prop_interpolatort::prop_interpolatort

  Inputs: 

 Outputs: 

 Purpose: Constructor for the propositional interpolator

\*******************************************************************/
prop_interpolatort::prop_interpolatort(const namespacet &_ns):
  ns(_ns), maximal_partition(0), 
  proof_lifting(true), weak_interpolants(false),
  lifter(ns, proof), 
  strong_interpolation_system(ns, lifter),
  weak_interpolation_system(ns, lifter)
{
}

/*******************************************************************\

Function: prop_interpolatort::set_maximal_partition

  Inputs: The highest partition number

 Outputs: 

 Purpose: Stores the highest partition number

\*******************************************************************/
void prop_interpolatort::set_maximal_partition(
  wordlevel_factt::partitiont partition)
{
  assert(partition>=maximal_partition);

  maximal_partition=partition;
  lifter.set_maximal_partition(maximal_partition);
}


/*******************************************************************\

Function: prop_interpolatort::add_formula

  Inputs: A list of partitions (conjunctions of facts)

 Outputs: 

 Purpose: Adds the partitions to the fact database and numbers
          them (starting with zero by default).

\*******************************************************************/
void prop_interpolatort::add_formulas
(const expr_listt& formulas,
 wordlevel_factt::partitiont partition)
{
  for (expr_listt::const_iterator e_it=formulas.begin();
       e_it!=formulas.end(); e_it++, partition++)
  {
    add_formula(*e_it, partition);
  }
}

/*******************************************************************\

Function: prop_interpolatort::add_formula

  Inputs: A wordlevel fact and a partition number

 Outputs: 

 Purpose: Adds fact to the fact database

\*******************************************************************/
void prop_interpolatort::add_formula
(const exprt& formula, wordlevel_factt::partitiont partition)
{
#ifdef DEBUG
  std::cout << "Adding " << from_expr(ns, "", formula) << std::endl;
#endif 

  maximal_partition=std::max(maximal_partition, partition);
  lifter.add_formula(formula, partition);
}

/*******************************************************************\

Function: prop_interpolatort::add_fact

  Inputs: A wordlevel fact

 Outputs: 

 Purpose: 

\*******************************************************************/
void prop_interpolatort::add_fact(
  const wordlevel_factt& fact)
{
  add_formula(fact.expression, fact.partition);
}

/*******************************************************************\

Function: prop_interpolatort::infer

  Inputs: 

 Outputs: 

 Purpose: Returns D_UNSATISFIABLE if a contradiction can be inferred,
          D_SATISFIABLE if the formula is satisfiable, and D_ERROR
          if the formula is unsatisfiable but we can't construct
          a resolution proof or the wordlevel interpolator fails 
          to derive a contradiction.

\*******************************************************************/
decision_proceduret::resultt prop_interpolatort::infer()
{
  return lifter.lift(proof_lifting, partial_interpolants);
}

/*******************************************************************\

Function: mcmillan_interpolation_systemt::get_partial_interpolant

  Inputs: 

 Outputs: 

 Purpose: Generates partial interpolants for initial nodes
          using McMillan's standard interpolation system

\*******************************************************************/
exprt mcmillan_interpolation_systemt::get_partial_interpolant(
  const bvt& clause, wordlevel_factt::partitiont threshold,
  wordlevel_factt::partitiont clause_partition)
{
  wordlevel_factt::partitiont partition;
  bool not_found=bitlevel_information.get_partition(clause, partition);
  assert(!not_found);

  if(partition>=threshold) // This clause stems from B-partition
    return true_exprt();
  
  exprt result(ID_or, typet(ID_bool));

  for(bvt::const_iterator c_it=clause.begin();
      c_it!=clause.end(); ++c_it)
  {
    literalt literal=*c_it;

    if(bitlevel_information.get_partition_type(literal, threshold)
       !=bitlevel_informationt::A_LOCAL)
    {
      exprt atom=
        bitlevel_information.map_to_wordlevel(literal, not_found).expression;
      if(not_found)
      {
        literal.invert();
        atom=bitlevel_information.map_to_wordlevel(
          literal, not_found).expression;
        atom.negate();
        assert(!not_found);
      }
      result.copy_to_operands(atom);
    }
  }

  if(!result.has_operands())
  {
    result.make_false();
  }
  else if(result.operands().size()==1)
  {
    exprt tmp=result.op0();
    result.swap(tmp);
  }
  else
  {
    simplify(result, ns);
  }
  
  return result;
}

/*******************************************************************\

Function: mcmillan_interpolation_systemt::get_partial_interpolant

  Inputs: A pivot literal, a threshold, two partial interpolants

 Outputs: 

 Purpose: Generates partial interpolants for internal nodes
          using McMillan's standard interpolation system

\*******************************************************************/
exprt mcmillan_interpolation_systemt::get_partial_interpolant(
  const literalt& pivot, wordlevel_factt::partitiont threshold,
  exprt &pos_pi, exprt &neg_pi)
{
  if(bitlevel_information.get_partition_type(pivot, threshold)==
     bitlevel_informationt::A_LOCAL)
  {
    if(pos_pi.is_true() || neg_pi.is_true())
      return true_exprt();
    else if(pos_pi.is_false())
      return neg_pi;
    else if(neg_pi.is_false())
      return pos_pi;
    else
    {
      binary_exprt disjunction(pos_pi, ID_or, neg_pi, bool_typet());
      simplify(disjunction, ns);
      return disjunction;
    }
  }
  else
  {
    if(pos_pi.is_false() || neg_pi.is_false())
      return false_exprt();
    else if(pos_pi.is_true())
      return neg_pi;
    else if(neg_pi.is_true())
      return pos_pi;
    else
    {
      binary_exprt conjunction(pos_pi, ID_and, neg_pi, bool_typet());
      simplify(conjunction, ns);
      return conjunction;
    }
  }
}

/*******************************************************************\

Function: inv_mcmillan_interpolation_systemt::get_partial_interpolant

  Inputs: 

 Outputs: 

 Purpose: Generates partial interpolants for initial nodes using
          McMillan's inverse interpolation system

\*******************************************************************/
exprt inv_mcmillan_interpolation_systemt::get_partial_interpolant(
  const bvt& clause, wordlevel_factt::partitiont threshold,
  wordlevel_factt::partitiont clause_partition)
{
  wordlevel_factt::partitiont partition;
  bool not_found=bitlevel_information.get_partition(clause, partition);
  assert(!not_found);

  if(partition<threshold) // This clause stems from A-partition
    return false_exprt();

  exprt result(ID_or, typet(ID_bool));

  for(bvt::const_iterator c_it=clause.begin();
      c_it!=clause.end(); ++c_it)
  {
    literalt literal=*c_it;

    if(bitlevel_information.get_partition_type(literal, threshold)
       !=bitlevel_informationt::B_LOCAL)
    {
      exprt atom=
        bitlevel_information.map_to_wordlevel(literal, not_found).expression;
      if(not_found)
      {
        literal.invert();
        atom=bitlevel_information.map_to_wordlevel(
          literal, not_found).expression;
        atom.negate();
        if(not_found)
        {
          std::cout << "Not found " << literal.var_no() << " , " << literal.get() << std::endl;
          literal.invert();
          colour_ranget range=bitlevel_information.get_partition_range(literal);
          std::cout << threshold << ":[ " << range.first << "," << range.second << "]\n";
          assert(false);
        }
      }
      result.copy_to_operands(atom);
    }
  }

  if(!result.has_operands())
  {
    result.make_true();
  }
  else if(result.operands().size()==1)
  {
    exprt tmp=result.op0();
    result.swap(tmp);
    result.negate();
  }
  else
  {
    result.negate();
    simplify(result, ns);
  }
  
  return result;
}

/*******************************************************************\

Function: inv_mcmillan_interpolation_systemt::get_partial_interpolant

  Inputs: A pivot literal, a threshold, two partial interpolants

 Outputs: 

 Purpose: Generates partial interpolants for internal nodes using
          McMillan's inverse interpolation system

\*******************************************************************/
exprt inv_mcmillan_interpolation_systemt::get_partial_interpolant(
  const literalt& pivot, wordlevel_factt::partitiont threshold,
  exprt &pos_pi, exprt &neg_pi)
{
  if(bitlevel_information.get_partition_type(pivot, threshold)!=
     bitlevel_informationt::B_LOCAL)
  {
    if(pos_pi.is_true() || neg_pi.is_true())
      return true_exprt();
    else if(pos_pi.is_false())
      return neg_pi;
    else if(neg_pi.is_false())
      return pos_pi;
    else
    {
      binary_exprt disjunction(pos_pi, ID_or, neg_pi, bool_typet());
      simplify(disjunction, ns);
      return disjunction;
    }
  }
  else
  {
    if(pos_pi.is_false() || neg_pi.is_false())
      return false_exprt();
    else if(pos_pi.is_true())
      return neg_pi;
    else if(neg_pi.is_true())
      return pos_pi;
    else
    {
      binary_exprt conjunction(pos_pi, ID_and, neg_pi, bool_typet());
      simplify(conjunction, ns);
      return conjunction;
    }
  }
}

/*******************************************************************\

Function: prop_interpolatort::resolve

  Inputs: Two clauses and a pivot, and a target clause

 Outputs: 

 Purpose: Resolves two clauses. Returns 0 if the pivot occurs
          positively in the first clause, 1 if the pivot occurs
          positively in the second clause, and a value >1 on error.
          

\*******************************************************************/
unsigned prop_interpolatort::resolve(
  const bvt &left, const bvt &right, unsigned pivot, bvt &target)
{
  const literalt pos_piv(pivot, false), neg_piv(pivot, true);
  std::set<literalt> resolvent;
  unsigned verdict=(unsigned)-1;

  bvt::const_iterator p_it, n_it;

  const bvt* pos_clause;
  const bvt* neg_clause;

  p_it=find(left.begin(), left.end(), pos_piv);
  n_it=find(right.begin(), right.end(), neg_piv);

  if(p_it!=left.end() && n_it!=right.end())
  {
    pos_clause=&left; neg_clause=&right; verdict=0;
  }
  else
  {
    p_it=find(right.begin(), right.end(), pos_piv);
    n_it=find(left.begin(), left.end(), neg_piv);

    assert(n_it!=left.end() && p_it!=right.end());

    pos_clause=&right; neg_clause=&left; verdict=1;
  }
  
  resolvent.insert(pos_clause->begin(), p_it);
  resolvent.insert(++p_it, pos_clause->end());
  resolvent.insert(neg_clause->begin(), n_it);
  resolvent.insert(++n_it, neg_clause->end());
  
  target.clear();
  target.insert(target.end(), resolvent.begin(), resolvent.end());

  return verdict;
}

/*******************************************************************\

Function: prop_interpolatort::get_partial_interpolant

  Inputs: A node number and a partition

 Outputs: 

 Purpose: The partial interpolant and the clause for the node

\*******************************************************************/
exprt prop_interpolatort::get_partial_interpolant(
  unsigned node, wordlevel_factt::partitiont threshold)
{
  bool not_found;
  propositional_prooft::vertext &vertex=proof.proof_tree[node];

  // check cache
  interpolant_cachet::const_iterator it=partial_interpolant_cache.find(node);
  if(it!=partial_interpolant_cache.end())
    return it->second;

  if(vertex.is_leaf)
  {
    bvt &clause=proof.proof_tree.clauses[node];
    liftert::partial_interpolantst::const_iterator p_it=
      partial_interpolants.find(clause);

    if(p_it!=partial_interpolants.end())
    {
      assert(lifter.is_blocking_clause(clause));
      return (p_it->second)[threshold-1];
    }
    
    wordlevel_factt::partitiont partition;
    not_found=lifter.get_partition(clause, partition);
    assert(!not_found);

    exprt result=(weak_interpolants?
                  weak_interpolation_system.get_partial_interpolant(
                    clause, threshold, partition):
                  strong_interpolation_system.get_partial_interpolant(
                    clause, threshold, partition));
    //store in chache
    partial_interpolant_cache[node]=result;
    return result;
  }

  /* otherwise: internal node */
  assert(vertex.out.size()==2);

  exprt interpolants[2];
  unsigned count=0;
  unsigned pos=-1, neg=-1;

  propositional_prooft::proof_treet::edgest::const_iterator e_it;
  for(e_it=vertex.out.begin(); e_it!=vertex.out.end(); ++e_it, count++)
  {
    unsigned predecessor=e_it->first;
    interpolants[count]=
      get_partial_interpolant(predecessor, threshold); 
    if(e_it->second.positive)
      pos=count;
    else
      neg=count;
  }

  assert(pos<2 && pos==((neg+1)%2));

  const literalt pivot_literal(vertex.pivot, false);
  exprt result=(weak_interpolants?
                weak_interpolation_system.get_partial_interpolant(
                  pivot_literal, threshold, 
                  interpolants[pos], interpolants[neg]):
                strong_interpolation_system.get_partial_interpolant(
                  pivot_literal, threshold, 
                  interpolants[pos], interpolants[neg]));
  //store in chache
  partial_interpolant_cache[node]=result;
  return result;
}

/*******************************************************************\

Function: prop_interpolatort::get_interpolant

  Inputs: 

 Outputs: 

 Purpose: 

\*******************************************************************/
void prop_interpolatort::get_interpolant
(wordlevel_factt::partitiont threshold, exprt& interpolant_expression)
{
#ifdef DEBUG
  // proof.output(std::cout); std::cout << std::endl;
#endif
  
  partial_interpolant_cache.clear();
  interpolant_expression=
    get_partial_interpolant(proof.proof_tree.sink, threshold);

  simplify(interpolant_expression, ns);
}

/*******************************************************************\

Function: prop_interpolatort::get_interpolants

  Inputs: 

 Outputs: 

 Purpose: 

\*******************************************************************/
void prop_interpolatort::get_interpolants(expr_listt& expressions)
{
  for (unsigned threshold=1; threshold<=maximal_partition; threshold++)
  {
    expressions.push_back(exprt());
    get_interpolant (threshold, expressions.back());
  }
}

