/*******************************************************************\

Module: Interface for proof-logging Minisat

Author: Georg Weissenbacher, georg@weissenbacher.name

Info:   Extracts a resolution proof from Minisat

\*******************************************************************/

#ifndef CPROVER_PROOF_LOGGING_H
#define CPROVER_PROOF_LOGGING_H

#include <solvers/sat/satcheck.h>

#include <hash_cont.h>
#include <graph.h>

#include <util/decision_procedure.h>
#include <solvers/sat/satcheck_minisat.h>

/*******************************************************************\

 Propositional proof data structure

\*******************************************************************/

class propositional_prooft
{
public:
  propositional_prooft(): invalid(false), has_sink(false) { }
  bool is_valid() { return (has_sink && !invalid); }

  class proof_edget
  {
  public:
    bool positive;
  };

  class vertext: public graph_nodet<proof_edget>
  {
  public:
    bool     is_leaf;
    unsigned pivot;

    vertext(): is_leaf(false) { }
  }; 

  class proof_treet: public graph<vertext>
  {
  public:
    typedef hash_map_cont<unsigned, bvt> clausest;
    clausest clauses;

    unsigned sink;
  };

  proof_treet proof_tree;

  void invalidate() { invalid=true; }
  void set_sink(unsigned sink) { proof_tree.sink=sink; has_sink=true; }

  void output(std::ostream&);

protected:
  bool invalid;
  bool has_sink;
};

/*******************************************************************\

 Proof- and core-generating SAT solvers

\*******************************************************************/

class satcheck_proof_loggingt: public satcheck_minisatt
{
public:
  satcheck_proof_loggingt(propositional_prooft&);
  virtual ~satcheck_proof_loggingt();

  bool has_valid_proof() { return propositional_proof.is_valid(); }
  
protected:
  propositional_prooft &propositional_proof;
  class proof_traversert *proof_traverser;
  class Proof *minisat_proof;
};

class satcheck_coret: public satcheck_proof_loggingt
{
public:
  satcheck_coret(propositional_prooft& proof):
    satcheck_proof_loggingt(proof)
  {
  }
  
  virtual ~satcheck_coret() { }

  virtual resultt prop_solve();

  virtual bool is_in_core(literalt &l) const
  {
    assert(l.var_no()<core.size());
    return core[l.var_no()];
  }

protected:
  std::vector<bool> core;  

  void construct_core();
}; 

#endif
