/*******************************************************************\

Module: Proof logging routines for Minisat

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include "proof_logging.h"

// Minisat headers
#ifndef SATCHECK_MINISAT1
#error WOLVERINE REQUIRES PROOF-LOGGING MINISAT v1.14
#else
#include <Solver.h>
#include <Proof.h>
#endif

//#define DEBUG

class proof_traversert: public ProofTraverser
{
public:
  proof_traversert(propositional_prooft &proof):
    propositional_proof(proof)
  { 
  }

  virtual void root(const vec<Lit>&);
  virtual void chain(const vec<ClauseId>&, const vec<Var>&);
  virtual void deleted(ClauseId);
  virtual void done();

protected:
  propositional_prooft &propositional_proof;
  std::vector<unsigned> clause_indices;

  unsigned resolve(const bvt&, const bvt&, unsigned, bvt&);
};

/*******************************************************************\

Function: satcheck_proof_loggingt::satcheck_proof_loggingt

  Inputs: 

 Outputs: 

 Purpose: Constructor for proof-logger.

\*******************************************************************/
satcheck_proof_loggingt::satcheck_proof_loggingt(
  propositional_prooft &proof):
  propositional_proof(proof)
{
  proof_traverser=new proof_traversert(propositional_proof);
  minisat_proof=new Proof(*proof_traverser);
  solver->proof=minisat_proof;
}

/*******************************************************************\

Function: satcheck_proof_loggingt::~satcheck_proof_loggingt

  Inputs: 

 Outputs: 

 Purpose: Destructor for proof-logger.

\*******************************************************************/
satcheck_proof_loggingt::~satcheck_proof_loggingt()
{
  delete minisat_proof;
  delete proof_traverser;
}

/*******************************************************************\

Function: satcheck_coret::construct_core

  Inputs: 

 Outputs: 

 Purpose: Generates the vector that indicates which literals
          are in the core

\*******************************************************************/
void satcheck_coret::construct_core()
{
  assert(has_valid_proof());
  core.resize(no_variables(), false);

  std::stack<unsigned> worklist;
  worklist.push(propositional_proof.proof_tree.sink);

  std::vector<bool> seen;
  seen.resize(propositional_proof.proof_tree.clauses.size(), false);

  assert(propositional_proof.proof_tree.clauses.size()==
         propositional_proof.proof_tree.size());

  while(!worklist.empty())
  {
    unsigned index=worklist.top(); 
    worklist.pop();

    if(seen[index])
      continue;
    seen[index]=true;
    
    const propositional_prooft::vertext &vertex=
      propositional_proof.proof_tree[index];

    if(!vertex.is_leaf)
    {
      assert(vertex.out.size()==2);

      core[vertex.pivot]=true;
      propositional_prooft::proof_treet::edgest::const_iterator e_it;
      for(e_it=vertex.out.begin(); e_it!=vertex.out.end(); ++e_it)
      {
        const unsigned predecessor=e_it->first;
        assert(predecessor>=0 && predecessor<index);
        worklist.push(predecessor);
      }
    }
  }
}

/*******************************************************************\

Function: satcheck_coret::prop_solve

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

propt::resultt satcheck_coret::prop_solve()
{
  propt::resultt verdict;

  verdict=satcheck_proof_loggingt::prop_solve();

  if(status==UNSAT && has_valid_proof())
  {
    construct_core();
  }

  return verdict;
}

/*******************************************************************\

Function: propositional_prooft::output

  Inputs: 

 Outputs: 

 Purpose: Pretty-prints a wordlevel proof to the given stream

\*******************************************************************/
void propositional_prooft::output(std::ostream &out)
{
  proof_treet::clausest::const_iterator it;

  for(it=proof_tree.clauses.begin(); it!=proof_tree.clauses.end(); ++it)
  {
    out << it->first << ":= ";
    const bvt &clause=it->second;
    for(bvt::const_iterator l_it=clause.begin(); 
        l_it!=clause.end(); ++l_it)
    {
      const literalt literal=*l_it;
      out << (literal.sign()?"-":"") << literal.var_no() << " ";
    }
    if (proof_tree[it->first].is_leaf)
      out << "(leaf)";
    out << std::endl;
  }

  out << "Sink: " << proof_tree.sink << std::endl;
  proof_tree.output_dot(out);
}

/*******************************************************************\

Function: proof_traversert::resolve

  Inputs: Two clauses and a pivot, and a target clause

 Outputs: 

 Purpose: Resolves two clauses. Returns 0 if the pivot occurs
          positively in the first clause, 1 if the pivot occurs
          positively in the second clause, and a value >1 on error.
          

\*******************************************************************/
unsigned proof_traversert::resolve(
  const bvt &left, const bvt &right, unsigned pivot, bvt &target)
{
  const literalt pos_piv(pivot, false), neg_piv(pivot, true);
  std::set<literalt> resolvent;
  unsigned verdict=(unsigned)-1;

  bvt::const_iterator p_it, n_it;

  const bvt* pos_clause;
  const bvt* neg_clause;

  p_it=find(left.begin(), left.end(), pos_piv);
  n_it=find(right.begin(), right.end(), neg_piv);

  if(p_it!=left.end() && n_it!=right.end())
  {
    pos_clause=&left; neg_clause=&right; verdict=0;
  }
  else
  {
    p_it=find(right.begin(), right.end(), pos_piv);
    n_it=find(left.begin(), left.end(), neg_piv);

    if(n_it==left.end() || p_it==right.end())
      return (unsigned)-1;

    pos_clause=&right; neg_clause=&left; verdict=1;
  }
  
  resolvent.insert(pos_clause->begin(), p_it);
  resolvent.insert(++p_it, pos_clause->end());
  resolvent.insert(neg_clause->begin(), n_it);
  resolvent.insert(++n_it, neg_clause->end());
  
  target.clear();
  target.insert(target.end(), resolvent.begin(), resolvent.end());

  return verdict;
}

/*******************************************************************\

Function: proof_traversert:root

  Inputs: 

 Outputs: 

 Purpose: Called by Minisat if a clause is introduced.

\*******************************************************************/
void proof_traversert::root(const vec<Lit>& minisat_clause)
{
  unsigned index=propositional_proof.proof_tree.add_node();
  clause_indices.push_back(index);

  propositional_proof.proof_tree[index].is_leaf=true;
  bvt &clause=propositional_proof.proof_tree.clauses[index];
  clause.resize(minisat_clause.size());

  for(int position=0; position<minisat_clause.size(); position++)
  {
    clause[position]=
      literalt(var(minisat_clause[position]), 
               sign(minisat_clause[position]));
  }
}

/*******************************************************************\

Function: proof_traversert:chain

  Inputs: 

 Outputs: 

 Purpose: Called by Minisat if a chain of resolution steps is
          performed.

\*******************************************************************/
void proof_traversert::chain(
  const vec<ClauseId> &clauses, const vec<Var> &pivots)
{
  propositional_prooft::proof_treet &tree=propositional_proof.proof_tree;

  assert(pivots.size()>0);

  assert(clauses[0]>=0 && 
         ((unsigned)clauses[0])<clause_indices.size());
  unsigned antecedent0=clause_indices[(unsigned)clauses[0]];

  assert(pivots.size()>0);

  unsigned current;

  for(unsigned step=0; step<(unsigned)pivots.size(); step++)
  {
    assert(clauses[step+1]>=0 && 
           ((unsigned)clauses[step+1])<clause_indices.size());
    unsigned antecedent1=clause_indices[(unsigned)clauses[step+1]];

    // now generate new node
    current=tree.add_node();
    const unsigned pivot=pivots[step];
    propositional_prooft::vertext &vertex=tree[current];
    vertex.pivot=pivot;
    
    bvt &resolvent=tree.clauses[current];
    unsigned verdict=resolve(
      tree.clauses[antecedent0],
      tree.clauses[antecedent1],
      pivot, resolvent);

    if(verdict>1)
    {
#ifdef DEBUG
      std::cout << "Invalid resolution step at node " << current << std::endl;
#endif 
      propositional_proof.invalidate();
    }
    else if(resolvent.empty())
    {
      propositional_proof.set_sink(current);
    }

    assert(antecedent0<current && antecedent1<current);

    vertex.out[antecedent0].positive=(verdict==0);
    vertex.out[antecedent1].positive=(verdict==1);

    antecedent0=current;
  }

  // remember last index
  clause_indices.push_back(current);
}

/*******************************************************************\

Function: proof_traversert:deleted

  Inputs: 

 Outputs: 

 Purpose: Called by Minisat if a clause is deleted

\*******************************************************************/
void proof_traversert::deleted(ClauseId id)
{
}

/*******************************************************************\

Function: proof_traversert:done

  Inputs: 

 Outputs: 

 Purpose: Called by Minisat if the proof construction is finished

\*******************************************************************/
void proof_traversert::done()
{
#ifdef DEBUG
  std::cout << "Proof construction completed " 
            << (propositional_proof.is_valid()?
                "successfully":"unsucessfully") << std::endl;
#endif
}
