/*******************************************************************\

Module: validity checker princess for Wolverine's implication check

Author: Angelo Brillout, bangelo@inf.ethz.ch

\*******************************************************************/

#include <sstream>

#include "piped_process.h"
#include "princess_dec.h"
#include "princess_interface.h"


piped_processt* princess_instancet::princess_process = 0;

princess_instancet::~princess_instancet()
{
  // not clear whether this is actually ever executed ...
  //princess_process.write("quit.\n");
}

piped_processt& princess_instancet::get_process() {
  if (!princess_process)
    princess_process =
      new piped_processt(PRINCESS_COMMAND, vector<string>());
  return *princess_process;
}

void princess_dect::set_to_false(const exprt &expr)
{
  problem.flush();
  PrincessLineariser lineariser(problem, ns);

  problem << "\\problem {";
  problem << "(";
  lineariser.lineariseFormula(expr);
  problem << ")";
  problem << " | !(" << endl;
  lineariser.printVariableRanges();
  problem << ")";

  problem << "\n}\n";
  lineariser.printVariableDecls();

}

decision_proceduret::resultt princess_dect::dec_solve()
{
  piped_processt& princess_process = get_process();

  cout << "Sending decision problem to Princess ... " << endl;
  cout.flush();

  princess_process.write(problem.str());
  princess_process.write("\ncheckValidity.\n");

  //  cout << "Linearised problem: " << endl << problem.str() << endl;

  const string verdict = princess_process.read_line();
  if (verdict == "INVALID") {
    cout << "sat" << endl;
    while (princess_process.read_line() != ".");
    return  decision_proceduret::D_SATISFIABLE;
  }
  else if(verdict == "VALID") {
    cout << "unsat" << endl;
    while (princess_process.read_line() != ".");
    return  decision_proceduret::D_UNSATISFIABLE;
  }
  else
    throw "Error while checking validity with princess";
}

void princess_sat_dect::set_to_false(const exprt &expr)
{
  use_princess = contains_quantifier(expr);

  //cout << "CONTAINS QUANTIFIERS: " << use_princess << endl;

  //still some problems with quantifiers and SAT so we inhibit the choice of the solver
  use_princess = true;

  if(use_princess) return princess_dect::set_to_false(expr);

  //princess_dect::set_to_false(expr);
  //sat_checker.set_to_false(expr);
}

decision_proceduret::resultt princess_sat_dect::dec_solve()
{
  if(use_princess) return princess_dect::dec_solve();
  else return sat_checker.dec_solve();

  /*
  decision_proceduret::resultt princess_result = princess_dect::dec_solve();
  decision_proceduret::resultt sat_checker_result = sat_checker.dec_solve();

  if(sat_checker_result==decision_proceduret::D_TAUTOLOGY)
    sat_checker_result=decision_proceduret::D_SATISFIABLE;

  cout << sat_checker_result << " " << princess_result << endl;

  if(sat_checker_result!=princess_result)
    throw "Result mismatch";

  cout << "Results match" << endl;
  return sat_checker_result;
  */
}

bool princess_sat_dect::contains_quantifier(const exprt& expr)
{
  std::stack<const exprt*> stack;

  stack.push(&expr);

  while(!stack.empty())
  {
    const exprt& expr=*stack.top();
    stack.pop();

    if(expr.id()=="exists" || expr.id()=="forall") return true;

    forall_operands(it, expr) {
      if(expr.id()=="not" || expr.id()=="or" || expr.id()=="and")
        stack.push(&(*it));
    }
  }
  return false;

}
