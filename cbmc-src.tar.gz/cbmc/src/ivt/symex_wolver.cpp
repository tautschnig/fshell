/*******************************************************************\

Module: Interpolation Based Model Checking for ANSI-C

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include "symex_wolver.h"

/*******************************************************************\

Function: symex_bmct::symex_bmct

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

symex_wolvert::symex_wolvert(
  const namespacet &_ns,
  contextt &_new_context,
  symex_target_equationt &_equation):
  goto_symext(_ns, _new_context, _equation),
  equation(_equation)
{
  // turn off constant propagation -- it's not sound here
  constant_propagation=false;
}

/*******************************************************************\

Function: symex_wolvert::swap_target_equation

  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/

void symex_wolvert::swap_target_equation(
  symex_target_equationt &_equation)
{
  equation.SSA_steps.swap(_equation.SSA_steps);
}

/*******************************************************************\

Function: symex_wolvert::symex_step

  Inputs:

 Outputs:

 Purpose: show progress

\*******************************************************************/

void symex_wolvert::symex_step(
  const goto_functionst &goto_functions,
  statet &state)
{
  const locationt &location=state.source.pc->location;

  if(!location.is_nil() && last_location!=location)
  {
    print(9, "File "+location.get_string("file")+
             " line "+location.get_string("line")+
             " function "+location.get_string("function"));

    last_location=location;
  }

  // override ASSUME
  const goto_programt::instructiont &instruction=*state.source.pc;
  if(instruction.type!=ASSUME)
  {
    goto_symext::symex_step(goto_functions, state);
  }
  else
  {
    if(!state.guard.is_false())
    {
      exprt tmp(instruction.guard);

      replace_nondet(tmp);
      dereference(tmp, state, false);
      state.rename(tmp, ns);

      do_simplify(tmp);

      if(!tmp.is_true())
      {
        target.assumption(state.guard, tmp, state.source);
      }
    }
    state.source.pc++;
  }
}

/*******************************************************************\

Function: symex_wolvert::symex_steps

  Inputs:

 Outputs:

 Purpose: Makes symbolic execution steps until either an assertion 
          or a branching instruction is reached. Alternatively,
          it stops if a certain location is reached.
          Records the steps in the equation provided as last 
          argument. Returns true if the end of instructions is
          reached.

\*******************************************************************/

bool symex_wolvert::symex_step_until(
  const goto_functionst &goto_functions,
  statet &state,
  goto_programt::const_targett &end_of_instructions,
  symex_target_equationt &equation)
{
  swap_target_equation(equation); 

  do
  {
    goto_symext::symex_step(goto_functions, state);

    if (state.source.pc==end_of_instructions)
      break;

    const goto_programt::instructiont &instruction=*state.source.pc;
   
    if (instruction.type==GOTO ||
        instruction.type==ASSERT ||
        instruction.type==ASSUME ||
        instruction.type==FUNCTION_CALL ||
        instruction.type==RETURN)
      break;
  }
  while (true);

  swap_target_equation(equation);

  return (state.source.pc==end_of_instructions);
}

/*******************************************************************\

Function: symex_wolvert::symex_step_goto

  Inputs:

 Outputs:

 Purpose: Doesn't update the program counter of the state!

\*******************************************************************/

void symex_wolvert::symex_step_goto(
  statet &state,
  symex_target_equationt &equation,
  bool taken)
{
  swap_target_equation(equation); 
  goto_symext::symex_step_goto(state, taken);
  swap_target_equation(equation);
}

/*******************************************************************\

Function: symex_wolvert::symex_step_return

  Inputs:

 Outputs:

 Purpose: 

\*******************************************************************/

void symex_wolvert::symex_step_return(
  statet &state,
  symex_target_equationt &equation)
{
  swap_target_equation(equation); 
  goto_symext::symex_step_return(state);
  swap_target_equation(equation);
}


/*******************************************************************\

Function: symex_wolvert::symex_step

  Inputs:

 Outputs:

 Purpose: A single symex step

\*******************************************************************/

void symex_wolvert::symex_step(
  const goto_functionst &goto_functions,
  statet &state,
  symex_target_equationt &equation)
{
  swap_target_equation(equation); 
  symex_step(goto_functions, state);
  swap_target_equation(equation);
}

/*******************************************************************\

Function: symex_wolvert::get_function_name

  Inputs:

 Outputs:

 Purpose: Returns the name of the function called (stores
          the result in the last parameter). Returns false
          if successful, true otherwise.

\*******************************************************************/

bool symex_wolvert::get_function_name(
  const goto_programt::instructiont& instruction, statet& state,
  irep_idt& name)
{
  if(instruction.type!=FUNCTION_CALL)
    return true;

  // get the name of the function
  code_function_callt deref_code=
    to_code_function_call(instruction.code);

  dereference(deref_code.function(), state, false);

  if(deref_code.function().id()=="symbol")
  {
    name=deref_code.function().get("identifier");
    return false;
  }
  
  return true;
}

/*******************************************************************\

Function: symex_wolvert::get_function_name

  Inputs:

 Outputs:

 Purpose: Returns the name of the function called (stores
          the result in the last parameter). Returns false
          if successful, true otherwise.

\*******************************************************************/

bool symex_wolvert::get_assertion_guard(
  const goto_programt::instructiont& instruction, statet& state,
  exprt &guard)
{
  if(instruction.type!=ASSERT)
    return true;

  guard=instruction.guard;
  replace_nondet(guard);
  dereference(guard, state, false);

  return false;
}


/*******************************************************************\

Function: symex_wolvert::no_body

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void symex_wolvert::no_body(const irep_idt &identifier)
{
  if(body_warnings.insert(identifier).second)
  {
    std::string msg=
      "**** WARNING: no body for function "+id2string(identifier);

    print(2, msg);
  }
}
