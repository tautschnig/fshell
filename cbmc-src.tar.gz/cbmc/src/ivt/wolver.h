/*******************************************************************\

Module: Interpolation Based Model Checking for ANSI-C

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef CPROVER_WOLVER_H
#define CPROVER_WOLVER_H

#include <hash_cont.h>
#include <options.h>
#include <message.h>
#include <goto-symex/goto_symex.h>
#include <langapi/language_ui.h>
#include <goto-symex/symex_target_equation.h>
#include <goto-symex/goto_trace.h>
#include <goto-programs/safety_checker.h>

#include "program_unwinding.h"

class wolver_baset: public messaget
{
public:
  wolver_baset(
    const contextt &_context,
    symex_wolvert &_symex,
    symex_target_equationt &_equation,
    goto_program_unwindingt &_unwinding,
    message_handlert &_message_handler,
    optionst &_options):
    messaget(_message_handler),
    options(_options),
    context(_context),
    symex(_symex),
    equation(_equation),
    unwinding(_unwinding),
    ui(ui_message_handlert::PLAIN)
  { 
  }

  optionst &options;
  
  virtual safety_checkert::resultt fight();
  virtual ~wolver_baset() { }
  
  void set_ui(language_uit::uit _ui) { ui=_ui; }
  
protected:
  const contextt &context;
  symex_wolvert &symex;
  symex_target_equationt &equation;
  goto_program_unwindingt &unwinding;

  language_uit::uit ui;

  // unwinding
  virtual void setup_unwind();

  // threshold for path length and force cover
  virtual void setup_thresholds();

  // activate or deactivate path-slicing
  virtual void setup_path_slicing();

  // activate or deactivate report of invariants (on success)
  virtual void setup_invariant_printing();

  // interpolator
  virtual void setup_interpolator();

  // logging
  void start_logging();
  void stop_logging();

  //
  // depth first search methods
  //
  virtual bool unwind();
};

class wolvert: public wolver_baset
{
public:
  wolvert(
    const contextt &_context,
    const goto_functionst &_goto_functions,
    goto_tracet &_trace,
    message_handlert &_message_handler):
    wolver_baset(_context, _symex, _equation, _unwinding, 
                 _message_handler, wolver_options),
    ns(_context, shadow_context),
    _equation(ns),
    _symex(ns, shadow_context, _equation),
    _unwinding(ns, _symex, _goto_functions, _trace)
    {
    }

  wolvert(
    const contextt &_context,
    const goto_functionst &_goto_functions,
    goto_tracet &_trace,
    message_handlert &_message_handler,
    optionst &_options):
    wolver_baset(_context, _symex, _equation, _unwinding, 
                 _message_handler, _options),
    ns(_context, shadow_context),
    _equation(ns),
    _symex(ns, shadow_context, _equation),
    _unwinding(ns, _symex, _goto_functions, _trace)
    {
    }

protected:
  optionst wolver_options;
  contextt shadow_context;
  namespacet ns;
  symex_target_equationt _equation;
  symex_wolvert _symex;
  goto_program_unwindingt _unwinding;
};

class wolver_safety_checkert: public safety_checkert
{
public:
  wolver_safety_checkert(const namespacet &_ns):
    safety_checkert(_ns)
  {
  }

  virtual resultt operator()(
    const goto_functionst &goto_functions)=0;

  optionst options;
};

#endif
