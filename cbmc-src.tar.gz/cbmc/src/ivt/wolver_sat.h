/*******************************************************************\

Module: SAT solver for Wolverine's implication check

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef WOLVER_SAT_H
#define WOLVER_SAT_H

#include <solvers/sat/satcheck.h>
#include <solvers/flattening/bv_pointers.h>

class satcheck_wrappert
{
public:
  satcheckt satcheck;
};

class wolver_satcheckt:
  public satcheck_wrappert,
  public bv_pointerst
{
public:
  virtual const std::string description()
  { return "Wolverine's SAT checker"; }

  wolver_satcheckt(const namespacet& ns):bv_pointerst(ns, satcheck) { }
};

#endif
