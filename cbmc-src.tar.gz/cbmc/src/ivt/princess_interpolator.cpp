/*******************************************************************\

Module: Interface to the Princess tool for interpolation in
        Presburger arithmetic

Author: Philipp Ruemmer, ph_r@gmx.net

\*******************************************************************/

#include <map>
#include <cmath>

#include <config.h>
#include <simplify_expr.h>
#include <arith_tools.h>
#include <solvers/flattening/boolbv.h>
#include <solvers/flattening/boolbv_width.h>
#include <i2string.h>

#include <wordlevel_interpolator.h>

#include "path_interpolator.h"
#include "princess_interpolator.h"
#include "princess_interface.h"
#include "version.h"

#include <cstdio>

//#define DEBUG

using namespace std;


/*******************************************************************\
Function: princess_interpolatort::interpolate

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

decision_proceduret::resultt princess_interpolatort::interpolate(
    const goto_program_unwindingt::unwinding_stept &step,
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt &result)
{
  piped_processt& princess_process = get_process();

  expr_listt expressions;
  partition(step, condition, from_node, expressions);

  // cout << "Princess --------------------------------------" << endl;

  stringstream out;

  PrincessLineariser lineariser (out, ns);

  unsigned int i = 0;
  string sep = "";

  // Linearise the transition relations
  out << "\\problem {";

  for(expr_listt::const_iterator e_it=expressions.begin();
      e_it!=expressions.end(); ++e_it, ++i) {
    exprt tmp(*e_it);
    simplify(tmp, ns);

    out << sep << endl;
    sep = " &";

    lineariser.printPartHeader(i);
    out << "(";
    lineariser.lineariseFormula(tmp);
    out << ")";

    lineariser.incTransitionRelation();
  }
  // Assumptions about the variable ranges
  out << sep << endl;
  lineariser.printVariableRanges();
  out << "\n-> false";
  out << "\n}\n";
  lineariser.printVariableDecls();

  //  cout << "Lin result: " << out.str() << endl;

  cout << "Sending interpolation problem to Princess ("
       << ++callCount << ") ... " << endl;
  cout.flush();

  princess_process.write(out.str());
  princess_process.write("\ninterpolate.\n");

  // Read back the verdict
  const string verdict = princess_process.read_line();
  if (verdict == "INVALID") {
	  cout << "sat (" << ++satCount << ")" << endl;
	  // we currently just ignore the actual counterexample
	  while (princess_process.read_line() != ".");
	  return  decision_proceduret::D_SATISFIABLE;
  } else {

  assert(verdict == "VALID");

  // Read back the interpolants
  expr_listt interpolants;

  cout << "unsat" << endl;

  TypeAdjuster typeAdjuster(ns);
  string str;
  while (true) {
	  str = princess_process.read_line();
	  if (str == ".")
		  break;
	  cerr << "interpolant " << interpolants.size()
               << " (" << ++interpolantCount
               << "): " << str << endl;

	  PrincessFormulaParser parser(lineariser.symbolsFromLin, str);
	  exprt ip = parser.parse();
	  //cout << "Interpolant: " << ip.pretty(0) << endl;
	  typeAdjuster.adjust(ip);
	  //cout << "Type adjusted interpolant: " << ip.pretty(0) << endl;
	  //std::getchar();
	  interpolants.push_back(ip);
  }
  
  goto_program_unwindingt::unwinding_patht
    path=unwinding_graph.path_prefix(step.node);

  goto_program_unwindingt::unwinding_patht::iterator p_it=path.begin();

  for(expr_listt::reverse_iterator i_it=interpolants.rbegin();
      i_it!=interpolants.rend(); ++i_it, ++p_it)
    result[p_it.get_index()]=*i_it;
  
  return  decision_proceduret::D_UNSATISFIABLE;
  }
}






