/*******************************************************************\

Module: Slicing paths for Wolverine's refinement step.
        Extends symex_slicet, since the properties in Wolverine
        aren't always necessarily assertions.

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef WOLVER_SLICE_H
#define WOLVER_SLICE_H


#include <goto-symex/symex_slice_class.h>

class wolver_slicet: public symex_slicet
{
public:
  void slice(symex_target_equationt &equation, const exprt& property);

protected:
  void reset_ignore_flags(symex_target_equationt &equation);
};

void wolver_slice(symex_target_equationt &equation, const exprt& property);

#endif
