/*******************************************************************\

Module: Slicer for symex traces in Wolverine

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include "wolver_slice.h"

/*******************************************************************\

Function: wolver_slicet::slice

  Inputs:

 Outputs:

 Purpose: Flags assignments unrelated to the property as ignorable

\*******************************************************************/

void wolver_slicet::slice(
  symex_target_equationt &equation, const exprt &property)
{
  depends.clear();
  reset_ignore_flags(equation);

  get_symbols(property);

  for(symex_target_equationt::SSA_stepst::reverse_iterator
      it=equation.SSA_steps.rbegin();
      it!=equation.SSA_steps.rend();
      it++)
    symex_slicet::slice(*it);  
}

/*******************************************************************\

Function: wolver_slicet::slice

  Inputs:

 Outputs:

 Purpose: Resets all ignore flags to false

\*******************************************************************/

void wolver_slicet::reset_ignore_flags(
  symex_target_equationt &equation)
{
  for(symex_target_equationt::SSA_stepst::iterator
        it=equation.SSA_steps.begin();
      it!=equation.SSA_steps.end();
      it++)
  {
    it->ignore=false;
  }
}

/*******************************************************************\

Function: wolver_slice

  Inputs:

 Outputs:

 Purpose: Slices a path represented by an equation and sets
          the ignore flags of each step accordingly

\*******************************************************************/
void wolver_slice(symex_target_equationt &equation, 
                  const exprt& property)
{
  wolver_slicet wolver_slice;
  wolver_slice.slice(equation, property);
}
