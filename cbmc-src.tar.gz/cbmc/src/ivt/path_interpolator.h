/*******************************************************************\

Module: Interpolator interface

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name,
        Mark Kattenbelt, mark.kattenbelt@comlab.ox.ac.uk

\*******************************************************************/

#ifndef CPROVER_WOLVER_INTERPOLATOR_H
#define CPROVER_WOLVER_INTERPOLATOR_H

#include <iostream>
#include <streambuf>
#include <cstdio>

#include <sys/types.h>
#ifdef _MSC_VER
#include <io.h>
#else
#include <unistd.h>
#endif

#include <decision_procedure.h>
#include <hash_cont.h>
#include <namespace.h>

#include "program_unwinding.h"

/*******************************************************************\

  Class:   path_interpolatort

  Purpose: The general path interpolator interface

\*******************************************************************/

class path_interpolatort
{
public:
  typedef hash_map_cont<unsigned, exprt> interpolant_mapt;

  path_interpolatort(
    goto_program_unwindingt::unwinding_grapht& _graph,
    const namespacet& _ns):
    unwinding_graph(_graph),
    ns(_ns)
  {
  }

  virtual bool initialise() { return false; }

  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&,
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&)=0;

  virtual ~path_interpolatort() { }

  virtual void process_options(const optionst&) { }
  
protected:
  goto_program_unwindingt::unwinding_grapht &unwinding_graph;
  const namespacet &ns;
};

/*******************************************************************\

  Class:   wolver_interpolatort

  Purpose: The "built-in" interpolator of Wolverine

\*******************************************************************/

class wolver_interpolatort: public path_interpolatort
{
public:
  wolver_interpolatort(
    goto_program_unwindingt::unwinding_grapht &_graph,
    const namespacet &_ns):
    path_interpolatort(_graph, _ns),
    proof_lifting(true),
    weak_interpolants(false)
  {
  }

  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&, 
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&);

  virtual ~wolver_interpolatort() { }

  virtual void process_options(const optionst&);

protected:
  // parameters for interpolator
  bool proof_lifting;
  bool weak_interpolants;

  void partition(const goto_program_unwindingt::unwinding_stept&,
                 const exprt&, unsigned, expr_listt&);

  bool check_interpolants(const expr_listt&, const expr_listt&);
};

/*******************************************************************\

  Class:   smt_dummy_interpolatort

  Purpose: Based on the "built-in" interpolator, 
           also generates SMT files

\*******************************************************************/

class smt_dummy_interpolatort: public wolver_interpolatort
{
public:
  smt_dummy_interpolatort(
    goto_program_unwindingt::unwinding_grapht &_graph,
    const namespacet &_ns):
    wolver_interpolatort(_graph, _ns),
    file_count(0)
  {
  }
  
  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&, 
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&);

  virtual ~smt_dummy_interpolatort() { }

protected:
  unsigned file_count;
};

/*******************************************************************\

  Class:   pipe_streambuft

  Purpose: Stream buffer that encapsulates piped processes

\*******************************************************************/

#define READ_BUFFER_SIZE 1024

class pipe_streambuf: public std::streambuf
{
public:
  pipe_streambuf();

  // selectors and modifiers for file descriptors
  void in(int fd) { proc_in=fd; }
  void out(int fd) { proc_out=fd; }
  int in() { return proc_in; }
  int out() { return proc_out; }

  ~pipe_streambuf();

  
protected:
  int proc_in, proc_out;
  char_type in_buffer[READ_BUFFER_SIZE];

  int_type overflow(int_type);
  std::streamsize xsputn(const char*, std::streamsize);
  int_type underflow();
  std::streamsize xsgetn(char*, std::streamsize);
  std::streamsize showmanyc();
};

/*******************************************************************\

  Class:   external_processt

  Purpose: Run an external program/process and communicate with it

\*******************************************************************/

class external_processt: public std::iostream
{
public:
  external_processt(const std::string&, const std::list<std::string>&);
  int run(bool);
  int wait();

protected:
  std::string executable;
  std::list<std::string> arguments;
  pid_t pid;
  pipe_streambuf buffer;
};

/*******************************************************************\

  Class:   external_interpolatort

  Purpose: Interface for calling external interpolators

\*******************************************************************/

class external_interpolatort: public wolver_interpolatort
{
public:
  external_interpolatort(
    goto_program_unwindingt::unwinding_grapht&,
    const namespacet&);
  
  virtual decision_proceduret::resultt interpolate(
    const goto_program_unwindingt::unwinding_stept&, 
    const exprt& condition,
    unsigned from_node,
    interpolant_mapt&);

  virtual bool initialise();
  virtual void process_options(const optionst&);

  virtual ~external_interpolatort() { }

protected:
  typedef hash_map_cont<irep_idt, irep_idt, irep_id_hash> id_mapt;

  /* mapping internal namespace ids to external identifiers */
  id_mapt int2ext;
  id_mapt ext2int;

  virtual void translate(const expr_listt&)=0;
  virtual decision_proceduret::resultt solve()=0;
  virtual void read_interpolants(expr_listt&)=0;

  bool typecheck(exprt&);


};

/*******************************************************************\

  Function: select_interpolatort

  Purpose:  Selects a specific interpolator

\*******************************************************************/

path_interpolatort *select_interpolator(
  const std::string&,
  const optionst&,
  goto_program_unwindingt::unwinding_grapht&,
  const namespacet&);

#endif
