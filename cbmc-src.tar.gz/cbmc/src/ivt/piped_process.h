/*******************************************************************\

Module: Spawning an external process that communicates with the
        main process via pipelines

Author: Philipp Ruemmer, ph_r@gmx.net

\*******************************************************************/

#ifndef PIPED_PROCESS_H_
#define PIPED_PROCESS_H_

#include <string>
#include <vector>
#include <sys/types.h>

class piped_processt {

public:
	/**
	 * The constructor also starts up the process
	 */
	piped_processt(const std::string& cmd,
	               const std::vector<std::string>& arguments);

	virtual ~piped_processt();

	/**
	 * Write some data to the process
	 */
	void write(const std::string& data);

	/**
	 * Read a line of data from the external process
	 */
	std::string read_line();

private:
	pid_t proc_id;
	int proc_in, proc_out, proc_err;

	std::string in_buffer;

	void cleanup();
};

#endif /* PIPED_PROCESS_H_ */
