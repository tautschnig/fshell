#define ARRAY_SIZE 3
int a[ARRAY_SIZE];

int main(int argc, char **argv)
{

int a[ARRAY_SIZE], count_neg=0, count_pos=0, i;

for(i=0;i < ARRAY_SIZE; i++)
{
 if(a[i] < 0)
   count_neg++;
}

__CPROVER_assert(count_neg > ARRAY_SIZE, "");
}
