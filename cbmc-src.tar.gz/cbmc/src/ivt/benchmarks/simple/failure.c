#include <stdbool.h>

int x;

bool nondet_bool( void );

int  main( void );
void func( void );

int  main( void)
{
  x = 0;
  func();

  bool hello = 1;

  return 1;
}

void func( void)
{
  bool n;

  x=x+1;
  n=nondet_bool();
  
  if (x<=1)
  {
    if (n)
    {
      func();
      __CPROVER_assert(0, "target");
    }
  }  
  
  return;
}





