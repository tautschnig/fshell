void main(int argc, char** argv) {
   for (int i = 0; i < 1000; ++i)
     __CPROVER_assert(i >= 0, "");
__CPROVER_assert(i >= 0, "");
}
