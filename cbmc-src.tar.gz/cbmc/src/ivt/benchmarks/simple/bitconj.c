int main(int argc, char** argv)
{
  unsigned x, y;

  y=x;

  while(y!=0)
  {
    y=y&(y-1);
    __CPROVER_assert(y<=x, "BITWISE CONJUNCTION");
  }

  return 0;
}
