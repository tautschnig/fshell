struct try
{
  int x;
  char y;
};

#define SIZE 10

int main()
{
  struct try ar[SIZE];

  ar[0].x = 1;
  ar[0].y = 2;

  __CPROVER_assert(ar[0].x == 1,"yey!");
//  __CPROVER_assert(test.y != 4,"yey!");
}

