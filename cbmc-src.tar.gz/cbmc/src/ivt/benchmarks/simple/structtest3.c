#include <stdlib.h>

struct X {
  int x;
  int y;
};

int main(int argc, char *argv[]) {
    struct X *x = malloc(sizeof(struct X));
    x->x = 13;
    x->y = -5;
    __CPROVER_assert(x->x > x->y, "");
}
