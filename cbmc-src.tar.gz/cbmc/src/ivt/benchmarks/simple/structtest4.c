#include <stdlib.h>

struct X {
  int data;
  struct X* next;
};

int main(int argc, char *argv[]) {
    struct X *x = malloc(sizeof(struct X));
    x->data = 13;
    x->next = NULL;
    struct X *y = malloc(sizeof(struct X));

    y->next = x;
    y->data = 12;

    int sum = 0;
    struct X* node = y;
    while (node) {
      sum += node->data;
      node = node->next;
    }

    __CPROVER_assert(sum == 25, "");
}
