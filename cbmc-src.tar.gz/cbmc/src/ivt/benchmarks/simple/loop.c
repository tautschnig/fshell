int main()
{
  unsigned i, x;
  
  for (i=0; 
       i<5; 
       i++)
  {
    x++;
  }

  assert(i==5);
  return 0;
}
