int main(int argc, char **argv) {
  int ar[5] = {1, 2, 3, 4, 5};
  int br[5] = {1, 2, 3, 4, 5};
  int i = nondet_int();
  __CPROVER_assume(0<=i && i<=4);
  
  br[i]=9;

  int b = nondet_int();
  int c = nondet_int();
  __CPROVER_assume(0<=b && b<=4 && 0<=c && c<=4 && b!=c);
  __CPROVER_assert(ar[b]==br[b] || ar[c]==br[c] , "");
}
