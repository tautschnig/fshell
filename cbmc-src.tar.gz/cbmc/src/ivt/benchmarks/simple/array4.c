

int f(int i, int ar[]) {
  __CPROVER_assume(i >= 0);
  return ar[i];
}

int main(int argc, char **argv) {
  int ar[5];
  __CPROVER_assert(f(3, ar) == f(3, ar), "");
}
