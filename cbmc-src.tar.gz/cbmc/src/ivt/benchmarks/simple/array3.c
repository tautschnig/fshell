int a[20];

int main(int argc, char **argv)
{
  for (int i = 0; i < 5; ++i)
    a[i] = i;
 
  __CPROVER_assert(a[1]>0, "BOOM1");
}
