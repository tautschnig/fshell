

int main(int argc, char *argv[])
{

  int m = 0, n = 1;
  for (int k = 0; k < 10; ++k) {
    int t = n;
    n = m + n;
    m = t;
  }

  __CPROVER_assert(n == 89, "");
}
