

int main(int argc, char *argv[])
{
  unsigned int x = 123;

  unsigned int k = 1;
  unsigned int n = 0;
  while (x > 0) {
    if (x & k) {
      n = n + 1;
      x = x - k;
    }
    k = k * 2;
  }

  __CPROVER_assert(n == 6, "");
}
