int a[20];

unsigned nondet_int();

int main(int argc, char **argv)
{
  unsigned i0, i1, i2;

  i0=1;
  i1=2;
  i2=i0;

  a[i0]=12;
  a[i1]=3;
 
  if(nondet_int())
    __CPROVER_assert(a[1]==12, "BOOM1");
  else
    __CPROVER_assert(a[i2]==12, "BOOM2");
}
