unsigned nondet_uint();

int foo()
{
  int u=nondet_uint();
  if (u)
    foo();

  return u;
}

int main()
{
  unsigned a, b, c;
  unsigned x, y, z;

  if (a>b)
  {
    a=b;
    b=-c;
  } 

  a=foo();

  if (y<z)
  {
    x=y;
    __CPROVER_assert (x<z, "kaboom");
  }
 
  return 0;
}
