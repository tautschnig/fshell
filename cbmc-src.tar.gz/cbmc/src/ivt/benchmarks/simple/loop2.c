int main()
{
  unsigned i, x = 0;
  
  for (i=0; 
       i<1000; 
       i++)
  {
    assert(x==i);
    x++;
  }

//  assert(i==1000);
  return 0;
}
