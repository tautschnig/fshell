unsigned nondet();

int main()
{
  switch(nondet())
  {
  case 0:
  {
    unsigned a=nondet();
    unsigned b=(a>>2);
    __CPROVER_assert(a>=b, "Testing Shift-right Rule");
  }
  break;
  case 1:
  {
    unsigned a=nondet();
    unsigned b=(a<<1);
    __CPROVER_assert(b==a+a, "Testing Shift-left Rule");
  }
  default:
    break;
  }
  
  return 0;
}
