#define LEN 4
unsigned int a[LEN];

int nondet_int();

int main(int argc, char **argv)
{

  for (int i2 = 0; i2 < LEN; ++i2)
    a[i2] = nondet_int();

  int changed = 1;
  while (changed) {
    changed = 0;
    for (int i = 0; i < LEN - 1; ++i) {
      if (a[i] > a[i+1]) {
        unsigned int t = a[i];
        a[i] = a[i+1];
        a[i+1] = t;
        changed = 1;
      }
    }
  }

  unsigned k = nondet_int();
  __CPROVER_assume(0 <= k && k < LEN - 1);
  __CPROVER_assert(a[k] <= a[k+1], "BOOM");

}
