/**
 * Author: Mark Kattenbelt <mark.kattenbelt@comlab.ox.ac.uk>
 */ 

struct try
{
  int x;
  int y;
};

int main(int argc, char *argv[])
{
  struct try test;

  test.x = 0;
  test.y = 2;
  test.y = test.y + 2;

  __CPROVER_assert(test.x == 0,"yey!");
//  __CPROVER_assert(test.y != 4,"yey!");
}

