int a[4];

int main(int argc, char **argv)
{
  unsigned int i;
  __CPROVER_assume(i < 4);

  a[i] = 15;

  for (int j = 0; j < 4; ++j)
    if (a[j] == 15)
      return 0;

  __CPROVER_assert(0, "");
}
