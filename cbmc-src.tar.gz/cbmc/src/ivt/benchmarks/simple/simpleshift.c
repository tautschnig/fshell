unsigned nondet();

int main()
{
  unsigned a=nondet();
  unsigned b=(a>>2);
  __CPROVER_assert(a>=b, "Testing Shift-right Rule");

  return 0;
}
