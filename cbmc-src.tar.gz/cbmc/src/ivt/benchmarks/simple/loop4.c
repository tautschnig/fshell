void main(int argc, char** argv) {
   int i = 0;
   while (i < 1000)
     i = i + 1;
__CPROVER_assert(i <= 1000, "");
}
