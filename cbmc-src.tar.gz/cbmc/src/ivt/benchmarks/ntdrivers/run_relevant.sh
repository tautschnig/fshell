#!/bin/bash

rm -f *.out

./run.sh $@ kbfiltr.i > kbfiltr.i.out 2>&1
./run.sh $@ diskperf.i > diskperf.i.out 2>&1
./run.sh $@ cdaudio.i > cdaudio.i.out 2>&1
./run.sh $@ floppy.i > floppy.i.out 2>&1
./run.sh $@ parport.i > parport.i.out 2>&1
./run.sh $@ parclass.i > parclass.i.out 2>&1
