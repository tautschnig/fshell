#!/bin/sh
echo Running WOLVERINE without pointer and bounds check on $@

export WOLVERINE=../../wolverine

time $WOLVERINE --error-label ERROR --no-library --32 --i386-win32 $@ 


