#!/bin/bash

rm -f *.out

for a in *.i ; do
  ./run.sh $@ $a > $a.out 2>&1
done


