/*******************************************************************\

Module: "Built-in" interpolator of Wolverine

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name,
        Mark Kattenbelt, mark.kattenbelt@comlab.ox.ac.uk

\*******************************************************************/

#include <sstream>

#include <simplify_expr.h>
#include <solvers/smt1/smt1_dec.h>

#include <wordlevel_interpolator.h>
#include <builtin_interpolator.h>

#include "wolver_sat.h"
#include "wolver_slice.h"
#include "path_interpolator.h"
#include "version.h"

//#define DEBUG
#define CHECK_INTERPOLANTS

/*******************************************************************\

Function: wolver_interpolatort::process_options

  Inputs:

 Outputs:

 Purpose: Processes command-line options

\*******************************************************************/
void wolver_interpolatort::process_options(const optionst &options)
{
  proof_lifting=!options.get_bool_option("no-proof-lifting");
  weak_interpolants=options.get_bool_option("weak-interpolants");
}

/*******************************************************************\

Function: wolver_interpolatort::interpolate

  Inputs:

 Outputs:

 Purpose: Computes interpolants for an infeasible path.
          Returns decision_proceduret::D_UNSATISFIABLE if
          it successfully computed interpolants,
          decision_proceduret::D_SATISFIABLE if the formula
          is satisfiable, and D_ERROR if the formula is
          unsatisfiable but the interpolator fails to derive
          interpolants

\*******************************************************************/
decision_proceduret::resultt wolver_interpolatort::interpolate(
  const goto_program_unwindingt::unwinding_stept &step, 
  const exprt& condition,
  unsigned from_node,
  path_interpolatort::interpolant_mapt& result)
{
  decision_proceduret::resultt decision;
  expr_listt expressions;
  partition(step, condition, from_node, expressions);

  builtin_interpolatort interpolator(ns);
  // set parameters
  if(!proof_lifting)
    interpolator.deactivate_proof_lifting();
  if(weak_interpolants)
    interpolator.generate_weak_interpolants();

  /* add formulas in reverse order, 
     so contradictions occur earlier in the path */
  unsigned partition=expressions.size()-1;

  for(expr_listt::const_reverse_iterator e_it=expressions.rbegin();
      e_it!=expressions.rend(); ++e_it, --partition)
  {
    interpolator.add_formula(*e_it, partition);
  }

  decision=interpolator.infer();
  
  if(decision==decision_proceduret::D_UNSATISFIABLE)
  {
    expr_listt interpolants;
    interpolator.get_interpolants(interpolants);
    goto_program_unwindingt::unwinding_patht 
      path=unwinding_graph.path_prefix(step.node);

#ifdef CHECK_INTERPOLANTS
    if(check_interpolants(expressions, interpolants))
      throw "Interpolants are invalid!";
#endif

    goto_program_unwindingt::unwinding_patht::iterator p_it=path.begin();
    
    for(expr_listt::reverse_iterator i_it=interpolants.rbegin();
        i_it!=interpolants.rend(); ++i_it, ++p_it)
    {
      exprt &interpolant=*i_it;

      unsigned index=p_it.get_index();

      result[index]=interpolant;
    }
    
    return decision_proceduret::D_UNSATISFIABLE;
  }

  return decision;
}


/*******************************************************************\

Function: wolver_interpolatort::partition

  Inputs: An unwinding step, a start node

 Outputs: A list of expressions

 Purpose: Partitions an equation according to the 
          locations along the control flow graph (starting
          with from_node).
          The assertion itself is always a separate partition
          (this guarantees that we do get at least one interpolant)

\*******************************************************************/
void wolver_interpolatort::partition(
  const goto_program_unwindingt::unwinding_stept& unwinding_step, 
  const exprt &condition, unsigned from_node, expr_listt& expressions)
{
  const symex_target_equationt &equation=unwinding_step.equation;

  exprt expression(condition);

  goto_program_unwindingt::unwinding_patht path=
    unwinding_graph.path_prefix(unwinding_step.node);
  goto_program_unwindingt::unwinding_patht::iterator p_it=path.begin();

  unsigned ssa_index=equation.SSA_steps.size();

  for(symex_target_equationt::SSA_stepst::const_reverse_iterator
        r_it=equation.SSA_steps.rbegin();
      !(p_it.get_index()==from_node && ssa_index==p_it->ssa_index);
      ++r_it, --ssa_index)
  {
    while(ssa_index==p_it->ssa_index && p_it.get_index()!=from_node)
    {
#ifdef DEBUG
      std::cout << " Partition at " << p_it->pc->location << std::endl;
#endif
      expressions.push_front(exprt());
      expressions.front().swap(expression);
      simplify(expressions.front(), ns);
      expression.make_true();
      // process previous block
      ++p_it;
    }

    if(p_it.get_index()==from_node && ssa_index==p_it->ssa_index)
      break;

    const symex_target_equationt::SSA_stept &step=*r_it;

    if(step.is_assert() || step.is_assume() || step.is_assignment())
    {
      if(!step.ignore)
      {
        exprt cond=step.cond_expr;
        goto_program_unwindingt::conjoin(cond, expression);
      }
    }
  }

  assert(p_it!=path.end()); // fails if from_node is not in the path

  // add the initial condition 
  exprt initial_cond(p_it->ssa_label);
  goto_program_unwindingt::conjoin(initial_cond, expression);

  // add the final expression
  expressions.push_front(expression);
  assert(p_it==path.end() || p_it.get_index()==from_node);   
}

/*******************************************************************\

Function: wolver_interpolatort::check_interpolants

  Inputs:

 Outputs:

 Purpose: Checks whether the interpolants are correct (implied by A,
          inconsistent with B). Returns true if there's a problem.

\*******************************************************************/
bool wolver_interpolatort::check_interpolants(
  const expr_listt &expressions, const expr_listt &interpolants)
{
#ifdef DEBUG
  std::cout << "Checking interpolants... ";
#endif

  unsigned partition=0;

  exprt last_interpolant=true_exprt();

  and_exprt b;
  for(expr_listt::const_iterator e_it=expressions.begin();
      e_it!=expressions.end(); ++e_it)
  {
    b.copy_to_operands(*e_it);
  }

  exprt::operandst::iterator e_it=b.operands().begin(); 
  
  for(expr_listt::const_iterator i_it=interpolants.begin();
      i_it!=interpolants.end(); ++i_it, ++e_it, ++partition)
  {
    exprt interpolant=*i_it;
    simplify(interpolant, ns);
    and_exprt a(last_interpolant, *e_it);
    e_it->make_true(); // neutralise it

    exprt impla(ID_implies, bool_typet());
    impla.copy_to_operands(a, interpolant);
    simplify(impla, ns);
    
    {
      wolver_satcheckt satcheck(ns);
      satcheck.set_to_false(impla);
      if(satcheck.dec_solve()!=decision_proceduret::D_UNSATISFIABLE)
      {
        std::cout << from_expr(ns, "", interpolant) << " not implied by "
                  << from_expr(ns, "", a) << std::endl;
        return true;
      }
    }

    exprt andb(ID_and, bool_typet());
    andb.copy_to_operands(interpolant, b);

    {
      wolver_satcheckt satcheck(ns);
      satcheck.set_to_true(andb);
      if(satcheck.dec_solve()!=decision_proceduret::D_UNSATISFIABLE)
      {
        std::cout << from_expr(ns, "", interpolant) << " and "
                  << from_expr(ns, "", b) << " not inconsistent" 
                  << std::endl;
        return true;
      }
    }
    
    last_interpolant=interpolant; 
  }

  return false;
}

/*******************************************************************\

Function: smt_dummy_interpolatort::interpolate

  Inputs:

 Outputs:

 Purpose: Based on wolver_interpolatort::interpolate.
          Also outputs files in the SMT format.


\*******************************************************************/
decision_proceduret::resultt smt_dummy_interpolatort::interpolate(
  const goto_program_unwindingt::unwinding_stept &step, 
  const exprt& condition,
  unsigned from_node,
  path_interpolatort::interpolant_mapt& result)
{
  std::stringstream ss;
  std::string name;
  ss << file_count;
  name="file"+ss.str()+".smt";

  ++file_count;

  std::ofstream file(name.c_str());
  smt1_convt checker(ns, TOOL_NAME, "generated by " TOOL_NAME, 
                     "QF_AUFBV", file); 

  expr_listt expressions;
  partition(step, condition, from_node, expressions);

  unsigned i=0;
  for(expr_listt::const_iterator e_it=expressions.begin();
      e_it!=expressions.end(); ++e_it)
  {
    exprt tmp(*e_it);
    simplify(tmp, ns);
    std::cout << from_expr(ns, "", tmp) << std::endl;
    std::cout << tmp << std::endl;
    file << ":formula " << i << std::endl;
    checker.set_to_true(tmp);      
  }

  file << ")" << std::endl;
  file.close();

  /* 
     if the SMT solver eventually computes a list of interpolants
     they have to be stored in the interpolant_mapt result
  */

  // call the original wolver_interpolatort
  return wolver_interpolatort::interpolate(
    step, condition, from_node, result);
}
