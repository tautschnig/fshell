/*******************************************************************\

Module: Symbolic Execution and Interpolation of ANSI-C

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include <sstream>
#include <fstream>
#include <errno.h>

#include <i2string.h>
#include <location.h>
#include <time_stopping.h>
#include <message_stream.h>

#include <solvers/sat/satcheck.h>

#include <langapi/mode.h>
#include <langapi/languages.h>
#include <langapi/language_util.h>

#include <goto-symex/goto_trace.h>
#include <goto-symex/build_goto_trace.h>
#include <goto-symex/slice.h>
#include <goto-symex/slice_by_trace.h>
#include <goto-symex/xml_goto_trace.h>


#ifdef HAVE_BV_REFINEMENT
#include <bv_refinement/bv_refinement_loop.h>
#endif

#include "wolver.h"

/*******************************************************************\

Function: wolver_baset::fight (Wolverine doesn't run, he fights!)

  Inputs:

 Outputs:

 Purpose: "does it all"

\*******************************************************************/

safety_checkert::resultt wolver_baset::fight()
{
  symex.set_message_handler(get_message_handler());
  symex.set_verbosity(get_verbosity());
  symex.options=options;

  status("Starting to analyze the program.");

  symex.last_location.make_nil();

  bool counterexample_found=false;

  try
  {
    setup_unwind();
    setup_thresholds();
    setup_path_slicing();
    setup_invariant_printing();
    setup_interpolator();
    start_logging();
    counterexample_found=unwind();
    stop_logging();
  }

  catch(std::string &error_str)
  {
    stop_logging();
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return safety_checkert::ERROR;
  }

  catch(const char *error_str)
  {
    stop_logging();
    message_streamt message_stream(get_message_handler());
    message_stream.err_location(symex.last_location);
    message_stream.error(error_str);
    return safety_checkert::ERROR;
  }

  return counterexample_found?
    safety_checkert::UNSAFE:safety_checkert::SAFE;
}

/*******************************************************************\

Function: wolver_baset::setup_interpolator

  Inputs:

 Outputs:

 Purpose: select a non-standard interpolator

\*******************************************************************/

void wolver_baset::setup_interpolator()
{
  const std::string &name=options.get_option("interpolator");
  unwinding.set_interpolator(name, options);
  if(unwinding.initialise_interpolator())
    throw "Failed to initialise interpolator!";
}

/*******************************************************************\

Function: wolver_baset::start_logging

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_baset::start_logging()
{
  const std::string &filename=options.get_option("log");
  if(filename!="")
  {
    status("Logging to "+filename);
    unwinding.start_logging(filename);
  }
}

/*******************************************************************\

Function: wolver_baset::start_logging

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_baset::stop_logging()
{
  unwinding.stop_logging();
}

/*******************************************************************\

Function: wolver_baset::setup_slicing

  Inputs:

 Outputs:

 Purpose: Activates or deactivates path slicing for equations

\*******************************************************************/

void wolver_baset::setup_path_slicing()
{
  if(options.get_bool_option("no-path-slicing"))
    unwinding.set_path_slicing(false);
}


/*******************************************************************\

Function: wolver_baset::setup_thresholds

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_baset::setup_thresholds()
{
  std::string path_length_threshold=
    options.get_option("path-length-threshold");

  if(path_length_threshold!="")
  {
    errno=0;
    unsigned threshold=
      strtol(path_length_threshold.c_str(), (char**)NULL, 10);

    if(errno==0)
      unwinding.set_path_length_threshold(threshold);
  }

  std::string force_cover_threshold=
    options.get_option("force-cover");

  if(force_cover_threshold!="")
  {
    errno=0;
    unsigned threshold=
      strtol(force_cover_threshold.c_str(), (char**)NULL, 10);
    
    if(errno==0)
      unwinding.set_force_cover_threshold(threshold);
  }
}

/*******************************************************************\

Function: wolver_baset::setup_invariant_printing

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_baset::setup_invariant_printing()
{
  if(options.get_bool_option("show-invariants"))
    unwinding.report_invariants();
}

/*******************************************************************\

Function: wolver_baset::setup_unwind

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

void wolver_baset::setup_unwind()
{
  const std::string &set = options.get_option("unwindset");
  unsigned int length = set.length();

  for(unsigned int idx = 0; idx < length; idx++)
  {
    std::string::size_type next = set.find(",", idx);
    std::string val = set.substr(idx, next - idx);
    unsigned long id = atoi(val.substr(0, val.find(":", 0)).c_str());
    unsigned long uw = atol(val.substr(val.find(":", 0) + 1).c_str());
    unwinding.unwind_set[id] = uw;
    if(next == std::string::npos) break;
    idx = next;
  }

  unwinding.max_unwind=atol(options.get_option("unwind").c_str());
}

/*******************************************************************\

Function: wolver_baset::unwind

  Inputs:

 Outputs:

 Purpose: unwinds the control flow graph using depth first search

\*******************************************************************/

bool wolver_baset::unwind()
{
  return unwinding();
}

/*******************************************************************\

Function: wolver_safety_checkert::operator()

  Inputs:

 Outputs:

 Purpose: Run the safety checker

\*******************************************************************/

safety_checkert::resultt wolver_safety_checkert::operator()(
  const goto_functionst &goto_functions)
{
  wolvert wolver(ns.get_context(), 
                 goto_functions, 
                 error_trace, 
                 get_message_handler());

  return wolver.fight();
}

