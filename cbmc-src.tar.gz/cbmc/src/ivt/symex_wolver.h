/*******************************************************************\

Module: Interpolation Based Model Checking for ANSI-C

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#ifndef CPROVER_WOLVER_SYMEX_H
#define CPROVER_WOLVER_SYMEX_H

#include <hash_cont.h>
#include <message.h>
#include <goto-symex/goto_symex.h>
#include <goto-symex/symex_target_equation.h>

class symex_wolvert:
  public goto_symext,
  virtual public messaget
{
public:
  symex_wolvert(
    const namespacet &_ns,
    contextt &_new_context,
    symex_target_equationt &_target);

  friend class wolver_baset;

  void swap_target_equation(symex_target_equationt&);

  symex_target_equationt &get_equation() { return equation; }

  bool symex_step_until(
    const goto_functionst &goto_functions,
    statet &state,
    goto_programt::const_targett &end_of_instructions,
    symex_target_equationt &equation);

  void symex_step(
    const goto_functionst &goto_functions,
    statet &state,
    symex_target_equationt &equation);

  void symex_step_goto(
    statet&, symex_target_equationt&, bool);

  void symex_step_return(statet&, symex_target_equationt&);

  bool get_function_name(
    const goto_programt::instructiont&, statet&, irep_idt&);

  bool get_assertion_guard(const goto_programt::instructiont&, 
                           statet&, exprt&);

protected:
  symex_target_equationt &equation;

  //
  // overloaded from goto_symext
  //
  virtual void symex_step(
    const goto_functionst &goto_functions,
    statet &state);

  virtual void no_body(const irep_idt &identifier);

  irept last_location;

  hash_set_cont<irep_idt, irep_id_hash> body_warnings;
};

#endif
