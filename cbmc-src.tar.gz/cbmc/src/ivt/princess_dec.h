/*******************************************************************\

Module: validity checker princess for Wolverine's implication check

Author: Angelo Brillout, bangelo@inf.ethz.ch

\*******************************************************************/

#ifndef PRINCESS_DEC_H
#define PRINCESS_DEC_H

#include <sstream>

#include <expr.h>
#include <std_types.h>
#include <decision_procedure.h>

#include "wolver_sat.h"
#include "princess_interface.h"
#include "piped_process.h"

#define PRINCESS_COMMAND "werePrincess"

class princess_instancet
{
 public:
  princess_instancet() { }
  ~princess_instancet();
  
 protected:
  piped_processt& get_process();

 private:
  static piped_processt* princess_process;
};

class princess_dect:
  public princess_instancet
//public decision_proceduret
{
public:
  const std::string description()
  { return "Princess's satisfiability checker"; }

  princess_dect(const namespacet &_ns): ns(_ns) { }
  ~princess_dect() { }

  void set_to_false(const exprt &expr);

  decision_proceduret::resultt dec_solve();

private:
  const namespacet &ns;
  std::stringstream problem;
};


class princess_sat_dect : public princess_dect
{
public:
  const std::string description()
  { return "Checks satisfiability with princess if the problem contains quantifiers and with SAT otherwise"; }

  princess_sat_dect(const namespacet &_ns): princess_dect(_ns), sat_checker(_ns) { }

  void set_to_false(const exprt &expr);

  decision_proceduret::resultt dec_solve();


private:
  wolver_satcheckt sat_checker;

  bool use_princess;
  bool contains_quantifier(const exprt& expr);

};

#endif
