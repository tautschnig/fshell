/*******************************************************************\

Module: Interface for external interpolators for Wolverine

Author: Georg Weissenbacher, georg@weissenbacher.name

\*******************************************************************/

#include <sstream>

#include <simplify_expr.h>

#include <wordlevel_interpolator.h>

#include <string.h>
#include <sys/wait.h>

#include "wolver_slice.h"
#include "path_interpolator.h"
#include "version.h"

//#define DEBUG
//#define CHECK_INTERPOLANTS

/*******************************************************************\

Function: external_interpolatort::external_interpolatort

  Inputs:

 Outputs:

 Purpose: Constructor

\*******************************************************************/

external_interpolatort::external_interpolatort(
  goto_program_unwindingt::unwinding_grapht &_graph,
  const namespacet &_ns):
  wolver_interpolatort(_graph, _ns)
{
}

/*******************************************************************\

Function: external_interpolatort::initialise

  Inputs:

 Outputs:

 Purpose: Could, for instance, be used to fork a process.
          Returns false on success, true if it fails.

\*******************************************************************/
bool external_interpolatort::initialise()
{
  return false;
}

/*******************************************************************\

Function: external_interpolatort::process_options

  Inputs:

 Outputs:

 Purpose: Processes command-line options

\*******************************************************************/
void external_interpolatort::process_options(const optionst &options)
{
  // for example:
  // query options.get_bool_option("some-option");
}

/*******************************************************************\

Function: external_interpolatort::interpolate

  Inputs:

 Outputs:

 Purpose: Returns decision_proceduret::D_UNSATISFIABLE if
          it successfully computed interpolants,
          decision_proceduret::D_SATISFIABLE if the formula
          is satisfiable, and D_ERROR if the interpolator fails
          for some reason

\*******************************************************************/
decision_proceduret::resultt external_interpolatort::interpolate(
  const goto_program_unwindingt::unwinding_stept &step, 
  const exprt& condition,
  unsigned from_node,
  path_interpolatort::interpolant_mapt& result)
{
  decision_proceduret::resultt decision;
  expr_listt expressions;

  partition(step, condition, from_node, expressions);
  translate(expressions);
  decision=solve();

  if(decision==decision_proceduret::D_UNSATISFIABLE)
  {
    expr_listt interpolants;
    read_interpolants(interpolants);
    goto_program_unwindingt::unwinding_patht 
      path=unwinding_graph.path_prefix(step.node);

#ifdef CHECK_INTERPOLANTS
    if(check_interpolants(expressions, interpolants))
      throw "Interpolants are invalid!";
#endif

    goto_program_unwindingt::unwinding_patht::iterator p_it=path.begin();
    
    for(expr_listt::reverse_iterator i_it=interpolants.rbegin();
        i_it!=interpolants.rend(); ++i_it, ++p_it)
    {
      exprt &interpolant=*i_it;

      unsigned index=p_it.get_index();

      result[index]=interpolant;
    }
    
    return decision_proceduret::D_UNSATISFIABLE;
  }

  return decision;
}

/*******************************************************************\

Function: external_processt::external_processt

  Inputs:

 Outputs:

 Purpose: Constructor for external process

\*******************************************************************/
external_processt::external_processt(
  const std::string &file, const std::list<std::string> &args):
  executable(file), arguments(args), pid(0)
{
  rdbuf(&buffer);
}

/*******************************************************************\

Function: external_processt::run

  Inputs:

 Outputs:

 Purpose: Starts an external process. If the parameter async
          is true, a new process is forked and run returns
          immediately. Otherwise, the run method waits until 
          the process has completed.
          Returns -1 if an error occurs.

\*******************************************************************/
int external_processt::run(bool async)
{
  int in[2], out[2];

  if(async)
  {
    if(pipe(in)==-1 || pipe(out)==-1)
    {
      return -1;
    }
  }

  char** args = new char*[arguments.size()+2];

  args[0]=(char*)executable.c_str();

  std::list<std::string>::const_iterator s_it=arguments.begin();
  for(unsigned index=1; s_it!=arguments.end(); ++index, ++s_it)
  {
    args[index]=(char*)(s_it->c_str());
  }

  args[arguments.size()+1]=NULL;

  if(async)
    pid=fork();
  else
    pid=0;
    
  if(pid==0)
  {
    if(async)
    {
      close(in[1]);
      close(out[0]);
      dup2(in[0], STDIN_FILENO);
      dup2(out[1], STDOUT_FILENO);
    }

    int result=execvp(executable.c_str(), args);

    if(result==-1)
      perror(0);
    return result;
  }
  else if(pid==-1)
  {
    return -1;
  }

  if(async)
  {
    close(in[0]);
    close(out[1]);
    buffer.in(in[1]);
    buffer.out(out[0]);
  }

  // clean up
  delete args;

  return pid;
}

/*******************************************************************\

Function: external_processt::run

  Inputs:

 Outputs:

 Purpose: Starts an external process. If the parameter async
          is true, a new process is forked and run returns
          immediately. Otherwise, the run method waits until 
          the process has completed.
          Returns -1 on error.

\*******************************************************************/
int external_processt::wait()
{
  int status, result;

  if(pid<=0)
    return -1;

  result=waitpid(pid, &status, WUNTRACED);

  return result;
}

/*******************************************************************\

Function: pipe_streambuf::pipe_streambuf

  Inputs:

 Outputs:

 Purpose: Constructor

\*******************************************************************/
pipe_streambuf::pipe_streambuf():
  proc_in(STDOUT_FILENO), proc_out(STDIN_FILENO)
{ 
  setg(in_buffer, in_buffer, in_buffer);
}

/*******************************************************************\

Function: pipe_streambuf::~pipe_streambuf

  Inputs:

 Outputs:

 Purpose: Destructor

\*******************************************************************/
pipe_streambuf::~pipe_streambuf()
{
  if(in()!=STDOUT_FILENO)
    close(in());
  if(out()!=STDIN_FILENO)
    close(out());
}

/*******************************************************************\

Function: pipe_streambuf::overflow

  Inputs:

 Outputs:

 Purpose: write one character to the piped process

\*******************************************************************/
std::streambuf::int_type pipe_streambuf::overflow(
  std::streambuf::int_type character)
{
  if(character!=EOF)
  {
    char buf=character;
    if(write(proc_in, &buf, 1)!=1)
    {
      return EOF;
    }
  }
  return character;
}

/*******************************************************************\

Function: piped_streambuf::xsputn

  Inputs:

 Outputs:

 Purpose: write a number of character to the piped process

\*******************************************************************/
std::streamsize pipe_streambuf::xsputn(
  const char* str, std::streamsize count)
{
  return write(proc_in, str, count);
}

/*******************************************************************\

Function: piped_streambuf::uflow

  Inputs:

 Outputs:

 Purpose: read a character from the piped process

\*******************************************************************/
std::streambuf::int_type pipe_streambuf::underflow()
{
  if (gptr()==0) 
    return traits_type::eof();
  
  if (gptr()<egptr())
    return traits_type::to_int_type(*gptr());
  
  ssize_t len=read(proc_out, eback(), READ_BUFFER_SIZE);
  if (len==-1)
    return traits_type::eof();
    
  setg(eback(), eback(), eback()+(sizeof(char_type)*len));
  
  if (len==0)
    return traits_type::eof();
  
  return traits_type::to_int_type(*gptr());
}

/*******************************************************************\

Function: piped_streambuf::xsgetn

  Inputs:

 Outputs:

 Purpose: read a number of characters from the piped process

\*******************************************************************/
std::streamsize pipe_streambuf::xsgetn(
  char *target, std::streamsize count)
{
  std::streamsize available = showmanyc();
  if (count <= available) 
  {
    memcpy(target, gptr(), count * sizeof(char_type));
    gbump(count);
    
    return count;
  }
  
  memcpy(target, gptr(), available * sizeof(char_type));
  gbump(available);

  if (traits_type::eof() == underflow()) {
    return available;
  }

  return (available + xsgetn(target+available, count-available));
}

/*******************************************************************\

Function: piped_streambuf::showmanyc

  Inputs:

 Outputs:

 Purpose: determine number of available characters in stream

\*******************************************************************/
std::streamsize pipe_streambuf::showmanyc()
{
  if(gptr()==0)
    return 0;

  if(gptr()<egptr())
    return egptr()-gptr();

  return 0;
}
