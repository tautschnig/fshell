/*******************************************************************\

Module: Main Module 

Author: Daniel Kroening, kroening@kroening.com

\*******************************************************************/

/*

  WOLVER
  Interpolation for ANSI-C
  Copyright (C) 2008 
  Daniel Kroening <kroening@kroening.com>
  Georg Weissenbacher <georg@weissenbacher.name>

*/

#include "parseoptions.h"
#include "path_interpolator.h"

/*******************************************************************\

Function: main

  Inputs:

 Outputs:

 Purpose:

\*******************************************************************/

int main(int argc, const char **argv)
{
  wolver_parseoptionst parseoptions(argc, argv);
  return parseoptions.main();
}
