/*******************************************************************\

Module: "Built-in" interpolator of Wolverine

Author: Daniel Kroening, kroening@kroening.com
        Georg Weissenbacher, georg@weissenbacher.name,

\*******************************************************************/

#include "path_interpolator.h"
#include "princess_interpolator.h"
#include "wp/wp_interpolator.h"

path_interpolatort *select_interpolator(
  const std::string& name,
  const optionst &options,
  goto_program_unwindingt::unwinding_grapht& graph,
  const namespacet& ns)
{
  path_interpolatort *interpolator;

  if(name=="smt_dummy")
    interpolator=new smt_dummy_interpolatort(graph, ns);
  else if(name=="princess")
    interpolator=new princess_interpolatort(graph, ns);
  else if(name=="wp")
    interpolator=new wp_interpolatort(graph, ns);
  else
  {
    // built-in default interpolator
    interpolator=new wolver_interpolatort(graph, ns);
  }

  interpolator->process_options(options);

  return interpolator;
}

