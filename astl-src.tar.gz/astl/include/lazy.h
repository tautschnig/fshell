/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2003 Vincent Le Maout (vincent.lemaout@chello.fr).
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_LAZY_H
#define ASTL_LAZY_H

#include "astl.h"
#include <map>
#include <utility>

#define USE_HASH_MAP

// guess what? crappy C++ compiler from sparc/solaris can't compile hash maps...
#if defined(USE_HASH_MAP) && defined(__sparc)
#undef USE_HASH_MAP
#endif

#if defined(USE_HASH_MAP)
// Use g++'s tr1::unordered_map if possible as it looks more efficient than boost's
#if defined(__GNUG__) && (__GNUC__ > 3)
#define USE_TR1_UNORDERED_MAP
#include <tr1/unordered_map>
#else
#define USE_BOOST_UNORDERED_MAP
#include <boost/unordered_map.hpp>
#endif

#endif // USE_HASH_TABLE

namespace astl {

// - solution using template template: the user does not have to instanciate 
//   the DFA by himself, he only has to pass a template as argument
//   for the cursor template (the DFA must be instanciated with Tag ==
//   Cursor::state_type) 
// - This implementation uses a smart pointer to reference the cache
//   and the map between the visited states of the cursor and their copy
//   in the cache for two reasons: 
//   1. We really need a constant time copy constructor
//   2. We want to keep the cache and the mapping as long as the lazy
//      cursor is alive
//   Multithreading notes: lazy construction is not thread-safe
  template <typename Cursor, template <typename Sigma, typename Tag> class DFA = DFA_matrix>
  class lazy_cursor : public cursor_concept
  {
  public:
    typedef DFA<typename Cursor::char_traits, const typename Cursor::state_type*> DFA_type;

  protected:
    typedef std::map<typename Cursor::state_type, safe<typename DFA_type::state_type, DFA_type::null_state> > mapper;

    Cursor              c;
    smart_ptr<DFA_type> dfa;
    smart_ptr<mapper>   mapping;  
    typename DFA_type::state_type my_sink;
    safe<typename DFA_type::state_type> q;

  public:
    typedef lazy_cursor                   self;
    typedef typename DFA_type::state_type state_type;
    typedef empty_tag                     tag_type;
    typedef typename Cursor::char_type    char_type;
    typedef typename Cursor::char_traits  char_traits;

    lazy_cursor(const Cursor &x)
      : c(x), my_sink(dfa->new_state()), q(DFA_type::null_state)
    { 
      if (!x.sink()) {
	q = dfa->new_state();
	dfa->tag(q) = &(mapping->insert(make_pair(c.src(), q)).first->first);
	//dfa->tag(q) = c.src();
	// (*mapping)[c.src()] = q;
	dfa->final(q) = c.src_final();
	dfa->initial(q);
      }
    }

    // deprecated:
//   const Cursor& cursor() {
//     c = dfa->tag(q);
//     return c;
//   }

    Cursor& adaptee() {
      if (q != DFA_type::null_state)
	c = *dfa->tag(q);
      return c;
    }

    // don't use this !!!
    const Cursor& adaptee() const {
      return c;
    }

    const DFA_type& cache() const {
      return *dfa;
    }

    state_type src() const {
      return q;
    }

    self& operator=(state_type p) {
      q = p;
      return *this;
    }

    bool src_final() const {
      return dfa->final(q);
    }

    empty_tag src_tag() const {
      return empty_tag();
    }

    bool sink() const {
      return q == DFA_type::null_state;
    }

    state_type sink_state() const {
      return DFA_type::null_state;
    }

//   bool exists(const char_type &a) const {
//     state_type aim = dfa->delta1(q, a);
//     if (aim == my_sink) return false;
//     Cursor tmp = c;
//     tmp = dfa->tag(q);
//     return tmp.exists(a);
//   }

    bool forward(const char_type &a) {
      state_type tmp = dfa->delta1(q, a);
      if (tmp == my_sink) {
	q = DFA_type::null_state; // we already know there is no transition with 'a'
	return false;
      }
      if (tmp == DFA_type::null_state) {    // transition not in the cache ?
	c = *dfa->tag(q);
	if (c.forward(a)) {   // any transition labelled with 'a' ?
	  std::pair<typename mapper::iterator, bool> p = 
	    mapping->insert(std::make_pair(c.src(), DFA_type::null_state));
	  if (p.second == true) {
	    tmp = dfa->new_state();
	    dfa->final(tmp) = c.src_final();
	    dfa->tag(tmp) = &(p.first->first);
	    p.first->second = tmp;
	  }
	  else tmp = p.first->second;
	  dfa->set_trans(q, a, tmp);
	}
	else {
	  dfa->set_trans(q, a, my_sink);
	  q = DFA_type::null_state;
	  return false;
	}
      }
      q = tmp;
      return true;
    }
  };

  template <class Cursor>
  inline
  lazy_cursor<Cursor> lazyc(const Cursor &c) {
    return lazy_cursor<Cursor>(c);
  }

// A lazy cursor which copy tags into the cache
  template <class Cursor, 
	    template <class Sigma, class Tag> class DFA = DFA_matrix>
  class lazy_cursor_tag : public cursor_concept
  {
  public:
    typedef DFA<typename Cursor::char_traits, 
		std::pair<typename Cursor::tag_type, const typename Cursor::state_type*> > DFA_type;

  protected:
#ifdef USE_HASH_MAP
    struct hasher // : public unary_function<typename Cursor::state_type, size_t>
    {
      template <typename T, typename U>
      size_t operator()(const pair<T, U> &s) const {
	size_t r = 0;
	for(typename T::const_iterator i = s.first.begin(); i != s.first.end(); ++i)
	  r += (size_t) *i;
	r += s.second;
	return r;
      }

      template <typename T>
      size_t operator()(const T &s) const {
	size_t r = 0;
	for(typename T::const_iterator i = s.begin(); i != s.end(); ++i)
	  r += (size_t) *i;
	return r;
      }
    };

  #ifdef USE_TR1_UNORDERED_MAP
    typedef tr1::unordered_map<typename Cursor::state_type, 
			       safe<typename DFA_type::state_type, DFA_type::null_state>, hasher> mapper;
  #else
    typedef boost::unordered_map<typename Cursor::state_type, 
			       safe<typename DFA_type::state_type, DFA_type::null_state>, hasher> mapper;
  #endif

#else
  typedef std::map<typename Cursor::state_type, 
		   safe<typename DFA_type::state_type, DFA_type::null_state> > mapper;
#endif
    Cursor              c;
    smart_ptr<DFA_type> dfa;
    smart_ptr<mapper>   mapping;  
    typename DFA_type::state_type my_sink;
    typename DFA_type::state_type q;

  public:
    typedef lazy_cursor_tag<Cursor, DFA>  self;
    typedef typename DFA_type::state_type state_type;
    typedef typename Cursor::tag_type     tag_type;
    typedef typename Cursor::char_type    char_type;
    typedef typename Cursor::char_traits  char_traits;

    lazy_cursor_tag(const Cursor &x)
      : c(x), my_sink(dfa->new_state()), q(DFA_type::null_state) { 
      if (!x.sink()) {
	q = dfa->new_state();
	dfa->tag(q).first = c.src_tag();
	dfa->tag(q).second = &(mapping->insert(make_pair(c.src(), q)).first->first);
	dfa->final(q) = c.src_final();
	dfa->initial(q);
      }
    }

    // copy-constructor does not copy the cache, it is shared between instances (NOT thread-safe)
    // for multi-threading: get a copy of *this with a new empty cache
    // use with caution: current state is the initial state and don't forget to deallocate !
    self* clone() const {
      return new self(c);
    }

    const Cursor& adaptee() const { return c; }

    Cursor& adaptee() { return c; }

    const DFA_type& cache() const { return *dfa; }

    state_type src() const { return q; }

    self& operator=(state_type p) {
      q = p;
      return *this;
    }

    bool src_final() const { return dfa->final(q); }

    const tag_type& src_tag() const { return dfa->tag(q).first; }

    bool sink() const { return q == DFA_type::null_state; }

    state_type sink_state() const { return DFA_type::null_state; }

    bool forward(const char_type &a) {
      state_type tmp = dfa->delta1(q, a);
      if (tmp == my_sink) {
	q = DFA_type::null_state; // we already know there is no transition with 'a'
	return false;
      }
      if (tmp == DFA_type::null_state) {    // transition not in the cache ?
	c = *dfa->tag(q).second;
	if (c.forward(a)) {   // any transition labelled with 'a' ?
	  std::pair<typename mapper::iterator, bool> p = 
	    mapping->insert(std::make_pair(c.src(), DFA_type::null_state));
	  if (p.second == true) {
	    tmp = dfa->new_state();
	    dfa->final(tmp) = c.src_final();
	    dfa->tag(tmp).first = c.src_tag();
	    dfa->tag(tmp).second = &(p.first->first);
	    p.first->second = tmp;
	  }
	  else tmp = p.first->second;
	  dfa->set_trans(q, a, tmp);
	}
	else {
	  dfa->set_trans(q, a, my_sink);
	  q = DFA_type::null_state;
	  return false;
	}
      }
      q = tmp;
      return true;
    }
  };

  template <class Cursor>
  inline
  lazy_cursor_tag<Cursor> lazyc_tag(const Cursor &c) {
    return lazy_cursor_tag<Cursor>(c);
  }

} // namespace astl
     
#endif // ASTL_LAZY_H
    





