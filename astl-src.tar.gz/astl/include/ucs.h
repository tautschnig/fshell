#ifndef ASTL_UCS_H
#define ASTL_UCS_H

#include "unicode.h"

#include <vector>
#include <algorithm>

using namespace std;

namespace astl {

  typedef unsigned short UCS2;
  typedef unsigned int   UCS4;

  static inline int ucs2pos(UCS2 c) {
    return (c >> 5); // c / 32
  }

  static inline int ucs2offset(UCS2 c) {
    return c & 0x001F; // c % 32
  }

  static inline bool check(const unsigned int s[], UCS2 c) {
    return (s[ucs2pos(c)] & (1 << ucs2offset(c))) != 0;
  }

  inline bool isalpha(UCS2 c) {
    return check(isUCS2alpha, c);
  }

  inline bool isalnum(UCS2 c) {
    return check(isUCS2alnum, c);
  }

  inline bool isdigit(UCS2 c) {
    return c >= '0' && c <= '9';
  }

  inline bool isxdigit(UCS2 c) {
    return check(isUCS2xdigit, c);
  }

  inline bool isgraph(UCS2 c) {
    return check(isUCS2graph, c);
  }

  inline bool isprint(UCS2 c) {
    return check(isUCS2print, c);
  }

  inline bool isascii(UCS2 c) {
    return c < 128;
  }

  inline bool isspace(UCS2 c) {
    return check(isUCS2space, c);
  }

  inline bool ispunct(UCS2 c) {
    return check(isUCS2punct, c);
  }

  inline bool isblank(UCS2 c) {
    return check(isUCS2blank, c);
  }

  inline bool iscontrol(UCS2 c) {
    return check(isUCS2control, c);
  }

  inline bool islower(UCS2 c) {
    return check(isUCS2lower, c);
  }

  inline bool isupper(UCS2 c) {
    return check(isUCS2upper, c);
  }

  inline bool isword(UCS2 c) {
    return isalnum(c) || c == '_';
  }

  inline bool ismark(UCS2 c) {
    return check(isUCS2mark, c);
  }

  inline UCS2 tolower(UCS2 c) {
    return toUCS2lower[c];
  }

  inline UCS2 toupper(UCS2 c) {
    return toUCS2upper[c];
  }

  class ucs2_set
  {
  public:
    struct range_compare : public binary_function<pair<UCS2, UCS2>, pair<UCS2, UCS2>, bool>
    {
      bool operator()(const pair<UCS2, UCS2> &x, const pair<UCS2, UCS2> &y) const {
	return x.first < y.first;
      }
    };

    ucs2_set()
      : icase(false), negative(false)
    { }

    void add(UCS2 c) {
      add_range(make_pair(c, c));
    }

    void add(UCS2 from, UCS2 to) {
      add_range(make_pair(from, to));
    }

    void add(const ucs2_set &s) {
      assert(negative == s.negative);
      for(vector<pair<UCS2, UCS2> >::const_iterator r = s.ranges.begin(); r != s.ranges.end(); ++r)
	add_range(*r);
      for(vector<checker>::const_iterator p = s.properties.begin(); p != s.properties.end(); ++p)
	if (std::find(properties.begin(), properties.end(), *p) == properties.end())
	  properties.push_back(*p);
    }

    void clear() {
      ranges.clear();
      properties.clear();
      icase = negative = false;
    }

    bool find(UCS2 c) const {
      bool r = false;
      if (!properties.empty() && c != 0) { // never match anchors ^ and $
	for(vector<checker>::const_iterator p = properties.begin(); p != properties.end(); ++p) {
	  if (((*this).*(*p))(c) == true) 
	    return negative ? false : true;
	}
      }
      vector<pair<UCS2, UCS2> >::const_iterator p = 
	lower_bound(ranges.begin(), ranges.end(), make_pair(c, c), range_compare());
      r = (p != ranges.end() && includes(*p, c)) || (p != ranges.begin() && includes(p[-1], c));
      if (r == false && icase == true) {
	if (astl::islower(c)) {
	  UCS2 tmp = astl::toupper(c);
	  p = lower_bound(ranges.begin(), ranges.end(), make_pair(tmp, tmp), range_compare());
	  r = (p != ranges.end() && includes(*p, tmp)) || (p != ranges.begin() && includes(p[-1], tmp));
	}
	else if (astl::isupper(c)) {
	  UCS2 tmp = astl::tolower(c);
	  p = lower_bound(ranges.begin(), ranges.end(), make_pair(tmp, tmp), range_compare());
	  r = (p != ranges.end() && includes(*p, tmp)) || (p != ranges.begin() && includes(p[-1], tmp));
	}
      }
      return negative ? (c != 0 && !r) : r;
    }
     
    void case_insensitive(bool b) { // for managing (?i:[ ])
      icase = b;
    }

    void negation(bool b) { // for managing [^ ]
      negative = b;
    }

    void alnum() {
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isalpha), properties.end());
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isnum), properties.end());
      properties.push_back(&ucs2_set::isalnum);
    }

    void word() {
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isalnum), properties.end());
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isalpha), properties.end());
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isnum), properties.end());
      properties.push_back(&ucs2_set::isword);
    }

    void not_word() {
      properties.push_back(&ucs2_set::isnotword);
    }

    void alpha() {
      if (std::find(properties.begin(), properties.end(), &ucs2_set::isalnum) == properties.end())
	properties.push_back(&ucs2_set::isalpha);
    }

    void ascii() {
      properties.push_back(&ucs2_set::isascii);
    }

    void control() {
      properties.push_back(&ucs2_set::iscontrol);
    }

    void lower() {
      properties.push_back(&ucs2_set::islower);
    }

    void upper() {
      properties.push_back(&ucs2_set::isupper);
    }

    void blank() {
      properties.push_back(&ucs2_set::isblank);
    }

    void graph() {
      properties.push_back(&ucs2_set::isgraph);
    }

    void print() {
      properties.push_back(&ucs2_set::isprint);
    }

    void num() {
      if (std::find(properties.begin(), properties.end(), &ucs2_set::isalnum) == properties.end())
	properties.push_back(&ucs2_set::isnum);
    }

    void not_num() {
      properties.push_back(&ucs2_set::isnotnum);
    }

    void xnum() {
      properties.erase(std::remove(properties.begin(), properties.end(), &ucs2_set::isnum), properties.end());
      if (std::find(properties.begin(), properties.end(), &ucs2_set::isalnum) == properties.end())
	properties.push_back(&ucs2_set::xnum);
    }

    void space() {
      properties.push_back(&ucs2_set::isspace);
    }

    void not_space() {
      properties.push_back(&ucs2_set::isnotspace);
    }

    void punct() {
      properties.push_back(&ucs2_set::ispunct);
    }


    void mark() {
      properties.push_back(&ucs2_set::ismark);
    }

    void not_mark() {
      properties.push_back(&ucs2_set::isnotmark);
    }


    void any() {
      properties.clear();
      ranges.clear();
      icase = negative = false;
      properties.push_back(&ucs2_set::isany);
    }

    bool full() const {
      return std::find(properties.begin(), properties.end(), &ucs2_set::isany) != properties.end();
    }

    UCS2 begin() const {
      return ranges.front().first;
    }

    UCS2 end() const {
      return ranges.back().second;
    }

    bool empty() const {
      return ranges.empty() && properties.empty();
    }

    bool single() const {
      return !icase && properties.empty() && ranges.size() == 1 && 
	ranges.front().first == ranges.front().second && !negative;
    }

  protected:
    typedef bool (ucs2_set::*checker)(UCS2) const;
    vector<pair<UCS2, UCS2> > ranges;
    vector<checker>           properties;
    bool                      icase;
    bool                      negative;

    bool isalnum(UCS2 c) const   { return astl::isalnum(c); }
    bool isword(UCS2 c) const    { return astl::isword(c); }
    bool isnotword(UCS2 c) const  { return !astl::isword(c); }
    bool isalpha(UCS2 c) const   { return astl::isalpha(c); }
    bool isnum(UCS2 c) const     { return astl::isdigit(c); }
    bool isnotnum(UCS2 c) const  { return !astl::isdigit(c); }
    bool xnum(UCS2 c) const      { return astl::isxdigit(c); }
    bool isgraph(UCS2 c) const   { return astl::isgraph(c); }
    bool isprint(UCS2 c) const   { return !astl::isprint(c); }
    bool isspace(UCS2 c) const   { return astl::isspace(c); }
    bool isnotspace(UCS2 c) const { return !astl::isspace(c); }
    bool ispunct(UCS2 c) const   { return astl::ispunct(c); }
    bool isascii(UCS2 c) const   { return astl::isascii(c); }
    bool isblank(UCS2 c) const   { return astl::isblank(c); }
    bool iscontrol(UCS2 c) const { return astl::iscontrol(c); }
    bool islower(UCS2 c) const   { return astl::islower(c); }
    bool isupper(UCS2 c) const   { return astl::isupper(c); }
    bool isany(UCS2 c) const     { return true; }
    bool ismark(UCS2 c) const    { return astl::ismark(c); }
    bool isnotmark(UCS2 c) const { return !astl::ismark(c); }

    bool includes(const pair<UCS2, UCS2> &p, UCS2 c) const {
      return c >= p.first && c <= p.second;
    }

    bool includes(const pair<UCS2, UCS2> &p, const pair<UCS2, UCS2> &c) const {
      return c.first >= p.first && c.second <= p.second;
    }

    bool overlaps(const pair<UCS2, UCS2> &p, const pair<UCS2, UCS2> &c) const {
      return (p.first <= c.second && p.second >= c.first) || 
	(unsigned long) p.second + 1 == (unsigned long) c.first || 
	(unsigned long) c.second + 1 == (unsigned long) p.first;
    }

    void merge(vector<pair<UCS2, UCS2> >::iterator p, const pair<UCS2, UCS2> &r) {
      p->first  = p->first < r.first ? p->first : r.first;
      p->second = p->second > r.second ? p->second : r.second;
      vector<pair<UCS2, UCS2> >::iterator next = p;
      for(++next; next != ranges.end() && overlaps(*p, *next); ++next) {
	p->first  = p->first < next->first ? p->first : next->first;
	p->second = p->second > next->second ? p->second : next->second;	  
      } 
      ranges.erase(++p, next);
    }

    void add_range(const pair<UCS2, UCS2> &r) {
      if (!ranges.empty()) {
	vector<pair<UCS2, UCS2> >::iterator p = lower_bound(ranges.begin(), ranges.end(), r, range_compare());
	if ((p != ranges.end() && includes(*p, r)) || (p != ranges.begin() && includes(p[-1], r)))
	  return;
	if (p != ranges.begin() && overlaps(p[-1], r))
	  merge(p - 1, r);
	else if (p != ranges.end() && overlaps(*p, r))
	  merge(p, r);
	else ranges.insert(p, r);
      }
      else ranges.push_back(r);
    }
  };

}

#endif // ASTL_UCS_H
