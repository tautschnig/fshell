/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2003 Vincent Le Maout (vincent.lemaout@chello.fr).
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_REGEXPU_H
#define ASTL_REGEXPU_H

#include "astl.h"
#include "regexp_tools.h"
#include "lazy.h"
#include "search.h"
#include <vector>
#include <iostream>
#include <set>
#include <iterator>
#include <cctype>  
#include <bitset>
#include <cstring>
#include <sstream>

using namespace std;

namespace astl {

  class regexpu_cursor : public cursor_concept
  {
  public:
    typedef rex::node*      node_type;
    typedef regexpu_cursor  self;
    typedef rex::state_set::node_container state_type;
    typedef set<rex::node*> ordered_state_type;
    typedef ucs2            char_traits;
    typedef UCS2            char_type;
    typedef empty_tag       tag_type; // matching expressions

    regexpu_cursor()
    { }

    regexpu_cursor(const string &utf8, bool horspool_optimized = false) {
      if (core->compile(utf8, horspool_optimized))
	q = core->root();
    }

    bool leftanchored() const { return core->initial().empty(); }

    bool simple() const { return core->simple(); }

    // possible error position (-1 if expression is ok)
    ptrdiff_t error_position() const { return core->error_position(); }
    
    const char* error_message() const {
      return core->error_message();
    }

    self& operator=(const state_type &s) {
      q = s;
      return *this;
    }

    const state_type& src() const { return q.nodes(); }

    bool exists(UCS2 a) const {
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(a)) return true;
      return false;
    }

    bool forward(UCS2 letter) {
      rex::state_set p = core->initial(); // for non-anchored expressions
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(letter))
	  p.insert((*i)->next.begin(), (*i)->next.end());
      q.swap(p);
      return !q.empty();
    }
    
    bool src_final() const {
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i) 
	if ((*i)->final()) return true;
      return false;
    }
     
    bool sink() const { return q.empty(); }
 
    tag_type src_tag() const { return tag_type(); }

  protected:
    rex::state_set                 q;
    smart_ptr<rex::implementation> core;
  };

  template <typename RegexpCursor>
  class regexp_utf8_layer_cursor : public RegexpCursor
  {
  public:
    typedef regexp_utf8_layer_cursor              self;
    typedef RegexpCursor                          super;
    typedef plain                                 char_traits;
    typedef plain::char_type                      char_type;
    typedef typename super::tag_type              tag_type;
    typedef pair<typename super::state_type, unsigned int> state_type; 

    regexp_utf8_layer_cursor(const string &utf8, bool horspool_optimized = false)
      : super(utf8, horspool_optimized), path(0)
    { 
      if (horspool_optimized && !super::core->horspool().empty()) {
	vector<vector<char> > utf8_prefixes;
	for(vector<vector<UCS2> >::const_iterator p = super::core->horspool().begin(); p != super::core->horspool().end(); ++p) {
	  utf8_prefixes.push_back(vector<char>());
	  ucs2_to_utf8(p->begin(), p->end(), back_inserter(utf8_prefixes.back()));
	}
	horspool->init(utf8_prefixes);
      }
    }

    state_type src() const {
      typename super::state_type tmp = super::src();
      sort(tmp.begin(), tmp.end());
      return make_pair(tmp, path);
    }

    bool src_final() const { return path == 0 && super::src_final(); }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      if (path == 0) { // start of utf8 character ?
	const int l = utf8_char_length(c);
	if (l == 1)
	  return super::forward(utf8_to_ucs2(c));
	pbyte(0) = c;
	pbyte(3) = (l << 4) + 1;
	return true;
      }
      const int length = (pbyte(3) & 0xF0) >> 4;
      int next_position = pbyte(3) & 0x0F;
      pbyte(next_position) = c;
      if (++next_position == length) {
	const bool r = super::forward(utf8_to_ucs2((const char*) &path, length));
	path = 0;
	return r;
      }
      pbyte(3) = (pbyte(3) & 0xF0) | next_position;
      return true;
    }

    self& operator=(state_type q) {
      super::operator=(q.first);
      path = q.second;
      return *this;
    }

  protected:
    unsigned int path; // local utf8 path
    smart_ptr<multiple_horspool_finder<plain> > horspool;

    unsigned char& pbyte(int i) { return ((unsigned char*) &path)[i]; }
    unsigned char  pbyte(int i) const { return ((const unsigned char*) &path)[i]; }

  public:
    multiple_horspool_finder<plain>& finder() { return *horspool; }
  };

  class utf8_regexp_cursor : public cursor_concept
  {
  public:
    typedef lazy_cursor_tag<regexp_utf8_layer_cursor<regexpu_cursor>, DFA_matrix_mini> implementation;
    typedef utf8_regexp_cursor      self;
    typedef implementation::char_type   char_type;
    typedef implementation::char_traits char_traits;
    typedef implementation::tag_type    tag_type;
    typedef implementation::state_type  state_type;
    typedef implementation::DFA_type    DFA_type;

    utf8_regexp_cursor(const string &exp, bool use_horspool = false)
      : adaptee(new implementation(regexp_utf8_layer_cursor<regexpu_cursor>(exp, use_horspool)))
    { }

    ~utf8_regexp_cursor() { delete adaptee; }

    multiple_horspool_finder<plain>& finder() { return adaptee->adaptee().finder(); }

    const char* error_message() const { return adaptee->adaptee().error_message(); }
    int         error_position() const { return (int) adaptee->adaptee().error_position(); }

    const DFA_type& cache() const { return adaptee->cache(); }

    state_type src() const { return adaptee->src(); }

    self& operator=(state_type p) {
      *adaptee = p;
      return *this;
    }

    bool src_final() const { return adaptee->src_final(); }

    const tag_type& src_tag() const { return adaptee->src_tag(); }

    bool sink() const { return adaptee->sink(); }

    state_type sink_state() const { return adaptee->sink_state(); }

    bool forward(const char_type &a) { return adaptee->forward(a); }
 
  protected:
    implementation *adaptee;

    utf8_regexp_cursor(implementation *c)
      : adaptee(c)
    { }

  };

  class regexp_ucs2_layer_cursor : public regexpu_cursor
  {
  public:
    typedef regexp_ucs2_layer_cursor self;
    typedef regexpu_cursor           super;
    typedef plain                    char_traits;
    typedef plain::char_type         char_type;
    typedef super::tag_type          tag_type;
    typedef pair<super::state_type, unsigned short> state_type; 

    regexp_ucs2_layer_cursor(const std::string &exp, bool use_horspool = false)
      : super(exp, use_horspool), path(0)
    { 
      if (!core->horspool().empty())
	horspool->init(core->horspool());
    }

    state_type src() const {
      super::state_type tmp = super::src();
      sort(tmp.begin(), tmp.end());
      return make_pair(tmp, path);
    }

    bool src_final() const {
      return path == 0 && super::src_final();
    }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      if (path == 0) { // start of ucs2 character ?
	path = (unsigned char) c;
	path <<= 8;
	path += 1;
	return true;
      }
      const unsigned short tmp = path - 1 + (unsigned char) c;
      path = 0;
      return super::forward(tmp);
    }

    self& operator=(state_type q) {
      super::operator=(q.first);
      path = q.second;
      return *this;
    }

    multiple_horspool_finder<ucs2>& finder()  { return *horspool; }

  protected:
    unsigned short path;
    smart_ptr<multiple_horspool_finder<ucs2> > horspool;
  };

  class ucs2_regexp_cursor : public cursor_concept
  {
  public:
    typedef lazy_cursor_tag<regexp_ucs2_layer_cursor, DFA_matrix_mini> implementation;
    typedef ucs2_regexp_cursor          self;
    typedef ucs2::char_type   char_type;
    typedef ucs2              char_traits;
    typedef implementation::tag_type    tag_type;
    typedef implementation::state_type  state_type;
    typedef implementation::DFA_type    DFA_type;

    ucs2_regexp_cursor(const string &exp, bool use_horspool = false)
      : adaptee(new implementation(regexp_ucs2_layer_cursor(exp, use_horspool)))
    { }

    ~ucs2_regexp_cursor() { delete adaptee; }

    multiple_horspool_finder<ucs2>& finder() { return adaptee->adaptee().finder(); }

    const char* error_message() const { return adaptee->adaptee().error_message(); }
    int         error_position() const { return (int) adaptee->adaptee().error_position(); }

    const DFA_type& cache() const { return adaptee->cache(); }

    state_type src() const { return adaptee->src(); }

    self& operator=(state_type p) {
      *adaptee = p;
      return *this;
    }

    bool src_final() const { return adaptee->src_final(); }

    const tag_type& src_tag() const { return adaptee->src_tag(); }

    bool sink() const { return adaptee->sink(); }

    state_type sink_state() const { return adaptee->sink_state(); }

    bool forward(const char_type &a) { 
      return adaptee->forward(((plain::char_type*) a)[0]) && adaptee->forward(((plain::char_type*) a)[1]);
    }
 
  protected:
    implementation *adaptee;
  };

  inline ucs2_regexp_cursor ucs2_regexpc(const string &expression, bool use_horspool = false) {
    return ucs2_regexp_cursor(expression, use_horspool);
  }

  inline utf8_regexp_cursor utf8_regexpc(const string &expression, bool use_horspool = false) {
    return utf8_regexp_cursor(expression, use_horspool);
  }

  // match algorithm specializations for regexp

  template <typename InputI>
  inline
  bool match(utf8_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match(c, first, last);
  }

  template <typename InputI>
  inline
  bool match(ucs2_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI first_match(utf8_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_first_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI first_match(ucs2_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_first_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI longest_match(utf8_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_longest_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI longest_match(ucs2_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_longest_match(c, first, last);
  }

  template <typename InputI>
  inline
  int match_count(utf8_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match_count(c, first, last);
  }

  template <typename InputI>
  inline
  int match_count(ucs2_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match_count(c, first, last);
  }

} // namespace astl

#endif 

