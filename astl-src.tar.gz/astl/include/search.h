/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2009 Vincent Le Maout (vintz@sourceforge.net)
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_SEARCH_H
#define ASTL_SEARCH_H

#include <string>
#include <vector>

using namespace std;

namespace astl {

  template <typename CharTraits>
  class horspool_finder
  {
  public:
    typedef CharTraits                     char_traits;
    typedef typename CharTraits::char_type char_type;
    typedef typename vector<char_type>::const_iterator vector_const_iterator;
    typedef typename vector<char_type>::size_type vector_size_type;

    horspool_finder()
    { }

    void init(const basic_string<char_type> &s) {
      init(s.begin(), s.end());
    }

    void init(const vector<char_type> &v) {
      init(v.begin(), v.end());
    }

    // precondition: s.size() > 0 && s.size() < 65536
    template <typename RandomAccessI>
    void init(RandomAccessI x, RandomAccessI y) {
      word_.clear();
      word_.insert(word_.end(), x, y);
      last_position = word_.end() - 1;
      shift.clear();
      shift.resize(CharTraits::size, (unsigned short) (y - x));
      shifts();
    }

    const vector<char_type>& word() const { return word_; }

    unsigned int size() const { return word_.size(); }

    typename basic_string<char_type>::const_iterator
    find(const basic_string<char_type> &s) const {
      return find(s.begin(), s.end());
    }

#ifndef _MSC_VER
    // returns beg of match
    template <typename RandomAccessI>
    RandomAccessI find(RandomAccessI first, RandomAccessI last) const {
      for(first += size() - 1; first < last; first += shift[CharTraits::to_int_type(*first)]) {
        RandomAccessI x = first;
        for(typename vector<char_type>::const_iterator y = last_position; CharTraits::eq(*x, *y); --x, --y)
          if (y == word_.begin()) return x;
      }
      return last;
    }
#else
    // returns beg of match
    template <typename RandomAccessI>
    RandomAccessI find(RandomAccessI first, RandomAccessI last) const {
      if ((unsigned int) (last - first) >= size()) {
        int displacement = size() - 1;
        do {
          first += displacement;
          RandomAccessI x = first;
          for(vector_const_iterator y = last_position; CharTraits::eq(*x, *y); --x, --y) {
            if (y == word_.begin())
              return x;
          }
          displacement = shift[CharTraits::to_int_type(*first)];
        } while (displacement < last - first);
      }
      return last;
    }

#endif
  protected:
    vector<char_type>      word_;
    vector<unsigned short> shift;
    vector_const_iterator       last_position;

    void shifts() {
      for (vector_size_type i = 0; i < word_.size() - 1; ++i)
        shift[CharTraits::to_int_type(word_[i])] = word_.size() - 1 - i;
    }

  private:
    horspool_finder(const horspool_finder&);
    horspool_finder& operator=(const horspool_finder&);
  };


  class boyer_moore_finder
  {
  public:
    boyer_moore_finder()
    { }

    boyer_moore_finder(const string &s) {
      init(s);
    }

    void init(const string &s) {
      word = s;
      bmGs.resize(s.size());
      bmBc.clear();
      bmBc.resize(256, s.size());
      good_suffix_shifts();
      bad_character_shifts();
    }

    unsigned int size() const { return word.size(); }

    string::const_iterator find(const string &s) const {
      return find(s.begin(), s.end());
    }

    // returns beg of match
    template <typename RandomAccessI>
    RandomAccessI find(RandomAccessI first, RandomAccessI last) const {
      const int m = size() - 1;
      last -= m;
      int i;
      while (first < last) {
        for (i = m; i >= 0 && word[i] == first[i]; --i);
        if (i < 0)
          return first;
        else
          first += bmGs[i] > (i - bmBc[(unsigned char) first[i]]) ?
            bmGs[i] : (i - bmBc[(unsigned char) first[i]]);
      }
      return last + m;
    }

  protected:
    string word;
    vector<int> bmGs, bmBc;

    void bad_character_shifts() {
      for (string::size_type i = 0; i < word.size() - 1; ++i)
        bmBc[(unsigned char) word[i]] = i;
    }
    void suffixes(vector<int>& suff) {
      const int m = (int) word.size();
      int f = 0, g, i;
      suff[m - 1] = m;
      g = m - 1;
      for (i = m - 2; i >= 0; --i) {
        if (i > g && suff[i + m - 1 - f] < i - g)
          suff[i] = suff[i + m - 1 - f];
        else {
          if (i < g)
            g = i;
          f = i;
          while (g >= 0 && word[g] == word[g + m - 1 - f])
            --g;
          suff[i] = f - g;
        }
      }
    }

    void good_suffix_shifts() {
      const int m = (int) word.size();
      int i, j;
      vector<int> suff(m);
      suffixes(suff);
      for (i = 0; i < m; ++i)
        bmGs[i] = m;
      j = 0;
      for (i = m - 1; i >= 0; --i)
        if (suff[i] == i + 1)
          for (; j < m - 1 - i; ++j)
            if (bmGs[j] == m)
              bmGs[j] = m - 1 - i;
      for (i = 0; i <= m - 2; ++i)
        bmGs[m - 1 - suff[i]] = m - 1 - i;
    }
  };

#if 0
  class multiple_horspool_finder
  {
    multiple_horspool_finder()
    { }

    multiple_horspool_finder(const vector<string> &s) {
      init(s);
    }
    
    void init(const vector<string> &s) {
      finders.clear();
      finders.reserve(s.size());
      for(vector<string>::const_iterator i = s.begin(); i != s.end(); ++i)
	finders.push_back(horspool_finder(*i));
    }

    // returns beg of match
    pair<const char*, const char*> find(const char *first, const char *last) const {
      while (true) {
	int shift = numeric_limits<int>::max();
	int match = 0;
	for(vector<horspool_finder>::const_iterator finder = 0; finder != finders.size(); ++finder) {
	  const char *finish = first + finder->size() - 1;
	  if (finish < last) {
	    const int s = finder->step(finish, last);
	    if (s < 0) 
	      match = max(match, finder->size());
	    else shift = min(shift, s);
	  }
	}
	if (match != 0)
	  return make_pair(first, first + finder->size());
	if (shift == numeric_limits<int>::max())
	  break;
	first += shift;
      }
      return last; // no match
    }

    /*  
	fill(positions.begin(), positions.end(), first);
	int candidate = -1;
	for(vector<horspool_finder*>::size_type finder = 0; finder != finders.size(); ++finder) 
	if (positions[finder] < last - finders[finder]->size()) {
	const int shift = step(positions[finder], last);
	if (shift < 0) {
	if (candidate == -1 || positions[finder] < positions[candidate] ||
	positions[finder] == positions[candidate] && finders[finder]->size() < finders[candidate]->size())
	candidate = finder;
	}
	else positions[finder] += shift;
	}
	if (candidate != -1)
	return positions[candidate];
	}
    */

  protected:
    vector<horspool_finder> finders;
  };
#endif

} //namespace astl

#endif // ASTL_SEARCH_H
