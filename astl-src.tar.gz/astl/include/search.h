/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2009 Vincent Le Maout (vintz@sourceforge.net)
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_SEARCH_H
#define ASTL_SEARCH_H

#include <string>
#include <vector>
#include <algorithm>
#include <utility>
#include <iostream>

using namespace std;

namespace astl {

  template <typename CharTraits>
  class horspool_finder
  {
  public:
    typedef CharTraits                                 char_traits;
    typedef typename CharTraits::char_type             char_type;
    typedef typename vector<char_type>::const_iterator vector_const_iterator;
    typedef typename vector<char_type>::size_type      vector_size_type;
    typedef horspool_finder<CharTraits>                self;

    horspool_finder()
      : singles(0)
    { }

    horspool_finder(const basic_string<char_type> &s) 
      : singles(0) {
      init(s);
    }

    horspool_finder(const vector<char_type> &v) 
      : singles(0) {
      init(v);
    }

    template <typename RandomAccessI>
    horspool_finder(RandomAccessI first, RandomAccessI last) 
      : singles(0) {
      init(first, last);
    }

    bool init(const basic_string<char_type> &s) {
      return init(s.begin(), s.end());
    }

    bool init(const vector<char_type> &v) {
      return init(v.begin(), v.end());
    }

    // precondition: s.size() > 0 && s.size() < 65536
    template <typename RandomAccessI>
    bool init(RandomAccessI x, RandomAccessI y) {
      if (y - x > 0 && y - x < 65536) {
	word_.clear();
	word_.insert(word_.end(), x, y);
	last_position = word_.end() - 1;
	shifts();
	return true;
      }
      return false;
    }

    bool init(const char_type &c) {
      word_.clear();
      word_.push_back(c);
      shifts();
      return true;
    }

    const vector<char_type>& word() const  { return word_; }
    unsigned int             size() const  { return word_.size(); }
    bool                     empty() const { return word_.empty(); }

    // returns beg of match
    template <typename RandomAccessI>
    RandomAccessI find(RandomAccessI first, RandomAccessI last) const {
      switch (singles) {
      default:
	for(; first != last; ++first) {
	  if (bitmap[CharTraits::to_int_type(*first)])
	    return first;
	}
	break;
      case 1:
	for(; first != last; ++first) {
	  if (*first == single)
	    return first;
	}
	break;
      case 0:
	for(int displacement = size() - 1; displacement < last - first; displacement = shift[CharTraits::to_int_type(*first)]) {
	  first += displacement;
	  RandomAccessI x = first;
	  for(vector_const_iterator y = last_position; CharTraits::eq(*x, *y); --x, --y)
	    if (y == word_.begin())
	      return x;
	}
      }
      return last;
    }

    bool operator<(const self &x) const {
      return size() < x.size() || (size() == x.size() && word_ < x.word_);
    }

  protected:
    vector<char_type>      word_;
    vector<unsigned short> shift;
    vector_const_iterator  last_position;
    vector<char>           bitmap;
    int                    singles;
    char_type              single;

    void shifts() {
      if (word_.size() == 1) {
	single = word_.front();
	++singles;
	bitmap.resize(CharTraits::size, false);
	bitmap[CharTraits::to_int_type(word_.front())] = true;
      }
      else {
	shift.clear();
	shift.resize(CharTraits::size, (unsigned short) word_.size());
	for (vector_size_type i = 0; i < word_.size() - 1; ++i)
	  shift[CharTraits::to_int_type(word_[i])] = word_.size() - 1 - i;
      }
    }

  private:
    horspool_finder(const self&);
    self& operator=(const self&);
  };

  template <typename CharTraits>
  class multiple_horspool_finder
  {
  public:
    typedef multiple_horspool_finder<CharTraits> self;
    typedef horspool_finder<CharTraits>          finder_type;
    typedef typename finder_type::char_type      char_type;

    multiple_horspool_finder()
    { }

    multiple_horspool_finder(const vector<basic_string<char_type> > &s) {
      init(s);
    }

    bool init(const basic_string<char_type> &s) {
      return init(vector<basic_string<char_type> >(1, s));
    }

    template <typename Container>
    bool init(const vector<Container> &s) {
      clear();
      finders.reserve(s.size());
      finder_type *singles = new finder_type;
      for(typename vector<Container>::const_iterator i = s.begin(); i != s.end(); ++i) {
	// cerr << "horspool " << i - s.begin() + 1 << " '" << string(i->begin(), i->end()) << "'" << endl;
	if (i->size() == 1)
	  singles->init(*i->begin()); // special optimization
	else
	  finders.push_back(make_pair((const char_type*) NULL, new finder_type(i->begin(), i->end())));
      }
      if (!singles->empty())
	finders.push_back(make_pair((const char_type*) NULL, singles));
      return !finders.empty();
    }

    void clear() {
      for(typename container::iterator i = finders.begin(); i != finders.end(); ++i)
        delete i->second;
      finders.clear();
    }

    ~multiple_horspool_finder() {
      clear();
    }

    int size() const {
      return finders.size();
    }

    const char_type* find(const char_type *first, const char_type *last) {
      leftmost = finders.begin();
      for(typename container::iterator f = finders.begin(); f != finders.end(); ++f) {
	f->first = f->second->find(first, last);
	if (f->first < leftmost->first)
	  leftmost = f;
      }
      return leftmost->first;
    }

    const char_type* next(const char_type *first, const char_type *last) {
      leftmost->first = leftmost->second->find(first, last);
      if (finders.size() > 1) {
	for(typename container::iterator f = finders.begin(); f != finders.end(); ++f) {
	  if (f->first < first)
	    f->first = f->second->find(first, last);
	  if (f->first < leftmost->first)
	    leftmost = f;
	}
      }
      return leftmost->first;
    }

  protected:
    typedef vector<pair<const char_type*, const finder_type*> > container;
    typename container::iterator leftmost;
    container finders;

  private:
    multiple_horspool_finder(self&);
    self& operator=(const self&);
  };

  class boyer_moore_finder
  {
  public:
    boyer_moore_finder()
    { }

    boyer_moore_finder(const string &s) {
      init(s);
    }

    void init(const string &s) {
      word = s;
      bmGs.resize(s.size());
      bmBc.clear();
      bmBc.resize(256, s.size());
      good_suffix_shifts();
      bad_character_shifts();
    }

    unsigned int size() const { return word.size(); }

    string::const_iterator find(const string &s) const {
      return find(s.begin(), s.end());
    }

    // returns beg of match
    template <typename RandomAccessI>
    RandomAccessI find(RandomAccessI first, RandomAccessI last) const {
      const int m = size() - 1;
      last -= m;
      int i;
      while (first < last) {
        for (i = m; i >= 0 && word[i] == first[i]; --i) ;
        if (i < 0)
          return first;
        else
          first += bmGs[i] > (i - bmBc[(unsigned char) first[i]]) ?
            bmGs[i] : (i - bmBc[(unsigned char) first[i]]);
      }
      return last + m;
    }

  protected:
    string word;
    vector<int> bmGs, bmBc;

    void bad_character_shifts() {
      for (string::size_type i = 0; i < word.size() - 1; ++i)
        bmBc[(unsigned char) word[i]] = i;
    }

    void suffixes(vector<int>& suff) {
      const int m = (int) word.size();
      int f = 0, g, i;
      suff[m - 1] = m;
      g = m - 1;
      for (i = m - 2; i >= 0; --i) {
        if (i > g && suff[i + m - 1 - f] < i - g)
          suff[i] = suff[i + m - 1 - f];
        else {
          if (i < g)
            g = i;
          f = i;
          while (g >= 0 && word[g] == word[g + m - 1 - f])
            --g;
          suff[i] = f - g;
        }
      }
    }

    void good_suffix_shifts() {
      const int m = (int) word.size();
      int i, j;
      vector<int> suff(m);
      suffixes(suff);
      for (i = 0; i < m; ++i)
        bmGs[i] = m;
      j = 0;
      for (i = m - 1; i >= 0; --i)
        if (suff[i] == i + 1)
          for (; j < m - 1 - i; ++j)
            if (bmGs[j] == m)
              bmGs[j] = m - 1 - i;
      for (i = 0; i <= m - 2; ++i)
        bmGs[m - 1 - suff[i]] = m - 1 - i;
    }
  };

} //namespace astl

#endif // ASTL_SEARCH_H
