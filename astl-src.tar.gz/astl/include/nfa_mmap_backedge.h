/* -*- Mode: C++; tab-width: 4 -*- */
/* vi: set ts=4 sw=4 noexpandtab: */

/*******************************************************************************
 * Hessen Automata Library
 * Copyright 2009 Michael Tautschnig, tautschnig@forsyte.de
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/

#ifndef HAT__CURSORS__NFA_MMAP_BACKEDGE_HPP
#define HAT__CURSORS__NFA_MMAP_BACKEDGE_HPP

/*! \file hat/cursors/nfa_mmap_backedge.hpp
 * \brief TODO
 *
 * $Id: nfa_mmap_backedge.hpp 105 2009-07-27 17:52:51Z tautschnig $
 * \author Michael Tautschnig  <mt@debian.org>
 * \date   Tue Mar 03 17:46:51 CET 2009
*/

#include <nfa_mmap.h>

namespace astl {

template <class _Sigma = ::astl::plain,
		 class _Tag   = ::astl::empty_tag> 
		 class NFA_mmap_backedge : public ::astl::NFA_mmap<_Sigma, _Tag>
{
	typedef ::astl::NFA_mmap<_Sigma, _Tag> super;
	public:
		typedef typename super::char_traits  char_traits;
		typedef typename super::char_type  char_type;
		typedef typename super::tag_type   tag_type;
		typedef typename super::state_type state_type;

	protected:
		typedef typename super::state_data state_data;

		// Copy construction for duplicate:
		state_type new_state(const state_data &x) {
			return super::new_state(x);
		}

		vector<state_data*> Qbackedge;

		class backedges_type : public super::edges_type {
			friend class NFA_mmap_backedge<_Sigma, _Tag>;

			protected:
			backedges_type(const typename super::transition_container *c)
				: super::edges_type(c) { }
		};

	public:
		typedef typename super::const_iterator  const_iterator;

		state_type new_state() 
		{
			Qbackedge.push_back(new state_data);
			return super::new_state();
		}

		void del_state(state_type s) 
		{ 
			for (typename super::edges_type::const_iterator iter(this->Q[s]->edges.begin());
					iter != this->Q[s]->edges.end(); ++iter)
			{
				typename multimap<char_type, state_type>::iterator iter2(Qbackedge[iter->second]->edges.begin());
				for(;iter2 != Qbackedge[iter->second]->edges.end() && iter2->second != s; ++iter2);
				Qbackedge[iter->second]->edges.erase(iter2);
			}
			super::del_state(s);
		}

		void set_trans(state_type s, const char_type &l, state_type aim)
		{
			Qbackedge[aim]->edges.insert(make_pair(l,s));
			super::set_trans(s, l, aim);
		}

		void del_trans(state_type s, const char_type &l) {
			pair<typename multimap<char_type, state_type>::iterator, 
				typename multimap<char_type, state_type>::iterator>
					p = this->Q[s]->edges.equal_range(l);
			for(; p.first != p.second; ++p.first)
				Qbackedge[p.first->second]->edges.erase(l);
			super::del_trans(s, l);
		}

		void del_trans(state_type s, const char_type &l, state_type aim)
		{
			pair<typename multimap<char_type, state_type>::iterator, 
				typename multimap<char_type, state_type>::iterator>
					p = Qbackedge[aim]->edges.equal_range(l);
			for(; p.first != p.second && p.first->second != s; ++p.first);
			Qbackedge[aim]->edges.erase(p.first);
			super::del_trans(s, l, aim);
		}

		void change_trans(state_type s, const char_type &l, 
				state_type former_aim, state_type new_aim)
		{
			typename super::transition_container &e = Qbackedge[former_aim]->edges;
			typename super::transition_container::iterator p = e.find(l);
			for(; (*p).second != s; ++p);
			Qbackedge[former_aim]->edges.erase(p);
			Qbackedge[new_aim]->edges.insert(make_pair(l,s));
			super::change_trans(s, l, former_aim, new_aim);
		}

		void copy_state(state_type from, state_type to)
		{
			for (typename super::edges_type::const_iterator iter(this->Q[to]->edges.begin());
					iter != this->Q[to]->edges.end(); ++iter)
			{
				typename super::edges_type::const_iterator iter2(Qbackedge[iter->second]->edges.begin());
				for(;iter2 != Qbackedge[iter->second]->edges.end() && iter2->second != to; ++iter2);
				Qbackedge[iter->second]->edges.erase(iter2);
			}
			for (typename super::edges_type::const_iterator iter(this->Q[from]->edges.begin());
					iter != this->Q[from]->edges.end(); ++iter)
			{
				Qbackedge[iter->second]->edges.insert(::std::make_pair(iter->first,to));
			}
			super::copy_state(from, to);
		}

		state_type duplicate_state(state_type q) {
			state_type s = super::duplicate_state(q);
			Qbackedge.push_back(new state_data);
			for (typename super::edges_type::const_iterator iter(this->Q[q]->edges.begin());
					iter != this->Q[q]->edges.end(); ++iter)
			{
				Qbackedge[iter->second]->edges.insert(::std::make_pair(iter->first,s));
			}

			return s;
		}
  
		typename super::edges_type delta2_backwards(state_type s) const { 
			return backedges_type(&Qbackedge[s]->edges); 
		}

		NFA_mmap_backedge(unsigned long n = 0) : super(n), Qbackedge(1, static_cast< state_data* >(0)) {}
};

}

#endif /* HAT__CURSORS__NFA_MMAP_BACKEDGE_HPP */

