#ifndef REGEXP_TOOLS_H_
# define REGEXP_TOOLS_H_

#include "ucs.h"
#include "utf8.h"

#include <vector>
#include <algorithm>
#include <utility>
#include <iostream>
#include <limits>

namespace astl { namespace rex {

    typedef enum { STAR, CONCAT, OR, REPEAT, EPSILON, 
		   LETTER, OPEN, CLOSE, QUESTION, PLUS,
		   ANY, FINAL } token_type;

    struct node;

    class state_set
    {
    public:
      typedef state_set self;
      typedef vector<node*> node_container;
      typedef node_container::iterator iterator;
      typedef node_container::const_iterator const_iterator;

      iterator begin() { return where.begin(); }
      const_iterator begin() const { return where.begin(); }

      iterator end() { return where.end(); }
      const_iterator end() const { return where.end(); }

      size_t size() const { return where.size(); }
      bool empty() const { return where.empty(); }

      void clear() {
        where.clear();
        deduper.clear();
      }

      void insert(node *n);

      template <typename InputI>
      void insert(InputI x, InputI y) {
        for(; x != y; ++x)
	  insert(*x);
      }

      void swap(self &x) { 
	where.swap(x.where); 
	deduper.swap(x.deduper);
      }

      self& operator=(const self &x) {
	where = x.where;
	deduper = x.deduper;
	return *this;
      }

      self& operator=(const node_container &x) {
	clear();
	insert(x.begin(), x.end());
	return *this;
      }

      const vector<node*>& nodes() const { return where; }

    protected:
      vector<node*> where;
      vector<char>  deduper;
    };
  
    struct node 
    {
      ucs2_set   cset;
      token_type type;
      short      n, m; // repeat operator
      bool       nullable;
      state_set  first, last, next;
      int        id; // for final states in regexpset

      bool match(UCS2 c) const {
	return cset.find(c);
      }
    
      explicit node(token_type t, short n_ = 0, short m_ = 0)
	: type(t), n(n_), m(m_), id(numeric_limits<int>::max())  {
	if (type == ANY) {
	  nullable = false;
	  type = LETTER;
	  cset.any();
	}
      }

      explicit node(UCS2 t)
	: type(LETTER), nullable(false), id(numeric_limits<int>::max())  { 
	cset.add(t);
      }

      explicit node(const ucs2_set &t)
	: cset(t), type(LETTER), nullable(false), id(numeric_limits<int>::max()) 
      { }

      bool final() const {
	return type == FINAL;
      }
    };

    struct lower_than_node : binary_function<const node*, const node*, bool>
    {
      bool operator()(const node *x, const node *y) const {
	return x->id < y->id;
      }
    };

    inline
    void state_set::insert(node *n) {
      assert(n->id < numeric_limits<int>::max());
      if (deduper.size() <= (vector<char>::size_type) n->id)
	deduper.resize(n->id + 1, false);
      if (deduper[n->id] == false) {
	deduper[n->id] = true;
	where.push_back(n);
      }
    }

    class node_allocator
    {
    public:
      typedef vector<node*>::iterator       iterator;
      typedef vector<node*>::const_iterator const_iterator;
      typedef vector<node*>::size_type     size_type;

      node_allocator()
	: letter_count_(0) { 
	e->reserve(1024);
      }

      size_type      size() const  { return e->size(); }
      iterator       begin()       { return e->begin(); }
      iterator       end()         { return e->end(); }
      const_iterator begin() const { return e->begin(); }
      const_iterator end() const   { return e->end(); }
      void           clear()       { e->clear(); }

      int            references() const { return e.count(); }
      
      node* nodeAt(size_type p) const {
	return (*e)[p];
      }

      node* newNode(token_type t, short n_ = 0, short m_ = 0) {
	e->push_back(new node(t, n_, m_));
	if (t == LETTER || t == FINAL || t == ANY)
	  e->back()->id = letter_count_++;
	return e->back();
      }

      node* newNodeUnregistered(const node &n) {
	node *r = new node(n);
	if (r->type == LETTER || r->type == FINAL || r->type == ANY)
	  r->id = letter_count_++;
	return r;
      }

      node* newNodeAt(vector<node*>::size_type p, token_type t, short n_ = 0, short m_ = 0) {
	e->insert(e->begin() + p, new node(t, n_, m_));
	if (t == LETTER || t == FINAL || t == ANY)
	  (*e)[p]->id = letter_count_++;
	return (*e)[p];
      }

      void replaceNodeAt(size_type p, token_type t) {
	(*e)[p] = new node(t);
	if (t == LETTER || t == FINAL || t == ANY)
	  (*e)[p]->id = letter_count_++;	
      }
      
      void deleteNodeAt(size_type p) {
	assert((*e)[p]->type != LETTER || (*e)[p]->type != FINAL || (*e)[p]->type != ANY);
	delete (*e)[p];
      }

      void eraseNodeAt(size_type p) {
	e->erase(e->begin() + p);
      }

      node* newNode(UCS2 t) {
	e->push_back(new node(t));
	e->back()->id = letter_count_++;
	return e->back();
      }

      node* newNode(const ucs2_set &t) {
	e->push_back(new node(t));
	e->back()->id = letter_count_++;
	return e->back();
      }

      node* newNode(const node &n) {
	e->push_back(new node(n));
	if (n.type == LETTER || n.type == FINAL || n.type == ANY)
	  e->back()->id = letter_count_++;
	return e->back();
      }

      int letter_count() const {
	return letter_count_;
      }

      template <typename InputI>
      void insert(size_type p, InputI first, InputI last) {
	e->insert(e->begin() + p, first, last);
      }

    protected:
      smart_ptr<vector<node*> > e;
      int letter_count_;
    };

    inline
    std::ostream& operator<<(std::ostream &out, const node &x) 
    {
      switch(x.type) {
      case LETTER :
	out << "LETTER";
	break;
	
      case OR : 
	out << "|"; 
	break;
	
      case FINAL :
	if (x.n > 0)
	  out << "[END " << x.n << "]";
	else
	  out << "[EoE]";
	break;
	
      case OPEN : 
	out << "("; 
	break;
	
      case CLOSE : 
	out << ")"; 
	break;
	
      case CONCAT : 
	out << " _ "; 
	break;
	
      case STAR : 
	out << "*"; 
	break;
	
      case QUESTION : 
	out << "?"; 
	break;
	
      case PLUS : 
	out << "+"; 
	break;
	
      case REPEAT : 
	out << "{" << x.n << "," << x.m << "}";
	break;
	
      default :
	break;
      } 
      return out;
    }

    inline
    void build_predefined_sets(map<string, ucs2_set>& predefined) {
      ucs2_set alpha, alnum, ascii, blank, cntrl, digit, notdigit, word, notword;
      ucs2_set graph, lower, print, punct, space, notspace, upper, xdigit;
      ucs2_set tab, nl, cr, ff, a, e, v, V, h, H;

      alpha.alpha();
      alnum.alnum();
      ascii.ascii();
      blank.blank();
      cntrl.control();
      digit.num();
      notdigit.not_num();
      word.word();
      notword.not_word();
      graph.graph();
      print.print();
      lower.lower();
      upper.upper();
      punct.punct();
      space.space();
      notspace.not_space();
      xdigit.xnum();
      tab.add((UCS2) '\t');
      nl.add((UCS2) '\n');
      cr.add((UCS2) '\r');
      ff.add((UCS2) '\f');
      a.add((UCS2) '\a');
      e.add((UCS2) '\x1B');
      v.add((UCS2) '\v');
      V.add((UCS2) 1, (UCS2) '\v' - 1); // ugly hack
      V.add((UCS2) '\v' + 1, (UCS2) -1);
      h.add((UCS2) ' ');
      H.add((UCS2) 1, (UCS2) ' ' - 1);  // ugly hack
      H.add((UCS2) ' ' + 1, (UCS2) -1);

      predefined["[:alnum:]"] = alnum;
      predefined["[:alpha:]"] = alpha;
      predefined["[:ascii:]"] = ascii;
      predefined["[:blank:]"] = blank;
      predefined["[:cntrl:]"] = cntrl;
      predefined["[:digit:]"] = digit;
      predefined["[:graph:]"] = graph;
      predefined["[:lower:]"] = lower;
      predefined["[:print:]"] = print;
      predefined["[:punct:]"] = punct;
      predefined["[:space:]"] = space;
      predefined["[:upper:]"] = upper;
      predefined["[:xdigit:]"] = xdigit;
      predefined["[:word:]"] = word;
      predefined["\\d"] = digit;
      predefined["\\D"] = notdigit;
      predefined["\\s"] = space;
      predefined["\\S"] = notspace;
      predefined["\\w"] = word;
      predefined["\\W"] = notword;
      predefined["\\t"] = tab;
      predefined["\\n"] = nl;
      predefined["\\r"] = cr;
      predefined["\\f"] = ff;
      predefined["\\a"] = a;
      predefined["\\e"] = e;
      predefined["\\v"] = v;
      predefined["\\V"] = V;
      predefined["\\h"] = h;
      predefined["\\H"] = H;
    }

    //  Mutex regexpu_cursor::predefined_sets_init_mutex = MUTEX_INIT;

    class tokenizer
    {
    public:
      node_allocator allocator;
      const char *error_message;
      int         error_position;

      tokenizer()
	: error_message(NULL), error_position(-1)
      { }

      int token_error(int p, const char *msg) {
	error_message = msg;
	error_position = p;
	return p;
      }

      int tokenize(const char *first, const char *last, int &final, bool sharp_is_final) {
	//     MutexAcquire(&predefined_sets_init_mutex);
	static map<string, ucs2_set> predefined;
	if (predefined.empty())
	  build_predefined_sets(predefined);
	//     MutexRelease(&predefined_sets_init_mutex);

	rex::node *previous = allocator.newNode(rex::OPEN);
  
	bool literal = false;
	bool to_upper = false, to_lower = false;
	vector<char> parenthesis; // contains '(' or 'i' for (?i:
	bool icase = false;
	final = 0;
  
	for(const char *begin = first; first != last;) {
	  if (literal && *first != '\\') {
	    if (previous->type != rex::OPEN && previous->type != rex::OR) 
	      allocator.newNode(rex::CONCAT);
	    ucs2_set tmp;
	    tmp.add(utf8_to_ucs2(first));
	    tmp.case_insensitive(icase);
	    previous = allocator.newNode(tmp);
	    first += utf8_char_length(*first);
	    continue;
	  }

	  switch (*first) {
	  case '|' :
	    if (first == begin)
	      return token_error(0, "missing left part of alternative");
	    previous = allocator.newNode(rex::OR);
	    ++first;
	    break;

	  case '(' : 
	    if (first + 2 < last && first[1] == '?' && first[2] == '#') {  // comments (?#
	      const char *end_of_comments = find(first + 3, last, ')');
	      if (end_of_comments == last)
		return token_error(first - begin, "unbalanced parenthesis for comments");
	      first = end_of_comments + 1;
	      break;
	    }
	    if (first + 2 < last && first[1] == '?' && first[2] == ':') { // non capturing parenthesis (?:
	      first += 2;
	    }
	    else
	      if (first + 3 < last && first[1] == '?' && first[2] == 'i' && 
		  (first[3] == ':' || first[3] == ')')) { // case insensitive (?i: or (?i)
		first += 3;
		if (icase == false) {
		  if (*first == ':') {
		    parenthesis.push_back('i');
		    if (previous->type != rex::OPEN && previous->type != rex::OR) 
		      allocator.newNode(rex::CONCAT);
		    previous = allocator.newNode(rex::OPEN);
		  }
		  else 
		    if (!parenthesis.empty())
		      parenthesis.back() = 'i'; // turn normal parenthesis to (?i:
		  icase = true;
		  ++first;
		  break;
		}
		else if (*first == ')') {
		  ++first; 
		  break; // forget the (?i), we already were in case-insensitive mode
		}
	      }
	    if (previous->type != rex::OPEN && previous->type != rex::OR) 
	      allocator.newNode(rex::CONCAT);
	    previous = allocator.newNode(rex::OPEN);
	    parenthesis.push_back('(');
	    ++first;
	    break;

	  case ')' : 
	    if (parenthesis.empty())
	      return token_error(first - begin, "unbalanced parenthesis");
	    if (parenthesis.back() == 'i')
	      icase = false;
	    parenthesis.pop_back();
	    previous = allocator.newNode(rex::CLOSE);
	    ++first;
	    break;

	  case '*' :
	    if (first == begin)
	      return token_error(0, "missing expression before operator *");
	    previous = allocator.newNode(rex::STAR);
	    ++first;
	    break;

	  case '?' :
	    if (first == begin)
	      return token_error(0, "missing expression before operator ?");
	    previous = allocator.newNode(rex::QUESTION);
	    ++first;
	    break;

	  case '+' :
	    if (first == begin)
	      return token_error(0, "missing expression before operator +");
	    previous = allocator.newNode(rex::PLUS);
	    ++first;
	    break;

	  case '{' : // {n,m}
	    if (first == begin)
	      return token_error(0, "missing expression before repeat operator");
	    if (++first == last) 
	      return token_error(first - begin, "unterminated expression");
	    {
	      int n = 0;
	      const char *tmp = first;
	      while (isdigit(*first)) {
		n = n * 10 + *first - '0';
		if (++first == last) 
		  return token_error(first - begin, "unterminated repeat operator");
	      }
	      int m = n;
	      if (*first == ',') {
		if (++first == last) 
		  return token_error(first - begin, "unterminated repeat operator");
		tmp = first;
		for(m = 0; isdigit(*first);) {
		  m = m * 10 + *first - '0';
		  if (++first == last) 
		    return token_error(first - begin, "unterminated repeat operator");
		}
		if (tmp == first) m = -1; // comma but no upper bound: {n,}
	      }
	      if (*first != '}') 
		return token_error(first - begin, "invalid repeat operator");

	      // errors: {0} {0,0} {,0}
	      if (n > 32768 || m > 65535 || (n > m && m > -1) || (n == m && n == 0)) 
		return token_error(first - begin, "wrong range for repeat operator");

	      // special cases: {0,1} {,1} {0,} {1,} {1,1}
	      if (n == 0 && m == 1)
		previous = allocator.newNode(rex::QUESTION);
	      else if (n == 0 && m == -1)
		previous = allocator.newNode(rex::STAR);
	      else if (n == 1 && m == -1)
		previous = allocator.newNode(rex::PLUS);
	      else if (!(n == 1 &&  m == 1))
		previous = allocator.newNode(rex::REPEAT, n, m);
	    }
	    ++first;
	    break;

	  case '[' :   // characters set
	    {
	      if (previous->type != rex::OPEN && previous->type != rex::OR) 
		allocator.newNode(rex::CONCAT);
	      ucs2_set a;
	      bool v = true; // a priori, not a negation
	      if (++first == last) 
		return token_error(first - begin, "unterminated expression");
	      if (*first == '^') {  // a negation ?
		v = false;
		if (++first == last) 
		  return token_error(first - begin, "unterminated expression");
	      }
	      if (*first == '-') {  // "escaped" hyphen at the beginning ?
		a.add((unsigned char) '-');
		++first;
	      }
	      else
		if (*first == ']') {  // "escaped" closing square bracket at the beginning ?
		  a.add((unsigned char) ']');
		  ++first;
		}
	      for(; first != last && *first != ']'; ++first) {
		if (*first == '[') {
		  if (++first == last) break;
		  if (*first != ':') { // not a predefined character set ?
		    a.add((unsigned char) '[');
		  }
		  else { // a predefined set as [:digits:]
		    const char *start = first - 1;
		    first = std::find(++first, last, ']');
		    if (first == last) break;
		    std::map<string, ucs2_set>::const_iterator c = predefined.find(std::string(start, first + 1));
		    if (c == predefined.end())
		      return token_error(start - begin, "unknown character set");
		    a.add(c->second);
		    continue;
		  }
		}
		// TODO: next_char manages ranges and return a character set (pass a boolean for 
		// saying this is a character set context and '-' as a special meaning, good for
		// . also, see below the ugly hack)
		ucs2_set tmp; // will possibly be used as a range lower bound
		if (*first != '-') {  // not a potential character range ?
		  switch (*first) {
		  case '^' : // literal in character set
		  case '$' : // literal in character set
		    tmp.add((unsigned char) *first++);
		  break;
		  default :
		    {
		      // case-insensitiveness will be handled once the character set is entirely built
		      int r = next_char(tmp, begin, first, last, literal, predefined, false, true, to_upper, to_lower);
		      if (r != -1)
			return r;
		    }
		  }
		  a.add(tmp);
		  if (*first != '-') {
		    --first;
		    continue;
		  }
		}
		// now *first == '-'
		if (++first == last) 
		  return token_error(first - begin, "unterminated expression");
		if (*first == ']') {  // unterminated character range ?
		  a.add((unsigned char) '-'); // that was not a character range
		  break; // end of character set
		}
		else { // character range [a-z]
		  bool is_range = true;
		  // if a bound is a set then the '-' is understood literally
		  if (tmp.begin() != tmp.end()) { // a bound must not be a character set
		    tmp.add((unsigned char) '-');
		    is_range = false;
		  }
		  ucs2_set upper_bound;
		  switch (*first) {
		  case '^' : // literal in character set
		  case '$' : // literal in character set
		    upper_bound.add((unsigned char) *first);
		  break;
		  default :
		    {
		      int r = next_char(upper_bound, begin, first, last, literal, predefined, false, true, to_upper, to_lower);
		      --first;
		      if (r != -1)
			return token_error(first - begin, "wrong character range");
		    }
		  }
		  // if a bound is a set then it is not a range
		  if (upper_bound.begin() != upper_bound.end() || !is_range) {
		    a.add(tmp);
		    a.add(upper_bound);
		  }
		  else {
		    // guess what, lower bound should be lower or equal to upper bound
		    if (upper_bound.begin() < tmp.begin())
		      return token_error(first - begin, "wrong character range: lower bound cannot be greater than upper bound");
		    else
		      a.add(tmp.begin(), upper_bound.begin());
		  }
		}
	      }
	      // first is supposed to point to ']'
	      if (first == last) 
		return token_error(first - begin, "unterminated expression");
	      ++first;
	      a.case_insensitive(icase);
	      // put negation handling here because we want to be able to manage for instance (?i:[^a-z])
	      a.negation(!v);
	      previous = allocator.newNode(a);
	      break;
	    }

	  default :
	    if (sharp_is_final && *first == '#') {
	      allocator.newNode(rex::CONCAT);
	      previous = allocator.newNode(rex::FINAL, final++);
	      ++first;
	      break;
	    }

	    // a few exceptions:
	    if (*first == '\\') {
	      if (++first == last) 
		return token_error(first - begin, "unterminated escape sequence");
	      if (*first == 'R') {  // \R == ([\r\n\x85\x{2028}\x{2029}]|\r\n)
		++first;
		ucs2_set rn;
		rn.add((unsigned char) '\r');
		rn.add((unsigned char) '\n');
		rn.add((UCS2) 0x85);
		rn.add((UCS2) 0x2028); // line separator
		rn.add((UCS2) 0x2029); // paragraph separator
		ucs2_set r;
		r.add((unsigned char) '\r');
		ucs2_set n;
		r.add((unsigned char) '\n');
		if (previous->type != rex::OPEN && previous->type != rex::OR) 
		  allocator.newNode(rex::CONCAT);
		allocator.newNode(rex::OPEN);
		allocator.newNode(rn);
		allocator.newNode(rex::OR);
		allocator.newNode(r);
		allocator.newNode(rex::CONCAT);
		allocator.newNode(n);
		previous = allocator.newNode(rex::CLOSE);
		break;
	      }
	      else if (*first == 'X') {  // \X matches any non mark character followed by zero or more mark characters
		++first;
		ucs2_set mark;
		mark.mark();
		ucs2_set not_mark;
		not_mark.not_mark();
		if (previous->type != rex::OPEN && previous->type != rex::OR) 
		  allocator.newNode(rex::CONCAT);
		allocator.newNode(not_mark);
		allocator.newNode(rex::CONCAT);
		allocator.newNode(mark);
		previous = allocator.newNode(rex::STAR);
		break;
	      }
	      else --first;
	    }
	    ucs2_set next_letter;
	    int r = next_char(next_letter, begin, first, last, literal, predefined, icase, false, to_upper, to_lower);
	    if (r != -1)
	      return r;
	    // next letter can be empty in the case of \E \L \U or \Q followed by nothing
	    if (!next_letter.empty()) {
	      if (previous->type != rex::OPEN && previous->type != rex::OR) 
		allocator.newNode(rex::CONCAT);
	      previous = allocator.newNode(next_letter);
	    }
	    break;
	  }
	}
	allocator.newNode(rex::CLOSE);
	allocator.newNode(rex::CONCAT);
	allocator.newNode(rex::FINAL);
	return -1;
      }

      // read char at position first and advance first
      // may return an empty char (\E, \L, \U or \Q followed by nothing)
      int next_char(ucs2_set &letter, const char *begin, const char*& first, const char *last, 
		    bool& literal, const map<string, ucs2_set> &predefined, bool icase, bool parsing_set,
		    bool &to_upper, bool &to_lower) {
	letter.clear();

	// std::cout << "next_char(" << first << ")" << std::endl; 

	// anchores
	if ((*first == '$' || *first == '^') && !literal) {
	  letter.add(0); // beginning/end of line is '\0'
	  ++first;
	  return -1;
	}

	if (*first == '\\') {
	  if (++first == last) 
	    return token_error(first - begin, "unterminated escape sequence");

	  // Uppercase sequence \U ... \E
	  if (*first == 'U')  {
	    if (literal) {
	      letter.add((unsigned char) '\\');
	      return -1;
	    }
	    else {
	      to_upper = true;
	      to_lower = false;
	      ++first;
	      return -1;
	    }
	  }

	  // Lowercase sequence \L ... \E
	  if (*first == 'L')  {
	    if (literal) {
	      letter.add((unsigned char) '\\');
	      return -1;
	    }
	    else {
	      to_upper = false;
	      to_lower = true;
	      ++first;
	      return -1;
	    }
	  }

	  // quote sequence \Q ... \E
	  if (*first == 'Q') {
	    if (literal) {
	      letter.add((unsigned char) '\\');
	      return -1;
	    }
	    else {
	      literal = true;
	      if (++first != last) 
		return next_char(letter, begin, first, last, literal, predefined, icase, parsing_set, to_upper, to_lower);
	      return -1;
	    }
	  }

	  if (*first == 'E') {
	    literal = false;
	    to_upper = false;
	    to_lower = false;
	    ++first;
	    return -1;
	  }

	  if (literal) {
	    letter.add((unsigned char) '\\');
	    return -1;
	  }
      
	  if (*first >= '0' && *first <= '9') { // octal notation \01 through \777
	    int length = 1;
	    UCS2 n = 0;
	    for(; first != last && *first >= '0' && *first <= '9'; ++first, ++length) {
	      if (length > 3)
		return token_error(first - begin, "octal number cannot have more than 3 digits");
	      if (*first > '7')
		return token_error(first - begin, "malformed octal number");
	      n *= 8;
	      n += *first - '0';
	    }
	    if (length < 2) 
	      return token_error(first - begin, "octal number must have at least 2 digits");
	    letter.add(n);
	    return -1;
	  }

	  if (*first == 'x') { // hexadecimal character \x01 through \xFF or \x{1} through \x{FFFF}
	    if (++first == last)
	      return token_error(first - begin, "unterminated \\x escape sequence");
	    int n = 0;
	    bool curly = *first == '{';
	    const char *end = first + 2;
	    if (curly) 
	      end = std::find(++first, last, '}');
	    if ((curly && end == last) || (!curly && end > last))
	      return token_error(first - begin, "unterminated \\x escape sequence");
	    for(; first != end; ++first) {
	      n *= 16;
	      if (*first >= '0' && *first <= '9') {
		n += *first - '0'; 
	      }
	      else 
		if (*first >= 'A' && *first <= 'F') {
		  n += 10 + (*first - 'A'); 
		}
		else
		  if (*first >= 'a' && *first <= 'f') {
		    n += 10 + (*first - 'a'); 
		  }
		  else
		    return token_error(first - begin, "malformed hex number in \\x escape sequence");
	    }
	    letter.add(n);
	    if (curly) ++first;
	    return -1;
	  }
      
	  if (parsing_set && *first == 'b') { // \b is backspace in a character set
	    letter.add((unsigned char) '\b');
	    ++first;
	    return -1;
	  }

	  if (*first == 'l') { // \l lowercase next char
	    if (++first == last)
	      return token_error(first - begin, "unterminated \\l escape sequence");
	    UCS2 original = utf8_to_ucs2(first);
	    UCS2 n = astl::tolower(original);
	    if (n == 0) letter.add(original);
	    else letter.add(n);
	    first += utf8_char_length(*first);
	    return -1;
	  }

	  if (*first == 'u') { // \u uppercase next char
	    if (++first == last)
	      return token_error(first - begin, "unterminated \\u escape sequence");
	    UCS2 original = utf8_to_ucs2(first);
	    UCS2 n = astl::toupper(original);
	    if (n == 0) letter.add(original);
	    else letter.add(n);
	    first += utf8_char_length(*first);
	    return -1;
	  }

	  if (*first == 'c') { // control character \cA through \c[ maps to \x01 \x1B
	    if (++first == last)
	      return token_error(first - begin, "unterminated \\c escape sequence");
	    if (*first >= 'A' && *first <= 'Z')
	      letter.add(*first - 'A' + 1);
	    else if (*first >= 'a' && *first <= 'z')
	      letter.add(*first - 'a' + 1);
	    else if (*first == '[')
	      letter.add(*first - 'A' + 1);
	    else return token_error(first - begin, "\\c used with illegal following letter");
	    ++first;
	    return -1;
	  }

	  // look for \s, \S, \w, \W, \d, \D, \n, \t, \v, \V, \r, \a, \e, \f, \h, \H
	  std::map<string, ucs2_set>::const_iterator c = predefined.find(std::string("\\") + *first);
	  if (c != predefined.end()) {
	    letter = c->second;
	    ++first;
	    return -1;
	  }

	  if (*first == '.') {
	    letter.add((unsigned char) '.');
	    ++first;
	    return -1;
	  }
	}

	if (*first == '.') {
	  if (literal || parsing_set) // a dot has no special meaning in a character set
	    letter.add((unsigned char) '.');
	  else
	    letter.any();
	}
	else {
	  UCS2 original = utf8_to_ucs2(first);
	  UCS2 n = original;
	  if (to_upper) {
	    n = astl::toupper(original);
	    if (n == 0) n = original;
	  }
	  else if (to_lower)  {
	    n = astl::tolower(original);
	    if (n == 0) n = original;
	  }
	  letter.add(n);
	  first += utf8_char_length(*first) - 1;
	  letter.case_insensitive(icase);
	}
	++first;
	return -1;
      }

      void preprocess_repeats() {
	for(rex::node_allocator::size_type p = 0; p < allocator.size();) {
	  if (allocator.nodeAt(p)->type != rex::REPEAT) ++p;
	  else {
	    // look for what is repeated: letter, (exp), ?, +, *, ANY 
	    rex::node_allocator::size_type first = p - 1, last = p;
	    for(; first > 0; --first) {
	      if (allocator.nodeAt(first)->type == rex::LETTER || allocator.nodeAt(first)->type == rex::CLOSE || allocator.nodeAt(first)->type == rex::ANY)
		break;
	    }
	    if (allocator.nodeAt(first)->type == rex::CLOSE) {
	      int count = 1;
	      while(count != 0 && --first > 0)
		if (allocator.nodeAt(first)->type == rex::CLOSE) ++count;
		else if (allocator.nodeAt(first)->type == rex::OPEN) --count;
	    }
	    // the range [first, last) contains the pattern to be repeated
	    // enclose it in parenthesis because of such things: a{0,2}{3}
	    // which would otherwise be rewritten: a?a?{3} but shoud be written: (a?a?){3}
	    // limiting to 1024
	    short n = (allocator.nodeAt(p)->n > 1024 ? 1024 : allocator.nodeAt(p)->n), 
	      m = (allocator.nodeAt(p)->m > 1024 ? 1024 : allocator.nodeAt(p)->m);
	    allocator.newNodeAt(first, rex::OPEN);
	    ++p;
	    ++last;
	    ++first;
	    // remove repeat node
	    allocator.deleteNodeAt(p);
	    if (n == 0) {
	      allocator.replaceNodeAt(p, rex::QUESTION);
	    }
	    else allocator.eraseNodeAt(p);
	    vector<rex::node*> tmp;
	    if (m == -1) 
	      tmp.reserve((last + 1 - first) * n + 1);
	    else
	      tmp.reserve((last + 1 - first) * m + m - n + 1);

	    while(n > 0 || m > 0) {
	      --n; 
	      --m;
	      if (n <= 0) { // end of mandatory repeats ?
		if (m < n) {  // case {n,}
		  tmp.push_back(new rex::node(rex::PLUS));
		  continue; // end of processing
		}
		if (m == 0)
		  continue; // end of processing
	      }
	      tmp.push_back(new rex::node(rex::CONCAT));
	      for(vector<rex::node*>::size_type tmp_p = first; tmp_p < last; ++tmp_p) {
		tmp.push_back(allocator.newNodeUnregistered(*allocator.nodeAt(tmp_p)));
	      }
	      if (n <= 0) {
		tmp.push_back(new rex::node(rex::QUESTION));
	      }
	    }
	    tmp.push_back(new rex::node(rex::CLOSE));
	    allocator.insert(p, tmp.begin(), tmp.end());
	  }
	}
      }
    };

  } // namespace rex

} // namespace astl

#endif /* !REGEXP_TOOLS_H_ */
