/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2003 Vincent Le Maout (vincent.lemaout@chello.fr).
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_REGEXPU_H
#define ASTL_REGEXPU_H

#include "astl.h"
#include "lazy.h"
#include "ucs.h"
#include "utf8.h"
#include <vector>
#include <iostream>
#include <set>
#include <iterator>
#include <cctype>  
#include <bitset>
#include <cstring>
#include <sstream>

#define USE_HASH_TABLE

// guess what? crappy C++ compiler from sparc/solaris can't compile hash sets...
#if defined(USE_HASH_TABLE) && defined(__sparc)
#undef USE_HASH_TABLE
#endif

#if defined(USE_HASH_TABLE)
// Use g++'s tr1::unordered_set if possible as it looks more efficient than boost's
#if defined(__GNUG__) && (__GNUC__ > 3)
#define USE_TR1_UNORDERED_SET
#include <tr1/unordered_set>
#else
#define USE_BOOST_UNORDERED_SET
#include <boost/unordered_set.hpp>
#endif

#endif // USE_HASH_TABLE

using namespace std;

namespace astl {

// regular expressions grammar:
// exp    -> term exp2
// exp2   -> + term exp2 | epsilon
// term   -> form repeat term2
// term2  -> . form repeat term2 | epsilon
// repeat -> * repeat | ? repeat | + repeat | {n,m} repeat | epsilon
// form   -> ( exp ) | letter 
//
// + is union, . is concatenation, epsilon is the empty word
// a letter is a set of chars

  // static Mutex regexp_predefined_sets_init_mutex = MUTEX_INIT;

  class regexpu_cursor : public cursor_concept
  {
#ifdef _MSC_VER
  public:
#else
  protected:
#endif
    struct node;
#ifdef USE_TR1_UNORDERED_SET
    typedef tr1::unordered_set<node*> S;
#else
#ifdef USE_BOOST_UNORDERED_SET
    typedef boost::unordered_set<node*> S;
#else
    typedef set<node*> S;
#endif
#endif

    typedef enum { STAR, CONCAT, OR, REPEAT, EPSILON, 
		   LETTER, OPEN, CLOSE, QUESTION, PLUS,
		   ANY, FINAL } token_type;


    struct node {
      ucs2_set cset;
      token_type type;
      short n, m; // repeat operator
      bool annulable;
      S premiere_pos, derniere_pos, pos_suivante;

      bool match(UCS2 c) const {
	return cset.find(c);
      }
    
      explicit node(token_type t, short n_ = 0, short m_ = 0)
	: type(t), n(n_), m(m_), annulable(false) {
	if (type == ANY) {
	  type = LETTER;
	  cset.any();
	}
      }

      explicit node(UCS2 t)
	: type(LETTER), annulable(false) { 
	cset.add(t);
      }

      explicit node(const ucs2_set &t)
	: cset(t), type(LETTER), annulable(false)
      { }

      bool final() const {
	return type == FINAL;
      }
    };

    S q;  // current state
    smart_ptr<vector<node*> > e;  // node "allocator"
    const char *errmsg;
    smart_ptr<S> I;

  public:
    // smart_ptr<horspool_finder> horspool;

  protected:
    // friend ostream& operator<<(ostream&, const regexpu_cursor&);

    node* exp(vector<node*>::iterator &first, vector<node*>::iterator last);
    node* form(vector<node*>::iterator &first, vector<node*>::iterator last);
    node* term(vector<node*>::iterator &first, vector<node*>::iterator last);
    node* exp2(vector<node*>::iterator &first, vector<node*>::iterator last, node *left);
    node* term2(vector<node*>::iterator &first, vector<node*>::iterator last, node *left);
    node* repeat(vector<node*>::iterator &first, vector<node*>::iterator last, node *left);
    void preprocess_repeats();
    void build_predefined_sets(map<string, ucs2_set>&);
    template <typename OutputIterator>
    int tokenize(const char *first, const char *last, OutputIterator x);

  public:
    friend ostream& operator<<(ostream &, const node&);
    ptrdiff_t errpos;

    typedef regexpu_cursor    self;
    typedef S                state_type;
    typedef set<node*>       ordered_state_type;
    typedef plain            char_traits;
    typedef UCS2             char_type;
    typedef empty_tag        tag_type;

    regexpu_cursor(const string &utf8)
      : errmsg(NULL), errpos(-1)
    {
      e->reserve(128);

      errpos = tokenize(utf8.c_str(), utf8.c_str() + utf8.size(), back_inserter(*e));

      if (errpos == -1) {
	preprocess_repeats();
	vector<node*>::iterator first = e->begin();
	node *root = exp(first, e->end());
	// managed non-anchored alternatives
	if (root != NULL) {
#if 0
	  // if there is only one position for the root and this position
	  // is not ^ nor ANY, then there may be a literal prefix that can
	  // be matched more efficiently with a horspool search
          if (horspool_optimized && root->premiere_pos.size() == 1) {
            // look for a litteral prefix of size > 1
            string prefix;
            node *n = *root->premiere_pos.begin();
            for(; n->letter.count() == 1 && !n->annulable && n->letter.test(0) == false; n = *(n->pos_suivante.begin())) {
              for(int i = 0; i < 256; ++i)
                if (n->letter.test(i) == true) {
                  prefix += (char) i;
                  break;
                }
              if (n->pos_suivante.size() != 1 || (*n->pos_suivante.begin())->type == FINAL) {
		if (prefix.size() > 1) {
		  // initialize horspool searcher and remove prefix from expression
		  horspool->init(prefix);
		  q = n->pos_suivante;
		  return;
		}
                break;
	      }
            }
            if (prefix.size() > 1) {
              // initialize horspool searcher and remove prefix from expression
              horspool->init(prefix);
              q.insert(n);
              return;
            }
          }
#endif
	  q = root->premiere_pos;
	  for(S::const_iterator i = q.begin(); i != q.end(); ++i)
	    // if not beginning of line anchor ^
	    if ((*i)->match(0) == false)
	      I->insert(*i);
	}
	else errpos = utf8.size() - errpos;
      }
    }

    void clear() {
      q.clear();
      I->clear();
      for(vector<node*>::iterator n = e->begin(); n != e->end(); ++n)
	delete *n;
      e->clear();
    }

    ptrdiff_t error() const { // possible error position (-1 if expression is ok)
      return errpos;
    }
    
    const char* error_message() const {
      return errmsg;
    }

    self& operator=(const state_type &s) {
      q = s;
      return *this;
    }

#ifdef USE_HASH_TABLE
    self& operator=(const ordered_state_type &s) {
      q.clear();
      q.insert(s.begin(), s.end());
      return *this;
    }
#endif

    const state_type& src() const {
      return q;
    }

    bool exists(UCS2 a) const {
      for(S::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(a)) return true;
      return false;
    }

    bool forward(UCS2 letter) {
      state_type p = *I; // for non-anchored expressions
      for(S::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(letter))
	  p.insert((*i)->pos_suivante.begin(), (*i)->pos_suivante.end());
      q.swap(p);   // optimized equivalent to q = p;
      return !q.empty();
    }
    
    bool src_final() const {
      for(S::const_iterator i = q.begin(); i != q.end(); ++i) 
	if ((*i)->final()) return true;
      return false;
    }
     
    bool sink() const {
      return q.empty();
    }
 
    tag_type src_tag() const {
      return tag_type();
    }

    ~regexpu_cursor() {
      if (e.count() == 1) {
	for(vector<node*>::iterator n = e->begin(); n != e->end(); ++n)
	  delete *n;
      }
    }

  protected:
    ptrdiff_t token_error(ptrdiff_t pos, const char *message) {
      errmsg = message;
      errpos = pos;
      return pos;
    }

    node* syntax_error(ptrdiff_t pos, const char *message = NULL) {
      errmsg = message;
      errpos = pos;
      return NULL;
    }

    int next_char(ucs2_set &letter, const char *begin, const char*& first, const char *last, 
		  bool& literal, const map<string, ucs2_set> &predefined, bool icase, bool parsing_set,
		  bool& to_upper, bool& to_lower);
  };

  inline
  void regexpu_cursor::preprocess_repeats() {
    vector<node*> &v = *e;
    for(vector<node*>::size_type p = 0; p < v.size();) {
      if (v[p]->type != REPEAT) ++p;
      else {
	// look for what is repeated: letter, (exp), ?, +, *, ANY 
	vector<node*>::size_type first = p - 1, last = p;
	for(; first > 0; --first) {
	  if (v[first]->type == LETTER || v[first]->type == CLOSE || v[first]->type == ANY)
	    break;
	}
	if (v[first]->type == CLOSE) {
	  int count = 1;
	  while(count != 0 && --first > 0)
	    if (v[first]->type == CLOSE) ++count;
	    else if (v[first]->type == OPEN) --count;
	}
	// the range [first, last) contains the pattern to be repeated
	// enclose it in parenthesis because of such things: a{0,2}{3}
	// which would otherwise be rewritten: a?a?{3} but shoud be written: (a?a?){3}
	// limiting to 1024
	short n = (v[p]->n > 1024 ? 1024 : v[p]->n), 
	  m = (v[p]->m > 1024 ? 1024 : v[p]->m);
	v.insert(v.begin() + first, new node(OPEN));
	++p;
	++last;
	++first;
	// remove repeat node
	if (n == 0)
	  v[p] = new node(QUESTION);
	else {
	  delete v[p];
	  v.erase(v.begin() + p);
	}
	vector<node*> tmp;
	if (m == -1) 
	  tmp.reserve((last + 1 - first) * n + 1);
	else
	  tmp.reserve((last + 1 - first) * m + m - n + 1);

	while(n > 0 || m > 0) {
	  --n; 
	  --m;
	  if (n <= 0) { // end of mandatory repeats ?
	    if (m < n) {  // case {n,}
	      tmp.push_back(new node(PLUS));
	      continue; // end of processing
	    }
	    if (m == 0)
	      continue; // end of processing
	  }
	  tmp.push_back(new node(CONCAT));
	  for(vector<node*>::size_type tmp_p = first; tmp_p < last; ++tmp_p)
	    tmp.push_back(new node(*v[tmp_p]));
	  if (n <= 0)
	    tmp.push_back(new node(QUESTION));
	}
	tmp.push_back(new node(CLOSE));
	v.insert(v.begin() + p, tmp.begin(), tmp.end());
      }
    }
  }

#if 0
  inline
  ostream& operator<<(ostream &out, const regexpu_cursor::node &x) 
  {
    switch(x.type) {
      case regexpu_cursor::LETTER :
	if (x.letter.count() == 256)
	  out << ".";
	else {
	  if (x.letter.count() > 1)
	    out << '[';
	  int lower = 0;
	  // rebuild approximatively the character set
	  for(int i = 32; i < 256; ++i) {
	    if (x.letter.test(i) == true) {
	      if (lower == 0)
		lower = i;
	    }
	    else {
	      if (lower > 0) {
		if (i - lower == 1) {
		  cout << (unsigned char) lower;
		}
		else if (i - lower == 2) {
		  cout << (unsigned char) lower << (unsigned char) (lower + 1);
		}
		else cout << (unsigned char) lower << '-' 
			  << (unsigned char) (i - 1);
		lower = 0;
	      }
	    }
	  }
	  if (x.letter.count() > 1)
	    out << ']';
	}
	break;
	
      case regexpu_cursor::OR : 
	out << "|"; 
	break;
	
      case regexpu_cursor::FINAL : 
	out << "[EoE]";
	break;
	
      case regexpu_cursor::OPEN : 
	out << "("; 
	break;
	
      case regexpu_cursor::CLOSE : 
	out << ")"; 
	break;
	
      case regexpu_cursor::CONCAT : 
	out << " "; 
	break;
	
      case regexpu_cursor::STAR : 
	out << "*"; 
	break;
	
      case regexpu_cursor::QUESTION : 
	out << "?"; 
	break;
	
      case regexpu_cursor::PLUS : 
	out << "+"; 
	break;
	
      case regexpu_cursor::REPEAT : 
	out << "{" << x.n << "," << x.m << "}";
	break;
	
      default :
	break;
    } 
    return out;
  }
#endif

  inline
  void regexpu_cursor::build_predefined_sets(map<string, ucs2_set>& predefined) {
    ucs2_set alpha, alnum, ascii, blank, cntrl, digit, notdigit, word, notword;
    ucs2_set graph, lower, print, punct, space, notspace, upper, xdigit;
    ucs2_set tab, nl, cr, ff, a, e, v, V, h, H;

    alpha.alpha();
    alnum.alnum();
    ascii.ascii();
    blank.blank();
    cntrl.control();
    digit.num();
    notdigit.not_num();
    word.word();
    notword.not_word();
    graph.graph();
    print.print();
    lower.lower();
    upper.upper();
    punct.punct();
    space.space();
    notspace.not_space();
    xdigit.xnum();
    tab.add((UCS2) '\t');
    nl.add((UCS2) '\n');
    cr.add((UCS2) '\r');
    ff.add((UCS2) '\f');
    a.add((UCS2) '\a');
    e.add((UCS2) '\x1B');
    v.add((UCS2) '\v');
    V.add((UCS2) 1, (UCS2) '\v' - 1); // ugly hack
    V.add((UCS2) '\v' + 1, (UCS2) -1);
    h.add((UCS2) ' ');
    H.add((UCS2) 1, (UCS2) ' ' - 1);  // ugly hack
    H.add((UCS2) ' ' + 1, (UCS2) -1);

    predefined["[:alnum:]"] = alnum;
    predefined["[:alpha:]"] = alpha;
    predefined["[:ascii:]"] = ascii;
    predefined["[:blank:]"] = blank;
    predefined["[:cntrl:]"] = cntrl;
    predefined["[:digit:]"] = digit;
    predefined["[:graph:]"] = graph;
    predefined["[:lower:]"] = lower;
    predefined["[:print:]"] = print;
    predefined["[:punct:]"] = punct;
    predefined["[:space:]"] = space;
    predefined["[:upper:]"] = upper;
    predefined["[:xdigit:]"] = xdigit;
    predefined["[:word:]"] = word;
    predefined["\\d"] = digit;
    predefined["\\D"] = notdigit;
    predefined["\\s"] = space;
    predefined["\\S"] = notspace;
    predefined["\\w"] = word;
    predefined["\\W"] = notword;
    predefined["\\t"] = tab;
    predefined["\\n"] = nl;
    predefined["\\r"] = cr;
    predefined["\\f"] = ff;
    predefined["\\a"] = a;
    predefined["\\e"] = e;
    predefined["\\v"] = v;
    predefined["\\V"] = V;
    predefined["\\h"] = h;
    predefined["\\H"] = H;
  }

  // read char at position first and advance first
  // may return an empty char (\E, \L, \U or \Q followed by nothing)
  inline
  int regexpu_cursor::next_char(ucs2_set &letter, const char *begin, const char*& first, const char *last, 
				bool& literal, const map<string, ucs2_set> &predefined, bool icase, bool parsing_set,
				bool &to_upper, bool &to_lower) {
    letter.clear();

    // std::cout << "next_char(" << first << ")" << std::endl; 

    // anchores
    if ((*first == '$' || *first == '^') && !literal) {
      letter.add(0); // beginning/end of line is '\0'
      ++first;
      return -1;
    }

    if (*first == '\\') {
      if (++first == last) 
	return token_error(first - begin, "unterminated escape sequence");

      // Uppercase sequence \U ... \E
      if (*first == 'U')  {
	if (literal) {
	  letter.add((unsigned char) '\\');
	  return -1;
	}
	else {
	  to_upper = true;
	  to_lower = false;
	  ++first;
	  return -1;
	}
      }

      // Lowercase sequence \L ... \E
      if (*first == 'L')  {
	if (literal) {
	  letter.add((unsigned char) '\\');
	  return -1;
	}
	else {
	  to_upper = false;
	  to_lower = true;
	  ++first;
	  return -1;
	}
      }

      // quote sequence \Q ... \E
      if (*first == 'Q') {
	if (literal) {
	  letter.add((unsigned char) '\\');
	  return -1;
	}
	else {
	  literal = true;
	  if (++first != last) 
	    return next_char(letter, begin, first, last, literal, predefined, icase, parsing_set, to_upper, to_lower);
	  return -1;
	}
      }

      if (*first == 'E') {
	literal = false;
	to_upper = false;
	to_lower = false;
	++first;
	return -1;
      }

      if (literal) {
	letter.add((unsigned char) '\\');
	return -1;
      }
      
      if (*first >= '0' && *first <= '9') { // octal notation \01 through \777
	int length = 1;
	UCS2 n = 0;
	for(; first != last && *first >= '0' && *first <= '9'; ++first, ++length) {
	  if (length > 3)
	    return token_error(first - begin, "octal number cannot have more than 3 digits");
	  if (*first > '7')
	    return token_error(first - begin, "malformed octal number");
	  n *= 8;
	  n += *first - '0';
	}
	if (length < 2) 
	  return token_error(first - begin, "octal number must have at least 2 digits");
	letter.add(n);
	return -1;
      }

      if (*first == 'x') { // hexadecimal character \x01 through \xFF or \x{1} through \x{FFFF}
	if (++first == last)
	  return token_error(first - begin, "unterminated \\x escape sequence");
	int n = 0;
	bool curly = *first == '{';
	const char *end = first + 2;
	if (curly) 
	  end = std::find(++first, last, '}');
	if ((curly && end == last) || (!curly && end > last))
	  return token_error(first - begin, "unterminated \\x escape sequence");
	for(; first != end; ++first) {
	  n *= 16;
	  if (*first >= '0' && *first <= '9') {
	    n += *first - '0'; 
	  }
	  else 
	    if (*first >= 'A' && *first <= 'F') {
	      n += 10 + (*first - 'A'); 
	    }
	    else
	      if (*first >= 'a' && *first <= 'f') {
		n += 10 + (*first - 'a'); 
	      }
	      else
		return token_error(first - begin, "malformed hex number in \\x escape sequence");
	}
	letter.add(n);
	if (curly) ++first;
	return -1;
      }
      
      if (parsing_set && *first == 'b') { // \b is backspace in a character set
	letter.add((unsigned char) '\b');
	++first;
	return -1;
      }

      if (*first == 'l') { // \l lowercase next char
	if (++first == last)
	  return token_error(first - begin, "unterminated \\l escape sequence");
	UCS2 original = utf8_to_ucs2(first);
	UCS2 n = astl::tolower(original);
	if (n == 0) letter.add(original);
	else letter.add(n);
	first += utf8_char_length(*first);
	return -1;
      }

      if (*first == 'u') { // \u uppercase next char
	if (++first == last)
	  return token_error(first - begin, "unterminated \\u escape sequence");
	UCS2 original = utf8_to_ucs2(first);
	UCS2 n = astl::toupper(original);
	if (n == 0) letter.add(original);
	else letter.add(n);
	first += utf8_char_length(*first);
	return -1;
      }

      if (*first == 'c') { // control character \cA through \c[ maps to \x01 \x1B
	if (++first == last)
	  return token_error(first - begin, "unterminated \\c escape sequence");
	if (*first >= 'A' && *first <= 'Z')
	  letter.add(*first - 'A' + 1);
	else if (*first >= 'a' && *first <= 'z')
	  letter.add(*first - 'a' + 1);
	else if (*first == '[')
	  letter.add(*first - 'A' + 1);
	else return token_error(first - begin, "\\c used with illegal following letter");
	++first;
	return -1;
      }

      // look for \s, \S, \w, \W, \d, \D, \n, \t, \v, \V, \r, \a, \e, \f, \h, \H
      std::map<string, ucs2_set>::const_iterator c = predefined.find(std::string("\\") + *first);
      if (c != predefined.end()) {
	letter = c->second;
	++first;
	return -1;
      }

      if (*first == '.') {
	letter.add((unsigned char) '.');
	++first;
	return -1;
      }
    }

    if (*first == '.') {
      if (literal || parsing_set) // a dot has no special meaning in a character set
	letter.add((unsigned char) '.');
      else
	letter.any();
    }
    else {
      UCS2 original = utf8_to_ucs2(first);
      UCS2 n = original;
      if (to_upper) {
	n = astl::toupper(original);
	if (n == 0) n = original;
      }
      else if (to_lower)  {
	n = astl::tolower(original);
	if (n == 0) n = original;
      }
      letter.add(n);
      first += utf8_char_length(*first) - 1;
      letter.case_insensitive(icase);
    }
    ++first;
    return -1;
  }

// Return error position or -1 if ok
  template <typename OutputIterator>
  int regexpu_cursor::tokenize(const char *first, const char *last, OutputIterator x)
  {
    //     MutexAcquire(&regexp_predefined_sets_init_mutex);
     static map<string, ucs2_set> predefined;
     if (predefined.empty())
       build_predefined_sets(predefined);
     //     MutexRelease(&regexp_predefined_sets_init_mutex);

    node *previous = new node(OPEN);
    *x++ = previous;
  
    bool literal = false;
    bool to_upper = false, to_lower = false;
    std::vector<char> parenthesis; // contains '(' or 'i' for (?i:
    bool icase = false;
  
    for(const char *begin = first; first != last; ++x) {
      if (literal && *first != '\\') {
	if (previous->type != OPEN && previous->type != OR) 
	  *x++ = new node(CONCAT);
	ucs2_set tmp;
	tmp.add(utf8_to_ucs2(first));
	tmp.case_insensitive(icase);
	*x = previous = new node(tmp);
	first += utf8_char_length(*first);
	continue;
      }

      switch (*first) {
	case '|' :
	  if (first == begin)
	    return token_error(0, "missing left part of alternative");
	  *x = previous = new node(OR);
	  ++first;
	  break;

	case '(' : 
	  if (first + 2 < last && first[1] == '?' && first[2] == '#') {  // comments (?#
	    const char *end_of_comments = find(first + 3, last, ')');
	    if (end_of_comments == last)
	      return token_error(first - begin, "unbalanced parenthesis for comments");
	    first = end_of_comments + 1;
	    break;
	  }
	  if (first + 2 < last && first[1] == '?' && first[2] == ':') { // non capturing parenthesis (?:
	    first += 2;
	  }
	  else
	    if (first + 3 < last && first[1] == '?' && first[2] == 'i' && 
		(first[3] == ':' || first[3] == ')')) { // case insensitive (?i: or (?i)
	      first += 3;
	      if (icase == false) {
		if (*first == ':') {
		  parenthesis.push_back('i');
		  if (previous->type != OPEN && previous->type != OR) 
		    *x++ = new node(CONCAT);
		  *x = previous = new node(OPEN);
		}
		else 
		  if (!parenthesis.empty())
		    parenthesis.back() = 'i'; // turn normal parenthesis to (?i:
		icase = true;
		++first;
		break;
	      }
	      else if (*first == ')') {
		++first; 
		break; // forget the (?i), we already were in case-insensitive mode
	      }
	    }
	  if (previous->type != OPEN && previous->type != OR) 
	    *x++ = new node(CONCAT);
	  *x = previous = new node(OPEN);
	  parenthesis.push_back('(');
	  ++first;
	  break;

	case ')' : 
	  if (parenthesis.empty())
	    return token_error(first - begin, "unbalanced parenthesis");
	  if (parenthesis.back() == 'i')
	    icase = false;
	  parenthesis.pop_back();
	  *x = previous = new node(CLOSE);
	  ++first;
	  break;

	case '*' :
	  if (first == begin)
	    return token_error(0, "missing expression before operator *");
	  *x = previous = new node(STAR);
	  ++first;
	  break;

	case '?' :
	  if (first == begin)
	    return token_error(0, "missing expression before operator ?");
	  *x = previous = new node(QUESTION);
	  ++first;
	  break;

	case '+' :
	  if (first == begin)
	    return token_error(0, "missing expression before operator +");
	  *x = previous = new node(PLUS);
	  ++first;
	  break;

	case '{' : // {n,m}
	  if (first == begin)
	    return token_error(0, "missing expression before repeat operator");
	  if (++first == last) 
	    return token_error(first - begin, "unterminated expression");
	  {
	    int n = 0;
	    const char *tmp = first;
	    while (isdigit(*first)) {
	      n = n * 10 + *first - '0';
	      if (++first == last) 
		return token_error(first - begin, "unterminated repeat operator");
	    }
	    int m = n;
	    if (*first == ',') {
	      if (++first == last) 
		return token_error(first - begin, "unterminated repeat operator");
	      tmp = first;
	      for(m = 0; isdigit(*first);) {
		m = m * 10 + *first - '0';
		if (++first == last) 
		  return token_error(first - begin, "unterminated repeat operator");
	      }
	      if (tmp == first) m = -1; // comma but no upper bound: {n,}
	    }
	    if (*first != '}') 
	      return token_error(first - begin, "invalid repeat operator");

	    // errors: {0} {0,0} {,0}
	    if (n > 32768 || m > 65535 || (n > m && m > -1) || (n == m && n == 0)) 
	      return token_error(first - begin, "wrong range for repeat operator");

	    // special cases: {0,1} {,1} {0,} {1,} {1,1}
	    if (n == 0 && m == 1)
	      *x = new node(QUESTION);
	    else if (n == 0 && m == -1)
	      *x = new node(STAR);
	    else if (n == 1 && m == -1)
	      *x = new node(PLUS);
	    else if (!(n == 1 &&  m == 1))
	      *x = new node(REPEAT, n, m);
	  }
	  ++first;
	  break;

	case '[' :   // characters set
	{
	  if (previous->type != OPEN && previous->type != OR) 
	    *x++ = new node(CONCAT);
	  ucs2_set a;
	  bool v = true; // a priori, not a negation
	  if (++first == last) 
	    return token_error(first - begin, "unterminated expression");
	  if (*first == '^') {  // a negation ?
	    v = false;
	    if (++first == last) 
	      return token_error(first - begin, "unterminated expression");
	  }
	  if (*first == '-') {  // "escaped" hyphen at the beginning ?
	    a.add((unsigned char) '-');
	    ++first;
	  }
	  else
	    if (*first == ']') {  // "escaped" closing square bracket at the beginning ?
	      a.add((unsigned char) ']');
	      ++first;
	    }
	  for(; first != last && *first != ']'; ++first) {
	    if (*first == '[') {
	      if (++first == last) break;
	      if (*first != ':') { // not a predefined character set ?
		a.add((unsigned char) '[');
	      }
	      else { // a predefined set as [:digits:]
		const char *start = first - 1;
		first = std::find(++first, last, ']');
		if (first == last) break;
		std::map<string, ucs2_set>::const_iterator c = predefined.find(std::string(start, first + 1));
		if (c == predefined.end())
		  return token_error(start - begin, "unknown character set");
		a.add(c->second);
		continue;
	      }
	    }
	    ucs2_set tmp; // will possibly be used as a range lower bound
	    if (*first != '-') {  // not a potential character range ?
	      switch (*first) {
	      case '^' : // literal in character set
	      case '$' : // literal in character set
		tmp.add((unsigned char) *first++);
		break;
	      default :
		{
		  // case-insensitiveness will be handled once the character set is entirely built
		  int r = next_char(tmp, begin, first, last, literal, predefined, false, true, to_upper, to_lower);
		  if (r != -1)
		    return r;
		}
	      }
	      a.add(tmp);
	      if (*first != '-') {
		--first;
		continue;
	      }
	    }
	    // now *first == '-'
	    if (++first == last) 
	      return token_error(first - begin, "unterminated expression");
	    if (*first == ']') {  // unterminated character range ?
	      a.add((unsigned char) '-'); // that was not a character range
	      break; // end of character set
	    }
	    else { // character range [a-z]
	      bool is_range = true;
	      // if a bound is a set then the '-' is understood literally
	      if (tmp.begin() != tmp.end()) { // a bound must not be a character set
		tmp.add((unsigned char) '-');
		is_range = false;
	      }
	      ucs2_set upper_bound;
	      switch (*first) {
	      case '^' : // literal in character set
	      case '$' : // literal in character set
		upper_bound.add((unsigned char) *first);
		break;
	      default :
		{
		  int r = next_char(upper_bound, begin, first, last, literal, predefined, false, true, to_upper, to_lower);
		  --first;
		  if (r != -1)
		    return token_error(first - begin, "wrong character range");
		}
	      }
	      // if a bound is a set then it is not a range
	      if (upper_bound.begin() != upper_bound.end() || !is_range) {
		a.add(tmp);
		a.add(upper_bound);
	      }
	      else {
		// guess what, lower bound should be lower or equal to upper bound
		if (upper_bound.begin() < tmp.begin())
		  return token_error(first - begin, "wrong character range: lower bound cannot be greater than upper bound");
		else
		  a.add(tmp.begin(), upper_bound.begin());
	      }
	    }
	  }
	  // first is supposed to point to ']'
	  if (first == last) 
	    return token_error(first - begin, "unterminated expression");
	  ++first;
	  a.case_insensitive(icase);
	  // put negation handling here because we want to be able to manage for instance (?i:[^a-z])
	  a.negation(!v);
	  *x = previous = new node(a);
	  break;
	}

	default :
	  // a few exceptions:
	  if (*first == '\\') {
	    if (++first == last) 
	      return token_error(first - begin, "unterminated escape sequence");
	    if (*first == 'R') {  // \R == ([\r\n\x85\x{2028}\x{2029}]|\r\n)
	      ++first;
	      ucs2_set rn;
	      rn.add((unsigned char) '\r');
	      rn.add((unsigned char) '\n');
	      rn.add((UCS2) 0x85);
	      rn.add((UCS2) 0x2028); // line separator
	      rn.add((UCS2) 0x2029); // paragraph separator
	      ucs2_set r;
	      r.add((unsigned char) '\r');
	      ucs2_set n;
	      r.add((unsigned char) '\n');
	      if (previous->type != OPEN && previous->type != OR) 
		*x++ = new node(CONCAT);
	      *x++ = new node(OPEN);
	      *x++ = new node(rn);
	      *x++ = new node(OR);
	      *x++ = new node(r);
	      *x++ = new node(CONCAT);
	      *x++ = new node(n);
	      *x = previous = new node(CLOSE);
	      break;
	    }
	    else if (*first == 'X') {  // \X matches any non mark character followed by zero or more mark characters
	      ++first;
	      ucs2_set mark;
	      mark.mark();
	      ucs2_set not_mark;
	      not_mark.not_mark();
	      if (previous->type != OPEN && previous->type != OR) 
		*x++ = new node(CONCAT);
	      *x++ = new node(not_mark);
	      *x++ = new node(CONCAT);
	      *x++ = new node(mark);
	      *x = previous = new node(STAR);
	      break;
	    }
	    else --first;
	  }
	  ucs2_set next_letter;
	  int r = next_char(next_letter, begin, first, last, literal, predefined, icase, false, to_upper, to_lower);
	  if (r != -1)
	    return r;
	  // next letter can be empty in the case of \E \L \U or \Q followed by nothing
	  if (!next_letter.empty()) {
	    if (previous->type != OPEN && previous->type != OR) 
	      *x++ = new node(CONCAT);
	    *x = previous = new node(next_letter);
	  }
	  break;
      }
    }
    *x++ = new node(CLOSE);
    *x++ = new node(CONCAT);
    *x++ = new node(FINAL);
    return -1;
  }

// exp -> term exp2    
  inline
  regexpu_cursor::node*
  regexpu_cursor::exp(vector<regexpu_cursor::node*>::iterator &first, 
		     vector<regexpu_cursor::node*>::iterator last)
  {
    if (first == last)
      return syntax_error(last - first, "empty expression");
    node *t = term(first, last);
    if (t == 0) return 0;
    return exp2(first, last, t);
  }

// exp2 -> + term exp2 | epsilon
  inline
  regexpu_cursor::node*
  regexpu_cursor::exp2(vector<regexpu_cursor::node*>::iterator &first, 
		      vector<regexpu_cursor::node*>::iterator last, node *left)
  {
    if (first != last && (*first)->type == OR) {
      node &root = **first;
      node *right = term(++first, last);
      if (right == 0) return 0;
      root.annulable = right->annulable || left->annulable;
      // premiere_pos(here) = premiere_pos(left) U premiere_pos(right): 
      root.premiere_pos.insert(left->premiere_pos.begin(),
			       left->premiere_pos.end()); 
      root.premiere_pos.insert(right->premiere_pos.begin(),
			       right->premiere_pos.end()); 
      root.derniere_pos.insert(left->derniere_pos.begin(),
			       left->derniere_pos.end()); 
      root.derniere_pos.insert(right->derniere_pos.begin(),
			       right->derniere_pos.end());
      return exp2(first, last, &root);
    }
    return left;
  }

// term -> form repeat term2
  inline
  regexpu_cursor::node*
  regexpu_cursor::term(vector<regexpu_cursor::node*>::iterator &first, 
		      vector<regexpu_cursor::node*>::iterator last)
  {
    if (first == last) 
      return syntax_error(last - first, "unterminated expression");
    node *f = form(first, last);
    if (f == 0) return 0;
    node *s = repeat(first, last, f);  // return f if no repeat token is found
    return term2(first, last, s);
  }

// repeat -> * repeat | ? repeat | + repeat | epsilon
  inline
  regexpu_cursor::node*
  regexpu_cursor::repeat(vector<regexpu_cursor::node*>::iterator &first, 
			vector<regexpu_cursor::node*>::iterator last, node *left)
  {
    if (first != last)
      switch ((*first)->type) {
	case STAR :
	{
	  node &root = **first;
	  root.annulable = true;
	  root.premiere_pos = left->premiere_pos;
	  root.derniere_pos = left->derniere_pos;
	
	  // pos_suivante(derniere_pos(here)) += premiere_pos(here):
	  for(S::const_iterator i = root.derniere_pos.begin(); 
	      i != root.derniere_pos.end(); ++i)
	    (*i)->pos_suivante.insert(root.premiere_pos.begin(),
				      root.premiere_pos.end());
	  return repeat(++first, last, &root);
	}
	case QUESTION : 
	{
	  node &root = **first;
	  root.annulable = true;
	  root.premiere_pos = left->premiere_pos;
	  root.derniere_pos = left->derniere_pos;
	  return repeat(++first, last, &root);
	}
	case PLUS :
	{
	  node &root = **first;
	  root.annulable = false;
	  root.premiere_pos = left->premiere_pos;
	  root.derniere_pos = left->derniere_pos;
	
	  // pos_suivante(derniere_pos(here)) += premiere_pos(here):
	  for(S::const_iterator i = root.derniere_pos.begin(); 
	      i != root.derniere_pos.end(); ++i)
	    (*i)->pos_suivante.insert(root.premiere_pos.begin(),
				      root.premiere_pos.end());
	  return repeat(++first, last, &root);
	}
	default : 
	  break;
      }
    return left;
  }
    

// term2 -> . form repeat term2 | epsilon
  inline
  regexpu_cursor::node*
  regexpu_cursor::term2(vector<regexpu_cursor::node*>::iterator &first, 
		       vector<regexpu_cursor::node*>::iterator last, node *left)
  {
    if (first != last && (*first)->type == CONCAT) {
      node &root = **first;
      node *f = form(++first, last);
      if (f == 0) return 0; 
      node *right = repeat(first, last, f);
      root.annulable = left->annulable && right->annulable;
      if (left->annulable) {
	root.premiere_pos.insert(left->premiere_pos.begin(),
				 left->premiere_pos.end()); 
	root.premiere_pos.insert(right->premiere_pos.begin(),
				 right->premiere_pos.end()); 
      }
      else
	root.premiere_pos = left->premiere_pos;
    
      if (right->annulable) {
	root.derniere_pos.insert(right->derniere_pos.begin(),
				 right->derniere_pos.end()); 
	root.derniere_pos.insert(left->derniere_pos.begin(),
				 left->derniere_pos.end());
      }
      else
	root.derniere_pos = right->derniere_pos;
      // pos_suivante(derniere_pos(left)) += premiere_pos(right):
      for(S::const_iterator i = left->derniere_pos.begin(); 
	  i != left->derniere_pos.end(); ++i)
	(*i)->pos_suivante.insert(right->premiere_pos.begin(),
				  right->premiere_pos.end());
      return term2(first, last, &root);
    }
    return left;
  }


// form -> ( exp ) | letter
  inline
  regexpu_cursor::node*
  regexpu_cursor::form(vector<regexpu_cursor::node*>::iterator &first, 
		      vector<regexpu_cursor::node*>::iterator last)
  {
    if (first == last) 
      return syntax_error(last - first, "unterminated expression");
    if ((*first)->type == OPEN) {
      node *e = exp(++first, last);
      if (e == 0) return 0;
      if ((*first)->type == CLOSE) ++first;
      else return syntax_error(last - first, "unbalanced parenthesis");
      return e;
    }
    (*first)->annulable = false;
    (*first)->premiere_pos.insert(*first);
    (*first)->derniere_pos.insert(*first);
    ++first;
    return first[-1];
  }

  class regexputf8_cursor : public regexpu_cursor
  {
  public:
    typedef regexputf8_cursor self;
    typedef regexpu_cursor   super;
    typedef plain            char_trais;
    typedef plain::char_type char_type;
    typedef super::tag_type  tag_type;
    typedef pair<super::ordered_state_type, unsigned int> state_type; 

    regexputf8_cursor(const string &utf8)
      : super(utf8), path(0)
    { }

    state_type src() const {
      return make_pair(super::ordered_state_type(super::src().begin(), super::src().end()), path);
    }

    bool src_final() const {
      return path == 0 && super::src_final();
    }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      if (path == 0) { // start of utf8 character ?
	const int l = utf8_char_length(c);
	if (l == 1)
	  return super::forward(utf8_to_ucs2(c));
	((char*) &path)[0] = c;
	((char*) &path)[3] = (l << 4) + 1;
	return true;
      }
      const int length = (((char*) &path)[3] & 0xF0) >> 4;
      const int next_position = ((char*) &path)[3] & 0x0F;
      ((char*) &path)[next_position] = c;
      if (next_position == length - 1) {
	const bool r = super::forward(utf8_to_ucs2((char*) &path, length));
	path = 0;
	return r;
      }
      ((char*) &path)[3] = (((char*) &path)[3] & 0xF0) | (next_position + 1);
      return true;
    }

    self& operator=(state_type q) {
      super::operator=(q.first);
      path = q.second;
      return *this;
    }

  protected:
    unsigned int path; // local utf8 path

  };

// match algorithm specializations for regexp

#if 0
inline
bool match(lazy_cursor<regexpu_cursor>& c, const char *w)
{
  if (!c.forward('\0')) // ^ anchoring
    return false;
  for(; *w != '\0' && c.forward(*w); ++w)
    if (c.src_final()) return true;
  return *w == '\0' && c.forward('\0') && c.src_final(); // $ anchoring
}

template <typename InputI>
inline
bool match(lazy_cursor<regexpu_cursor>& c, InputI first, InputI last)
{
  if (!c.forward('\0'))  // ^ anchoring
    return false;
  for(; first != last && c.forward(*first); ++first)
    if (c.src_final()) return true;
  return first == last && c.forward('\0') && c.src_final(); // $ anchoring
}

template <typename InputI, typename Cursor>
inline
bool regexp_match(Cursor& c, InputI first, InputI last)
{
  if (!c.forward('\0'))  // ^ anchoring
    return false;
  for(; first != last && c.forward(*first); ++first)
    if (c.src_final()) return true;
  return first == last && c.forward('\0') && c.src_final(); // $ anchoring
}

template <typename ForwardI>
inline
ForwardI first_match(lazy_cursor<regexpu_cursor> &c, ForwardI first, ForwardI last)
{
  if (!c.forward('\0')) return first;
  const ForwardI start = first;
  for(; first != last && c.forward(*first); ++first)
    if (c.src_final()) return ++first;
  return first == last && c.forward('\0') && c.src_final() ? first : start;
}

inline
const char*
first_match(lazy_cursor<regexpu_cursor> &c, const char *text)
{
  if (!c.forward('\0')) return text;
  const char *start = text;
  for(; *text != '\0' && c.forward(*text); ++text)
    if (c.src_final()) return ++text;
  return *text == '\0' && c.forward('\0') && c.src_final() ? text : start;
}

template <typename ForwardI>
inline
ForwardI 
longest_match(lazy_cursor<regexpu_cursor> &c, ForwardI first, ForwardI last)
{
  ForwardI last_match_position = first;
  if (c.forward('\0')) {
    while(first != last && c.forward(*first)) {
      ++first;
      if (c.src_final()) 
	last_match_position = first;
    }
    if (first == last && c.forward('\0') && c.src_final())
      last_match_position = first;
  }
  return last_match_position;
}

inline
const char*
longest_match(lazy_cursor<regexpu_cursor> &c, const char *text)
{
  const char *last_match_position = text;
  if (c.forward('\0')) {
    while(*text != '\0' && c.forward(*text)) {
      ++text;
      if (c.src_final()) 
	last_match_position = text;
    }
    if (*text == '\0' && c.forward('\0') && c.src_final())
      last_match_position = text;
  }
  return last_match_position;
}

inline
ostream& operator<<(ostream& out, const regexpu_cursor& c) {
  for(vector<regexpu_cursor::node*>::const_iterator n = c.e->begin(); n != c.e->end(); ++n)
    if (c.q.find(const_cast<astl::regexpu_cursor::node*>(&*n)) != c.q.end())
      out << "\033[1m" << *n << "\033[0m";
    else
      out << *n;
  return out;
}
#endif

} // namespace astl

#endif 

