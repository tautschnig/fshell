/*
 * ASTL - the Automaton Standard Template Library.
 * C++ generic components for Finite State Automata handling.
 * Copyright (C) 2000-2003 Vincent Le Maout (vincent.lemaout@chello.fr).
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef ASTL_REGEXPU_H
#define ASTL_REGEXPU_H

#include "astl.h"
#include "regexp_tools.h"
#include "lazy.h"
#include "search.h"
#include <vector>
#include <iostream>
#include <set>
#include <iterator>
#include <cctype>  
#include <bitset>
#include <cstring>
#include <sstream>

using namespace std;

namespace astl {

  class regexpu_cursor : public cursor_concept
  {
  public:
    smart_ptr<vector<UCS2> > horspool_prefix; // if applicable

    typedef rex::node*      node_type;
    typedef regexpu_cursor  self;
    typedef rex::state_set::node_container state_type;
    typedef set<rex::node*> ordered_state_type;
    typedef ucs2            char_traits;
    typedef UCS2            char_type;
    typedef empty_tag       tag_type; // matching expressions

    regexpu_cursor()
      : errmsg(NULL), errpos(-1)
      { }

    regexpu_cursor(const string &utf8, bool horspool_optimized = false)
      : errmsg(NULL), errpos(-1)
      {
	int finals = 0;
	errpos = tokenz.tokenize(utf8.c_str(), utf8.c_str() + utf8.size(), finals, false);

	if (errpos == -1) {
	  tokenz.preprocess_repeats();
	  rex::node_allocator::iterator first = tokenz.allocator.begin();
	  rex::node *root = exp(first, tokenz.allocator.end());

	  // managed non-anchored alternatives
	  if (root != NULL) {
	    // if there is only one position for the root and this position
	    // is not ^ nor ANY, then there may be a literal prefix that can
	    // be matched more efficiently with a horspool search
	    if (horspool_optimized && root->first.size() == 1) {
	      // look for a litteral prefix of size > 1
	      rex::node *n = *root->first.begin();
	      for(; n->cset.single() && !n->nullable && n->match(0) == false && horspool_prefix->size() < 65536; n = *(n->next.begin())) {
		horspool_prefix->push_back(n->cset.begin());
		if (n->next.size() != 1 || (*n->next.begin())->type == rex::FINAL) {
		  if (horspool_prefix->size() > 1) {
		    //		if (prefix.size() > 1) {
		    // initialize horspool searcher and remove prefix from expression
		    //		  horspool->init(prefix);
		    q = n->next;
		    return;
		  }
		  break;
		}
	      }
	      if (horspool_prefix->size() > 1) {
		//            if (prefix.size() > 1) {
		// initialize horspool searcher and remove prefix from expression
		//              horspool->init(prefix);
		q.insert(n);
		return;
	      }
	      horspool_prefix->clear();
	    }
	    q = root->first;
	    for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i) {
	      // if not beginning of line anchor ^
	      if ((*i)->match(0) == false) {
		I->insert(*i); //, deduper);
	      }
	    }
	  }
	  else errpos = utf8.size() - errpos;
	}
      }

    bool leftanchored() const { return I->empty(); }

    bool simple() const {
      for(rex::node_allocator::const_iterator n = tokenz.allocator.begin(); n != tokenz.allocator.end(); ++n) {
	switch ((*n)->type) {
	case rex::STAR:
	case rex::REPEAT:
	case rex::PLUS:
	case rex::QUESTION:
	  return false;
	default: break;
	}
      }
      return true;
    }

    void clear() {
      q.clear();
      tokenz.allocator.clear();
      I->clear();
      horspool_prefix->clear();
    }

    // possible error position (-1 if expression is ok)
    ptrdiff_t error_position() const { return errpos; }
    
    const char* error_message() const {
      return errmsg;
    }

    self& operator=(const state_type &s) {
      q = s;
      return *this;
    }

    const state_type& src() const { return q.nodes(); }

    bool exists(UCS2 a) const {
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(a)) return true;
      return false;
    }

    bool forward(UCS2 letter) {
      rex::state_set p = *I; // for non-anchored expressions
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i)
	if ((*i)->match(letter))
	  p.insert((*i)->next.begin(), (*i)->next.end());
      q.swap(p);   // optimized equivalent to q = p;
      return !q.empty();
    }
    
    bool src_final() const {
      for(rex::state_set::const_iterator i = q.begin(); i != q.end(); ++i) 
	if ((*i)->final()) return true;
      return false;
    }
     
    bool sink() const { return q.empty(); }
 
    tag_type src_tag() const { return tag_type(); }

    ~regexpu_cursor() {
      if (tokenz.allocator.references() == 1) 
	for(rex::node_allocator::iterator n = tokenz.allocator.begin(); n != tokenz.allocator.end(); ++n)
	  delete *n;
    }

  protected:
    rex::state_set            q;  // current state
    rex::tokenizer            tokenz;
    const char                *errmsg;
    smart_ptr<rex::state_set> I;
    ptrdiff_t                 errpos;

    rex::node* exp(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last);
    rex::node* form(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last);
    rex::node* term(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last);
    rex::node* exp2(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last, rex::node *left);
    rex::node* term2(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last, rex::node *left);
    rex::node* repeat(vector<rex::node*>::iterator &first, vector<rex::node*>::iterator last, rex::node *left);

    rex::node* syntax_error(ptrdiff_t pos, const char *message = NULL) {
      errmsg = message;
      errpos = pos;
      return NULL;
    }

  };

  template <typename RegexpCursor>
  class regexp_utf8_layer_cursor : public RegexpCursor
  {
  public:
    typedef regexp_utf8_layer_cursor              self;
    typedef RegexpCursor                          super;
    typedef plain                                 char_traits;
    typedef plain::char_type                      char_type;
    typedef typename super::tag_type              tag_type;
    typedef pair<typename super::state_type, unsigned int> state_type; 

    regexp_utf8_layer_cursor(const string &utf8, bool horspool_optimized = false)
      : super(utf8, horspool_optimized), path(0)
    { 
      if (horspool_optimized && super::horspool_prefix->size() > 0) {
	string prefix;
	ucs2_to_utf8(super::horspool_prefix->begin(), super::horspool_prefix->end(), back_inserter(prefix));
	super::horspool_prefix.reset();
	horspool->init(prefix);
      }
    }

    state_type src() const {
      typename super::state_type tmp = super::src();
      sort(tmp.begin(), tmp.end());
      return make_pair(tmp, path);
    }

    bool src_final() const { return path == 0 && super::src_final(); }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      if (path == 0) { // start of utf8 character ?
	const int l = utf8_char_length(c);
	if (l == 1)
	  return super::forward(utf8_to_ucs2(c));
	((char*) &path)[0] = c;
	((char*) &path)[3] = (l << 4) + 1;
	return true;
      }
      const int length = (((char*) &path)[3] & 0xF0) >> 4;
      const int next_position = ((char*) &path)[3] & 0x0F;
      ((char*) &path)[next_position] = c;
      if (next_position == length - 1) {
	const bool r = super::forward(utf8_to_ucs2((char*) &path, length));
	path = 0;
	return r;
      }
      ((char*) &path)[3] = (((char*) &path)[3] & 0xF0) | (next_position + 1);
      return true;
    }

    self& operator=(state_type q) {
      super::operator=(q.first);
      path = q.second;
      return *this;
    }

  protected:
    unsigned int path; // local utf8 path

  public:
    smart_ptr<horspool_finder<plain> > horspool;
    const horspool_finder<plain>& finder() const { return *horspool; }
  };

  class utf8_regexp_cursor : public cursor_concept
  {
  public:
    typedef lazy_cursor_tag<regexp_utf8_layer_cursor<regexpu_cursor>, DFA_matrix_mini> implementation;
    typedef utf8_regexp_cursor      self;
    typedef implementation::char_type   char_type;
    typedef implementation::char_traits char_traits;
    typedef implementation::tag_type    tag_type;
    typedef implementation::state_type  state_type;
    typedef implementation::DFA_type    DFA_type;

    utf8_regexp_cursor(const string &exp, bool use_horspool = false)
      : adaptee(new implementation(regexp_utf8_layer_cursor<regexpu_cursor>(exp, use_horspool)))
    { }

    ~utf8_regexp_cursor() { delete adaptee; }

    const horspool_finder<plain>& finder() const { return adaptee->adaptee().finder(); }

    const char* error_message() const { return adaptee->adaptee().error_message(); }
    int         error_position() const { return (int) adaptee->adaptee().error_position(); }

    const DFA_type& cache() const { return adaptee->cache(); }

    // this clone shares the thread-safe part (non-deterministic FA) and will build
    // its own thread-unsafe part (deterministic FA). Don't forget to deallocate !
    self* clone() const { return new self(adaptee->clone()); }

    state_type src() const { return adaptee->src(); }

    self& operator=(state_type p) {
      *adaptee = p;
      return *this;
    }

    bool src_final() const { return adaptee->src_final(); }

    const tag_type& src_tag() const { return adaptee->src_tag(); }

    bool sink() const { return adaptee->sink(); }

    state_type sink_state() const { return adaptee->sink_state(); }

    bool forward(const char_type &a) { return adaptee->forward(a); }
 
  protected:
    implementation *adaptee;

    utf8_regexp_cursor(implementation *c)
      : adaptee(c)
    { }

  };

  class regexpucs2_cursor : public regexpu_cursor
  {
  public:
    typedef regexpu_cursor    super;
    typedef regexpucs2_cursor self;
    typedef super::state_type state_type;

    regexpucs2_cursor(const std::string &exp, bool use_horspool = false)
      : super(exp, use_horspool)
    { 
      if (horspool_prefix->size() > 0)
	horspool->init(*horspool_prefix);
    }

    self& operator=(state_type q) {
      super::operator=(q);
      return *this;
    }

    state_type src() const {
      super::state_type tmp = super::src();
      sort(tmp.begin(), tmp.end());
      return tmp;
    }

    const horspool_finder<ucs2>& finder() const { return *horspool; }

  protected:
    smart_ptr<horspool_finder<ucs2> > horspool;
  };

  class regexpucs2byte_cursor : public regexpu_cursor
  {
  public:
    typedef regexpucs2byte_cursor self;
    typedef regexpu_cursor   super;
    typedef plain            char_traits;
    typedef plain::char_type char_type;
    typedef super::tag_type  tag_type;
    typedef pair<super::state_type, UCS2> state_type; 

    regexpucs2byte_cursor(const std::string &exp, bool use_horspool = false)
      : super(exp, use_horspool), path(0)
    { 
      if (horspool_prefix->size() > 0)
	horspool->init(*horspool_prefix);
    }

    state_type src() const {
      super::state_type tmp = super::src();
      sort(tmp.begin(), tmp.end());
      return make_pair(tmp, path);
    }

    bool src_final() const {
      return path == 0 && super::src_final();
    }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      if (path == 0) { // start of ucs2 character ?
	path = (unsigned char) c;
	path <<= 8;
	path += 1;
	return true;
      }
      path -=1;
      path += (unsigned char) c;
      const bool r = super::forward(path);
      path = 0;
      return r;
    }

    self& operator=(state_type q) {
      super::operator=(q.first);
      path = q.second;
      return *this;
    }

    const horspool_finder<ucs2>& finder() const { return *horspool; }

  protected:
    unsigned short path; // local utf8 path

    smart_ptr<horspool_finder<ucs2> > horspool;
  };

  class ucs2_regexp_cursor : public lazy_cursor<regexpucs2_cursor, DFA_tr>
  {
  public:
    typedef lazy_cursor<regexpucs2_cursor, DFA_tr> super;
    typedef ucs2_regexp_cursor self;

    ucs2_regexp_cursor(const std::string &exp, bool use_horspool = false)
      : super(regexpucs2_cursor(exp, use_horspool))
    { }

    self& operator=(state_type q) {
      super::operator=(q);
      return *this;
    }

    const horspool_finder<ucs2>& finder() const { return adaptee().finder(); }

    const char* error_message() const { return adaptee().error_message(); }
    int         error_position() const { return (int) adaptee().error_position(); }
  };

  class ucs22_regexp_cursor : public lazy_cursor<regexpucs2byte_cursor, DFA_matrix_mini>
  {
  public:
    typedef lazy_cursor<regexpucs2byte_cursor, DFA_matrix_mini> super;
    typedef ucs22_regexp_cursor self;
    typedef ucs2 char_traits;
    typedef UCS2 char_type;

    ucs22_regexp_cursor(const std::string &exp, bool use_horspool = false)
      : super(regexpucs2byte_cursor(exp, use_horspool))
    { }

    self& operator=(state_type q) {
      super::operator=(q);
      return *this;
    }

    bool exists(char_type c) const {
      // FIXME: optimize
      self tmp = *this;
      return tmp.forward(c);
    }

    bool forward(char_type c) {
      super::forward((char) (c & 0xFF00));
      return super::forward((char) (c & 0x00FF));
    }

    const horspool_finder<ucs2>& finder() const { return adaptee().finder(); }

    const char* error_message() const { return adaptee().error_message(); }
    int         error_position() const { return (int) adaptee().error_position(); }
  };

  inline ucs2_regexp_cursor ucs2_regexpc(const string &expression, bool use_horspool = false) {
    return ucs2_regexp_cursor(expression, use_horspool);
  }

  inline ucs22_regexp_cursor ucs22_regexpc(const string &expression, bool use_horspool = false) {
    return ucs22_regexp_cursor(expression, use_horspool);
  }

  // helpers
  inline utf8_regexp_cursor utf8_regexpc(const string &expression, bool use_horspool = false) {
    return utf8_regexp_cursor(expression, use_horspool);
  }

  // match algorithm specializations for regexp

  inline
  bool match(utf8_regexp_cursor &c, const char *w) {
    return regexp_match(c, w);
  }

  template <typename InputI>
  inline
  bool match(utf8_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match(c, first, last);
  }

  template <typename InputI>
  inline
  bool match(ucs2_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match(c, first, last);
  }

  template <typename InputI>
  inline
  bool match(ucs22_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI first_match(utf8_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_first_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI first_match(ucs2_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_first_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI first_match(ucs22_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_first_match(c, first, last);
  }

  inline
  const char* first_match(utf8_regexp_cursor &c, const char *text) {
    return regexp_first_match(c, text);
  }

  template <typename ForwardI>
  inline
  ForwardI longest_match(utf8_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_longest_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI longest_match(ucs2_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_longest_match(c, first, last);
  }

  template <typename ForwardI>
  inline
  ForwardI longest_match(ucs22_regexp_cursor &c, ForwardI first, ForwardI last) {
    return regexp_longest_match(c, first, last);
  }

  inline
  const char* longest_match(utf8_regexp_cursor &c, const char *text) {
    return regexp_longest_match(c, text);
  }

  inline
  int match_count(utf8_regexp_cursor c, const char *w) {
    return regexp_match_count(c, w);
  }

  template <typename InputI>
  inline
  int match_count(utf8_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match_count(c, first, last);
  }

  template <typename InputI>
  inline
  int match_count(ucs2_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match_count(c, first, last);
  }

  template <typename InputI>
  inline
  int match_count(ucs22_regexp_cursor &c, InputI first, InputI last) {
    return regexp_match_count(c, first, last);
  }

#if 0
  inline
  ostream& operator<<(ostream& out, const regexp_utf8_layer_cursor& c) {
    for(vector<regexp_utf8_layer_cursor::node>::const_iterator n = c.e->begin(); n != c.e->end(); ++n)
      if (c.q.find(const_cast<astl::regexp_utf8_layer_cursor::node*>(&*n)) != c.q.end())
	out << "\033[1m" << *n << "\033[0m";
      else
	out << *n;
    return out;
  }
#endif

  // regular expressions grammar:
  // exp    -> term exp2
  // exp2   -> + term exp2 | epsilon
  // term   -> form repeat term2
  // term2  -> . form repeat term2 | epsilon
  // repeat -> * repeat | ? repeat | + repeat | {n,m} repeat | epsilon
  // form   -> ( exp ) | letter 
  //
  // + is union, . is concatenation, epsilon is the empty word
  // a letter is a set of chars


  // exp -> term exp2    
  rex::node*
  regexpu_cursor::exp(vector<rex::node*>::iterator &first, 
		      vector<rex::node*>::iterator last)
  {
    if (first == last)
      return syntax_error(last - first, "empty expression");
    rex::node *t = term(first, last);
    if (t == NULL) return NULL;
    return exp2(first, last, t);
  }

  // exp2 -> + term exp2 | epsilon
  rex::node*
  regexpu_cursor::exp2(vector<rex::node*>::iterator &first, 
		       vector<rex::node*>::iterator last, rex::node *left)
  {
    if (first == last) return left;
    if ((*first)->type == rex::OR) {
      rex::node &root = **first;
      rex::node *right = term(++first, last);
      if (right == NULL) return NULL;
      root.nullable = right->nullable || left->nullable;
      // first(here) = first(left) U first(right): 
      root.first.insert(left->first.begin(), left->first.end());
      root.first.insert(right->first.begin(), right->first.end());
      
      root.last.insert(left->last.begin(), left->last.end());
      root.last.insert(right->last.begin(), right->last.end());
      
      return exp2(first, last, &root);
    }
    return left;
  }

  // term -> form repeat term2
  rex::node*
  regexpu_cursor::term(vector<rex::node*>::iterator &first, 
		       vector<rex::node*>::iterator last)
  {
    if (first == last) 
      return syntax_error(last - first, "unterminated expression");
    rex::node *f = form(first, last);
    if (f == NULL) return NULL;
    rex::node *s = repeat(first, last, f);  // return f if no repeat token is found
    return term2(first, last, s);
  }

  // repeat -> * repeat | ? repeat | + repeat | epsilon
  rex::node*
  regexpu_cursor::repeat(vector<rex::node*>::iterator &first, 
			 vector<rex::node*>::iterator last, rex::node *left)
  {
    if (first != last)
      switch ((*first)->type) {
      case rex::STAR :
      case rex::PLUS : {
	rex::node &root = **first;
	root.nullable = (*first)->type == rex::STAR;
	root.first = left->first;
	root.last = left->last;
	
	// next(last(here)) += first(here):
	for(rex::state_set::const_iterator i = root.last.begin(); i != root.last.end(); ++i)
	  (*i)->next.insert(root.first.begin(), root.first.end());

	return repeat(++first, last, &root);
      }

      case rex::QUESTION : {
	rex::node &root = **first;
	root.nullable = true;
	root.first = left->first;
	root.last = left->last;
	return repeat(++first, last, &root);
      }

      default : 
	break;
      }
    return left;
  }
    

  // term2 -> . form repeat term2 | epsilon
  rex::node*
  regexpu_cursor::term2(vector<rex::node*>::iterator &first, 
			vector<rex::node*>::iterator last, rex::node *left)
  {
    if (first != last && (*first)->type == rex::CONCAT) {
      rex::node &root = **first;
      rex::node *f = form(++first, last);
      if (f == NULL) return NULL; 
      rex::node *right = repeat(first, last, f); // returns f is no repeat
      root.nullable = left->nullable && right->nullable;
      if (left->nullable) {
	root.first.insert(left->first.begin(), left->first.end()); //, dedup); 
	root.first.insert(right->first.begin(), right->first.end()); //, dedup); 
      }
      else
	root.first = left->first;
    
      if (right->nullable) {
	root.last.insert(right->last.begin(), right->last.end()); //, dedup); 
	root.last.insert(left->last.begin(), left->last.end()); //, dedup);
      }
      else
	root.last = right->last;
      // next(last(left)) += first(right):
      for(rex::state_set::const_iterator i = left->last.begin(); i != left->last.end(); ++i)
	(*i)->next.insert(right->first.begin(), right->first.end()); //, dedup);

      return term2(first, last, &root);
    }
    return left;
  }


  // form -> ( exp ) | letter
  rex::node*
  regexpu_cursor::form(vector<rex::node*>::iterator &first, 
		       vector<rex::node*>::iterator last)
  {
    if (first == last) 
      return syntax_error(last - first, "unterminated expression");
    if ((*first)->type == rex::OPEN) {
      rex::node *ex = exp(++first, last);
      if (ex == NULL) return NULL;
      if ((*first)->type == rex::CLOSE) {
	++first;
      }
      else {
	return syntax_error(last - first, "syntax error: unbalanced parenthesis");
      }
      return ex;
    }
    (*first)->nullable = false;
    (*first)->first.insert(*first);
    (*first)->last.insert(*first);
    ++first;
    return first[-1];
  }

} // namespace astl

#endif 

