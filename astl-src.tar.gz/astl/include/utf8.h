#ifndef ASTL_UTF8_H
#define ASTL_UTF8_H

#include "ucs.h"

namespace astl {

  static const char mb_lengthes[256] = {
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
    3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0
  };

  inline int utf8_char_length(char c) {
    return mb_lengthes[(unsigned char) c];
  }

  inline UCS2 utf8_to_ucs2(const char *s, int length) {
    UCS2 r = (unsigned char) *s++;
    switch (length) {
    case 4:  
      r -= 0xF0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      return r;
    case 3: 
      r -= 0xE0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      return r;
    case 2: 
      r -= 0xC0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
    default: return r;
    }
  }
  
  inline UCS2 utf8_to_ucs2(const char *s) {
    return utf8_to_ucs2(s, utf8_char_length(*s));
  }

  inline UCS2 utf8_to_ucs2(char c) {
    return utf8_to_ucs2(&c, 1);
  }
  
}

#endif // ASTL_UTF8_H
