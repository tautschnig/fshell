#ifndef ASTL_UTF8_H
#define ASTL_UTF8_H

#include "ucs.h"

namespace astl {

  static const char mb_lengthes[256] = {
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
    3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0
  };

  inline int utf8_char_length(char c) {
    return mb_lengthes[(unsigned char) c];
  }

  inline UCS2 utf8_to_ucs2(const char *s, int length) {
    switch (length) {
    case 4: { 
      UCS2 r = (unsigned char) *s++;
      r -= 0xF0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      return r;
    }
    case 3: {
      UCS2 r = (unsigned char) *s++;
      r -= 0xE0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      return r;
    }
    case 2: {
      UCS2 r = (unsigned char) *s++;
      r -= 0xC0; 
      r <<= 6; r += (unsigned char) *s++ - 0x80;
      return r;
    }
    default: return (unsigned char) *s++;
    }
  }
  
  inline UCS2 utf8_to_ucs2(const char *s) {
    return utf8_to_ucs2(s, utf8_char_length(*s));
  }

  inline UCS2 utf8_to_ucs2(char c) {
    return utf8_to_ucs2(&c, 1);
  }

  template <typename InputI, typename OutputI>
  inline OutputI ucs2_to_utf8(InputI first, InputI last, OutputI to) {
    for(; first != last; ++first) {
      if (*first < 0x0080) *to++ = (char) *first;
      else if (*first < 0x0800) {
	*to++ = 0xC0 + (*first >> 6);
	*to++ = 0x80 + (*first & 0x003F);
      }
      else {
	*to++ = 0xE0 + (*first >> 12);
	*to++ = 0x80 + (*first & 0x0FC0);
	*to++ = 0x80 + (*first & 0x003F);
      }
    }
    return to;
  }

  template <typename OutputI>
  inline OutputI ucs2_to_utf8(UCS2 c, OutputI to) {
    return ucs2_to_utf8(&c, &c + 1, to);
  }
}

#endif // ASTL_UTF8_H
