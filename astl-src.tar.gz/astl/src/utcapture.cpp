#include <astl.h>
#include <vector>
#include <string>
#include <lazy.h>
#include <iostream>
// #include "capture.h"
#include <experiment.h>

using namespace std;
using namespace astl;

const bool USE_HORSPOOL = true;

// typedef lazy_cursor<capture_cursor, DFT_matrix_mini> capturer_type;
typedef capture_cursor capturer_type;
typedef astl::non_deterministic_regexp_capture_cursor non_deterministic_capturer_type;

capturer_type build_capturer(const string &exp, bool use_horspool) {
  return capturer_type(capture_cursor(exp, use_horspool));
}

non_deterministic_capturer_type build_non_deterministic_capturer(const string &exp, bool use_horspool) {
  return non_deterministic_capturer_type(exp, use_horspool);
}

pair<string::const_iterator, string::const_iterator> trim_range(const string &s) {
  pair<string::const_iterator, string::const_iterator> p(s.begin(), s.end());
  if (!s.empty()) {
    for(; p.first < p.second && (*p.first == ' ' || *p.first == '\t' || *p.first == '\n' || *p.first == '\r'); ++p.first);
    for(--p.second; p.second > p.first && (*p.second == ' ' || *p.second == '\t' || *p.first == '\n' || *p.first == '\r'); --p.second);
    ++p.second;
  }
  return p;
}

string trim(const string &s) {
  pair<string::const_iterator, string::const_iterator> p = trim_range(s);
  return string(p.first, p.second);
}

template <typename RandomAccessI, typename NonDeterministicCaptureCursor>
void cleanup(vector<vector<RandomAccessI> > &v, const NonDeterministicCaptureCursor &c, RandomAccessI marker) {
  const vector<pair<int, long> > &remove = c.removed();
  for(vector<pair<int, long> >::const_iterator i = remove.begin(); i != remove.end(); ++i) {
    assert((unsigned long) i->first < v.size());
    assert((unsigned long) i->second < v[i->first].size());
    v[i->first][i->second] = marker; // mark for removal
  }
  for(typename vector<vector<RandomAccessI> >::size_type p = 0; p < v.size(); ++p)
    v[p].resize(std::remove(v[p].begin(), v[p].end(), marker) - v[p].begin());
}

template <typename RandomAccessI, typename NonDeterministicCaptureCursor>
void action(vector<vector<RandomAccessI> > &v, const NonDeterministicCaptureCursor &c, RandomAccessI position) {
  const typename NonDeterministicCaptureCursor::tag_type &conf = c.src_tag();
  for(typename NonDeterministicCaptureCursor::tag_type::const_iterator i = conf.begin(); i != conf.end(); ++i) {
    if (v[i->first.id()].size() == (unsigned long) i->second)
      v[i->first.id()].push_back(position);
    else v[i->first.id()][i->second] = position;
  }
}

template <typename RandomAccessI, typename NonDeterministicCaptureCursor>
void finalize(std::vector<RandomAccessI> &captures, const vector<vector<RandomAccessI> > &v, NonDeterministicCaptureCursor &c) {
  cout << "finalizing _______________" << endl;
  c.finalize();
  const typename NonDeterministicCaptureCursor::tag_type &conf = c.src_tag();
  cout << "final configuration " << conf << std::endl;
  for(typename NonDeterministicCaptureCursor::tag_type::const_iterator i = conf.begin(); i != conf.end(); ++i) {
    //      cout << "captures[" << i->first.id() << "] = tmp[" << i->first.id() << "]" << endl;
    captures[i->first.id()] = v[i->first.id()][i->second];
  }
}

template <typename RandomAccessI>
bool capture(RandomAccessI &first, RandomAccessI last, 
	     non_deterministic_capturer_type &c, 
	     std::vector<RandomAccessI> &captures) {
  const RandomAccessI start = first;
  vector<vector<RandomAccessI> > tmp(c.capture_count());

  c.initialize();
  for(action(tmp, c, first); first != last && c.forward(*first); action(tmp, c, ++first)) {
    cleanup(tmp, c, last);
  }
  if (first == last && c.src_final()) {
    finalize(captures, tmp, c);
    return true;
  }
  return false;
}

void display(ostream &out, const vector<string::const_iterator> &captures, const std::string &text) {
  for(string::const_iterator c = text.begin(); c != text.end(); ++c) {
    for(vector<string::const_iterator>::const_iterator cap = captures.begin(); cap < captures.end(); ++cap)
      if (*cap == c) 
	out << ((cap - captures.begin()) % 2 == 0 ? '[' : ']');
    out << *c;
  }
  for(vector<string::const_iterator>::const_iterator cap = captures.begin(); cap < captures.end(); ++cap)
    if (*cap == text.end()) 	
      out << ((cap - captures.begin()) % 2 == 0 ? '[' : ']');
}

#if 0
bool lookup(string::const_iterator &first, string::const_iterator last, capturer_type &c) {
  capturer_type::state_type last_valid = c.src();
  if (c.adaptee().horspool->size() > 0) {
    const horspool_finder &hs = *c.adaptee().horspool;
    const capturer_type::state_type i = c.src();
    for(first = hs.find(first, last); first < last; first = hs.find(first, last)) {
      c = i;
      first += hs.size();
      string::const_iterator start;
      for(start = first; start < last && !c.src_final() && c.forward(*start); ++start)
	last_valid = c.src();
      if (!c.sink() && (c.src_final() || (start == last && c.forward('\0') && c.src_final()))) 
	return true;
    }
  }
  else {
    if (c.forward('\0')) { // ^ anchoring
      last_valid = c.src();
      for(const string::const_iterator start = first; first != last && c.forward(*first); ++first) {
	last_valid = c.src();
	if (c.src_final()) {
	  c = last_valid;
	  return true;
	}
      }
      if (first == last && c.forward('\0'))
	return c.src_final();
    }
  }
  c = last_valid;
  return false;
}
#endif

const string bold = "\033[1m";
const string normal = "\033[0m";
const string red = "\033[47;31m";
const string underline = "\033[4m";
const string green = "\033[47;32m";
const string blue = "\033[47;34m";

int main(int argc, const char **argv) {
  const bool verbose = argc == 2 && argv[1] == string("-v");
  vector<string> fields, text;
  int counter = 0, success = 0, line_count = 0;
  for(string line; getline(cin, line); ) {
    ++line_count;
    cut(line, fields);
    if (fields.size() < 3) continue;
    // trim expression
    fields[0] = trim(fields[0]);

    // apply test 4 times: non-anchored, ^left-anchord, right-anchored$ and ^both-anchors$
    for(int version = 0; version < 4; ++version) {
      string exp;
      switch (version) {
      case 0: exp = fields[0]; break;
      case 1: exp = "^" + fields[0]; break;
      case 2: exp = fields[0] + "$"; break;
      default: exp = "^" + fields[0] + "$"; break;
      }
    capturer_type c = build_capturer(exp, USE_HORSPOOL);

    if (verbose) {
      cout << line_count << '\t' << fields[1] << endl << "\t" << bold << exp << normal << endl;
      cout << '\t' << c /*.adaptee()*/ << endl;
    }
    if (c.sink()) {
      cout << line_count << '\t' << fields[1] << endl << "\t" << bold << exp << normal << endl;
      cout << "\tPARSE ERROR\t" << c /*.adaptee()*/.error_message() << " at character " 
	   << c /*.adaptee()*/ .error() << " line " << line_count << endl;
      return 1;
    }

    non_deterministic_capturer_type::state_type i = c.src();
    // for each test:
    for(vector<string>::iterator test = fields.begin() + 2; test < fields.end(); ++test) {
      const string bogus;
      const string reference = trim(test[0]);
      string text_tmp = reference;
      text_tmp.resize(std::remove(text_tmp.begin(), text_tmp.end(), '[') - text_tmp.begin());
      text_tmp.resize(std::remove(text_tmp.begin(), text_tmp.end(), ']') - text_tmp.begin());
      const string text = text_tmp;

      // build reference
      vector<string::const_iterator> reference_captures(c.capture_count(), bogus.end());
      unsigned long position = 0;
      int current_open_capture = 0;
      vector<int> open_capture_stack;
      for(string::const_iterator cc = reference.begin(); cc != reference.end(); ++cc) {
	switch (*cc) {
	case '[' :
	  reference_captures[current_open_capture] = text.begin() + position;
	  open_capture_stack.push_back(current_open_capture);
	  current_open_capture += 2;
	  break;
	case ']' :
	  reference_captures[open_capture_stack.back() + 1] = text.begin() + position;
	  open_capture_stack.pop_back();
	  break;
	default :
	  ++position;
	  break;
	}
      }

      ++counter;
      c = i;
      vector<string::const_iterator> captures(c.capture_count(), bogus.end());
      bool failed = false;
      string::const_iterator first = text.begin();
      if (capture(first, text.end(), c, captures)) {
	bool ok = captures == reference_captures;
	if (!(ok || (captures.size() > reference_captures.size() && 
	    equal(reference_captures.begin(), reference_captures.end(), captures.begin()) &&
	    count(captures.begin() + reference_captures.size(), captures.end(), bogus.end()) ==
		     (int) (captures.size() - reference_captures.size())))) {
	  
// 	  for(vector<string::const_iterator>::const_iterator cap = captures.begin(); cap != captures.end(); ++cap)
// 	    cout << (void*) &**cap << " ";
// 	  cout << endl;

// 	  for(vector<string::const_iterator>::const_iterator cap = configuration_reference.begin(); cap != configuration_reference.end(); ++cap)
// 	    cout << (void*) &**cap << " ";
// 	  cout << endl;

	  if (!verbose)
	    cout << line_count << '\t' << fields[1] << endl << "\t\"" << bold << exp << normal << '"' << endl;
	  cout << '\t' << red << "WRONG CAPTURES (" << reference_captures.size() << ')' << normal;
	  cout << "\t" << green + bold << string(text.begin(), first) << normal << red 
	       << string(first, text.end()) << normal << '\t';
	  display(cout, captures, text);
	  cout << " SHOULD BE ";
	  display(cout, reference_captures, text);
	  cout << "\t" << c /*.adaptee()*/ << '"' << endl;
	  failed = true;
	}
	else {
	  ++success;
	  if (verbose) {
	    cout << '\t' << blue + bold << "SUCCESSFUL MATCH" << normal << '\t';
	    cout << '\t' << green + bold << string(text.begin(), text.end()) << normal << '\t';
	    display(cout, captures, text);
// 	    cout << "\t\tstates " << c.cache().state_count()
// 	    << "\ttransitions " << c.cache().trans_count();
	    cout << endl;
	  }
	}
      }
      else {
	if (!verbose)
	  cout << line_count << '\t' << fields[1] << endl << "\t\"" << bold << exp << normal << '"' << endl;
	cout << '\t' << red << "FAILED TO MATCH" << normal;
	cout << "\t" << green + bold << string(text.begin(), first) << normal << red << string(first, text.end()) << normal;
	cout << "\t\"";
	cout << c /*.adaptee()*/ << '"' << endl;
	failed = true;
      }

      if (failed)
	cout << '\t' << string(70, '_') << endl << endl;
      //      else if (verbose)
      //	cout << endl << endl;
    }
    }
  }
  cout << "success " << success << '/' << counter << " (" << ((double) success / counter) * 100 << "%)" << endl;
  return success == counter ? 0 : 1;
}

