#include <search.h>
#include <alphabet.h>

#include <vector>
#include <string>
#include <iostream>

using namespace std;
using namespace astl;

int main(int argc, const char **argv) {
  if (argc < 2) {
    cerr << "usage: " << argv[0] << " strings..." << endl;
    return 1;
  }

  ios_base::sync_with_stdio(false);
  const string red = "\033[47;31m";
  const string normal = "\033[0m";
  int count = 0;

  multiple_horspool_finder<plain> finder(vector<string>(argv + 1, argv + argc));

#define NORMAL_HORSPOOL

#ifndef NORMAL_HORSPOOL
  string data, line;
  while (getline(cin, line)) {
    data += line;
    data += '\n';
  }
  const char* end = data.c_str() + data.size();
  const char* match = finder.find(data.c_str(), end);
  while (match != end) {
    // cout << end - match << endl;
    // cout << string(line.c_str(), match.first) << red << string(match.first, match.second) << normal 
    //    << match.second << endl;
    match = finder.next(match + 1, end);
    ++count;
  }

#else
  for(string line; getline(cin, line); ) {
    const char* end = line.c_str() + line.size();
    const char* match = finder.find(line.c_str(), end);
    while (match != end) {
      // cout << string(line.c_str(), match.first) << red << string(match.first, match.second) << normal 
      //    << match.second << endl;
      match = finder.next(match + 1, end);
      ++count;
    }
  }
#endif

  cout << "count " << count << endl;
  return 0;
}
